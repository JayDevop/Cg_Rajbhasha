        <div class="footer">
            <div class="float-right">
                <strong></strong>
            </div>
            <div>
                <p>Copyright © <?php echo date('Y'); ?> . All rights reserved by <a href="https://www.chips.gov.in/" target="_blank">CHiPS</a></p>
            </div>
        </div>
           </div>
    </div>
</body>

</html>
