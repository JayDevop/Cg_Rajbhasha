<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-03-17 12:31:23 --> Config Class Initialized
INFO - 2021-03-17 12:31:23 --> Hooks Class Initialized
DEBUG - 2021-03-17 12:31:23 --> UTF-8 Support Enabled
INFO - 2021-03-17 12:31:23 --> Utf8 Class Initialized
INFO - 2021-03-17 12:31:24 --> URI Class Initialized
INFO - 2021-03-17 12:31:24 --> Router Class Initialized
INFO - 2021-03-17 12:31:24 --> Output Class Initialized
INFO - 2021-03-17 12:31:24 --> Security Class Initialized
DEBUG - 2021-03-17 12:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 12:31:24 --> Input Class Initialized
INFO - 2021-03-17 12:31:24 --> Language Class Initialized
ERROR - 2021-03-17 12:31:25 --> 404 Page Not Found: AdminLoginController/admin_login
ERROR - 2021-03-17 12:31:25 --> Severity: Warning --> include(E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 182
ERROR - 2021-03-17 12:31:25 --> Severity: Warning --> include(): Failed opening 'E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_404.php' for inclusion (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 182
INFO - 2021-03-17 12:37:40 --> Config Class Initialized
INFO - 2021-03-17 12:37:40 --> Hooks Class Initialized
DEBUG - 2021-03-17 12:37:40 --> UTF-8 Support Enabled
INFO - 2021-03-17 12:37:40 --> Utf8 Class Initialized
INFO - 2021-03-17 12:37:40 --> URI Class Initialized
INFO - 2021-03-17 12:37:40 --> Router Class Initialized
INFO - 2021-03-17 12:37:40 --> Output Class Initialized
INFO - 2021-03-17 12:37:40 --> Security Class Initialized
DEBUG - 2021-03-17 12:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 12:37:40 --> Input Class Initialized
INFO - 2021-03-17 12:37:40 --> Language Class Initialized
ERROR - 2021-03-17 12:37:40 --> 404 Page Not Found: AdminLoginController/admin_login
ERROR - 2021-03-17 12:37:40 --> Severity: Warning --> include(E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 182
ERROR - 2021-03-17 12:37:40 --> Severity: Warning --> include(): Failed opening 'E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_404.php' for inclusion (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 182
INFO - 2021-03-17 12:44:44 --> Config Class Initialized
INFO - 2021-03-17 12:44:44 --> Hooks Class Initialized
DEBUG - 2021-03-17 12:44:44 --> UTF-8 Support Enabled
INFO - 2021-03-17 12:44:44 --> Utf8 Class Initialized
INFO - 2021-03-17 12:44:44 --> URI Class Initialized
INFO - 2021-03-17 12:44:44 --> Router Class Initialized
INFO - 2021-03-17 12:44:44 --> Output Class Initialized
INFO - 2021-03-17 12:44:44 --> Security Class Initialized
DEBUG - 2021-03-17 12:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 12:44:44 --> Input Class Initialized
INFO - 2021-03-17 12:44:44 --> Language Class Initialized
ERROR - 2021-03-17 12:44:44 --> 404 Page Not Found: AdminLoginController/admin_login
ERROR - 2021-03-17 12:44:44 --> Severity: Warning --> include(E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 182
ERROR - 2021-03-17 12:44:44 --> Severity: Warning --> include(): Failed opening 'E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_404.php' for inclusion (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 182
INFO - 2021-03-17 15:09:10 --> Config Class Initialized
INFO - 2021-03-17 15:09:10 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:09:10 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:09:10 --> Utf8 Class Initialized
INFO - 2021-03-17 15:09:10 --> URI Class Initialized
INFO - 2021-03-17 15:09:10 --> Router Class Initialized
INFO - 2021-03-17 15:09:10 --> Output Class Initialized
INFO - 2021-03-17 15:09:10 --> Security Class Initialized
DEBUG - 2021-03-17 15:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:09:10 --> Input Class Initialized
INFO - 2021-03-17 15:09:10 --> Language Class Initialized
ERROR - 2021-03-17 15:09:10 --> 404 Page Not Found: AdminLoginController/admin_login
ERROR - 2021-03-17 15:09:10 --> Severity: Warning --> include(E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_404.php): Failed to open stream: No such file or directory E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 182
ERROR - 2021-03-17 15:09:10 --> Severity: Warning --> include(): Failed opening 'E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_404.php' for inclusion (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 182
INFO - 2021-03-17 15:12:14 --> Config Class Initialized
INFO - 2021-03-17 15:12:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:12:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:12:14 --> Utf8 Class Initialized
INFO - 2021-03-17 15:12:14 --> URI Class Initialized
DEBUG - 2021-03-17 15:12:14 --> No URI present. Default controller set.
INFO - 2021-03-17 15:12:14 --> Router Class Initialized
INFO - 2021-03-17 15:12:14 --> Output Class Initialized
INFO - 2021-03-17 15:12:14 --> Security Class Initialized
DEBUG - 2021-03-17 15:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:12:14 --> Input Class Initialized
INFO - 2021-03-17 15:12:14 --> Language Class Initialized
INFO - 2021-03-17 15:12:14 --> Loader Class Initialized
INFO - 2021-03-17 15:12:14 --> Helper loaded: url_helper
INFO - 2021-03-17 15:12:14 --> Helper loaded: file_helper
INFO - 2021-03-17 15:12:14 --> Helper loaded: form_helper
INFO - 2021-03-17 15:12:14 --> Helper loaded: text_helper
INFO - 2021-03-17 15:12:14 --> Helper loaded: security_helper
INFO - 2021-03-17 15:12:14 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 15:12:14 --> Database Driver Class Initialized
ERROR - 2021-03-17 15:12:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) E:\xampp\htdocs\RDA_Web\adminpoint\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-03-17 15:12:14 --> Unable to connect to the database
INFO - 2021-03-17 15:12:14 --> Email Class Initialized
DEBUG - 2021-03-17 15:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 15:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 15:12:15 --> Form Validation Class Initialized
INFO - 2021-03-17 15:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 15:12:15 --> Pagination Class Initialized
ERROR - 2021-03-17 15:12:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Admin_model E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Loader.php 344
ERROR - 2021-03-17 15:12:15 --> Severity: Warning --> include(E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 219
ERROR - 2021-03-17 15:12:15 --> Severity: Warning --> include(): Failed opening 'E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_exception.php' for inclusion (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 219
INFO - 2021-03-17 15:16:19 --> Config Class Initialized
INFO - 2021-03-17 15:16:19 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:16:19 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:16:19 --> Utf8 Class Initialized
INFO - 2021-03-17 15:16:19 --> URI Class Initialized
DEBUG - 2021-03-17 15:16:19 --> No URI present. Default controller set.
INFO - 2021-03-17 15:16:19 --> Router Class Initialized
INFO - 2021-03-17 15:16:19 --> Output Class Initialized
INFO - 2021-03-17 15:16:19 --> Security Class Initialized
DEBUG - 2021-03-17 15:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:16:19 --> Input Class Initialized
INFO - 2021-03-17 15:16:19 --> Language Class Initialized
INFO - 2021-03-17 15:16:19 --> Loader Class Initialized
INFO - 2021-03-17 15:16:19 --> Helper loaded: url_helper
INFO - 2021-03-17 15:16:19 --> Helper loaded: file_helper
INFO - 2021-03-17 15:16:19 --> Helper loaded: form_helper
INFO - 2021-03-17 15:16:19 --> Helper loaded: text_helper
INFO - 2021-03-17 15:16:19 --> Helper loaded: security_helper
INFO - 2021-03-17 15:16:19 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 15:16:19 --> Database Driver Class Initialized
ERROR - 2021-03-17 15:16:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) E:\xampp\htdocs\RDA_Web\adminpoint\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-03-17 15:16:19 --> Unable to connect to the database
INFO - 2021-03-17 15:16:19 --> Email Class Initialized
DEBUG - 2021-03-17 15:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 15:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 15:16:19 --> Form Validation Class Initialized
INFO - 2021-03-17 15:16:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 15:16:19 --> Pagination Class Initialized
ERROR - 2021-03-17 15:16:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Admin_model E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Loader.php 344
ERROR - 2021-03-17 15:16:19 --> Severity: Warning --> include(E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 219
ERROR - 2021-03-17 15:16:19 --> Severity: Warning --> include(): Failed opening 'E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_exception.php' for inclusion (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 219
INFO - 2021-03-17 15:18:29 --> Config Class Initialized
INFO - 2021-03-17 15:18:29 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:18:29 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:18:29 --> Utf8 Class Initialized
INFO - 2021-03-17 15:18:29 --> URI Class Initialized
INFO - 2021-03-17 15:18:29 --> Router Class Initialized
INFO - 2021-03-17 15:18:29 --> Output Class Initialized
INFO - 2021-03-17 15:18:29 --> Security Class Initialized
DEBUG - 2021-03-17 15:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:18:29 --> Input Class Initialized
INFO - 2021-03-17 15:18:29 --> Language Class Initialized
INFO - 2021-03-17 15:18:29 --> Loader Class Initialized
INFO - 2021-03-17 15:18:29 --> Helper loaded: url_helper
INFO - 2021-03-17 15:18:29 --> Helper loaded: file_helper
INFO - 2021-03-17 15:18:29 --> Helper loaded: form_helper
INFO - 2021-03-17 15:18:29 --> Helper loaded: text_helper
INFO - 2021-03-17 15:18:29 --> Helper loaded: security_helper
INFO - 2021-03-17 15:18:29 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 15:18:29 --> Database Driver Class Initialized
ERROR - 2021-03-17 15:18:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) E:\xampp\htdocs\RDA_Web\adminpoint\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-03-17 15:18:29 --> Unable to connect to the database
INFO - 2021-03-17 15:18:29 --> Email Class Initialized
DEBUG - 2021-03-17 15:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 15:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 15:18:29 --> Form Validation Class Initialized
INFO - 2021-03-17 15:18:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 15:18:29 --> Pagination Class Initialized
ERROR - 2021-03-17 15:18:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Admin_model E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Loader.php 344
ERROR - 2021-03-17 15:18:30 --> Severity: Warning --> include(E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 219
ERROR - 2021-03-17 15:18:30 --> Severity: Warning --> include(): Failed opening 'E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_exception.php' for inclusion (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 219
INFO - 2021-03-17 15:23:03 --> Config Class Initialized
INFO - 2021-03-17 15:23:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:23:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:23:03 --> Utf8 Class Initialized
INFO - 2021-03-17 15:23:03 --> URI Class Initialized
INFO - 2021-03-17 15:23:03 --> Router Class Initialized
INFO - 2021-03-17 15:23:04 --> Output Class Initialized
INFO - 2021-03-17 15:23:04 --> Security Class Initialized
DEBUG - 2021-03-17 15:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:23:04 --> Input Class Initialized
INFO - 2021-03-17 15:23:04 --> Language Class Initialized
INFO - 2021-03-17 15:23:04 --> Loader Class Initialized
INFO - 2021-03-17 15:23:04 --> Helper loaded: url_helper
INFO - 2021-03-17 15:23:04 --> Helper loaded: file_helper
INFO - 2021-03-17 15:23:04 --> Helper loaded: form_helper
INFO - 2021-03-17 15:23:04 --> Helper loaded: text_helper
INFO - 2021-03-17 15:23:04 --> Helper loaded: security_helper
INFO - 2021-03-17 15:23:04 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 15:23:04 --> Database Driver Class Initialized
ERROR - 2021-03-17 15:23:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) E:\xampp\htdocs\RDA_Web\adminpoint\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-03-17 15:23:04 --> Unable to connect to the database
INFO - 2021-03-17 15:23:04 --> Email Class Initialized
DEBUG - 2021-03-17 15:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 15:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 15:23:04 --> Form Validation Class Initialized
INFO - 2021-03-17 15:23:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 15:23:04 --> Pagination Class Initialized
ERROR - 2021-03-17 15:23:04 --> Severity: error --> Exception: Unable to locate the model you have specified: Admin_model E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Loader.php 344
ERROR - 2021-03-17 15:23:04 --> Severity: Warning --> include(E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 219
ERROR - 2021-03-17 15:23:04 --> Severity: Warning --> include(): Failed opening 'E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_exception.php' for inclusion (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 219
INFO - 2021-03-17 15:23:07 --> Config Class Initialized
INFO - 2021-03-17 15:23:07 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:23:07 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:23:07 --> Utf8 Class Initialized
INFO - 2021-03-17 15:23:07 --> URI Class Initialized
DEBUG - 2021-03-17 15:23:07 --> No URI present. Default controller set.
INFO - 2021-03-17 15:23:07 --> Router Class Initialized
INFO - 2021-03-17 15:23:07 --> Output Class Initialized
INFO - 2021-03-17 15:23:07 --> Security Class Initialized
DEBUG - 2021-03-17 15:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:23:07 --> Input Class Initialized
INFO - 2021-03-17 15:23:07 --> Language Class Initialized
INFO - 2021-03-17 15:23:07 --> Loader Class Initialized
INFO - 2021-03-17 15:23:07 --> Helper loaded: url_helper
INFO - 2021-03-17 15:23:08 --> Helper loaded: file_helper
INFO - 2021-03-17 15:23:08 --> Helper loaded: form_helper
INFO - 2021-03-17 15:23:08 --> Helper loaded: text_helper
INFO - 2021-03-17 15:23:08 --> Helper loaded: security_helper
INFO - 2021-03-17 15:23:08 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 15:23:08 --> Database Driver Class Initialized
ERROR - 2021-03-17 15:23:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) E:\xampp\htdocs\RDA_Web\adminpoint\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-03-17 15:23:08 --> Unable to connect to the database
INFO - 2021-03-17 15:23:08 --> Email Class Initialized
DEBUG - 2021-03-17 15:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 15:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 15:23:08 --> Form Validation Class Initialized
INFO - 2021-03-17 15:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 15:23:08 --> Pagination Class Initialized
ERROR - 2021-03-17 15:23:08 --> Severity: error --> Exception: Unable to locate the model you have specified: Admin_model E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Loader.php 344
ERROR - 2021-03-17 15:23:08 --> Severity: Warning --> include(E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_exception.php): Failed to open stream: No such file or directory E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 219
ERROR - 2021-03-17 15:23:08 --> Severity: Warning --> include(): Failed opening 'E:\xampp\htdocs\RDA_Web\adminpoint\application\views\errors\html\error_exception.php' for inclusion (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\RDA_Web\adminpoint\system\core\Exceptions.php 219
INFO - 2021-03-17 15:24:05 --> Config Class Initialized
INFO - 2021-03-17 15:24:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:24:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:24:05 --> Utf8 Class Initialized
INFO - 2021-03-17 15:24:05 --> URI Class Initialized
DEBUG - 2021-03-17 15:24:05 --> No URI present. Default controller set.
INFO - 2021-03-17 15:24:05 --> Router Class Initialized
INFO - 2021-03-17 15:24:05 --> Output Class Initialized
INFO - 2021-03-17 15:24:05 --> Security Class Initialized
DEBUG - 2021-03-17 15:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:24:05 --> Input Class Initialized
INFO - 2021-03-17 15:24:05 --> Language Class Initialized
INFO - 2021-03-17 15:24:05 --> Loader Class Initialized
INFO - 2021-03-17 15:24:05 --> Helper loaded: url_helper
INFO - 2021-03-17 15:24:05 --> Helper loaded: file_helper
INFO - 2021-03-17 15:24:05 --> Helper loaded: form_helper
INFO - 2021-03-17 15:24:05 --> Helper loaded: text_helper
INFO - 2021-03-17 15:24:05 --> Helper loaded: security_helper
INFO - 2021-03-17 15:24:05 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 15:24:05 --> Database Driver Class Initialized
ERROR - 2021-03-17 15:24:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'buggy' E:\xampp\htdocs\RDA_Web\adminpoint\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-03-17 15:24:05 --> Unable to connect to the database
INFO - 2021-03-17 15:24:05 --> Email Class Initialized
DEBUG - 2021-03-17 15:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 15:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 15:24:05 --> Form Validation Class Initialized
INFO - 2021-03-17 15:24:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 15:24:05 --> Pagination Class Initialized
INFO - 2021-03-17 15:24:06 --> Model Class Initialized
INFO - 2021-03-17 15:24:06 --> Controller Class Initialized
INFO - 2021-03-17 15:24:06 --> Config Class Initialized
INFO - 2021-03-17 15:24:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:24:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:24:06 --> Utf8 Class Initialized
INFO - 2021-03-17 15:24:06 --> URI Class Initialized
INFO - 2021-03-17 15:24:06 --> Router Class Initialized
INFO - 2021-03-17 15:24:06 --> Output Class Initialized
INFO - 2021-03-17 15:24:06 --> Security Class Initialized
DEBUG - 2021-03-17 15:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:24:06 --> Input Class Initialized
INFO - 2021-03-17 15:24:06 --> Language Class Initialized
ERROR - 2021-03-17 15:24:06 --> 404 Page Not Found: Admin-dashboard/index
INFO - 2021-03-17 15:24:11 --> Config Class Initialized
INFO - 2021-03-17 15:24:11 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:24:11 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:24:11 --> Utf8 Class Initialized
INFO - 2021-03-17 15:24:11 --> URI Class Initialized
DEBUG - 2021-03-17 15:24:11 --> No URI present. Default controller set.
INFO - 2021-03-17 15:24:11 --> Router Class Initialized
INFO - 2021-03-17 15:24:11 --> Output Class Initialized
INFO - 2021-03-17 15:24:11 --> Security Class Initialized
DEBUG - 2021-03-17 15:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:24:11 --> Input Class Initialized
INFO - 2021-03-17 15:24:11 --> Language Class Initialized
INFO - 2021-03-17 15:24:11 --> Loader Class Initialized
INFO - 2021-03-17 15:24:11 --> Helper loaded: url_helper
INFO - 2021-03-17 15:24:11 --> Helper loaded: file_helper
INFO - 2021-03-17 15:24:11 --> Helper loaded: form_helper
INFO - 2021-03-17 15:24:11 --> Helper loaded: text_helper
INFO - 2021-03-17 15:24:11 --> Helper loaded: security_helper
INFO - 2021-03-17 15:24:11 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 15:24:11 --> Database Driver Class Initialized
ERROR - 2021-03-17 15:24:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'buggy' E:\xampp\htdocs\RDA_Web\adminpoint\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-03-17 15:24:11 --> Unable to connect to the database
INFO - 2021-03-17 15:24:11 --> Email Class Initialized
DEBUG - 2021-03-17 15:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 15:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 15:24:11 --> Form Validation Class Initialized
INFO - 2021-03-17 15:24:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 15:24:11 --> Pagination Class Initialized
INFO - 2021-03-17 15:24:11 --> Model Class Initialized
INFO - 2021-03-17 15:24:11 --> Controller Class Initialized
INFO - 2021-03-17 15:24:11 --> Config Class Initialized
INFO - 2021-03-17 15:24:11 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:24:11 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:24:11 --> Utf8 Class Initialized
INFO - 2021-03-17 15:24:11 --> URI Class Initialized
INFO - 2021-03-17 15:24:11 --> Router Class Initialized
INFO - 2021-03-17 15:24:11 --> Output Class Initialized
INFO - 2021-03-17 15:24:11 --> Security Class Initialized
DEBUG - 2021-03-17 15:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:24:12 --> Input Class Initialized
INFO - 2021-03-17 15:24:12 --> Language Class Initialized
ERROR - 2021-03-17 15:24:12 --> 404 Page Not Found: Admin-dashboard/index
INFO - 2021-03-17 15:25:13 --> Config Class Initialized
INFO - 2021-03-17 15:25:13 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:25:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:25:13 --> Utf8 Class Initialized
INFO - 2021-03-17 15:25:13 --> URI Class Initialized
DEBUG - 2021-03-17 15:25:13 --> No URI present. Default controller set.
INFO - 2021-03-17 15:25:13 --> Router Class Initialized
INFO - 2021-03-17 15:25:13 --> Output Class Initialized
INFO - 2021-03-17 15:25:13 --> Security Class Initialized
DEBUG - 2021-03-17 15:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:25:13 --> Input Class Initialized
INFO - 2021-03-17 15:25:13 --> Language Class Initialized
INFO - 2021-03-17 15:25:13 --> Loader Class Initialized
INFO - 2021-03-17 15:25:13 --> Helper loaded: url_helper
INFO - 2021-03-17 15:25:13 --> Helper loaded: file_helper
INFO - 2021-03-17 15:25:13 --> Helper loaded: form_helper
INFO - 2021-03-17 15:25:13 --> Helper loaded: text_helper
INFO - 2021-03-17 15:25:13 --> Helper loaded: security_helper
INFO - 2021-03-17 15:25:13 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 15:25:13 --> Database Driver Class Initialized
ERROR - 2021-03-17 15:25:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'buggy' E:\xampp\htdocs\RDA_Web\adminpoint\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-03-17 15:25:13 --> Unable to connect to the database
INFO - 2021-03-17 15:25:13 --> Email Class Initialized
DEBUG - 2021-03-17 15:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 15:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 15:25:13 --> Form Validation Class Initialized
INFO - 2021-03-17 15:25:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 15:25:13 --> Pagination Class Initialized
INFO - 2021-03-17 15:25:13 --> Model Class Initialized
INFO - 2021-03-17 15:25:13 --> Controller Class Initialized
INFO - 2021-03-17 15:25:13 --> Config Class Initialized
INFO - 2021-03-17 15:25:13 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:25:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:25:13 --> Utf8 Class Initialized
INFO - 2021-03-17 15:25:13 --> URI Class Initialized
INFO - 2021-03-17 15:25:13 --> Router Class Initialized
INFO - 2021-03-17 15:25:13 --> Output Class Initialized
INFO - 2021-03-17 15:25:13 --> Security Class Initialized
DEBUG - 2021-03-17 15:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:25:14 --> Input Class Initialized
INFO - 2021-03-17 15:25:14 --> Language Class Initialized
ERROR - 2021-03-17 15:25:14 --> 404 Page Not Found: Admin-dashboard/index
INFO - 2021-03-17 15:25:30 --> Config Class Initialized
INFO - 2021-03-17 15:25:30 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:25:30 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:25:30 --> Utf8 Class Initialized
INFO - 2021-03-17 15:25:30 --> URI Class Initialized
INFO - 2021-03-17 15:25:30 --> Router Class Initialized
INFO - 2021-03-17 15:25:30 --> Output Class Initialized
INFO - 2021-03-17 15:25:30 --> Security Class Initialized
DEBUG - 2021-03-17 15:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:25:30 --> Input Class Initialized
INFO - 2021-03-17 15:25:30 --> Language Class Initialized
ERROR - 2021-03-17 15:25:30 --> 404 Page Not Found: AdminLoginController/admin_login
INFO - 2021-03-17 15:27:08 --> Config Class Initialized
INFO - 2021-03-17 15:27:08 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:27:08 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:27:08 --> Utf8 Class Initialized
INFO - 2021-03-17 15:27:08 --> URI Class Initialized
INFO - 2021-03-17 15:27:08 --> Router Class Initialized
INFO - 2021-03-17 15:27:08 --> Output Class Initialized
INFO - 2021-03-17 15:27:08 --> Security Class Initialized
DEBUG - 2021-03-17 15:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:27:08 --> Input Class Initialized
INFO - 2021-03-17 15:27:08 --> Language Class Initialized
ERROR - 2021-03-17 15:27:08 --> 404 Page Not Found: AdminLoginController/admin_login
INFO - 2021-03-17 15:27:13 --> Config Class Initialized
INFO - 2021-03-17 15:27:13 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:27:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:27:13 --> Utf8 Class Initialized
INFO - 2021-03-17 15:27:13 --> URI Class Initialized
DEBUG - 2021-03-17 15:27:13 --> No URI present. Default controller set.
INFO - 2021-03-17 15:27:13 --> Router Class Initialized
INFO - 2021-03-17 15:27:13 --> Output Class Initialized
INFO - 2021-03-17 15:27:13 --> Security Class Initialized
DEBUG - 2021-03-17 15:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:27:13 --> Input Class Initialized
INFO - 2021-03-17 15:27:13 --> Language Class Initialized
INFO - 2021-03-17 15:27:13 --> Loader Class Initialized
INFO - 2021-03-17 15:27:13 --> Helper loaded: url_helper
INFO - 2021-03-17 15:27:13 --> Helper loaded: file_helper
INFO - 2021-03-17 15:27:13 --> Helper loaded: form_helper
INFO - 2021-03-17 15:27:13 --> Helper loaded: text_helper
INFO - 2021-03-17 15:27:13 --> Helper loaded: security_helper
INFO - 2021-03-17 15:27:13 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 15:27:14 --> Database Driver Class Initialized
ERROR - 2021-03-17 15:27:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'buggy' E:\xampp\htdocs\RDA_Web\adminpoint\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-03-17 15:27:14 --> Unable to connect to the database
INFO - 2021-03-17 15:27:14 --> Email Class Initialized
DEBUG - 2021-03-17 15:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 15:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 15:27:14 --> Form Validation Class Initialized
INFO - 2021-03-17 15:27:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 15:27:14 --> Pagination Class Initialized
INFO - 2021-03-17 15:27:14 --> Model Class Initialized
INFO - 2021-03-17 15:27:14 --> Controller Class Initialized
INFO - 2021-03-17 15:27:14 --> Config Class Initialized
INFO - 2021-03-17 15:27:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:27:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:27:14 --> Utf8 Class Initialized
INFO - 2021-03-17 15:27:14 --> URI Class Initialized
INFO - 2021-03-17 15:27:14 --> Router Class Initialized
INFO - 2021-03-17 15:27:14 --> Output Class Initialized
INFO - 2021-03-17 15:27:14 --> Security Class Initialized
DEBUG - 2021-03-17 15:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:27:14 --> Input Class Initialized
INFO - 2021-03-17 15:27:14 --> Language Class Initialized
ERROR - 2021-03-17 15:27:14 --> 404 Page Not Found: Admin-dashboard/index
INFO - 2021-03-17 15:28:13 --> Config Class Initialized
INFO - 2021-03-17 15:28:13 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:28:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:28:13 --> Utf8 Class Initialized
INFO - 2021-03-17 15:28:13 --> URI Class Initialized
INFO - 2021-03-17 15:28:13 --> Router Class Initialized
INFO - 2021-03-17 15:28:13 --> Output Class Initialized
INFO - 2021-03-17 15:28:13 --> Security Class Initialized
DEBUG - 2021-03-17 15:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:28:13 --> Input Class Initialized
INFO - 2021-03-17 15:28:13 --> Language Class Initialized
INFO - 2021-03-17 15:28:13 --> Loader Class Initialized
INFO - 2021-03-17 15:28:13 --> Helper loaded: url_helper
INFO - 2021-03-17 15:28:13 --> Helper loaded: file_helper
INFO - 2021-03-17 15:28:13 --> Helper loaded: form_helper
INFO - 2021-03-17 15:28:13 --> Helper loaded: text_helper
INFO - 2021-03-17 15:28:13 --> Helper loaded: security_helper
INFO - 2021-03-17 15:28:13 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 15:28:13 --> Database Driver Class Initialized
ERROR - 2021-03-17 15:28:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'buggy' E:\xampp\htdocs\RDA_Web\adminpoint\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-03-17 15:28:13 --> Unable to connect to the database
INFO - 2021-03-17 15:28:13 --> Email Class Initialized
DEBUG - 2021-03-17 15:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 15:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 15:28:13 --> Form Validation Class Initialized
INFO - 2021-03-17 15:28:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 15:28:13 --> Pagination Class Initialized
INFO - 2021-03-17 15:28:13 --> Model Class Initialized
INFO - 2021-03-17 15:28:13 --> Controller Class Initialized
INFO - 2021-03-17 15:28:13 --> Final output sent to browser
DEBUG - 2021-03-17 15:28:13 --> Total execution time: 0.6505
INFO - 2021-03-17 15:29:14 --> Config Class Initialized
INFO - 2021-03-17 15:29:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 15:29:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 15:29:14 --> Utf8 Class Initialized
INFO - 2021-03-17 15:29:14 --> URI Class Initialized
INFO - 2021-03-17 15:29:14 --> Router Class Initialized
INFO - 2021-03-17 15:29:14 --> Output Class Initialized
INFO - 2021-03-17 15:29:14 --> Security Class Initialized
DEBUG - 2021-03-17 15:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 15:29:14 --> Input Class Initialized
INFO - 2021-03-17 15:29:14 --> Language Class Initialized
INFO - 2021-03-17 15:29:14 --> Loader Class Initialized
INFO - 2021-03-17 15:29:14 --> Helper loaded: url_helper
INFO - 2021-03-17 15:29:14 --> Helper loaded: file_helper
INFO - 2021-03-17 15:29:14 --> Helper loaded: form_helper
INFO - 2021-03-17 15:29:14 --> Helper loaded: text_helper
INFO - 2021-03-17 15:29:14 --> Helper loaded: security_helper
INFO - 2021-03-17 15:29:14 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 15:29:14 --> Database Driver Class Initialized
INFO - 2021-03-17 15:29:14 --> Email Class Initialized
DEBUG - 2021-03-17 15:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 15:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 15:29:15 --> Form Validation Class Initialized
INFO - 2021-03-17 15:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 15:29:15 --> Pagination Class Initialized
INFO - 2021-03-17 15:29:15 --> Model Class Initialized
INFO - 2021-03-17 15:29:15 --> Controller Class Initialized
INFO - 2021-03-17 15:29:15 --> Final output sent to browser
DEBUG - 2021-03-17 15:29:15 --> Total execution time: 0.4991
INFO - 2021-03-17 16:59:16 --> Config Class Initialized
INFO - 2021-03-17 16:59:16 --> Hooks Class Initialized
DEBUG - 2021-03-17 16:59:16 --> UTF-8 Support Enabled
INFO - 2021-03-17 16:59:16 --> Utf8 Class Initialized
INFO - 2021-03-17 16:59:16 --> URI Class Initialized
INFO - 2021-03-17 16:59:16 --> Router Class Initialized
INFO - 2021-03-17 16:59:16 --> Output Class Initialized
INFO - 2021-03-17 16:59:16 --> Security Class Initialized
DEBUG - 2021-03-17 16:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 16:59:16 --> Input Class Initialized
INFO - 2021-03-17 16:59:16 --> Language Class Initialized
INFO - 2021-03-17 16:59:16 --> Loader Class Initialized
INFO - 2021-03-17 16:59:16 --> Helper loaded: url_helper
INFO - 2021-03-17 16:59:16 --> Helper loaded: file_helper
INFO - 2021-03-17 16:59:16 --> Helper loaded: form_helper
INFO - 2021-03-17 16:59:16 --> Helper loaded: text_helper
INFO - 2021-03-17 16:59:16 --> Helper loaded: security_helper
INFO - 2021-03-17 16:59:16 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 16:59:16 --> Database Driver Class Initialized
INFO - 2021-03-17 16:59:16 --> Email Class Initialized
DEBUG - 2021-03-17 16:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 16:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 16:59:16 --> Form Validation Class Initialized
INFO - 2021-03-17 16:59:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 16:59:16 --> Pagination Class Initialized
INFO - 2021-03-17 16:59:16 --> Model Class Initialized
INFO - 2021-03-17 16:59:16 --> Controller Class Initialized
INFO - 2021-03-17 16:59:16 --> Model Class Initialized
INFO - 2021-03-17 17:00:58 --> Config Class Initialized
INFO - 2021-03-17 17:00:58 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:00:58 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:00:58 --> Utf8 Class Initialized
INFO - 2021-03-17 17:00:58 --> URI Class Initialized
INFO - 2021-03-17 17:00:58 --> Router Class Initialized
INFO - 2021-03-17 17:00:58 --> Output Class Initialized
INFO - 2021-03-17 17:00:58 --> Security Class Initialized
DEBUG - 2021-03-17 17:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:00:58 --> Input Class Initialized
INFO - 2021-03-17 17:00:58 --> Language Class Initialized
INFO - 2021-03-17 17:00:58 --> Loader Class Initialized
INFO - 2021-03-17 17:00:59 --> Helper loaded: url_helper
INFO - 2021-03-17 17:00:59 --> Helper loaded: file_helper
INFO - 2021-03-17 17:00:59 --> Helper loaded: form_helper
INFO - 2021-03-17 17:00:59 --> Helper loaded: text_helper
INFO - 2021-03-17 17:00:59 --> Helper loaded: security_helper
INFO - 2021-03-17 17:00:59 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:00:59 --> Database Driver Class Initialized
INFO - 2021-03-17 17:00:59 --> Email Class Initialized
DEBUG - 2021-03-17 17:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:00:59 --> Form Validation Class Initialized
INFO - 2021-03-17 17:00:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:00:59 --> Pagination Class Initialized
INFO - 2021-03-17 17:00:59 --> Model Class Initialized
INFO - 2021-03-17 17:00:59 --> Controller Class Initialized
INFO - 2021-03-17 17:00:59 --> Model Class Initialized
INFO - 2021-03-17 17:01:41 --> Config Class Initialized
INFO - 2021-03-17 17:01:41 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:01:41 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:01:41 --> Utf8 Class Initialized
INFO - 2021-03-17 17:01:41 --> URI Class Initialized
INFO - 2021-03-17 17:01:41 --> Router Class Initialized
INFO - 2021-03-17 17:01:41 --> Output Class Initialized
INFO - 2021-03-17 17:01:41 --> Security Class Initialized
DEBUG - 2021-03-17 17:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:01:41 --> Input Class Initialized
INFO - 2021-03-17 17:01:41 --> Language Class Initialized
INFO - 2021-03-17 17:01:41 --> Loader Class Initialized
INFO - 2021-03-17 17:01:41 --> Helper loaded: url_helper
INFO - 2021-03-17 17:01:41 --> Helper loaded: file_helper
INFO - 2021-03-17 17:01:41 --> Helper loaded: form_helper
INFO - 2021-03-17 17:01:41 --> Helper loaded: text_helper
INFO - 2021-03-17 17:01:41 --> Helper loaded: security_helper
INFO - 2021-03-17 17:01:41 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:01:41 --> Database Driver Class Initialized
INFO - 2021-03-17 17:01:42 --> Email Class Initialized
DEBUG - 2021-03-17 17:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:01:42 --> Form Validation Class Initialized
INFO - 2021-03-17 17:01:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:01:42 --> Pagination Class Initialized
INFO - 2021-03-17 17:01:42 --> Model Class Initialized
INFO - 2021-03-17 17:01:42 --> Controller Class Initialized
INFO - 2021-03-17 17:01:42 --> Model Class Initialized
INFO - 2021-03-17 17:02:05 --> Config Class Initialized
INFO - 2021-03-17 17:02:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:05 --> URI Class Initialized
INFO - 2021-03-17 17:02:05 --> Router Class Initialized
INFO - 2021-03-17 17:02:05 --> Output Class Initialized
INFO - 2021-03-17 17:02:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:05 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> Loader Class Initialized
INFO - 2021-03-17 17:02:06 --> Helper loaded: url_helper
INFO - 2021-03-17 17:02:06 --> Helper loaded: file_helper
INFO - 2021-03-17 17:02:06 --> Helper loaded: form_helper
INFO - 2021-03-17 17:02:06 --> Helper loaded: text_helper
INFO - 2021-03-17 17:02:06 --> Helper loaded: security_helper
INFO - 2021-03-17 17:02:06 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:02:06 --> Database Driver Class Initialized
INFO - 2021-03-17 17:02:06 --> Email Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:02:06 --> Form Validation Class Initialized
INFO - 2021-03-17 17:02:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:02:06 --> Pagination Class Initialized
INFO - 2021-03-17 17:02:06 --> Model Class Initialized
INFO - 2021-03-17 17:02:06 --> Controller Class Initialized
INFO - 2021-03-17 17:02:06 --> Model Class Initialized
INFO - 2021-03-17 17:02:06 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:02:06 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:02:06 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:02:06 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:02:06 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:02:06 --> Final output sent to browser
DEBUG - 2021-03-17 17:02:06 --> Total execution time: 0.6582
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/font-awesome
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/css
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/css
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/img
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Img/profile.jpg
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Img/a7.jpg
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Img/a4.jpg
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> Config Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Hooks Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Img/a2.jpg
DEBUG - 2021-03-17 17:02:06 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:06 --> Language Class Initialized
ERROR - 2021-03-17 17:02:06 --> 404 Page Not Found: Img/a5.jpg
INFO - 2021-03-17 17:02:06 --> URI Class Initialized
INFO - 2021-03-17 17:02:06 --> Router Class Initialized
INFO - 2021-03-17 17:02:06 --> Output Class Initialized
INFO - 2021-03-17 17:02:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:06 --> Input Class Initialized
INFO - 2021-03-17 17:02:07 --> Language Class Initialized
ERROR - 2021-03-17 17:02:07 --> 404 Page Not Found: Img/a3.jpg
INFO - 2021-03-17 17:02:07 --> Config Class Initialized
INFO - 2021-03-17 17:02:07 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:07 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:07 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:07 --> URI Class Initialized
INFO - 2021-03-17 17:02:07 --> Router Class Initialized
INFO - 2021-03-17 17:02:07 --> Output Class Initialized
INFO - 2021-03-17 17:02:07 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:07 --> Input Class Initialized
INFO - 2021-03-17 17:02:07 --> Language Class Initialized
ERROR - 2021-03-17 17:02:07 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:07 --> Config Class Initialized
INFO - 2021-03-17 17:02:07 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:07 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:07 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:07 --> URI Class Initialized
INFO - 2021-03-17 17:02:07 --> Router Class Initialized
INFO - 2021-03-17 17:02:07 --> Output Class Initialized
INFO - 2021-03-17 17:02:07 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:07 --> Input Class Initialized
INFO - 2021-03-17 17:02:07 --> Language Class Initialized
ERROR - 2021-03-17 17:02:07 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:07 --> Config Class Initialized
INFO - 2021-03-17 17:02:07 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:07 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:07 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:07 --> URI Class Initialized
INFO - 2021-03-17 17:02:07 --> Router Class Initialized
INFO - 2021-03-17 17:02:07 --> Output Class Initialized
INFO - 2021-03-17 17:02:07 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:07 --> Input Class Initialized
INFO - 2021-03-17 17:02:07 --> Language Class Initialized
ERROR - 2021-03-17 17:02:07 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:07 --> Config Class Initialized
INFO - 2021-03-17 17:02:07 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:07 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:07 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:07 --> URI Class Initialized
INFO - 2021-03-17 17:02:07 --> Router Class Initialized
INFO - 2021-03-17 17:02:07 --> Output Class Initialized
INFO - 2021-03-17 17:02:07 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:07 --> Input Class Initialized
INFO - 2021-03-17 17:02:07 --> Language Class Initialized
ERROR - 2021-03-17 17:02:07 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:07 --> Config Class Initialized
INFO - 2021-03-17 17:02:07 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:07 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:07 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:07 --> URI Class Initialized
INFO - 2021-03-17 17:02:07 --> Router Class Initialized
INFO - 2021-03-17 17:02:07 --> Output Class Initialized
INFO - 2021-03-17 17:02:07 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:08 --> Input Class Initialized
INFO - 2021-03-17 17:02:08 --> Language Class Initialized
ERROR - 2021-03-17 17:02:08 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:08 --> Config Class Initialized
INFO - 2021-03-17 17:02:08 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:08 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:08 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:08 --> URI Class Initialized
INFO - 2021-03-17 17:02:08 --> Router Class Initialized
INFO - 2021-03-17 17:02:08 --> Output Class Initialized
INFO - 2021-03-17 17:02:08 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:08 --> Input Class Initialized
INFO - 2021-03-17 17:02:08 --> Language Class Initialized
ERROR - 2021-03-17 17:02:08 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:08 --> Config Class Initialized
INFO - 2021-03-17 17:02:08 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:08 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:08 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:08 --> URI Class Initialized
INFO - 2021-03-17 17:02:08 --> Router Class Initialized
INFO - 2021-03-17 17:02:08 --> Output Class Initialized
INFO - 2021-03-17 17:02:08 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:08 --> Input Class Initialized
INFO - 2021-03-17 17:02:08 --> Language Class Initialized
ERROR - 2021-03-17 17:02:08 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:08 --> Config Class Initialized
INFO - 2021-03-17 17:02:08 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:08 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:08 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:08 --> URI Class Initialized
INFO - 2021-03-17 17:02:08 --> Router Class Initialized
INFO - 2021-03-17 17:02:08 --> Output Class Initialized
INFO - 2021-03-17 17:02:08 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:08 --> Input Class Initialized
INFO - 2021-03-17 17:02:08 --> Language Class Initialized
ERROR - 2021-03-17 17:02:08 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:08 --> Config Class Initialized
INFO - 2021-03-17 17:02:08 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:08 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:08 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:08 --> URI Class Initialized
INFO - 2021-03-17 17:02:08 --> Router Class Initialized
INFO - 2021-03-17 17:02:08 --> Output Class Initialized
INFO - 2021-03-17 17:02:08 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:08 --> Input Class Initialized
INFO - 2021-03-17 17:02:08 --> Language Class Initialized
ERROR - 2021-03-17 17:02:09 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:09 --> Config Class Initialized
INFO - 2021-03-17 17:02:09 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:09 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:09 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:09 --> URI Class Initialized
INFO - 2021-03-17 17:02:09 --> Router Class Initialized
INFO - 2021-03-17 17:02:09 --> Output Class Initialized
INFO - 2021-03-17 17:02:09 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:09 --> Input Class Initialized
INFO - 2021-03-17 17:02:09 --> Language Class Initialized
ERROR - 2021-03-17 17:02:09 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:09 --> Config Class Initialized
INFO - 2021-03-17 17:02:09 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:09 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:09 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:09 --> URI Class Initialized
INFO - 2021-03-17 17:02:09 --> Router Class Initialized
INFO - 2021-03-17 17:02:09 --> Output Class Initialized
INFO - 2021-03-17 17:02:09 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:09 --> Input Class Initialized
INFO - 2021-03-17 17:02:09 --> Language Class Initialized
ERROR - 2021-03-17 17:02:09 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:09 --> Config Class Initialized
INFO - 2021-03-17 17:02:09 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:09 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:09 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:09 --> URI Class Initialized
INFO - 2021-03-17 17:02:09 --> Router Class Initialized
INFO - 2021-03-17 17:02:09 --> Output Class Initialized
INFO - 2021-03-17 17:02:09 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:09 --> Input Class Initialized
INFO - 2021-03-17 17:02:09 --> Language Class Initialized
ERROR - 2021-03-17 17:02:09 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:09 --> Config Class Initialized
INFO - 2021-03-17 17:02:09 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:09 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:09 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:09 --> URI Class Initialized
INFO - 2021-03-17 17:02:09 --> Router Class Initialized
INFO - 2021-03-17 17:02:09 --> Output Class Initialized
INFO - 2021-03-17 17:02:09 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:09 --> Input Class Initialized
INFO - 2021-03-17 17:02:09 --> Language Class Initialized
ERROR - 2021-03-17 17:02:09 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:09 --> Config Class Initialized
INFO - 2021-03-17 17:02:09 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:09 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:09 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:09 --> URI Class Initialized
INFO - 2021-03-17 17:02:10 --> Router Class Initialized
INFO - 2021-03-17 17:02:10 --> Output Class Initialized
INFO - 2021-03-17 17:02:10 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:10 --> Input Class Initialized
INFO - 2021-03-17 17:02:10 --> Language Class Initialized
ERROR - 2021-03-17 17:02:10 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:10 --> Config Class Initialized
INFO - 2021-03-17 17:02:10 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:10 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:10 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:10 --> URI Class Initialized
INFO - 2021-03-17 17:02:10 --> Router Class Initialized
INFO - 2021-03-17 17:02:10 --> Output Class Initialized
INFO - 2021-03-17 17:02:10 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:10 --> Input Class Initialized
INFO - 2021-03-17 17:02:10 --> Language Class Initialized
ERROR - 2021-03-17 17:02:10 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:10 --> Config Class Initialized
INFO - 2021-03-17 17:02:10 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:10 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:10 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:10 --> URI Class Initialized
INFO - 2021-03-17 17:02:10 --> Router Class Initialized
INFO - 2021-03-17 17:02:10 --> Output Class Initialized
INFO - 2021-03-17 17:02:10 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:10 --> Input Class Initialized
INFO - 2021-03-17 17:02:10 --> Language Class Initialized
ERROR - 2021-03-17 17:02:10 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:10 --> Config Class Initialized
INFO - 2021-03-17 17:02:10 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:10 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:10 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:10 --> URI Class Initialized
INFO - 2021-03-17 17:02:10 --> Router Class Initialized
INFO - 2021-03-17 17:02:10 --> Output Class Initialized
INFO - 2021-03-17 17:02:10 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:10 --> Input Class Initialized
INFO - 2021-03-17 17:02:10 --> Language Class Initialized
ERROR - 2021-03-17 17:02:10 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:02:10 --> Config Class Initialized
INFO - 2021-03-17 17:02:10 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:02:10 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:02:10 --> Utf8 Class Initialized
INFO - 2021-03-17 17:02:10 --> URI Class Initialized
INFO - 2021-03-17 17:02:10 --> Router Class Initialized
INFO - 2021-03-17 17:02:10 --> Output Class Initialized
INFO - 2021-03-17 17:02:10 --> Security Class Initialized
DEBUG - 2021-03-17 17:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:02:11 --> Input Class Initialized
INFO - 2021-03-17 17:02:11 --> Language Class Initialized
ERROR - 2021-03-17 17:02:11 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:12 --> Config Class Initialized
INFO - 2021-03-17 17:03:12 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:12 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:12 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:12 --> URI Class Initialized
INFO - 2021-03-17 17:03:12 --> Router Class Initialized
INFO - 2021-03-17 17:03:12 --> Output Class Initialized
INFO - 2021-03-17 17:03:12 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:12 --> Input Class Initialized
INFO - 2021-03-17 17:03:12 --> Language Class Initialized
INFO - 2021-03-17 17:03:12 --> Loader Class Initialized
INFO - 2021-03-17 17:03:12 --> Helper loaded: url_helper
INFO - 2021-03-17 17:03:12 --> Helper loaded: file_helper
INFO - 2021-03-17 17:03:12 --> Helper loaded: form_helper
INFO - 2021-03-17 17:03:12 --> Helper loaded: text_helper
INFO - 2021-03-17 17:03:12 --> Helper loaded: security_helper
INFO - 2021-03-17 17:03:12 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:03:12 --> Database Driver Class Initialized
INFO - 2021-03-17 17:03:12 --> Email Class Initialized
DEBUG - 2021-03-17 17:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:03:13 --> Form Validation Class Initialized
INFO - 2021-03-17 17:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:03:13 --> Pagination Class Initialized
INFO - 2021-03-17 17:03:13 --> Model Class Initialized
INFO - 2021-03-17 17:03:13 --> Controller Class Initialized
INFO - 2021-03-17 17:03:13 --> Model Class Initialized
INFO - 2021-03-17 17:03:13 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:03:13 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:03:13 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:03:13 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:03:13 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:03:13 --> Final output sent to browser
DEBUG - 2021-03-17 17:03:13 --> Total execution time: 0.6307
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/css
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/font-awesome
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/css
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/img
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Img/a7.jpg
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Img/a4.jpg
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Img/profile.jpg
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Img/a2.jpg
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Img/a5.jpg
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Config Class Initialized
INFO - 2021-03-17 17:03:13 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:13 --> Language Class Initialized
ERROR - 2021-03-17 17:03:13 --> 404 Page Not Found: Img/a3.jpg
INFO - 2021-03-17 17:03:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:13 --> URI Class Initialized
INFO - 2021-03-17 17:03:13 --> Router Class Initialized
INFO - 2021-03-17 17:03:13 --> Output Class Initialized
INFO - 2021-03-17 17:03:13 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:13 --> Input Class Initialized
INFO - 2021-03-17 17:03:14 --> Language Class Initialized
ERROR - 2021-03-17 17:03:14 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:14 --> Config Class Initialized
INFO - 2021-03-17 17:03:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:14 --> URI Class Initialized
INFO - 2021-03-17 17:03:14 --> Router Class Initialized
INFO - 2021-03-17 17:03:14 --> Output Class Initialized
INFO - 2021-03-17 17:03:14 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:14 --> Input Class Initialized
INFO - 2021-03-17 17:03:14 --> Language Class Initialized
ERROR - 2021-03-17 17:03:14 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:14 --> Config Class Initialized
INFO - 2021-03-17 17:03:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:14 --> URI Class Initialized
INFO - 2021-03-17 17:03:14 --> Router Class Initialized
INFO - 2021-03-17 17:03:14 --> Output Class Initialized
INFO - 2021-03-17 17:03:14 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:14 --> Input Class Initialized
INFO - 2021-03-17 17:03:14 --> Language Class Initialized
ERROR - 2021-03-17 17:03:14 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:14 --> Config Class Initialized
INFO - 2021-03-17 17:03:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:14 --> URI Class Initialized
INFO - 2021-03-17 17:03:14 --> Router Class Initialized
INFO - 2021-03-17 17:03:14 --> Output Class Initialized
INFO - 2021-03-17 17:03:14 --> Config Class Initialized
INFO - 2021-03-17 17:03:14 --> Config Class Initialized
INFO - 2021-03-17 17:03:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:14 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:03:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:14 --> URI Class Initialized
INFO - 2021-03-17 17:03:14 --> URI Class Initialized
INFO - 2021-03-17 17:03:14 --> Config Class Initialized
INFO - 2021-03-17 17:03:14 --> Router Class Initialized
INFO - 2021-03-17 17:03:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:14 --> Router Class Initialized
INFO - 2021-03-17 17:03:14 --> Config Class Initialized
INFO - 2021-03-17 17:03:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:14 --> Config Class Initialized
INFO - 2021-03-17 17:03:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:03:14 --> Output Class Initialized
INFO - 2021-03-17 17:03:14 --> Output Class Initialized
DEBUG - 2021-03-17 17:03:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:14 --> Security Class Initialized
INFO - 2021-03-17 17:03:14 --> Security Class Initialized
INFO - 2021-03-17 17:03:14 --> URI Class Initialized
DEBUG - 2021-03-17 17:03:14 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:03:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:14 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:14 --> Input Class Initialized
INFO - 2021-03-17 17:03:14 --> Router Class Initialized
INFO - 2021-03-17 17:03:14 --> Input Class Initialized
INFO - 2021-03-17 17:03:14 --> URI Class Initialized
INFO - 2021-03-17 17:03:14 --> Language Class Initialized
INFO - 2021-03-17 17:03:14 --> URI Class Initialized
INFO - 2021-03-17 17:03:14 --> Language Class Initialized
INFO - 2021-03-17 17:03:14 --> Router Class Initialized
INFO - 2021-03-17 17:03:14 --> Output Class Initialized
ERROR - 2021-03-17 17:03:14 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:03:14 --> Router Class Initialized
ERROR - 2021-03-17 17:03:14 --> 404 Page Not Found: Adminassets/font-awesome
INFO - 2021-03-17 17:03:14 --> Security Class Initialized
INFO - 2021-03-17 17:03:14 --> Output Class Initialized
INFO - 2021-03-17 17:03:14 --> Output Class Initialized
DEBUG - 2021-03-17 17:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:14 --> Input Class Initialized
INFO - 2021-03-17 17:03:14 --> Security Class Initialized
INFO - 2021-03-17 17:03:14 --> Security Class Initialized
INFO - 2021-03-17 17:03:14 --> Language Class Initialized
DEBUG - 2021-03-17 17:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:14 --> Input Class Initialized
INFO - 2021-03-17 17:03:14 --> Input Class Initialized
ERROR - 2021-03-17 17:03:14 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:03:14 --> Language Class Initialized
INFO - 2021-03-17 17:03:14 --> Language Class Initialized
ERROR - 2021-03-17 17:03:14 --> 404 Page Not Found: Adminassets/css
ERROR - 2021-03-17 17:03:14 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:14 --> Security Class Initialized
INFO - 2021-03-17 17:03:14 --> Config Class Initialized
INFO - 2021-03-17 17:03:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:14 --> URI Class Initialized
INFO - 2021-03-17 17:03:14 --> Router Class Initialized
INFO - 2021-03-17 17:03:14 --> Output Class Initialized
INFO - 2021-03-17 17:03:14 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:14 --> Input Class Initialized
INFO - 2021-03-17 17:03:14 --> Language Class Initialized
ERROR - 2021-03-17 17:03:14 --> 404 Page Not Found: Adminassets/css
DEBUG - 2021-03-17 17:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:14 --> Input Class Initialized
INFO - 2021-03-17 17:03:15 --> Language Class Initialized
ERROR - 2021-03-17 17:03:15 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:15 --> Config Class Initialized
INFO - 2021-03-17 17:03:15 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:15 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:15 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:15 --> URI Class Initialized
INFO - 2021-03-17 17:03:15 --> Router Class Initialized
INFO - 2021-03-17 17:03:15 --> Output Class Initialized
INFO - 2021-03-17 17:03:15 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:15 --> Input Class Initialized
INFO - 2021-03-17 17:03:15 --> Language Class Initialized
ERROR - 2021-03-17 17:03:15 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:15 --> Config Class Initialized
INFO - 2021-03-17 17:03:15 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:15 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:15 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:15 --> URI Class Initialized
INFO - 2021-03-17 17:03:15 --> Router Class Initialized
INFO - 2021-03-17 17:03:15 --> Output Class Initialized
INFO - 2021-03-17 17:03:15 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:15 --> Input Class Initialized
INFO - 2021-03-17 17:03:15 --> Language Class Initialized
ERROR - 2021-03-17 17:03:15 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:15 --> Config Class Initialized
INFO - 2021-03-17 17:03:15 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:15 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:15 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:15 --> URI Class Initialized
INFO - 2021-03-17 17:03:15 --> Router Class Initialized
INFO - 2021-03-17 17:03:15 --> Output Class Initialized
INFO - 2021-03-17 17:03:15 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:15 --> Input Class Initialized
INFO - 2021-03-17 17:03:15 --> Language Class Initialized
ERROR - 2021-03-17 17:03:15 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:15 --> Config Class Initialized
INFO - 2021-03-17 17:03:15 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:15 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:16 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:16 --> URI Class Initialized
INFO - 2021-03-17 17:03:16 --> Router Class Initialized
INFO - 2021-03-17 17:03:16 --> Output Class Initialized
INFO - 2021-03-17 17:03:16 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:16 --> Input Class Initialized
INFO - 2021-03-17 17:03:16 --> Language Class Initialized
ERROR - 2021-03-17 17:03:16 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:16 --> Config Class Initialized
INFO - 2021-03-17 17:03:16 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:16 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:16 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:16 --> URI Class Initialized
INFO - 2021-03-17 17:03:16 --> Router Class Initialized
INFO - 2021-03-17 17:03:16 --> Output Class Initialized
INFO - 2021-03-17 17:03:16 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:16 --> Input Class Initialized
INFO - 2021-03-17 17:03:16 --> Language Class Initialized
ERROR - 2021-03-17 17:03:16 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:16 --> Config Class Initialized
INFO - 2021-03-17 17:03:16 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:16 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:16 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:16 --> URI Class Initialized
INFO - 2021-03-17 17:03:16 --> Router Class Initialized
INFO - 2021-03-17 17:03:16 --> Output Class Initialized
INFO - 2021-03-17 17:03:16 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:16 --> Input Class Initialized
INFO - 2021-03-17 17:03:16 --> Language Class Initialized
ERROR - 2021-03-17 17:03:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:17 --> Config Class Initialized
INFO - 2021-03-17 17:03:17 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:17 --> URI Class Initialized
INFO - 2021-03-17 17:03:17 --> Router Class Initialized
INFO - 2021-03-17 17:03:17 --> Output Class Initialized
INFO - 2021-03-17 17:03:17 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:17 --> Input Class Initialized
INFO - 2021-03-17 17:03:17 --> Language Class Initialized
ERROR - 2021-03-17 17:03:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:17 --> Config Class Initialized
INFO - 2021-03-17 17:03:17 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:17 --> URI Class Initialized
INFO - 2021-03-17 17:03:17 --> Router Class Initialized
INFO - 2021-03-17 17:03:17 --> Output Class Initialized
INFO - 2021-03-17 17:03:17 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:17 --> Input Class Initialized
INFO - 2021-03-17 17:03:17 --> Language Class Initialized
ERROR - 2021-03-17 17:03:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:17 --> Config Class Initialized
INFO - 2021-03-17 17:03:17 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:17 --> URI Class Initialized
INFO - 2021-03-17 17:03:17 --> Router Class Initialized
INFO - 2021-03-17 17:03:17 --> Output Class Initialized
INFO - 2021-03-17 17:03:17 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:17 --> Input Class Initialized
INFO - 2021-03-17 17:03:17 --> Language Class Initialized
ERROR - 2021-03-17 17:03:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:17 --> Config Class Initialized
INFO - 2021-03-17 17:03:18 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:18 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:18 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:18 --> URI Class Initialized
INFO - 2021-03-17 17:03:18 --> Router Class Initialized
INFO - 2021-03-17 17:03:18 --> Output Class Initialized
INFO - 2021-03-17 17:03:18 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:18 --> Input Class Initialized
INFO - 2021-03-17 17:03:18 --> Language Class Initialized
ERROR - 2021-03-17 17:03:18 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:18 --> Config Class Initialized
INFO - 2021-03-17 17:03:18 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:18 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:18 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:18 --> URI Class Initialized
INFO - 2021-03-17 17:03:18 --> Router Class Initialized
INFO - 2021-03-17 17:03:18 --> Output Class Initialized
INFO - 2021-03-17 17:03:18 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:18 --> Input Class Initialized
INFO - 2021-03-17 17:03:18 --> Language Class Initialized
ERROR - 2021-03-17 17:03:18 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:18 --> Config Class Initialized
INFO - 2021-03-17 17:03:18 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:18 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:18 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:18 --> URI Class Initialized
INFO - 2021-03-17 17:03:18 --> Router Class Initialized
INFO - 2021-03-17 17:03:18 --> Output Class Initialized
INFO - 2021-03-17 17:03:18 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:18 --> Input Class Initialized
INFO - 2021-03-17 17:03:18 --> Language Class Initialized
ERROR - 2021-03-17 17:03:18 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:03:19 --> Config Class Initialized
INFO - 2021-03-17 17:03:19 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:03:19 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:03:19 --> Utf8 Class Initialized
INFO - 2021-03-17 17:03:19 --> URI Class Initialized
INFO - 2021-03-17 17:03:19 --> Router Class Initialized
INFO - 2021-03-17 17:03:19 --> Output Class Initialized
INFO - 2021-03-17 17:03:19 --> Security Class Initialized
DEBUG - 2021-03-17 17:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:03:19 --> Input Class Initialized
INFO - 2021-03-17 17:03:19 --> Language Class Initialized
ERROR - 2021-03-17 17:03:19 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:19 --> Config Class Initialized
INFO - 2021-03-17 17:04:19 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:19 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:19 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:19 --> URI Class Initialized
INFO - 2021-03-17 17:04:19 --> Router Class Initialized
INFO - 2021-03-17 17:04:19 --> Output Class Initialized
INFO - 2021-03-17 17:04:19 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:19 --> Input Class Initialized
INFO - 2021-03-17 17:04:19 --> Language Class Initialized
INFO - 2021-03-17 17:04:19 --> Loader Class Initialized
INFO - 2021-03-17 17:04:19 --> Helper loaded: url_helper
INFO - 2021-03-17 17:04:19 --> Helper loaded: file_helper
INFO - 2021-03-17 17:04:19 --> Helper loaded: form_helper
INFO - 2021-03-17 17:04:19 --> Helper loaded: text_helper
INFO - 2021-03-17 17:04:19 --> Helper loaded: security_helper
INFO - 2021-03-17 17:04:19 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:04:19 --> Database Driver Class Initialized
INFO - 2021-03-17 17:04:19 --> Email Class Initialized
DEBUG - 2021-03-17 17:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:04:19 --> Form Validation Class Initialized
INFO - 2021-03-17 17:04:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:04:19 --> Pagination Class Initialized
INFO - 2021-03-17 17:04:19 --> Model Class Initialized
INFO - 2021-03-17 17:04:19 --> Controller Class Initialized
INFO - 2021-03-17 17:04:19 --> Model Class Initialized
INFO - 2021-03-17 17:04:19 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:04:20 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:04:20 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:04:20 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:04:20 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:04:20 --> Final output sent to browser
DEBUG - 2021-03-17 17:04:20 --> Total execution time: 0.7235
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/css
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/font-awesome
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Img/profile.jpg
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Img/a7.jpg
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Img/a4.jpg
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/img
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/css
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Img/a3.jpg
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Img/a5.jpg
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Img/a2.jpg
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:20 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:20 --> Input Class Initialized
INFO - 2021-03-17 17:04:20 --> Language Class Initialized
ERROR - 2021-03-17 17:04:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:20 --> Config Class Initialized
INFO - 2021-03-17 17:04:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:20 --> URI Class Initialized
INFO - 2021-03-17 17:04:20 --> Router Class Initialized
INFO - 2021-03-17 17:04:20 --> Output Class Initialized
INFO - 2021-03-17 17:04:21 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:21 --> Input Class Initialized
INFO - 2021-03-17 17:04:21 --> Language Class Initialized
ERROR - 2021-03-17 17:04:21 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:21 --> Config Class Initialized
INFO - 2021-03-17 17:04:21 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:21 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:21 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:21 --> URI Class Initialized
INFO - 2021-03-17 17:04:21 --> Router Class Initialized
INFO - 2021-03-17 17:04:21 --> Output Class Initialized
INFO - 2021-03-17 17:04:21 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:21 --> Input Class Initialized
INFO - 2021-03-17 17:04:21 --> Language Class Initialized
ERROR - 2021-03-17 17:04:21 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:21 --> Config Class Initialized
INFO - 2021-03-17 17:04:21 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:21 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:21 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:21 --> URI Class Initialized
INFO - 2021-03-17 17:04:21 --> Router Class Initialized
INFO - 2021-03-17 17:04:21 --> Output Class Initialized
INFO - 2021-03-17 17:04:21 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:21 --> Input Class Initialized
INFO - 2021-03-17 17:04:21 --> Language Class Initialized
ERROR - 2021-03-17 17:04:21 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:22 --> Config Class Initialized
INFO - 2021-03-17 17:04:22 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:22 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:22 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:22 --> URI Class Initialized
INFO - 2021-03-17 17:04:22 --> Router Class Initialized
INFO - 2021-03-17 17:04:22 --> Output Class Initialized
INFO - 2021-03-17 17:04:22 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:22 --> Input Class Initialized
INFO - 2021-03-17 17:04:22 --> Language Class Initialized
ERROR - 2021-03-17 17:04:22 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:22 --> Config Class Initialized
INFO - 2021-03-17 17:04:22 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:22 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:22 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:22 --> URI Class Initialized
INFO - 2021-03-17 17:04:22 --> Router Class Initialized
INFO - 2021-03-17 17:04:22 --> Output Class Initialized
INFO - 2021-03-17 17:04:22 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:22 --> Input Class Initialized
INFO - 2021-03-17 17:04:22 --> Language Class Initialized
ERROR - 2021-03-17 17:04:22 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:22 --> Config Class Initialized
INFO - 2021-03-17 17:04:22 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:22 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:22 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:22 --> URI Class Initialized
INFO - 2021-03-17 17:04:22 --> Router Class Initialized
INFO - 2021-03-17 17:04:22 --> Output Class Initialized
INFO - 2021-03-17 17:04:22 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:22 --> Input Class Initialized
INFO - 2021-03-17 17:04:22 --> Language Class Initialized
ERROR - 2021-03-17 17:04:22 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:22 --> Config Class Initialized
INFO - 2021-03-17 17:04:23 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:23 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:23 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:23 --> URI Class Initialized
INFO - 2021-03-17 17:04:23 --> Router Class Initialized
INFO - 2021-03-17 17:04:23 --> Output Class Initialized
INFO - 2021-03-17 17:04:23 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:23 --> Input Class Initialized
INFO - 2021-03-17 17:04:23 --> Language Class Initialized
ERROR - 2021-03-17 17:04:23 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:23 --> Config Class Initialized
INFO - 2021-03-17 17:04:23 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:23 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:23 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:23 --> URI Class Initialized
INFO - 2021-03-17 17:04:23 --> Router Class Initialized
INFO - 2021-03-17 17:04:23 --> Output Class Initialized
INFO - 2021-03-17 17:04:23 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:23 --> Input Class Initialized
INFO - 2021-03-17 17:04:23 --> Language Class Initialized
ERROR - 2021-03-17 17:04:23 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:23 --> Config Class Initialized
INFO - 2021-03-17 17:04:23 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:23 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:23 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:23 --> URI Class Initialized
INFO - 2021-03-17 17:04:23 --> Router Class Initialized
INFO - 2021-03-17 17:04:23 --> Output Class Initialized
INFO - 2021-03-17 17:04:23 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:23 --> Input Class Initialized
INFO - 2021-03-17 17:04:23 --> Language Class Initialized
ERROR - 2021-03-17 17:04:23 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:23 --> Config Class Initialized
INFO - 2021-03-17 17:04:24 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:24 --> URI Class Initialized
INFO - 2021-03-17 17:04:24 --> Router Class Initialized
INFO - 2021-03-17 17:04:24 --> Output Class Initialized
INFO - 2021-03-17 17:04:24 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:24 --> Input Class Initialized
INFO - 2021-03-17 17:04:24 --> Language Class Initialized
ERROR - 2021-03-17 17:04:24 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:24 --> Config Class Initialized
INFO - 2021-03-17 17:04:24 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:24 --> URI Class Initialized
INFO - 2021-03-17 17:04:24 --> Router Class Initialized
INFO - 2021-03-17 17:04:24 --> Output Class Initialized
INFO - 2021-03-17 17:04:24 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:24 --> Input Class Initialized
INFO - 2021-03-17 17:04:24 --> Language Class Initialized
ERROR - 2021-03-17 17:04:24 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:24 --> Config Class Initialized
INFO - 2021-03-17 17:04:24 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:24 --> URI Class Initialized
INFO - 2021-03-17 17:04:24 --> Router Class Initialized
INFO - 2021-03-17 17:04:24 --> Output Class Initialized
INFO - 2021-03-17 17:04:24 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:24 --> Input Class Initialized
INFO - 2021-03-17 17:04:24 --> Language Class Initialized
ERROR - 2021-03-17 17:04:24 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:24 --> Config Class Initialized
INFO - 2021-03-17 17:04:24 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:25 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:25 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:25 --> URI Class Initialized
INFO - 2021-03-17 17:04:25 --> Router Class Initialized
INFO - 2021-03-17 17:04:25 --> Output Class Initialized
INFO - 2021-03-17 17:04:25 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:25 --> Input Class Initialized
INFO - 2021-03-17 17:04:25 --> Language Class Initialized
ERROR - 2021-03-17 17:04:25 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:25 --> Config Class Initialized
INFO - 2021-03-17 17:04:25 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:25 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:25 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:25 --> URI Class Initialized
INFO - 2021-03-17 17:04:25 --> Router Class Initialized
INFO - 2021-03-17 17:04:25 --> Output Class Initialized
INFO - 2021-03-17 17:04:25 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:25 --> Input Class Initialized
INFO - 2021-03-17 17:04:25 --> Language Class Initialized
ERROR - 2021-03-17 17:04:25 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:25 --> Config Class Initialized
INFO - 2021-03-17 17:04:25 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:25 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:25 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:25 --> URI Class Initialized
INFO - 2021-03-17 17:04:25 --> Router Class Initialized
INFO - 2021-03-17 17:04:25 --> Output Class Initialized
INFO - 2021-03-17 17:04:25 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:25 --> Input Class Initialized
INFO - 2021-03-17 17:04:25 --> Language Class Initialized
ERROR - 2021-03-17 17:04:25 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:26 --> Config Class Initialized
INFO - 2021-03-17 17:04:26 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:26 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:26 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:26 --> URI Class Initialized
INFO - 2021-03-17 17:04:26 --> Router Class Initialized
INFO - 2021-03-17 17:04:26 --> Output Class Initialized
INFO - 2021-03-17 17:04:26 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:26 --> Input Class Initialized
INFO - 2021-03-17 17:04:26 --> Language Class Initialized
ERROR - 2021-03-17 17:04:26 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:04:26 --> Config Class Initialized
INFO - 2021-03-17 17:04:26 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:04:26 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:04:26 --> Utf8 Class Initialized
INFO - 2021-03-17 17:04:26 --> URI Class Initialized
INFO - 2021-03-17 17:04:26 --> Router Class Initialized
INFO - 2021-03-17 17:04:26 --> Output Class Initialized
INFO - 2021-03-17 17:04:26 --> Security Class Initialized
DEBUG - 2021-03-17 17:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:04:26 --> Input Class Initialized
INFO - 2021-03-17 17:04:26 --> Language Class Initialized
ERROR - 2021-03-17 17:04:26 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:37 --> Config Class Initialized
INFO - 2021-03-17 17:05:37 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:37 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:37 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:37 --> URI Class Initialized
INFO - 2021-03-17 17:05:37 --> Router Class Initialized
INFO - 2021-03-17 17:05:37 --> Output Class Initialized
INFO - 2021-03-17 17:05:37 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:37 --> Input Class Initialized
INFO - 2021-03-17 17:05:37 --> Language Class Initialized
INFO - 2021-03-17 17:05:37 --> Loader Class Initialized
INFO - 2021-03-17 17:05:37 --> Helper loaded: url_helper
INFO - 2021-03-17 17:05:37 --> Helper loaded: file_helper
INFO - 2021-03-17 17:05:37 --> Helper loaded: form_helper
INFO - 2021-03-17 17:05:37 --> Helper loaded: text_helper
INFO - 2021-03-17 17:05:37 --> Helper loaded: security_helper
INFO - 2021-03-17 17:05:37 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:05:37 --> Database Driver Class Initialized
INFO - 2021-03-17 17:05:37 --> Email Class Initialized
DEBUG - 2021-03-17 17:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:05:37 --> Form Validation Class Initialized
INFO - 2021-03-17 17:05:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:05:37 --> Pagination Class Initialized
INFO - 2021-03-17 17:05:37 --> Model Class Initialized
INFO - 2021-03-17 17:05:37 --> Controller Class Initialized
INFO - 2021-03-17 17:05:37 --> Model Class Initialized
INFO - 2021-03-17 17:05:37 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:05:37 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:05:38 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:05:38 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:05:38 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:05:38 --> Final output sent to browser
DEBUG - 2021-03-17 17:05:38 --> Total execution time: 0.7947
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Img/a7.jpg
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Img/profile.jpg
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Img/a4.jpg
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Img/a3.jpg
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/img
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Img/a5.jpg
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Img/a2.jpg
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:38 --> Config Class Initialized
INFO - 2021-03-17 17:05:38 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:38 --> URI Class Initialized
INFO - 2021-03-17 17:05:38 --> Router Class Initialized
INFO - 2021-03-17 17:05:38 --> Output Class Initialized
INFO - 2021-03-17 17:05:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:38 --> Input Class Initialized
INFO - 2021-03-17 17:05:38 --> Language Class Initialized
ERROR - 2021-03-17 17:05:38 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:39 --> Config Class Initialized
INFO - 2021-03-17 17:05:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:39 --> URI Class Initialized
INFO - 2021-03-17 17:05:39 --> Router Class Initialized
INFO - 2021-03-17 17:05:39 --> Output Class Initialized
INFO - 2021-03-17 17:05:39 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:39 --> Input Class Initialized
INFO - 2021-03-17 17:05:39 --> Language Class Initialized
ERROR - 2021-03-17 17:05:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:39 --> Config Class Initialized
INFO - 2021-03-17 17:05:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:39 --> URI Class Initialized
INFO - 2021-03-17 17:05:39 --> Router Class Initialized
INFO - 2021-03-17 17:05:39 --> Output Class Initialized
INFO - 2021-03-17 17:05:39 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:39 --> Input Class Initialized
INFO - 2021-03-17 17:05:39 --> Language Class Initialized
ERROR - 2021-03-17 17:05:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:39 --> Config Class Initialized
INFO - 2021-03-17 17:05:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:39 --> URI Class Initialized
INFO - 2021-03-17 17:05:39 --> Router Class Initialized
INFO - 2021-03-17 17:05:39 --> Output Class Initialized
INFO - 2021-03-17 17:05:39 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:39 --> Input Class Initialized
INFO - 2021-03-17 17:05:39 --> Language Class Initialized
ERROR - 2021-03-17 17:05:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:39 --> Config Class Initialized
INFO - 2021-03-17 17:05:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:39 --> URI Class Initialized
INFO - 2021-03-17 17:05:39 --> Router Class Initialized
INFO - 2021-03-17 17:05:39 --> Output Class Initialized
INFO - 2021-03-17 17:05:39 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:40 --> Input Class Initialized
INFO - 2021-03-17 17:05:40 --> Language Class Initialized
ERROR - 2021-03-17 17:05:40 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:40 --> Config Class Initialized
INFO - 2021-03-17 17:05:40 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:40 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:40 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:40 --> URI Class Initialized
INFO - 2021-03-17 17:05:40 --> Router Class Initialized
INFO - 2021-03-17 17:05:40 --> Output Class Initialized
INFO - 2021-03-17 17:05:40 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:40 --> Input Class Initialized
INFO - 2021-03-17 17:05:40 --> Language Class Initialized
ERROR - 2021-03-17 17:05:40 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:40 --> Config Class Initialized
INFO - 2021-03-17 17:05:40 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:40 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:40 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:40 --> URI Class Initialized
INFO - 2021-03-17 17:05:40 --> Router Class Initialized
INFO - 2021-03-17 17:05:40 --> Output Class Initialized
INFO - 2021-03-17 17:05:40 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:40 --> Input Class Initialized
INFO - 2021-03-17 17:05:40 --> Language Class Initialized
ERROR - 2021-03-17 17:05:40 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:40 --> Config Class Initialized
INFO - 2021-03-17 17:05:40 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:40 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:40 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:40 --> URI Class Initialized
INFO - 2021-03-17 17:05:40 --> Router Class Initialized
INFO - 2021-03-17 17:05:40 --> Output Class Initialized
INFO - 2021-03-17 17:05:40 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:40 --> Input Class Initialized
INFO - 2021-03-17 17:05:40 --> Language Class Initialized
ERROR - 2021-03-17 17:05:40 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:40 --> Config Class Initialized
INFO - 2021-03-17 17:05:40 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:41 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:41 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:41 --> URI Class Initialized
INFO - 2021-03-17 17:05:41 --> Router Class Initialized
INFO - 2021-03-17 17:05:41 --> Output Class Initialized
INFO - 2021-03-17 17:05:41 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:41 --> Input Class Initialized
INFO - 2021-03-17 17:05:41 --> Language Class Initialized
ERROR - 2021-03-17 17:05:41 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:41 --> Config Class Initialized
INFO - 2021-03-17 17:05:41 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:41 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:41 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:41 --> URI Class Initialized
INFO - 2021-03-17 17:05:41 --> Router Class Initialized
INFO - 2021-03-17 17:05:41 --> Output Class Initialized
INFO - 2021-03-17 17:05:41 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:41 --> Input Class Initialized
INFO - 2021-03-17 17:05:41 --> Language Class Initialized
ERROR - 2021-03-17 17:05:41 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:41 --> Config Class Initialized
INFO - 2021-03-17 17:05:41 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:41 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:41 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:41 --> URI Class Initialized
INFO - 2021-03-17 17:05:41 --> Router Class Initialized
INFO - 2021-03-17 17:05:41 --> Output Class Initialized
INFO - 2021-03-17 17:05:41 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:41 --> Input Class Initialized
INFO - 2021-03-17 17:05:41 --> Language Class Initialized
ERROR - 2021-03-17 17:05:41 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:41 --> Config Class Initialized
INFO - 2021-03-17 17:05:42 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:42 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:42 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:42 --> URI Class Initialized
INFO - 2021-03-17 17:05:42 --> Router Class Initialized
INFO - 2021-03-17 17:05:42 --> Output Class Initialized
INFO - 2021-03-17 17:05:42 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:42 --> Input Class Initialized
INFO - 2021-03-17 17:05:42 --> Language Class Initialized
ERROR - 2021-03-17 17:05:42 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:42 --> Config Class Initialized
INFO - 2021-03-17 17:05:42 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:42 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:42 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:42 --> URI Class Initialized
INFO - 2021-03-17 17:05:42 --> Router Class Initialized
INFO - 2021-03-17 17:05:42 --> Output Class Initialized
INFO - 2021-03-17 17:05:42 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:42 --> Input Class Initialized
INFO - 2021-03-17 17:05:42 --> Language Class Initialized
ERROR - 2021-03-17 17:05:42 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:42 --> Config Class Initialized
INFO - 2021-03-17 17:05:42 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:42 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:42 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:42 --> URI Class Initialized
INFO - 2021-03-17 17:05:42 --> Router Class Initialized
INFO - 2021-03-17 17:05:42 --> Output Class Initialized
INFO - 2021-03-17 17:05:42 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:42 --> Input Class Initialized
INFO - 2021-03-17 17:05:42 --> Language Class Initialized
ERROR - 2021-03-17 17:05:42 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:42 --> Config Class Initialized
INFO - 2021-03-17 17:05:42 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:42 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:42 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:42 --> URI Class Initialized
INFO - 2021-03-17 17:05:42 --> Router Class Initialized
INFO - 2021-03-17 17:05:42 --> Output Class Initialized
INFO - 2021-03-17 17:05:43 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:43 --> Input Class Initialized
INFO - 2021-03-17 17:05:43 --> Language Class Initialized
ERROR - 2021-03-17 17:05:43 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:43 --> Config Class Initialized
INFO - 2021-03-17 17:05:43 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:43 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:43 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:43 --> URI Class Initialized
INFO - 2021-03-17 17:05:43 --> Router Class Initialized
INFO - 2021-03-17 17:05:43 --> Output Class Initialized
INFO - 2021-03-17 17:05:43 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:43 --> Input Class Initialized
INFO - 2021-03-17 17:05:43 --> Language Class Initialized
ERROR - 2021-03-17 17:05:43 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:43 --> Config Class Initialized
INFO - 2021-03-17 17:05:43 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:43 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:43 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:43 --> URI Class Initialized
INFO - 2021-03-17 17:05:43 --> Router Class Initialized
INFO - 2021-03-17 17:05:43 --> Output Class Initialized
INFO - 2021-03-17 17:05:43 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:43 --> Input Class Initialized
INFO - 2021-03-17 17:05:43 --> Language Class Initialized
ERROR - 2021-03-17 17:05:43 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:43 --> Config Class Initialized
INFO - 2021-03-17 17:05:43 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:43 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:43 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:43 --> URI Class Initialized
INFO - 2021-03-17 17:05:43 --> Router Class Initialized
INFO - 2021-03-17 17:05:43 --> Output Class Initialized
INFO - 2021-03-17 17:05:43 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:43 --> Input Class Initialized
INFO - 2021-03-17 17:05:44 --> Language Class Initialized
ERROR - 2021-03-17 17:05:44 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:05:44 --> Config Class Initialized
INFO - 2021-03-17 17:05:44 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:05:44 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:05:44 --> Utf8 Class Initialized
INFO - 2021-03-17 17:05:44 --> URI Class Initialized
INFO - 2021-03-17 17:05:44 --> Router Class Initialized
INFO - 2021-03-17 17:05:44 --> Output Class Initialized
INFO - 2021-03-17 17:05:44 --> Security Class Initialized
DEBUG - 2021-03-17 17:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:05:44 --> Input Class Initialized
INFO - 2021-03-17 17:05:44 --> Language Class Initialized
ERROR - 2021-03-17 17:05:44 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:16 --> Config Class Initialized
INFO - 2021-03-17 17:06:16 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:16 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:16 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:16 --> URI Class Initialized
INFO - 2021-03-17 17:06:16 --> Router Class Initialized
INFO - 2021-03-17 17:06:16 --> Output Class Initialized
INFO - 2021-03-17 17:06:16 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:16 --> Input Class Initialized
INFO - 2021-03-17 17:06:16 --> Language Class Initialized
INFO - 2021-03-17 17:06:16 --> Loader Class Initialized
INFO - 2021-03-17 17:06:16 --> Helper loaded: url_helper
INFO - 2021-03-17 17:06:16 --> Helper loaded: file_helper
INFO - 2021-03-17 17:06:16 --> Helper loaded: form_helper
INFO - 2021-03-17 17:06:16 --> Helper loaded: text_helper
INFO - 2021-03-17 17:06:16 --> Helper loaded: security_helper
INFO - 2021-03-17 17:06:16 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:06:16 --> Database Driver Class Initialized
INFO - 2021-03-17 17:06:16 --> Email Class Initialized
DEBUG - 2021-03-17 17:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:06:16 --> Form Validation Class Initialized
INFO - 2021-03-17 17:06:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:06:16 --> Pagination Class Initialized
INFO - 2021-03-17 17:06:17 --> Model Class Initialized
INFO - 2021-03-17 17:06:17 --> Controller Class Initialized
INFO - 2021-03-17 17:06:17 --> Model Class Initialized
INFO - 2021-03-17 17:06:17 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:06:17 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:06:17 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:06:17 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:06:17 --> Final output sent to browser
DEBUG - 2021-03-17 17:06:17 --> Total execution time: 0.8515
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Img/a7.jpg
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Img/a4.jpg
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Img/profile.jpg
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Img/a2.jpg
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Img/a3.jpg
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Img/a5.jpg
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/img
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:17 --> Router Class Initialized
INFO - 2021-03-17 17:06:17 --> Output Class Initialized
INFO - 2021-03-17 17:06:17 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:17 --> Input Class Initialized
INFO - 2021-03-17 17:06:17 --> Language Class Initialized
ERROR - 2021-03-17 17:06:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:17 --> Config Class Initialized
INFO - 2021-03-17 17:06:17 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:17 --> URI Class Initialized
INFO - 2021-03-17 17:06:18 --> Router Class Initialized
INFO - 2021-03-17 17:06:18 --> Output Class Initialized
INFO - 2021-03-17 17:06:18 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:18 --> Input Class Initialized
INFO - 2021-03-17 17:06:18 --> Language Class Initialized
ERROR - 2021-03-17 17:06:18 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:18 --> Config Class Initialized
INFO - 2021-03-17 17:06:18 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:18 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:18 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:18 --> URI Class Initialized
INFO - 2021-03-17 17:06:18 --> Router Class Initialized
INFO - 2021-03-17 17:06:18 --> Output Class Initialized
INFO - 2021-03-17 17:06:18 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:18 --> Input Class Initialized
INFO - 2021-03-17 17:06:18 --> Language Class Initialized
ERROR - 2021-03-17 17:06:18 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:18 --> Config Class Initialized
INFO - 2021-03-17 17:06:18 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:18 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:18 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:18 --> URI Class Initialized
INFO - 2021-03-17 17:06:18 --> Router Class Initialized
INFO - 2021-03-17 17:06:18 --> Output Class Initialized
INFO - 2021-03-17 17:06:18 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:18 --> Input Class Initialized
INFO - 2021-03-17 17:06:18 --> Language Class Initialized
ERROR - 2021-03-17 17:06:18 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:18 --> Config Class Initialized
INFO - 2021-03-17 17:06:18 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:18 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:18 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:18 --> URI Class Initialized
INFO - 2021-03-17 17:06:18 --> Router Class Initialized
INFO - 2021-03-17 17:06:19 --> Output Class Initialized
INFO - 2021-03-17 17:06:19 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:19 --> Input Class Initialized
INFO - 2021-03-17 17:06:19 --> Language Class Initialized
ERROR - 2021-03-17 17:06:19 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:19 --> Config Class Initialized
INFO - 2021-03-17 17:06:19 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:19 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:19 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:19 --> URI Class Initialized
INFO - 2021-03-17 17:06:19 --> Router Class Initialized
INFO - 2021-03-17 17:06:19 --> Output Class Initialized
INFO - 2021-03-17 17:06:19 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:19 --> Input Class Initialized
INFO - 2021-03-17 17:06:19 --> Language Class Initialized
ERROR - 2021-03-17 17:06:19 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:19 --> Config Class Initialized
INFO - 2021-03-17 17:06:19 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:19 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:19 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:19 --> URI Class Initialized
INFO - 2021-03-17 17:06:19 --> Router Class Initialized
INFO - 2021-03-17 17:06:19 --> Output Class Initialized
INFO - 2021-03-17 17:06:19 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:19 --> Input Class Initialized
INFO - 2021-03-17 17:06:19 --> Language Class Initialized
ERROR - 2021-03-17 17:06:19 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:19 --> Config Class Initialized
INFO - 2021-03-17 17:06:19 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:19 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:19 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:19 --> URI Class Initialized
INFO - 2021-03-17 17:06:19 --> Router Class Initialized
INFO - 2021-03-17 17:06:19 --> Output Class Initialized
INFO - 2021-03-17 17:06:19 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:20 --> Input Class Initialized
INFO - 2021-03-17 17:06:20 --> Language Class Initialized
ERROR - 2021-03-17 17:06:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:20 --> Config Class Initialized
INFO - 2021-03-17 17:06:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:20 --> URI Class Initialized
INFO - 2021-03-17 17:06:20 --> Router Class Initialized
INFO - 2021-03-17 17:06:20 --> Output Class Initialized
INFO - 2021-03-17 17:06:20 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:20 --> Input Class Initialized
INFO - 2021-03-17 17:06:20 --> Language Class Initialized
ERROR - 2021-03-17 17:06:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:20 --> Config Class Initialized
INFO - 2021-03-17 17:06:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:20 --> URI Class Initialized
INFO - 2021-03-17 17:06:20 --> Router Class Initialized
INFO - 2021-03-17 17:06:20 --> Output Class Initialized
INFO - 2021-03-17 17:06:20 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:20 --> Input Class Initialized
INFO - 2021-03-17 17:06:20 --> Language Class Initialized
ERROR - 2021-03-17 17:06:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:20 --> Config Class Initialized
INFO - 2021-03-17 17:06:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:20 --> URI Class Initialized
INFO - 2021-03-17 17:06:20 --> Router Class Initialized
INFO - 2021-03-17 17:06:20 --> Output Class Initialized
INFO - 2021-03-17 17:06:21 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:21 --> Input Class Initialized
INFO - 2021-03-17 17:06:21 --> Language Class Initialized
ERROR - 2021-03-17 17:06:21 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:21 --> Config Class Initialized
INFO - 2021-03-17 17:06:21 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:21 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:21 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:21 --> URI Class Initialized
INFO - 2021-03-17 17:06:21 --> Router Class Initialized
INFO - 2021-03-17 17:06:21 --> Output Class Initialized
INFO - 2021-03-17 17:06:21 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:21 --> Input Class Initialized
INFO - 2021-03-17 17:06:21 --> Language Class Initialized
ERROR - 2021-03-17 17:06:21 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:21 --> Config Class Initialized
INFO - 2021-03-17 17:06:21 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:21 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:21 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:21 --> URI Class Initialized
INFO - 2021-03-17 17:06:21 --> Router Class Initialized
INFO - 2021-03-17 17:06:21 --> Output Class Initialized
INFO - 2021-03-17 17:06:21 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:21 --> Input Class Initialized
INFO - 2021-03-17 17:06:21 --> Language Class Initialized
ERROR - 2021-03-17 17:06:21 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:21 --> Config Class Initialized
INFO - 2021-03-17 17:06:21 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:21 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:21 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:21 --> URI Class Initialized
INFO - 2021-03-17 17:06:21 --> Router Class Initialized
INFO - 2021-03-17 17:06:21 --> Output Class Initialized
INFO - 2021-03-17 17:06:21 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:22 --> Input Class Initialized
INFO - 2021-03-17 17:06:22 --> Language Class Initialized
ERROR - 2021-03-17 17:06:22 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:22 --> Config Class Initialized
INFO - 2021-03-17 17:06:22 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:22 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:22 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:22 --> URI Class Initialized
INFO - 2021-03-17 17:06:22 --> Router Class Initialized
INFO - 2021-03-17 17:06:22 --> Output Class Initialized
INFO - 2021-03-17 17:06:22 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:22 --> Input Class Initialized
INFO - 2021-03-17 17:06:22 --> Language Class Initialized
ERROR - 2021-03-17 17:06:22 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:22 --> Config Class Initialized
INFO - 2021-03-17 17:06:22 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:22 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:22 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:22 --> URI Class Initialized
INFO - 2021-03-17 17:06:22 --> Router Class Initialized
INFO - 2021-03-17 17:06:22 --> Output Class Initialized
INFO - 2021-03-17 17:06:22 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:22 --> Input Class Initialized
INFO - 2021-03-17 17:06:22 --> Language Class Initialized
ERROR - 2021-03-17 17:06:22 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:22 --> Config Class Initialized
INFO - 2021-03-17 17:06:22 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:22 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:22 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:22 --> URI Class Initialized
INFO - 2021-03-17 17:06:22 --> Router Class Initialized
INFO - 2021-03-17 17:06:22 --> Output Class Initialized
INFO - 2021-03-17 17:06:22 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:23 --> Input Class Initialized
INFO - 2021-03-17 17:06:23 --> Language Class Initialized
ERROR - 2021-03-17 17:06:23 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:23 --> Config Class Initialized
INFO - 2021-03-17 17:06:23 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:23 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:23 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:23 --> URI Class Initialized
INFO - 2021-03-17 17:06:23 --> Router Class Initialized
INFO - 2021-03-17 17:06:23 --> Output Class Initialized
INFO - 2021-03-17 17:06:23 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:23 --> Input Class Initialized
INFO - 2021-03-17 17:06:23 --> Language Class Initialized
ERROR - 2021-03-17 17:06:23 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:31 --> Config Class Initialized
INFO - 2021-03-17 17:06:31 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:31 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:31 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:31 --> URI Class Initialized
INFO - 2021-03-17 17:06:31 --> Router Class Initialized
INFO - 2021-03-17 17:06:31 --> Output Class Initialized
INFO - 2021-03-17 17:06:31 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:32 --> Input Class Initialized
INFO - 2021-03-17 17:06:32 --> Language Class Initialized
INFO - 2021-03-17 17:06:32 --> Loader Class Initialized
INFO - 2021-03-17 17:06:32 --> Helper loaded: url_helper
INFO - 2021-03-17 17:06:32 --> Helper loaded: file_helper
INFO - 2021-03-17 17:06:32 --> Helper loaded: form_helper
INFO - 2021-03-17 17:06:32 --> Helper loaded: text_helper
INFO - 2021-03-17 17:06:32 --> Helper loaded: security_helper
INFO - 2021-03-17 17:06:32 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:06:32 --> Database Driver Class Initialized
INFO - 2021-03-17 17:06:32 --> Email Class Initialized
DEBUG - 2021-03-17 17:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:06:32 --> Form Validation Class Initialized
INFO - 2021-03-17 17:06:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:06:32 --> Pagination Class Initialized
INFO - 2021-03-17 17:06:32 --> Model Class Initialized
INFO - 2021-03-17 17:06:32 --> Controller Class Initialized
INFO - 2021-03-17 17:06:32 --> Model Class Initialized
INFO - 2021-03-17 17:06:32 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:06:32 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:06:32 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:06:32 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:06:32 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:06:32 --> Final output sent to browser
DEBUG - 2021-03-17 17:06:32 --> Total execution time: 0.9384
INFO - 2021-03-17 17:06:32 --> Config Class Initialized
INFO - 2021-03-17 17:06:32 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:32 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:32 --> Config Class Initialized
INFO - 2021-03-17 17:06:32 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:32 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:32 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:32 --> Config Class Initialized
INFO - 2021-03-17 17:06:32 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:32 --> URI Class Initialized
INFO - 2021-03-17 17:06:32 --> Config Class Initialized
INFO - 2021-03-17 17:06:32 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:32 --> Config Class Initialized
INFO - 2021-03-17 17:06:32 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:32 --> Config Class Initialized
INFO - 2021-03-17 17:06:32 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:32 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:32 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:32 --> URI Class Initialized
DEBUG - 2021-03-17 17:06:32 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:06:32 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:32 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:32 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:06:32 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:32 --> Router Class Initialized
INFO - 2021-03-17 17:06:32 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:32 --> Router Class Initialized
INFO - 2021-03-17 17:06:32 --> URI Class Initialized
INFO - 2021-03-17 17:06:32 --> URI Class Initialized
INFO - 2021-03-17 17:06:32 --> URI Class Initialized
INFO - 2021-03-17 17:06:32 --> Output Class Initialized
INFO - 2021-03-17 17:06:32 --> Router Class Initialized
INFO - 2021-03-17 17:06:32 --> Router Class Initialized
INFO - 2021-03-17 17:06:32 --> Output Class Initialized
INFO - 2021-03-17 17:06:32 --> Router Class Initialized
INFO - 2021-03-17 17:06:32 --> Security Class Initialized
INFO - 2021-03-17 17:06:32 --> Security Class Initialized
INFO - 2021-03-17 17:06:32 --> Output Class Initialized
INFO - 2021-03-17 17:06:32 --> Output Class Initialized
INFO - 2021-03-17 17:06:32 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:32 --> Output Class Initialized
DEBUG - 2021-03-17 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:32 --> Input Class Initialized
DEBUG - 2021-03-17 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:32 --> Security Class Initialized
INFO - 2021-03-17 17:06:32 --> Security Class Initialized
INFO - 2021-03-17 17:06:32 --> Input Class Initialized
INFO - 2021-03-17 17:06:32 --> Security Class Initialized
INFO - 2021-03-17 17:06:32 --> Language Class Initialized
INFO - 2021-03-17 17:06:32 --> Language Class Initialized
DEBUG - 2021-03-17 17:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:32 --> Input Class Initialized
INFO - 2021-03-17 17:06:32 --> Input Class Initialized
DEBUG - 2021-03-17 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:32 --> Input Class Initialized
ERROR - 2021-03-17 17:06:32 --> 404 Page Not Found: Img/a7.jpg
INFO - 2021-03-17 17:06:32 --> Language Class Initialized
INFO - 2021-03-17 17:06:32 --> Language Class Initialized
INFO - 2021-03-17 17:06:32 --> Language Class Initialized
ERROR - 2021-03-17 17:06:32 --> 404 Page Not Found: Img/a4.jpg
ERROR - 2021-03-17 17:06:32 --> 404 Page Not Found: Img/a2.jpg
ERROR - 2021-03-17 17:06:32 --> 404 Page Not Found: Img/a3.jpg
ERROR - 2021-03-17 17:06:32 --> 404 Page Not Found: Img/profile.jpg
INFO - 2021-03-17 17:06:32 --> Config Class Initialized
INFO - 2021-03-17 17:06:32 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:32 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:32 --> URI Class Initialized
INFO - 2021-03-17 17:06:32 --> Router Class Initialized
INFO - 2021-03-17 17:06:32 --> Output Class Initialized
INFO - 2021-03-17 17:06:32 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:32 --> Input Class Initialized
INFO - 2021-03-17 17:06:32 --> Language Class Initialized
ERROR - 2021-03-17 17:06:32 --> 404 Page Not Found: Adminassets/img
INFO - 2021-03-17 17:06:32 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:32 --> Config Class Initialized
INFO - 2021-03-17 17:06:32 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:32 --> Config Class Initialized
INFO - 2021-03-17 17:06:32 --> Config Class Initialized
INFO - 2021-03-17 17:06:32 --> Config Class Initialized
INFO - 2021-03-17 17:06:32 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:32 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:32 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:32 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:32 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:32 --> Config Class Initialized
INFO - 2021-03-17 17:06:32 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:32 --> URI Class Initialized
DEBUG - 2021-03-17 17:06:32 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:06:32 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:06:32 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:32 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:32 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:32 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:32 --> Router Class Initialized
DEBUG - 2021-03-17 17:06:32 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:32 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:32 --> URI Class Initialized
INFO - 2021-03-17 17:06:32 --> URI Class Initialized
INFO - 2021-03-17 17:06:32 --> URI Class Initialized
INFO - 2021-03-17 17:06:32 --> URI Class Initialized
INFO - 2021-03-17 17:06:32 --> Output Class Initialized
INFO - 2021-03-17 17:06:32 --> Router Class Initialized
INFO - 2021-03-17 17:06:32 --> Router Class Initialized
INFO - 2021-03-17 17:06:32 --> Router Class Initialized
INFO - 2021-03-17 17:06:32 --> Router Class Initialized
INFO - 2021-03-17 17:06:32 --> Security Class Initialized
INFO - 2021-03-17 17:06:32 --> Output Class Initialized
INFO - 2021-03-17 17:06:32 --> Output Class Initialized
INFO - 2021-03-17 17:06:32 --> Output Class Initialized
INFO - 2021-03-17 17:06:32 --> Output Class Initialized
DEBUG - 2021-03-17 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:32 --> Input Class Initialized
INFO - 2021-03-17 17:06:32 --> Security Class Initialized
INFO - 2021-03-17 17:06:32 --> Security Class Initialized
INFO - 2021-03-17 17:06:32 --> Language Class Initialized
INFO - 2021-03-17 17:06:32 --> Security Class Initialized
INFO - 2021-03-17 17:06:32 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:32 --> Input Class Initialized
INFO - 2021-03-17 17:06:32 --> Input Class Initialized
ERROR - 2021-03-17 17:06:32 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:32 --> Input Class Initialized
DEBUG - 2021-03-17 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:32 --> Language Class Initialized
INFO - 2021-03-17 17:06:32 --> Language Class Initialized
INFO - 2021-03-17 17:06:32 --> Language Class Initialized
INFO - 2021-03-17 17:06:32 --> Input Class Initialized
INFO - 2021-03-17 17:06:32 --> Language Class Initialized
ERROR - 2021-03-17 17:06:32 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:06:32 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:06:32 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:06:32 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:32 --> URI Class Initialized
INFO - 2021-03-17 17:06:32 --> Config Class Initialized
INFO - 2021-03-17 17:06:32 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:32 --> Config Class Initialized
INFO - 2021-03-17 17:06:32 --> Config Class Initialized
INFO - 2021-03-17 17:06:32 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:32 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:32 --> Config Class Initialized
INFO - 2021-03-17 17:06:32 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:32 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:32 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:32 --> Config Class Initialized
INFO - 2021-03-17 17:06:32 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:32 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:06:32 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:32 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:06:32 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:32 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:32 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:32 --> URI Class Initialized
INFO - 2021-03-17 17:06:32 --> URI Class Initialized
INFO - 2021-03-17 17:06:32 --> URI Class Initialized
INFO - 2021-03-17 17:06:32 --> URI Class Initialized
INFO - 2021-03-17 17:06:32 --> Router Class Initialized
INFO - 2021-03-17 17:06:32 --> Router Class Initialized
INFO - 2021-03-17 17:06:32 --> Router Class Initialized
INFO - 2021-03-17 17:06:32 --> Router Class Initialized
DEBUG - 2021-03-17 17:06:32 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:32 --> Output Class Initialized
INFO - 2021-03-17 17:06:32 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:32 --> Output Class Initialized
INFO - 2021-03-17 17:06:32 --> Output Class Initialized
INFO - 2021-03-17 17:06:32 --> Output Class Initialized
INFO - 2021-03-17 17:06:32 --> URI Class Initialized
INFO - 2021-03-17 17:06:32 --> Security Class Initialized
INFO - 2021-03-17 17:06:32 --> Security Class Initialized
INFO - 2021-03-17 17:06:32 --> Security Class Initialized
INFO - 2021-03-17 17:06:32 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:32 --> Input Class Initialized
INFO - 2021-03-17 17:06:32 --> Router Class Initialized
INFO - 2021-03-17 17:06:32 --> Language Class Initialized
DEBUG - 2021-03-17 17:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:32 --> Input Class Initialized
INFO - 2021-03-17 17:06:32 --> Input Class Initialized
INFO - 2021-03-17 17:06:32 --> Input Class Initialized
INFO - 2021-03-17 17:06:32 --> Language Class Initialized
INFO - 2021-03-17 17:06:32 --> Language Class Initialized
INFO - 2021-03-17 17:06:32 --> Language Class Initialized
ERROR - 2021-03-17 17:06:32 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:32 --> Output Class Initialized
ERROR - 2021-03-17 17:06:32 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:06:32 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:06:32 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:32 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:32 --> Input Class Initialized
INFO - 2021-03-17 17:06:32 --> Language Class Initialized
ERROR - 2021-03-17 17:06:33 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:33 --> Router Class Initialized
INFO - 2021-03-17 17:06:33 --> Config Class Initialized
INFO - 2021-03-17 17:06:33 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:33 --> Config Class Initialized
INFO - 2021-03-17 17:06:33 --> Config Class Initialized
INFO - 2021-03-17 17:06:33 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:33 --> Config Class Initialized
INFO - 2021-03-17 17:06:33 --> Config Class Initialized
INFO - 2021-03-17 17:06:33 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:33 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:33 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:33 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:33 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:06:33 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:06:33 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:06:33 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:06:33 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:33 --> URI Class Initialized
INFO - 2021-03-17 17:06:33 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:33 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:33 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:33 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:33 --> URI Class Initialized
INFO - 2021-03-17 17:06:33 --> Router Class Initialized
INFO - 2021-03-17 17:06:33 --> URI Class Initialized
INFO - 2021-03-17 17:06:33 --> URI Class Initialized
INFO - 2021-03-17 17:06:33 --> URI Class Initialized
INFO - 2021-03-17 17:06:33 --> Router Class Initialized
INFO - 2021-03-17 17:06:33 --> Router Class Initialized
INFO - 2021-03-17 17:06:33 --> Router Class Initialized
INFO - 2021-03-17 17:06:33 --> Router Class Initialized
INFO - 2021-03-17 17:06:33 --> Output Class Initialized
INFO - 2021-03-17 17:06:33 --> Security Class Initialized
INFO - 2021-03-17 17:06:33 --> Output Class Initialized
INFO - 2021-03-17 17:06:33 --> Output Class Initialized
INFO - 2021-03-17 17:06:33 --> Output Class Initialized
INFO - 2021-03-17 17:06:33 --> Output Class Initialized
DEBUG - 2021-03-17 17:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:33 --> Input Class Initialized
INFO - 2021-03-17 17:06:33 --> Security Class Initialized
INFO - 2021-03-17 17:06:33 --> Security Class Initialized
INFO - 2021-03-17 17:06:33 --> Security Class Initialized
INFO - 2021-03-17 17:06:33 --> Security Class Initialized
INFO - 2021-03-17 17:06:33 --> Language Class Initialized
DEBUG - 2021-03-17 17:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:33 --> Input Class Initialized
DEBUG - 2021-03-17 17:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:33 --> Input Class Initialized
ERROR - 2021-03-17 17:06:33 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:33 --> Input Class Initialized
INFO - 2021-03-17 17:06:33 --> Input Class Initialized
INFO - 2021-03-17 17:06:33 --> Language Class Initialized
INFO - 2021-03-17 17:06:33 --> Language Class Initialized
INFO - 2021-03-17 17:06:33 --> Language Class Initialized
INFO - 2021-03-17 17:06:33 --> Language Class Initialized
ERROR - 2021-03-17 17:06:33 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:06:33 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:06:33 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:06:33 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:33 --> Output Class Initialized
INFO - 2021-03-17 17:06:33 --> Config Class Initialized
INFO - 2021-03-17 17:06:33 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:33 --> Config Class Initialized
INFO - 2021-03-17 17:06:33 --> Config Class Initialized
INFO - 2021-03-17 17:06:33 --> Config Class Initialized
INFO - 2021-03-17 17:06:33 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:33 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:33 --> Hooks Class Initialized
INFO - 2021-03-17 17:06:33 --> Config Class Initialized
INFO - 2021-03-17 17:06:33 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:33 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:33 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:06:33 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:33 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:06:33 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:06:33 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:06:33 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:33 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:33 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:33 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:33 --> URI Class Initialized
INFO - 2021-03-17 17:06:33 --> URI Class Initialized
INFO - 2021-03-17 17:06:33 --> URI Class Initialized
INFO - 2021-03-17 17:06:33 --> URI Class Initialized
INFO - 2021-03-17 17:06:33 --> URI Class Initialized
INFO - 2021-03-17 17:06:33 --> Router Class Initialized
INFO - 2021-03-17 17:06:33 --> Router Class Initialized
INFO - 2021-03-17 17:06:33 --> Router Class Initialized
INFO - 2021-03-17 17:06:33 --> Router Class Initialized
INFO - 2021-03-17 17:06:33 --> Router Class Initialized
INFO - 2021-03-17 17:06:33 --> Output Class Initialized
INFO - 2021-03-17 17:06:33 --> Output Class Initialized
INFO - 2021-03-17 17:06:33 --> Output Class Initialized
INFO - 2021-03-17 17:06:33 --> Output Class Initialized
INFO - 2021-03-17 17:06:33 --> Output Class Initialized
INFO - 2021-03-17 17:06:33 --> Security Class Initialized
INFO - 2021-03-17 17:06:33 --> Security Class Initialized
INFO - 2021-03-17 17:06:33 --> Security Class Initialized
INFO - 2021-03-17 17:06:33 --> Security Class Initialized
INFO - 2021-03-17 17:06:33 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:33 --> Input Class Initialized
INFO - 2021-03-17 17:06:33 --> Security Class Initialized
INFO - 2021-03-17 17:06:33 --> Language Class Initialized
DEBUG - 2021-03-17 17:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:33 --> Input Class Initialized
DEBUG - 2021-03-17 17:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:33 --> Input Class Initialized
INFO - 2021-03-17 17:06:33 --> Input Class Initialized
INFO - 2021-03-17 17:06:33 --> Language Class Initialized
INFO - 2021-03-17 17:06:33 --> Language Class Initialized
INFO - 2021-03-17 17:06:33 --> Language Class Initialized
DEBUG - 2021-03-17 17:06:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-17 17:06:33 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:33 --> Input Class Initialized
ERROR - 2021-03-17 17:06:33 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:33 --> Language Class Initialized
ERROR - 2021-03-17 17:06:33 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:06:33 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:06:33 --> 404 Page Not Found: Img/a5.jpg
DEBUG - 2021-03-17 17:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:33 --> Config Class Initialized
INFO - 2021-03-17 17:06:33 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:33 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:33 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:33 --> URI Class Initialized
INFO - 2021-03-17 17:06:33 --> Router Class Initialized
INFO - 2021-03-17 17:06:33 --> Output Class Initialized
INFO - 2021-03-17 17:06:33 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:33 --> Input Class Initialized
INFO - 2021-03-17 17:06:33 --> Language Class Initialized
ERROR - 2021-03-17 17:06:33 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:33 --> Input Class Initialized
INFO - 2021-03-17 17:06:33 --> Config Class Initialized
INFO - 2021-03-17 17:06:33 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:33 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:33 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:33 --> URI Class Initialized
INFO - 2021-03-17 17:06:33 --> Router Class Initialized
INFO - 2021-03-17 17:06:33 --> Output Class Initialized
INFO - 2021-03-17 17:06:33 --> Language Class Initialized
INFO - 2021-03-17 17:06:33 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:33 --> Input Class Initialized
INFO - 2021-03-17 17:06:33 --> Language Class Initialized
ERROR - 2021-03-17 17:06:33 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:33 --> Config Class Initialized
ERROR - 2021-03-17 17:06:33 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:33 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:33 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:33 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:33 --> URI Class Initialized
INFO - 2021-03-17 17:06:33 --> Router Class Initialized
INFO - 2021-03-17 17:06:33 --> Output Class Initialized
INFO - 2021-03-17 17:06:33 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:33 --> Input Class Initialized
INFO - 2021-03-17 17:06:33 --> Language Class Initialized
ERROR - 2021-03-17 17:06:33 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:33 --> Config Class Initialized
INFO - 2021-03-17 17:06:33 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:33 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:33 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:33 --> URI Class Initialized
INFO - 2021-03-17 17:06:33 --> Router Class Initialized
INFO - 2021-03-17 17:06:33 --> Output Class Initialized
INFO - 2021-03-17 17:06:33 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:33 --> Input Class Initialized
INFO - 2021-03-17 17:06:33 --> Language Class Initialized
ERROR - 2021-03-17 17:06:33 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:34 --> Config Class Initialized
INFO - 2021-03-17 17:06:34 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:34 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:34 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:34 --> URI Class Initialized
INFO - 2021-03-17 17:06:34 --> Router Class Initialized
INFO - 2021-03-17 17:06:34 --> Output Class Initialized
INFO - 2021-03-17 17:06:34 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:34 --> Input Class Initialized
INFO - 2021-03-17 17:06:34 --> Language Class Initialized
ERROR - 2021-03-17 17:06:34 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:34 --> Config Class Initialized
INFO - 2021-03-17 17:06:34 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:34 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:34 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:34 --> URI Class Initialized
INFO - 2021-03-17 17:06:34 --> Router Class Initialized
INFO - 2021-03-17 17:06:34 --> Output Class Initialized
INFO - 2021-03-17 17:06:34 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:34 --> Input Class Initialized
INFO - 2021-03-17 17:06:34 --> Language Class Initialized
ERROR - 2021-03-17 17:06:34 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:34 --> Config Class Initialized
INFO - 2021-03-17 17:06:34 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:34 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:34 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:34 --> URI Class Initialized
INFO - 2021-03-17 17:06:34 --> Router Class Initialized
INFO - 2021-03-17 17:06:34 --> Output Class Initialized
INFO - 2021-03-17 17:06:34 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:34 --> Input Class Initialized
INFO - 2021-03-17 17:06:34 --> Language Class Initialized
ERROR - 2021-03-17 17:06:34 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:34 --> Config Class Initialized
INFO - 2021-03-17 17:06:35 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:35 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:35 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:35 --> URI Class Initialized
INFO - 2021-03-17 17:06:35 --> Router Class Initialized
INFO - 2021-03-17 17:06:35 --> Output Class Initialized
INFO - 2021-03-17 17:06:35 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:35 --> Input Class Initialized
INFO - 2021-03-17 17:06:35 --> Language Class Initialized
ERROR - 2021-03-17 17:06:35 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:35 --> Config Class Initialized
INFO - 2021-03-17 17:06:35 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:35 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:35 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:35 --> URI Class Initialized
INFO - 2021-03-17 17:06:35 --> Router Class Initialized
INFO - 2021-03-17 17:06:35 --> Output Class Initialized
INFO - 2021-03-17 17:06:35 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:35 --> Input Class Initialized
INFO - 2021-03-17 17:06:35 --> Language Class Initialized
ERROR - 2021-03-17 17:06:35 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:35 --> Config Class Initialized
INFO - 2021-03-17 17:06:35 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:35 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:35 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:35 --> URI Class Initialized
INFO - 2021-03-17 17:06:35 --> Router Class Initialized
INFO - 2021-03-17 17:06:35 --> Output Class Initialized
INFO - 2021-03-17 17:06:35 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:35 --> Input Class Initialized
INFO - 2021-03-17 17:06:35 --> Language Class Initialized
ERROR - 2021-03-17 17:06:35 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:36 --> Config Class Initialized
INFO - 2021-03-17 17:06:36 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:36 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:36 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:36 --> URI Class Initialized
INFO - 2021-03-17 17:06:36 --> Router Class Initialized
INFO - 2021-03-17 17:06:36 --> Output Class Initialized
INFO - 2021-03-17 17:06:36 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:36 --> Input Class Initialized
INFO - 2021-03-17 17:06:36 --> Language Class Initialized
ERROR - 2021-03-17 17:06:36 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:36 --> Config Class Initialized
INFO - 2021-03-17 17:06:36 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:36 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:36 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:36 --> URI Class Initialized
INFO - 2021-03-17 17:06:36 --> Router Class Initialized
INFO - 2021-03-17 17:06:36 --> Output Class Initialized
INFO - 2021-03-17 17:06:36 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:36 --> Input Class Initialized
INFO - 2021-03-17 17:06:36 --> Language Class Initialized
ERROR - 2021-03-17 17:06:36 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:36 --> Config Class Initialized
INFO - 2021-03-17 17:06:36 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:36 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:36 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:36 --> URI Class Initialized
INFO - 2021-03-17 17:06:36 --> Router Class Initialized
INFO - 2021-03-17 17:06:36 --> Output Class Initialized
INFO - 2021-03-17 17:06:36 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:36 --> Input Class Initialized
INFO - 2021-03-17 17:06:36 --> Language Class Initialized
ERROR - 2021-03-17 17:06:36 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:37 --> Config Class Initialized
INFO - 2021-03-17 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:37 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:37 --> URI Class Initialized
INFO - 2021-03-17 17:06:37 --> Router Class Initialized
INFO - 2021-03-17 17:06:37 --> Output Class Initialized
INFO - 2021-03-17 17:06:37 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:37 --> Input Class Initialized
INFO - 2021-03-17 17:06:37 --> Language Class Initialized
ERROR - 2021-03-17 17:06:37 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:37 --> Config Class Initialized
INFO - 2021-03-17 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:37 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:37 --> URI Class Initialized
INFO - 2021-03-17 17:06:37 --> Router Class Initialized
INFO - 2021-03-17 17:06:37 --> Output Class Initialized
INFO - 2021-03-17 17:06:37 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:37 --> Input Class Initialized
INFO - 2021-03-17 17:06:37 --> Language Class Initialized
ERROR - 2021-03-17 17:06:37 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:37 --> Config Class Initialized
INFO - 2021-03-17 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:37 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:37 --> URI Class Initialized
INFO - 2021-03-17 17:06:37 --> Router Class Initialized
INFO - 2021-03-17 17:06:37 --> Output Class Initialized
INFO - 2021-03-17 17:06:37 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:37 --> Input Class Initialized
INFO - 2021-03-17 17:06:37 --> Language Class Initialized
ERROR - 2021-03-17 17:06:37 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:38 --> Config Class Initialized
INFO - 2021-03-17 17:06:38 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:38 --> URI Class Initialized
INFO - 2021-03-17 17:06:38 --> Router Class Initialized
INFO - 2021-03-17 17:06:38 --> Output Class Initialized
INFO - 2021-03-17 17:06:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:38 --> Input Class Initialized
INFO - 2021-03-17 17:06:38 --> Language Class Initialized
ERROR - 2021-03-17 17:06:38 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:38 --> Config Class Initialized
INFO - 2021-03-17 17:06:38 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:38 --> URI Class Initialized
INFO - 2021-03-17 17:06:38 --> Router Class Initialized
INFO - 2021-03-17 17:06:38 --> Output Class Initialized
INFO - 2021-03-17 17:06:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:38 --> Input Class Initialized
INFO - 2021-03-17 17:06:38 --> Language Class Initialized
ERROR - 2021-03-17 17:06:38 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:38 --> Config Class Initialized
INFO - 2021-03-17 17:06:38 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:38 --> URI Class Initialized
INFO - 2021-03-17 17:06:38 --> Router Class Initialized
INFO - 2021-03-17 17:06:38 --> Output Class Initialized
INFO - 2021-03-17 17:06:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:39 --> Input Class Initialized
INFO - 2021-03-17 17:06:39 --> Language Class Initialized
ERROR - 2021-03-17 17:06:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:06:39 --> Config Class Initialized
INFO - 2021-03-17 17:06:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:06:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:06:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:06:39 --> URI Class Initialized
INFO - 2021-03-17 17:06:39 --> Router Class Initialized
INFO - 2021-03-17 17:06:39 --> Output Class Initialized
INFO - 2021-03-17 17:06:39 --> Security Class Initialized
DEBUG - 2021-03-17 17:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:06:39 --> Input Class Initialized
INFO - 2021-03-17 17:06:39 --> Language Class Initialized
ERROR - 2021-03-17 17:06:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:23 --> Config Class Initialized
INFO - 2021-03-17 17:07:23 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:23 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:23 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:23 --> URI Class Initialized
INFO - 2021-03-17 17:07:23 --> Router Class Initialized
INFO - 2021-03-17 17:07:23 --> Output Class Initialized
INFO - 2021-03-17 17:07:23 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:23 --> Input Class Initialized
INFO - 2021-03-17 17:07:23 --> Language Class Initialized
INFO - 2021-03-17 17:07:23 --> Loader Class Initialized
INFO - 2021-03-17 17:07:23 --> Helper loaded: url_helper
INFO - 2021-03-17 17:07:23 --> Helper loaded: file_helper
INFO - 2021-03-17 17:07:23 --> Helper loaded: form_helper
INFO - 2021-03-17 17:07:23 --> Helper loaded: text_helper
INFO - 2021-03-17 17:07:23 --> Helper loaded: security_helper
INFO - 2021-03-17 17:07:23 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:07:23 --> Database Driver Class Initialized
INFO - 2021-03-17 17:07:23 --> Email Class Initialized
DEBUG - 2021-03-17 17:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:07:23 --> Form Validation Class Initialized
INFO - 2021-03-17 17:07:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:07:23 --> Pagination Class Initialized
INFO - 2021-03-17 17:07:23 --> Model Class Initialized
INFO - 2021-03-17 17:07:23 --> Controller Class Initialized
INFO - 2021-03-17 17:07:23 --> Model Class Initialized
INFO - 2021-03-17 17:07:23 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:07:24 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:07:24 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:07:24 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:07:24 --> Final output sent to browser
DEBUG - 2021-03-17 17:07:24 --> Total execution time: 0.9665
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Img/a4.jpg
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Img/a2.jpg
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Img/a3.jpg
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Img/a5.jpg
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Img/a7.jpg
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Img/profile.jpg
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
INFO - 2021-03-17 17:07:24 --> Config Class Initialized
INFO - 2021-03-17 17:07:24 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:24 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:24 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:24 --> URI Class Initialized
INFO - 2021-03-17 17:07:24 --> Router Class Initialized
INFO - 2021-03-17 17:07:24 --> Output Class Initialized
INFO - 2021-03-17 17:07:24 --> Security Class Initialized
ERROR - 2021-03-17 17:07:24 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:24 --> Input Class Initialized
INFO - 2021-03-17 17:07:24 --> Language Class Initialized
ERROR - 2021-03-17 17:07:25 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:25 --> Config Class Initialized
INFO - 2021-03-17 17:07:25 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:25 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:25 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:25 --> URI Class Initialized
INFO - 2021-03-17 17:07:25 --> Router Class Initialized
INFO - 2021-03-17 17:07:25 --> Output Class Initialized
INFO - 2021-03-17 17:07:25 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:25 --> Input Class Initialized
INFO - 2021-03-17 17:07:25 --> Language Class Initialized
ERROR - 2021-03-17 17:07:25 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:25 --> Config Class Initialized
INFO - 2021-03-17 17:07:25 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:25 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:25 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:25 --> URI Class Initialized
INFO - 2021-03-17 17:07:25 --> Router Class Initialized
INFO - 2021-03-17 17:07:25 --> Output Class Initialized
INFO - 2021-03-17 17:07:25 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:25 --> Input Class Initialized
INFO - 2021-03-17 17:07:25 --> Language Class Initialized
ERROR - 2021-03-17 17:07:25 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:25 --> Config Class Initialized
INFO - 2021-03-17 17:07:25 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:25 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:25 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:25 --> URI Class Initialized
INFO - 2021-03-17 17:07:25 --> Router Class Initialized
INFO - 2021-03-17 17:07:25 --> Output Class Initialized
INFO - 2021-03-17 17:07:26 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:26 --> Input Class Initialized
INFO - 2021-03-17 17:07:26 --> Language Class Initialized
ERROR - 2021-03-17 17:07:26 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:26 --> Config Class Initialized
INFO - 2021-03-17 17:07:26 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:26 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:26 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:26 --> URI Class Initialized
INFO - 2021-03-17 17:07:26 --> Router Class Initialized
INFO - 2021-03-17 17:07:26 --> Output Class Initialized
INFO - 2021-03-17 17:07:26 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:26 --> Input Class Initialized
INFO - 2021-03-17 17:07:26 --> Language Class Initialized
ERROR - 2021-03-17 17:07:26 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:26 --> Config Class Initialized
INFO - 2021-03-17 17:07:26 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:26 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:26 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:26 --> URI Class Initialized
INFO - 2021-03-17 17:07:26 --> Router Class Initialized
INFO - 2021-03-17 17:07:26 --> Output Class Initialized
INFO - 2021-03-17 17:07:26 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:26 --> Input Class Initialized
INFO - 2021-03-17 17:07:26 --> Language Class Initialized
ERROR - 2021-03-17 17:07:27 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:27 --> Config Class Initialized
INFO - 2021-03-17 17:07:27 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:27 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:27 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:27 --> URI Class Initialized
INFO - 2021-03-17 17:07:27 --> Router Class Initialized
INFO - 2021-03-17 17:07:27 --> Output Class Initialized
INFO - 2021-03-17 17:07:27 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:27 --> Input Class Initialized
INFO - 2021-03-17 17:07:27 --> Language Class Initialized
ERROR - 2021-03-17 17:07:27 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:27 --> Config Class Initialized
INFO - 2021-03-17 17:07:27 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:27 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:27 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:27 --> URI Class Initialized
INFO - 2021-03-17 17:07:27 --> Router Class Initialized
INFO - 2021-03-17 17:07:27 --> Output Class Initialized
INFO - 2021-03-17 17:07:27 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:27 --> Input Class Initialized
INFO - 2021-03-17 17:07:27 --> Language Class Initialized
ERROR - 2021-03-17 17:07:27 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:27 --> Config Class Initialized
INFO - 2021-03-17 17:07:27 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:27 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:27 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:28 --> URI Class Initialized
INFO - 2021-03-17 17:07:28 --> Router Class Initialized
INFO - 2021-03-17 17:07:28 --> Output Class Initialized
INFO - 2021-03-17 17:07:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:28 --> Input Class Initialized
INFO - 2021-03-17 17:07:28 --> Language Class Initialized
ERROR - 2021-03-17 17:07:28 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:28 --> Config Class Initialized
INFO - 2021-03-17 17:07:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:28 --> URI Class Initialized
INFO - 2021-03-17 17:07:28 --> Router Class Initialized
INFO - 2021-03-17 17:07:28 --> Output Class Initialized
INFO - 2021-03-17 17:07:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:28 --> Input Class Initialized
INFO - 2021-03-17 17:07:28 --> Language Class Initialized
ERROR - 2021-03-17 17:07:28 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:28 --> Config Class Initialized
INFO - 2021-03-17 17:07:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:28 --> URI Class Initialized
INFO - 2021-03-17 17:07:28 --> Router Class Initialized
INFO - 2021-03-17 17:07:28 --> Output Class Initialized
INFO - 2021-03-17 17:07:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:29 --> Input Class Initialized
INFO - 2021-03-17 17:07:29 --> Language Class Initialized
ERROR - 2021-03-17 17:07:29 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:29 --> Config Class Initialized
INFO - 2021-03-17 17:07:29 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:29 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:29 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:29 --> URI Class Initialized
INFO - 2021-03-17 17:07:29 --> Router Class Initialized
INFO - 2021-03-17 17:07:29 --> Output Class Initialized
INFO - 2021-03-17 17:07:29 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:29 --> Input Class Initialized
INFO - 2021-03-17 17:07:29 --> Language Class Initialized
ERROR - 2021-03-17 17:07:29 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:29 --> Config Class Initialized
INFO - 2021-03-17 17:07:29 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:29 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:29 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:29 --> URI Class Initialized
INFO - 2021-03-17 17:07:29 --> Router Class Initialized
INFO - 2021-03-17 17:07:29 --> Output Class Initialized
INFO - 2021-03-17 17:07:29 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:29 --> Input Class Initialized
INFO - 2021-03-17 17:07:29 --> Language Class Initialized
ERROR - 2021-03-17 17:07:29 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:30 --> Config Class Initialized
INFO - 2021-03-17 17:07:30 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:30 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:30 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:30 --> URI Class Initialized
INFO - 2021-03-17 17:07:30 --> Router Class Initialized
INFO - 2021-03-17 17:07:30 --> Output Class Initialized
INFO - 2021-03-17 17:07:30 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:30 --> Input Class Initialized
INFO - 2021-03-17 17:07:30 --> Language Class Initialized
ERROR - 2021-03-17 17:07:30 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:30 --> Config Class Initialized
INFO - 2021-03-17 17:07:30 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:30 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:30 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:30 --> URI Class Initialized
INFO - 2021-03-17 17:07:30 --> Router Class Initialized
INFO - 2021-03-17 17:07:30 --> Output Class Initialized
INFO - 2021-03-17 17:07:30 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:30 --> Input Class Initialized
INFO - 2021-03-17 17:07:30 --> Language Class Initialized
ERROR - 2021-03-17 17:07:30 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:30 --> Config Class Initialized
INFO - 2021-03-17 17:07:30 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:30 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:31 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:31 --> URI Class Initialized
INFO - 2021-03-17 17:07:31 --> Router Class Initialized
INFO - 2021-03-17 17:07:31 --> Output Class Initialized
INFO - 2021-03-17 17:07:31 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:31 --> Input Class Initialized
INFO - 2021-03-17 17:07:31 --> Language Class Initialized
ERROR - 2021-03-17 17:07:31 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:07:31 --> Config Class Initialized
INFO - 2021-03-17 17:07:31 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:07:31 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:07:31 --> Utf8 Class Initialized
INFO - 2021-03-17 17:07:31 --> URI Class Initialized
INFO - 2021-03-17 17:07:31 --> Router Class Initialized
INFO - 2021-03-17 17:07:31 --> Output Class Initialized
INFO - 2021-03-17 17:07:31 --> Security Class Initialized
DEBUG - 2021-03-17 17:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:07:31 --> Input Class Initialized
INFO - 2021-03-17 17:07:31 --> Language Class Initialized
ERROR - 2021-03-17 17:07:31 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:00 --> Config Class Initialized
INFO - 2021-03-17 17:08:00 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:00 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:00 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:00 --> URI Class Initialized
INFO - 2021-03-17 17:08:00 --> Router Class Initialized
INFO - 2021-03-17 17:08:00 --> Output Class Initialized
INFO - 2021-03-17 17:08:00 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:00 --> Input Class Initialized
INFO - 2021-03-17 17:08:00 --> Language Class Initialized
INFO - 2021-03-17 17:08:00 --> Loader Class Initialized
INFO - 2021-03-17 17:08:00 --> Helper loaded: url_helper
INFO - 2021-03-17 17:08:00 --> Helper loaded: file_helper
INFO - 2021-03-17 17:08:00 --> Helper loaded: form_helper
INFO - 2021-03-17 17:08:00 --> Helper loaded: text_helper
INFO - 2021-03-17 17:08:00 --> Helper loaded: security_helper
INFO - 2021-03-17 17:08:00 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:08:00 --> Database Driver Class Initialized
INFO - 2021-03-17 17:08:00 --> Email Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:08:01 --> Form Validation Class Initialized
INFO - 2021-03-17 17:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:08:01 --> Pagination Class Initialized
INFO - 2021-03-17 17:08:01 --> Model Class Initialized
INFO - 2021-03-17 17:08:01 --> Controller Class Initialized
INFO - 2021-03-17 17:08:01 --> Model Class Initialized
INFO - 2021-03-17 17:08:01 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:08:01 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:08:01 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:08:01 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:08:01 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:08:01 --> Final output sent to browser
DEBUG - 2021-03-17 17:08:01 --> Total execution time: 0.9876
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/img
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Img/a4.jpg
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Img/a3.jpg
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Img/profile.jpg
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Img/a7.jpg
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Img/a2.jpg
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Img/a5.jpg
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Config Class Initialized
INFO - 2021-03-17 17:08:01 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
DEBUG - 2021-03-17 17:08:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:01 --> URI Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:01 --> Input Class Initialized
INFO - 2021-03-17 17:08:01 --> Language Class Initialized
ERROR - 2021-03-17 17:08:01 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:01 --> Router Class Initialized
INFO - 2021-03-17 17:08:01 --> Output Class Initialized
INFO - 2021-03-17 17:08:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:02 --> Input Class Initialized
INFO - 2021-03-17 17:08:02 --> Language Class Initialized
ERROR - 2021-03-17 17:08:02 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:02 --> Config Class Initialized
INFO - 2021-03-17 17:08:02 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:02 --> URI Class Initialized
INFO - 2021-03-17 17:08:02 --> Router Class Initialized
INFO - 2021-03-17 17:08:02 --> Output Class Initialized
INFO - 2021-03-17 17:08:02 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:02 --> Input Class Initialized
INFO - 2021-03-17 17:08:02 --> Language Class Initialized
ERROR - 2021-03-17 17:08:02 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:02 --> Config Class Initialized
INFO - 2021-03-17 17:08:02 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:02 --> URI Class Initialized
INFO - 2021-03-17 17:08:02 --> Router Class Initialized
INFO - 2021-03-17 17:08:02 --> Output Class Initialized
INFO - 2021-03-17 17:08:02 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:02 --> Input Class Initialized
INFO - 2021-03-17 17:08:02 --> Language Class Initialized
ERROR - 2021-03-17 17:08:02 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:02 --> Config Class Initialized
INFO - 2021-03-17 17:08:02 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:02 --> URI Class Initialized
INFO - 2021-03-17 17:08:03 --> Router Class Initialized
INFO - 2021-03-17 17:08:03 --> Output Class Initialized
INFO - 2021-03-17 17:08:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:03 --> Input Class Initialized
INFO - 2021-03-17 17:08:03 --> Language Class Initialized
ERROR - 2021-03-17 17:08:03 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:03 --> Config Class Initialized
INFO - 2021-03-17 17:08:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:03 --> URI Class Initialized
INFO - 2021-03-17 17:08:03 --> Router Class Initialized
INFO - 2021-03-17 17:08:03 --> Output Class Initialized
INFO - 2021-03-17 17:08:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:03 --> Input Class Initialized
INFO - 2021-03-17 17:08:03 --> Language Class Initialized
ERROR - 2021-03-17 17:08:03 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:03 --> Config Class Initialized
INFO - 2021-03-17 17:08:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:03 --> URI Class Initialized
INFO - 2021-03-17 17:08:03 --> Router Class Initialized
INFO - 2021-03-17 17:08:03 --> Output Class Initialized
INFO - 2021-03-17 17:08:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:03 --> Input Class Initialized
INFO - 2021-03-17 17:08:03 --> Language Class Initialized
ERROR - 2021-03-17 17:08:03 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:03 --> Config Class Initialized
INFO - 2021-03-17 17:08:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:04 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:04 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:04 --> URI Class Initialized
INFO - 2021-03-17 17:08:04 --> Router Class Initialized
INFO - 2021-03-17 17:08:04 --> Output Class Initialized
INFO - 2021-03-17 17:08:04 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:04 --> Input Class Initialized
INFO - 2021-03-17 17:08:04 --> Language Class Initialized
ERROR - 2021-03-17 17:08:04 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:04 --> Config Class Initialized
INFO - 2021-03-17 17:08:04 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:04 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:04 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:04 --> URI Class Initialized
INFO - 2021-03-17 17:08:04 --> Router Class Initialized
INFO - 2021-03-17 17:08:04 --> Output Class Initialized
INFO - 2021-03-17 17:08:04 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:04 --> Input Class Initialized
INFO - 2021-03-17 17:08:04 --> Language Class Initialized
ERROR - 2021-03-17 17:08:04 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:04 --> Config Class Initialized
INFO - 2021-03-17 17:08:04 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:04 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:04 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:04 --> URI Class Initialized
INFO - 2021-03-17 17:08:04 --> Router Class Initialized
INFO - 2021-03-17 17:08:05 --> Output Class Initialized
INFO - 2021-03-17 17:08:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:05 --> Input Class Initialized
INFO - 2021-03-17 17:08:05 --> Language Class Initialized
ERROR - 2021-03-17 17:08:05 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:05 --> Config Class Initialized
INFO - 2021-03-17 17:08:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:05 --> URI Class Initialized
INFO - 2021-03-17 17:08:05 --> Router Class Initialized
INFO - 2021-03-17 17:08:05 --> Output Class Initialized
INFO - 2021-03-17 17:08:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:05 --> Input Class Initialized
INFO - 2021-03-17 17:08:05 --> Language Class Initialized
ERROR - 2021-03-17 17:08:05 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:05 --> Config Class Initialized
INFO - 2021-03-17 17:08:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:05 --> URI Class Initialized
INFO - 2021-03-17 17:08:05 --> Router Class Initialized
INFO - 2021-03-17 17:08:05 --> Output Class Initialized
INFO - 2021-03-17 17:08:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:05 --> Input Class Initialized
INFO - 2021-03-17 17:08:06 --> Language Class Initialized
ERROR - 2021-03-17 17:08:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:06 --> Config Class Initialized
INFO - 2021-03-17 17:08:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:06 --> URI Class Initialized
INFO - 2021-03-17 17:08:06 --> Router Class Initialized
INFO - 2021-03-17 17:08:06 --> Output Class Initialized
INFO - 2021-03-17 17:08:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:06 --> Input Class Initialized
INFO - 2021-03-17 17:08:06 --> Language Class Initialized
ERROR - 2021-03-17 17:08:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:06 --> Config Class Initialized
INFO - 2021-03-17 17:08:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:06 --> URI Class Initialized
INFO - 2021-03-17 17:08:06 --> Router Class Initialized
INFO - 2021-03-17 17:08:06 --> Output Class Initialized
INFO - 2021-03-17 17:08:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:06 --> Input Class Initialized
INFO - 2021-03-17 17:08:06 --> Language Class Initialized
ERROR - 2021-03-17 17:08:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:06 --> Config Class Initialized
INFO - 2021-03-17 17:08:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:07 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:07 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:07 --> URI Class Initialized
INFO - 2021-03-17 17:08:07 --> Router Class Initialized
INFO - 2021-03-17 17:08:07 --> Output Class Initialized
INFO - 2021-03-17 17:08:07 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:07 --> Input Class Initialized
INFO - 2021-03-17 17:08:07 --> Language Class Initialized
ERROR - 2021-03-17 17:08:07 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:07 --> Config Class Initialized
INFO - 2021-03-17 17:08:07 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:07 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:07 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:07 --> URI Class Initialized
INFO - 2021-03-17 17:08:07 --> Router Class Initialized
INFO - 2021-03-17 17:08:07 --> Output Class Initialized
INFO - 2021-03-17 17:08:07 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:07 --> Input Class Initialized
INFO - 2021-03-17 17:08:07 --> Language Class Initialized
ERROR - 2021-03-17 17:08:07 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:07 --> Config Class Initialized
INFO - 2021-03-17 17:08:07 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:07 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:07 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:07 --> URI Class Initialized
INFO - 2021-03-17 17:08:07 --> Router Class Initialized
INFO - 2021-03-17 17:08:07 --> Output Class Initialized
INFO - 2021-03-17 17:08:07 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:07 --> Input Class Initialized
INFO - 2021-03-17 17:08:07 --> Language Class Initialized
ERROR - 2021-03-17 17:08:07 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:07 --> Config Class Initialized
INFO - 2021-03-17 17:08:07 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:07 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:07 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:07 --> URI Class Initialized
INFO - 2021-03-17 17:08:08 --> Router Class Initialized
INFO - 2021-03-17 17:08:08 --> Output Class Initialized
INFO - 2021-03-17 17:08:08 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:08 --> Input Class Initialized
INFO - 2021-03-17 17:08:08 --> Language Class Initialized
ERROR - 2021-03-17 17:08:08 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:38 --> Config Class Initialized
INFO - 2021-03-17 17:08:38 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:38 --> URI Class Initialized
INFO - 2021-03-17 17:08:38 --> Router Class Initialized
INFO - 2021-03-17 17:08:38 --> Output Class Initialized
INFO - 2021-03-17 17:08:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:38 --> Input Class Initialized
INFO - 2021-03-17 17:08:38 --> Language Class Initialized
INFO - 2021-03-17 17:08:38 --> Loader Class Initialized
INFO - 2021-03-17 17:08:38 --> Helper loaded: url_helper
INFO - 2021-03-17 17:08:38 --> Helper loaded: file_helper
INFO - 2021-03-17 17:08:38 --> Helper loaded: form_helper
INFO - 2021-03-17 17:08:38 --> Helper loaded: text_helper
INFO - 2021-03-17 17:08:38 --> Helper loaded: security_helper
INFO - 2021-03-17 17:08:38 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:08:38 --> Database Driver Class Initialized
INFO - 2021-03-17 17:08:38 --> Email Class Initialized
DEBUG - 2021-03-17 17:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:08:38 --> Form Validation Class Initialized
INFO - 2021-03-17 17:08:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:08:38 --> Pagination Class Initialized
INFO - 2021-03-17 17:08:38 --> Model Class Initialized
INFO - 2021-03-17 17:08:38 --> Controller Class Initialized
INFO - 2021-03-17 17:08:38 --> Model Class Initialized
INFO - 2021-03-17 17:08:38 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:08:39 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:08:39 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:08:39 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:08:39 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:08:39 --> Final output sent to browser
DEBUG - 2021-03-17 17:08:39 --> Total execution time: 1.0690
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/css
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/css
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/font-awesome
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Img/a7.jpg
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Img/a4.jpg
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Img/profile.jpg
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/img
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Img/a5.jpg
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Img/a2.jpg
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Img/a3.jpg
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:39 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:39 --> URI Class Initialized
INFO - 2021-03-17 17:08:39 --> Router Class Initialized
INFO - 2021-03-17 17:08:39 --> Output Class Initialized
INFO - 2021-03-17 17:08:39 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:39 --> Input Class Initialized
INFO - 2021-03-17 17:08:39 --> Language Class Initialized
ERROR - 2021-03-17 17:08:39 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:39 --> Config Class Initialized
INFO - 2021-03-17 17:08:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:40 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:40 --> URI Class Initialized
INFO - 2021-03-17 17:08:40 --> Router Class Initialized
INFO - 2021-03-17 17:08:40 --> Output Class Initialized
INFO - 2021-03-17 17:08:40 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:40 --> Input Class Initialized
INFO - 2021-03-17 17:08:40 --> Language Class Initialized
ERROR - 2021-03-17 17:08:40 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:40 --> Config Class Initialized
INFO - 2021-03-17 17:08:40 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:40 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:40 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:40 --> URI Class Initialized
INFO - 2021-03-17 17:08:40 --> Router Class Initialized
INFO - 2021-03-17 17:08:40 --> Output Class Initialized
INFO - 2021-03-17 17:08:40 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:40 --> Input Class Initialized
INFO - 2021-03-17 17:08:40 --> Language Class Initialized
ERROR - 2021-03-17 17:08:40 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:40 --> Config Class Initialized
INFO - 2021-03-17 17:08:40 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:40 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:40 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:40 --> URI Class Initialized
INFO - 2021-03-17 17:08:40 --> Router Class Initialized
INFO - 2021-03-17 17:08:40 --> Output Class Initialized
INFO - 2021-03-17 17:08:40 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:40 --> Input Class Initialized
INFO - 2021-03-17 17:08:41 --> Language Class Initialized
ERROR - 2021-03-17 17:08:41 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:41 --> Config Class Initialized
INFO - 2021-03-17 17:08:41 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:41 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:41 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:41 --> URI Class Initialized
INFO - 2021-03-17 17:08:41 --> Router Class Initialized
INFO - 2021-03-17 17:08:41 --> Output Class Initialized
INFO - 2021-03-17 17:08:41 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:41 --> Input Class Initialized
INFO - 2021-03-17 17:08:41 --> Language Class Initialized
ERROR - 2021-03-17 17:08:41 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:41 --> Config Class Initialized
INFO - 2021-03-17 17:08:41 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:41 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:41 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:41 --> URI Class Initialized
INFO - 2021-03-17 17:08:41 --> Router Class Initialized
INFO - 2021-03-17 17:08:41 --> Output Class Initialized
INFO - 2021-03-17 17:08:41 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:41 --> Input Class Initialized
INFO - 2021-03-17 17:08:41 --> Language Class Initialized
ERROR - 2021-03-17 17:08:41 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:41 --> Config Class Initialized
INFO - 2021-03-17 17:08:41 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:41 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:41 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:41 --> URI Class Initialized
INFO - 2021-03-17 17:08:41 --> Router Class Initialized
INFO - 2021-03-17 17:08:41 --> Output Class Initialized
INFO - 2021-03-17 17:08:41 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:42 --> Input Class Initialized
INFO - 2021-03-17 17:08:42 --> Language Class Initialized
ERROR - 2021-03-17 17:08:42 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:42 --> Config Class Initialized
INFO - 2021-03-17 17:08:42 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:42 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:42 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:42 --> URI Class Initialized
INFO - 2021-03-17 17:08:42 --> Router Class Initialized
INFO - 2021-03-17 17:08:42 --> Output Class Initialized
INFO - 2021-03-17 17:08:42 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:42 --> Input Class Initialized
INFO - 2021-03-17 17:08:42 --> Language Class Initialized
ERROR - 2021-03-17 17:08:42 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:42 --> Config Class Initialized
INFO - 2021-03-17 17:08:42 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:42 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:42 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:42 --> URI Class Initialized
INFO - 2021-03-17 17:08:42 --> Router Class Initialized
INFO - 2021-03-17 17:08:42 --> Output Class Initialized
INFO - 2021-03-17 17:08:42 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:42 --> Input Class Initialized
INFO - 2021-03-17 17:08:42 --> Language Class Initialized
ERROR - 2021-03-17 17:08:42 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:42 --> Config Class Initialized
INFO - 2021-03-17 17:08:42 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:42 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:42 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:42 --> URI Class Initialized
INFO - 2021-03-17 17:08:43 --> Router Class Initialized
INFO - 2021-03-17 17:08:43 --> Output Class Initialized
INFO - 2021-03-17 17:08:43 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:43 --> Input Class Initialized
INFO - 2021-03-17 17:08:43 --> Language Class Initialized
ERROR - 2021-03-17 17:08:43 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:43 --> Config Class Initialized
INFO - 2021-03-17 17:08:43 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:43 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:43 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:43 --> URI Class Initialized
INFO - 2021-03-17 17:08:43 --> Router Class Initialized
INFO - 2021-03-17 17:08:43 --> Output Class Initialized
INFO - 2021-03-17 17:08:43 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:43 --> Input Class Initialized
INFO - 2021-03-17 17:08:43 --> Language Class Initialized
ERROR - 2021-03-17 17:08:43 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:43 --> Config Class Initialized
INFO - 2021-03-17 17:08:43 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:43 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:43 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:43 --> URI Class Initialized
INFO - 2021-03-17 17:08:43 --> Router Class Initialized
INFO - 2021-03-17 17:08:43 --> Output Class Initialized
INFO - 2021-03-17 17:08:43 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:43 --> Input Class Initialized
INFO - 2021-03-17 17:08:43 --> Language Class Initialized
ERROR - 2021-03-17 17:08:43 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:44 --> Config Class Initialized
INFO - 2021-03-17 17:08:44 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:44 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:44 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:44 --> URI Class Initialized
INFO - 2021-03-17 17:08:44 --> Router Class Initialized
INFO - 2021-03-17 17:08:44 --> Output Class Initialized
INFO - 2021-03-17 17:08:44 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:44 --> Input Class Initialized
INFO - 2021-03-17 17:08:44 --> Language Class Initialized
ERROR - 2021-03-17 17:08:44 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:44 --> Config Class Initialized
INFO - 2021-03-17 17:08:44 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:44 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:44 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:44 --> URI Class Initialized
INFO - 2021-03-17 17:08:44 --> Router Class Initialized
INFO - 2021-03-17 17:08:44 --> Output Class Initialized
INFO - 2021-03-17 17:08:44 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:44 --> Input Class Initialized
INFO - 2021-03-17 17:08:44 --> Language Class Initialized
ERROR - 2021-03-17 17:08:44 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:44 --> Config Class Initialized
INFO - 2021-03-17 17:08:44 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:44 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:44 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:44 --> URI Class Initialized
INFO - 2021-03-17 17:08:44 --> Router Class Initialized
INFO - 2021-03-17 17:08:44 --> Output Class Initialized
INFO - 2021-03-17 17:08:44 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:44 --> Input Class Initialized
INFO - 2021-03-17 17:08:45 --> Language Class Initialized
ERROR - 2021-03-17 17:08:45 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:45 --> Config Class Initialized
INFO - 2021-03-17 17:08:45 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:45 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:45 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:45 --> URI Class Initialized
INFO - 2021-03-17 17:08:45 --> Router Class Initialized
INFO - 2021-03-17 17:08:45 --> Output Class Initialized
INFO - 2021-03-17 17:08:45 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:45 --> Input Class Initialized
INFO - 2021-03-17 17:08:45 --> Language Class Initialized
ERROR - 2021-03-17 17:08:45 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:56 --> Config Class Initialized
INFO - 2021-03-17 17:08:56 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:56 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:56 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:56 --> URI Class Initialized
INFO - 2021-03-17 17:08:56 --> Router Class Initialized
INFO - 2021-03-17 17:08:56 --> Output Class Initialized
INFO - 2021-03-17 17:08:56 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:56 --> Input Class Initialized
INFO - 2021-03-17 17:08:56 --> Language Class Initialized
INFO - 2021-03-17 17:08:56 --> Loader Class Initialized
INFO - 2021-03-17 17:08:57 --> Helper loaded: url_helper
INFO - 2021-03-17 17:08:57 --> Helper loaded: file_helper
INFO - 2021-03-17 17:08:57 --> Helper loaded: form_helper
INFO - 2021-03-17 17:08:57 --> Helper loaded: text_helper
INFO - 2021-03-17 17:08:57 --> Helper loaded: security_helper
INFO - 2021-03-17 17:08:57 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:08:57 --> Database Driver Class Initialized
INFO - 2021-03-17 17:08:57 --> Email Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:08:57 --> Form Validation Class Initialized
INFO - 2021-03-17 17:08:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:08:57 --> Pagination Class Initialized
INFO - 2021-03-17 17:08:57 --> Model Class Initialized
INFO - 2021-03-17 17:08:57 --> Controller Class Initialized
INFO - 2021-03-17 17:08:57 --> Model Class Initialized
INFO - 2021-03-17 17:08:57 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:08:57 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:08:57 --> Final output sent to browser
DEBUG - 2021-03-17 17:08:57 --> Total execution time: 0.9385
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/font-awesome
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/css
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
INFO - 2021-03-17 17:08:57 --> URI Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Img/a2.jpg
INFO - 2021-03-17 17:08:57 --> Router Class Initialized
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Img/a4.jpg
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
INFO - 2021-03-17 17:08:57 --> Output Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Img/a5.jpg
INFO - 2021-03-17 17:08:57 --> Security Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Img/profile.jpg
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Img/a7.jpg
INFO - 2021-03-17 17:08:57 --> Config Class Initialized
DEBUG - 2021-03-17 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:57 --> Input Class Initialized
INFO - 2021-03-17 17:08:57 --> Language Class Initialized
ERROR - 2021-03-17 17:08:57 --> 404 Page Not Found: Img/a3.jpg
INFO - 2021-03-17 17:08:57 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:58 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:58 --> URI Class Initialized
INFO - 2021-03-17 17:08:58 --> Router Class Initialized
INFO - 2021-03-17 17:08:58 --> Output Class Initialized
INFO - 2021-03-17 17:08:58 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:58 --> Input Class Initialized
INFO - 2021-03-17 17:08:58 --> Language Class Initialized
ERROR - 2021-03-17 17:08:58 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:58 --> Config Class Initialized
INFO - 2021-03-17 17:08:58 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:58 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:58 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:58 --> URI Class Initialized
INFO - 2021-03-17 17:08:58 --> Router Class Initialized
INFO - 2021-03-17 17:08:58 --> Output Class Initialized
INFO - 2021-03-17 17:08:58 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:58 --> Input Class Initialized
INFO - 2021-03-17 17:08:58 --> Language Class Initialized
ERROR - 2021-03-17 17:08:58 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:58 --> Config Class Initialized
INFO - 2021-03-17 17:08:58 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:58 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:58 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:58 --> URI Class Initialized
INFO - 2021-03-17 17:08:59 --> Router Class Initialized
INFO - 2021-03-17 17:08:59 --> Output Class Initialized
INFO - 2021-03-17 17:08:59 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:59 --> Input Class Initialized
INFO - 2021-03-17 17:08:59 --> Language Class Initialized
ERROR - 2021-03-17 17:08:59 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:59 --> Config Class Initialized
INFO - 2021-03-17 17:08:59 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:59 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:59 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:59 --> URI Class Initialized
INFO - 2021-03-17 17:08:59 --> Router Class Initialized
INFO - 2021-03-17 17:08:59 --> Output Class Initialized
INFO - 2021-03-17 17:08:59 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:08:59 --> Input Class Initialized
INFO - 2021-03-17 17:08:59 --> Language Class Initialized
ERROR - 2021-03-17 17:08:59 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:08:59 --> Config Class Initialized
INFO - 2021-03-17 17:08:59 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:08:59 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:08:59 --> Utf8 Class Initialized
INFO - 2021-03-17 17:08:59 --> URI Class Initialized
INFO - 2021-03-17 17:08:59 --> Router Class Initialized
INFO - 2021-03-17 17:08:59 --> Output Class Initialized
INFO - 2021-03-17 17:08:59 --> Security Class Initialized
DEBUG - 2021-03-17 17:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:00 --> Input Class Initialized
INFO - 2021-03-17 17:09:00 --> Language Class Initialized
ERROR - 2021-03-17 17:09:00 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:09:00 --> Config Class Initialized
INFO - 2021-03-17 17:09:00 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:09:00 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:00 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:00 --> URI Class Initialized
INFO - 2021-03-17 17:09:00 --> Router Class Initialized
INFO - 2021-03-17 17:09:00 --> Output Class Initialized
INFO - 2021-03-17 17:09:00 --> Security Class Initialized
DEBUG - 2021-03-17 17:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:00 --> Input Class Initialized
INFO - 2021-03-17 17:09:00 --> Language Class Initialized
ERROR - 2021-03-17 17:09:00 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:09:00 --> Config Class Initialized
INFO - 2021-03-17 17:09:00 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:09:00 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:00 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:00 --> URI Class Initialized
INFO - 2021-03-17 17:09:00 --> Router Class Initialized
INFO - 2021-03-17 17:09:00 --> Output Class Initialized
INFO - 2021-03-17 17:09:00 --> Security Class Initialized
DEBUG - 2021-03-17 17:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:00 --> Input Class Initialized
INFO - 2021-03-17 17:09:00 --> Language Class Initialized
ERROR - 2021-03-17 17:09:00 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:09:00 --> Config Class Initialized
INFO - 2021-03-17 17:09:00 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:09:00 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:01 --> URI Class Initialized
INFO - 2021-03-17 17:09:01 --> Router Class Initialized
INFO - 2021-03-17 17:09:01 --> Output Class Initialized
INFO - 2021-03-17 17:09:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:01 --> Input Class Initialized
INFO - 2021-03-17 17:09:01 --> Language Class Initialized
ERROR - 2021-03-17 17:09:01 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:09:01 --> Config Class Initialized
INFO - 2021-03-17 17:09:01 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:09:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:01 --> URI Class Initialized
INFO - 2021-03-17 17:09:01 --> Router Class Initialized
INFO - 2021-03-17 17:09:01 --> Output Class Initialized
INFO - 2021-03-17 17:09:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:01 --> Input Class Initialized
INFO - 2021-03-17 17:09:01 --> Language Class Initialized
ERROR - 2021-03-17 17:09:01 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:09:01 --> Config Class Initialized
INFO - 2021-03-17 17:09:01 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:09:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:01 --> URI Class Initialized
INFO - 2021-03-17 17:09:01 --> Router Class Initialized
INFO - 2021-03-17 17:09:02 --> Output Class Initialized
INFO - 2021-03-17 17:09:02 --> Security Class Initialized
DEBUG - 2021-03-17 17:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:02 --> Input Class Initialized
INFO - 2021-03-17 17:09:02 --> Language Class Initialized
ERROR - 2021-03-17 17:09:02 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:09:02 --> Config Class Initialized
INFO - 2021-03-17 17:09:02 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:09:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:02 --> URI Class Initialized
INFO - 2021-03-17 17:09:02 --> Router Class Initialized
INFO - 2021-03-17 17:09:02 --> Output Class Initialized
INFO - 2021-03-17 17:09:02 --> Security Class Initialized
DEBUG - 2021-03-17 17:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:02 --> Input Class Initialized
INFO - 2021-03-17 17:09:02 --> Language Class Initialized
ERROR - 2021-03-17 17:09:02 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:09:02 --> Config Class Initialized
INFO - 2021-03-17 17:09:02 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:09:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:02 --> URI Class Initialized
INFO - 2021-03-17 17:09:02 --> Router Class Initialized
INFO - 2021-03-17 17:09:02 --> Output Class Initialized
INFO - 2021-03-17 17:09:02 --> Security Class Initialized
DEBUG - 2021-03-17 17:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:02 --> Input Class Initialized
INFO - 2021-03-17 17:09:03 --> Language Class Initialized
ERROR - 2021-03-17 17:09:03 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:09:03 --> Config Class Initialized
INFO - 2021-03-17 17:09:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:09:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:03 --> URI Class Initialized
INFO - 2021-03-17 17:09:03 --> Router Class Initialized
INFO - 2021-03-17 17:09:03 --> Output Class Initialized
INFO - 2021-03-17 17:09:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:03 --> Input Class Initialized
INFO - 2021-03-17 17:09:03 --> Language Class Initialized
ERROR - 2021-03-17 17:09:03 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:09:03 --> Config Class Initialized
INFO - 2021-03-17 17:09:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:09:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:03 --> URI Class Initialized
INFO - 2021-03-17 17:09:03 --> Router Class Initialized
INFO - 2021-03-17 17:09:03 --> Output Class Initialized
INFO - 2021-03-17 17:09:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:03 --> Input Class Initialized
INFO - 2021-03-17 17:09:03 --> Language Class Initialized
ERROR - 2021-03-17 17:09:03 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:09:03 --> Config Class Initialized
INFO - 2021-03-17 17:09:04 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:09:04 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:04 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:04 --> URI Class Initialized
INFO - 2021-03-17 17:09:04 --> Router Class Initialized
INFO - 2021-03-17 17:09:04 --> Output Class Initialized
INFO - 2021-03-17 17:09:04 --> Security Class Initialized
DEBUG - 2021-03-17 17:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:04 --> Input Class Initialized
INFO - 2021-03-17 17:09:04 --> Language Class Initialized
ERROR - 2021-03-17 17:09:04 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:09:04 --> Config Class Initialized
INFO - 2021-03-17 17:09:04 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:09:04 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:04 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:04 --> URI Class Initialized
INFO - 2021-03-17 17:09:04 --> Router Class Initialized
INFO - 2021-03-17 17:09:04 --> Output Class Initialized
INFO - 2021-03-17 17:09:04 --> Security Class Initialized
DEBUG - 2021-03-17 17:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:04 --> Input Class Initialized
INFO - 2021-03-17 17:09:04 --> Language Class Initialized
ERROR - 2021-03-17 17:09:04 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:09:04 --> Config Class Initialized
INFO - 2021-03-17 17:09:04 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:09:04 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:05 --> URI Class Initialized
INFO - 2021-03-17 17:09:05 --> Router Class Initialized
INFO - 2021-03-17 17:09:05 --> Output Class Initialized
INFO - 2021-03-17 17:09:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:05 --> Input Class Initialized
INFO - 2021-03-17 17:09:05 --> Language Class Initialized
ERROR - 2021-03-17 17:09:05 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:09:05 --> Config Class Initialized
INFO - 2021-03-17 17:09:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:09:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:05 --> URI Class Initialized
INFO - 2021-03-17 17:09:05 --> Router Class Initialized
INFO - 2021-03-17 17:09:05 --> Output Class Initialized
INFO - 2021-03-17 17:09:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:05 --> Input Class Initialized
INFO - 2021-03-17 17:09:05 --> Language Class Initialized
ERROR - 2021-03-17 17:09:05 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:09:46 --> Config Class Initialized
INFO - 2021-03-17 17:09:46 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:09:46 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:46 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:46 --> URI Class Initialized
INFO - 2021-03-17 17:09:46 --> Router Class Initialized
INFO - 2021-03-17 17:09:46 --> Output Class Initialized
INFO - 2021-03-17 17:09:46 --> Security Class Initialized
DEBUG - 2021-03-17 17:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:46 --> Input Class Initialized
INFO - 2021-03-17 17:09:47 --> Language Class Initialized
INFO - 2021-03-17 17:09:47 --> Loader Class Initialized
INFO - 2021-03-17 17:09:47 --> Helper loaded: url_helper
INFO - 2021-03-17 17:09:47 --> Helper loaded: file_helper
INFO - 2021-03-17 17:09:47 --> Helper loaded: form_helper
INFO - 2021-03-17 17:09:47 --> Helper loaded: text_helper
INFO - 2021-03-17 17:09:47 --> Helper loaded: security_helper
INFO - 2021-03-17 17:09:47 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:09:47 --> Database Driver Class Initialized
INFO - 2021-03-17 17:09:47 --> Email Class Initialized
DEBUG - 2021-03-17 17:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:09:47 --> Form Validation Class Initialized
INFO - 2021-03-17 17:09:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:09:47 --> Pagination Class Initialized
INFO - 2021-03-17 17:09:47 --> Model Class Initialized
INFO - 2021-03-17 17:09:47 --> Controller Class Initialized
INFO - 2021-03-17 17:09:47 --> Model Class Initialized
INFO - 2021-03-17 17:09:47 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:09:47 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-17 17:09:47 --> Final output sent to browser
DEBUG - 2021-03-17 17:09:47 --> Total execution time: 0.9449
INFO - 2021-03-17 17:09:47 --> Config Class Initialized
INFO - 2021-03-17 17:09:47 --> Config Class Initialized
INFO - 2021-03-17 17:09:47 --> Hooks Class Initialized
INFO - 2021-03-17 17:09:47 --> Config Class Initialized
INFO - 2021-03-17 17:09:47 --> Hooks Class Initialized
INFO - 2021-03-17 17:09:47 --> Config Class Initialized
INFO - 2021-03-17 17:09:47 --> Config Class Initialized
INFO - 2021-03-17 17:09:47 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:09:47 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:47 --> Hooks Class Initialized
INFO - 2021-03-17 17:09:47 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:47 --> URI Class Initialized
DEBUG - 2021-03-17 17:09:47 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:47 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:47 --> Config Class Initialized
DEBUG - 2021-03-17 17:09:47 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:47 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:47 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:09:47 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:47 --> Router Class Initialized
INFO - 2021-03-17 17:09:47 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:47 --> URI Class Initialized
INFO - 2021-03-17 17:09:47 --> URI Class Initialized
INFO - 2021-03-17 17:09:47 --> URI Class Initialized
INFO - 2021-03-17 17:09:47 --> Router Class Initialized
INFO - 2021-03-17 17:09:47 --> Output Class Initialized
INFO - 2021-03-17 17:09:47 --> Router Class Initialized
INFO - 2021-03-17 17:09:47 --> Router Class Initialized
INFO - 2021-03-17 17:09:47 --> Output Class Initialized
INFO - 2021-03-17 17:09:47 --> Security Class Initialized
INFO - 2021-03-17 17:09:47 --> Output Class Initialized
DEBUG - 2021-03-17 17:09:47 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:47 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:47 --> Output Class Initialized
INFO - 2021-03-17 17:09:47 --> Security Class Initialized
DEBUG - 2021-03-17 17:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:47 --> Input Class Initialized
INFO - 2021-03-17 17:09:47 --> Security Class Initialized
INFO - 2021-03-17 17:09:47 --> Language Class Initialized
INFO - 2021-03-17 17:09:47 --> URI Class Initialized
INFO - 2021-03-17 17:09:47 --> Security Class Initialized
DEBUG - 2021-03-17 17:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:47 --> Input Class Initialized
DEBUG - 2021-03-17 17:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:47 --> Input Class Initialized
ERROR - 2021-03-17 17:09:47 --> 404 Page Not Found: Adminassets/font-awesome
INFO - 2021-03-17 17:09:47 --> Language Class Initialized
INFO - 2021-03-17 17:09:47 --> Language Class Initialized
DEBUG - 2021-03-17 17:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:47 --> Input Class Initialized
INFO - 2021-03-17 17:09:47 --> Language Class Initialized
ERROR - 2021-03-17 17:09:47 --> 404 Page Not Found: Adminassets/css
ERROR - 2021-03-17 17:09:47 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:09:47 --> Router Class Initialized
ERROR - 2021-03-17 17:09:47 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:09:47 --> Output Class Initialized
INFO - 2021-03-17 17:09:47 --> Security Class Initialized
INFO - 2021-03-17 17:09:47 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:09:47 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:09:47 --> Utf8 Class Initialized
INFO - 2021-03-17 17:09:47 --> URI Class Initialized
INFO - 2021-03-17 17:09:47 --> Router Class Initialized
INFO - 2021-03-17 17:09:47 --> Output Class Initialized
INFO - 2021-03-17 17:09:47 --> Security Class Initialized
DEBUG - 2021-03-17 17:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:47 --> Input Class Initialized
INFO - 2021-03-17 17:09:47 --> Language Class Initialized
ERROR - 2021-03-17 17:09:47 --> 404 Page Not Found: Adminassets/css
DEBUG - 2021-03-17 17:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:09:47 --> Input Class Initialized
INFO - 2021-03-17 17:09:47 --> Language Class Initialized
ERROR - 2021-03-17 17:09:47 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:10:04 --> Config Class Initialized
INFO - 2021-03-17 17:10:04 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:10:04 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:10:04 --> Utf8 Class Initialized
INFO - 2021-03-17 17:10:04 --> URI Class Initialized
INFO - 2021-03-17 17:10:04 --> Router Class Initialized
INFO - 2021-03-17 17:10:04 --> Output Class Initialized
INFO - 2021-03-17 17:10:04 --> Security Class Initialized
DEBUG - 2021-03-17 17:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:10:04 --> Input Class Initialized
INFO - 2021-03-17 17:10:04 --> Language Class Initialized
INFO - 2021-03-17 17:10:04 --> Loader Class Initialized
INFO - 2021-03-17 17:10:04 --> Helper loaded: url_helper
INFO - 2021-03-17 17:10:04 --> Helper loaded: file_helper
INFO - 2021-03-17 17:10:04 --> Helper loaded: form_helper
INFO - 2021-03-17 17:10:04 --> Helper loaded: text_helper
INFO - 2021-03-17 17:10:04 --> Helper loaded: security_helper
INFO - 2021-03-17 17:10:04 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:10:04 --> Database Driver Class Initialized
INFO - 2021-03-17 17:10:04 --> Email Class Initialized
DEBUG - 2021-03-17 17:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:10:04 --> Form Validation Class Initialized
INFO - 2021-03-17 17:10:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:10:04 --> Pagination Class Initialized
INFO - 2021-03-17 17:10:04 --> Model Class Initialized
INFO - 2021-03-17 17:10:04 --> Controller Class Initialized
INFO - 2021-03-17 17:10:04 --> Model Class Initialized
INFO - 2021-03-17 17:10:05 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:10:05 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-17 17:10:05 --> Final output sent to browser
DEBUG - 2021-03-17 17:10:05 --> Total execution time: 1.1129
INFO - 2021-03-17 17:10:05 --> Config Class Initialized
INFO - 2021-03-17 17:10:05 --> Config Class Initialized
INFO - 2021-03-17 17:10:05 --> Hooks Class Initialized
INFO - 2021-03-17 17:10:05 --> Config Class Initialized
INFO - 2021-03-17 17:10:05 --> Hooks Class Initialized
INFO - 2021-03-17 17:10:05 --> Config Class Initialized
INFO - 2021-03-17 17:10:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:10:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:10:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:10:05 --> Config Class Initialized
INFO - 2021-03-17 17:10:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:10:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:10:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:10:05 --> URI Class Initialized
INFO - 2021-03-17 17:10:05 --> URI Class Initialized
INFO - 2021-03-17 17:10:05 --> Router Class Initialized
DEBUG - 2021-03-17 17:10:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:10:05 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:10:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:10:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:10:05 --> Router Class Initialized
INFO - 2021-03-17 17:10:05 --> URI Class Initialized
INFO - 2021-03-17 17:10:05 --> Output Class Initialized
INFO - 2021-03-17 17:10:05 --> URI Class Initialized
INFO - 2021-03-17 17:10:05 --> Config Class Initialized
INFO - 2021-03-17 17:10:05 --> Hooks Class Initialized
INFO - 2021-03-17 17:10:05 --> Output Class Initialized
INFO - 2021-03-17 17:10:05 --> Router Class Initialized
INFO - 2021-03-17 17:10:05 --> Router Class Initialized
INFO - 2021-03-17 17:10:05 --> Security Class Initialized
INFO - 2021-03-17 17:10:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:10:05 --> Input Class Initialized
INFO - 2021-03-17 17:10:05 --> Output Class Initialized
INFO - 2021-03-17 17:10:05 --> Output Class Initialized
INFO - 2021-03-17 17:10:05 --> Language Class Initialized
DEBUG - 2021-03-17 17:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:10:05 --> Input Class Initialized
INFO - 2021-03-17 17:10:05 --> Security Class Initialized
INFO - 2021-03-17 17:10:05 --> Language Class Initialized
ERROR - 2021-03-17 17:10:05 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:10:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:10:05 --> Input Class Initialized
DEBUG - 2021-03-17 17:10:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:10:05 --> Utf8 Class Initialized
ERROR - 2021-03-17 17:10:05 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:10:05 --> Language Class Initialized
DEBUG - 2021-03-17 17:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:10:05 --> Input Class Initialized
INFO - 2021-03-17 17:10:05 --> URI Class Initialized
INFO - 2021-03-17 17:10:05 --> Language Class Initialized
ERROR - 2021-03-17 17:10:05 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:10:05 --> Hooks Class Initialized
INFO - 2021-03-17 17:10:05 --> Router Class Initialized
INFO - 2021-03-17 17:10:05 --> Output Class Initialized
DEBUG - 2021-03-17 17:10:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:10:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:10:05 --> Security Class Initialized
INFO - 2021-03-17 17:10:05 --> URI Class Initialized
DEBUG - 2021-03-17 17:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:10:05 --> Input Class Initialized
INFO - 2021-03-17 17:10:05 --> Router Class Initialized
INFO - 2021-03-17 17:10:05 --> Language Class Initialized
ERROR - 2021-03-17 17:10:05 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:10:05 --> Output Class Initialized
INFO - 2021-03-17 17:10:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:10:05 --> Input Class Initialized
INFO - 2021-03-17 17:10:05 --> Language Class Initialized
ERROR - 2021-03-17 17:10:05 --> 404 Page Not Found: Adminassets/css
ERROR - 2021-03-17 17:10:05 --> 404 Page Not Found: Adminassets/font-awesome
INFO - 2021-03-17 17:10:27 --> Config Class Initialized
INFO - 2021-03-17 17:10:27 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:10:27 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:10:27 --> Utf8 Class Initialized
INFO - 2021-03-17 17:10:28 --> URI Class Initialized
INFO - 2021-03-17 17:10:28 --> Router Class Initialized
INFO - 2021-03-17 17:10:28 --> Output Class Initialized
INFO - 2021-03-17 17:10:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:10:28 --> Input Class Initialized
INFO - 2021-03-17 17:10:28 --> Language Class Initialized
INFO - 2021-03-17 17:10:28 --> Loader Class Initialized
INFO - 2021-03-17 17:10:28 --> Helper loaded: url_helper
INFO - 2021-03-17 17:10:28 --> Helper loaded: file_helper
INFO - 2021-03-17 17:10:28 --> Helper loaded: form_helper
INFO - 2021-03-17 17:10:28 --> Helper loaded: text_helper
INFO - 2021-03-17 17:10:28 --> Helper loaded: security_helper
INFO - 2021-03-17 17:10:28 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:10:28 --> Database Driver Class Initialized
INFO - 2021-03-17 17:10:28 --> Email Class Initialized
DEBUG - 2021-03-17 17:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:10:28 --> Form Validation Class Initialized
INFO - 2021-03-17 17:10:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:10:28 --> Pagination Class Initialized
INFO - 2021-03-17 17:10:28 --> Model Class Initialized
INFO - 2021-03-17 17:10:28 --> Controller Class Initialized
INFO - 2021-03-17 17:10:28 --> Model Class Initialized
INFO - 2021-03-17 17:10:28 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:10:28 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-17 17:10:29 --> Final output sent to browser
DEBUG - 2021-03-17 17:10:29 --> Total execution time: 1.1663
INFO - 2021-03-17 17:10:29 --> Config Class Initialized
INFO - 2021-03-17 17:10:29 --> Config Class Initialized
INFO - 2021-03-17 17:10:29 --> Hooks Class Initialized
INFO - 2021-03-17 17:10:29 --> Config Class Initialized
INFO - 2021-03-17 17:10:29 --> Hooks Class Initialized
INFO - 2021-03-17 17:10:29 --> Config Class Initialized
INFO - 2021-03-17 17:10:29 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:10:29 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:10:29 --> Utf8 Class Initialized
INFO - 2021-03-17 17:10:29 --> URI Class Initialized
DEBUG - 2021-03-17 17:10:29 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:10:29 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:10:29 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:10:29 --> Router Class Initialized
INFO - 2021-03-17 17:10:29 --> Utf8 Class Initialized
INFO - 2021-03-17 17:10:29 --> Config Class Initialized
INFO - 2021-03-17 17:10:29 --> URI Class Initialized
INFO - 2021-03-17 17:10:29 --> Hooks Class Initialized
INFO - 2021-03-17 17:10:29 --> URI Class Initialized
INFO - 2021-03-17 17:10:29 --> Output Class Initialized
INFO - 2021-03-17 17:10:29 --> Router Class Initialized
INFO - 2021-03-17 17:10:29 --> Router Class Initialized
INFO - 2021-03-17 17:10:29 --> Security Class Initialized
INFO - 2021-03-17 17:10:29 --> Output Class Initialized
DEBUG - 2021-03-17 17:10:29 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:10:29 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:10:29 --> Security Class Initialized
INFO - 2021-03-17 17:10:29 --> Output Class Initialized
INFO - 2021-03-17 17:10:29 --> Input Class Initialized
INFO - 2021-03-17 17:10:29 --> URI Class Initialized
INFO - 2021-03-17 17:10:29 --> Language Class Initialized
DEBUG - 2021-03-17 17:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:10:29 --> Input Class Initialized
INFO - 2021-03-17 17:10:29 --> Security Class Initialized
INFO - 2021-03-17 17:10:29 --> Config Class Initialized
INFO - 2021-03-17 17:10:29 --> Hooks Class Initialized
INFO - 2021-03-17 17:10:29 --> Language Class Initialized
ERROR - 2021-03-17 17:10:29 --> 404 Page Not Found: Adminassets/font-awesome
INFO - 2021-03-17 17:10:29 --> Router Class Initialized
DEBUG - 2021-03-17 17:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:10:29 --> Input Class Initialized
ERROR - 2021-03-17 17:10:29 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:10:29 --> Language Class Initialized
DEBUG - 2021-03-17 17:10:29 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:10:29 --> Utf8 Class Initialized
INFO - 2021-03-17 17:10:29 --> Output Class Initialized
ERROR - 2021-03-17 17:10:29 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:10:29 --> URI Class Initialized
INFO - 2021-03-17 17:10:29 --> Security Class Initialized
INFO - 2021-03-17 17:10:29 --> Hooks Class Initialized
INFO - 2021-03-17 17:10:29 --> Router Class Initialized
DEBUG - 2021-03-17 17:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:10:29 --> Input Class Initialized
INFO - 2021-03-17 17:10:29 --> Language Class Initialized
INFO - 2021-03-17 17:10:29 --> Output Class Initialized
ERROR - 2021-03-17 17:10:29 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:10:29 --> Security Class Initialized
DEBUG - 2021-03-17 17:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:10:29 --> Input Class Initialized
INFO - 2021-03-17 17:10:29 --> Language Class Initialized
ERROR - 2021-03-17 17:10:29 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:10:29 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:10:29 --> Utf8 Class Initialized
INFO - 2021-03-17 17:10:29 --> URI Class Initialized
INFO - 2021-03-17 17:10:29 --> Router Class Initialized
INFO - 2021-03-17 17:10:29 --> Output Class Initialized
INFO - 2021-03-17 17:10:29 --> Security Class Initialized
DEBUG - 2021-03-17 17:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:10:29 --> Input Class Initialized
INFO - 2021-03-17 17:10:29 --> Language Class Initialized
ERROR - 2021-03-17 17:10:29 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:11:04 --> Config Class Initialized
INFO - 2021-03-17 17:11:04 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:04 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:04 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:04 --> URI Class Initialized
INFO - 2021-03-17 17:11:04 --> Router Class Initialized
INFO - 2021-03-17 17:11:04 --> Output Class Initialized
INFO - 2021-03-17 17:11:04 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:04 --> Input Class Initialized
INFO - 2021-03-17 17:11:04 --> Language Class Initialized
INFO - 2021-03-17 17:11:04 --> Loader Class Initialized
INFO - 2021-03-17 17:11:04 --> Helper loaded: url_helper
INFO - 2021-03-17 17:11:04 --> Helper loaded: file_helper
INFO - 2021-03-17 17:11:04 --> Helper loaded: form_helper
INFO - 2021-03-17 17:11:04 --> Helper loaded: text_helper
INFO - 2021-03-17 17:11:04 --> Helper loaded: security_helper
INFO - 2021-03-17 17:11:05 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:11:05 --> Database Driver Class Initialized
INFO - 2021-03-17 17:11:05 --> Email Class Initialized
DEBUG - 2021-03-17 17:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:11:05 --> Form Validation Class Initialized
INFO - 2021-03-17 17:11:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:11:05 --> Pagination Class Initialized
INFO - 2021-03-17 17:11:05 --> Model Class Initialized
INFO - 2021-03-17 17:11:05 --> Controller Class Initialized
INFO - 2021-03-17 17:11:05 --> Model Class Initialized
INFO - 2021-03-17 17:11:05 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:11:05 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:11:05 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:11:05 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-17 17:11:05 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:11:05 --> Final output sent to browser
DEBUG - 2021-03-17 17:11:05 --> Total execution time: 1.2619
INFO - 2021-03-17 17:11:05 --> Config Class Initialized
INFO - 2021-03-17 17:11:05 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:05 --> Config Class Initialized
INFO - 2021-03-17 17:11:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:05 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:11:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:05 --> URI Class Initialized
INFO - 2021-03-17 17:11:05 --> URI Class Initialized
INFO - 2021-03-17 17:11:05 --> Router Class Initialized
INFO - 2021-03-17 17:11:05 --> Router Class Initialized
INFO - 2021-03-17 17:11:05 --> Output Class Initialized
INFO - 2021-03-17 17:11:05 --> Output Class Initialized
INFO - 2021-03-17 17:11:05 --> Security Class Initialized
INFO - 2021-03-17 17:11:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:05 --> Input Class Initialized
INFO - 2021-03-17 17:11:05 --> Language Class Initialized
INFO - 2021-03-17 17:11:05 --> Config Class Initialized
ERROR - 2021-03-17 17:11:05 --> 404 Page Not Found: Adminassets/font-awesome
INFO - 2021-03-17 17:11:05 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:05 --> Config Class Initialized
INFO - 2021-03-17 17:11:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:05 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:11:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:05 --> Config Class Initialized
INFO - 2021-03-17 17:11:05 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:05 --> URI Class Initialized
INFO - 2021-03-17 17:11:05 --> URI Class Initialized
INFO - 2021-03-17 17:11:05 --> Router Class Initialized
INFO - 2021-03-17 17:11:05 --> Router Class Initialized
DEBUG - 2021-03-17 17:11:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:05 --> URI Class Initialized
INFO - 2021-03-17 17:11:05 --> Output Class Initialized
INFO - 2021-03-17 17:11:05 --> Output Class Initialized
INFO - 2021-03-17 17:11:05 --> Config Class Initialized
INFO - 2021-03-17 17:11:05 --> Router Class Initialized
INFO - 2021-03-17 17:11:05 --> Security Class Initialized
INFO - 2021-03-17 17:11:05 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:05 --> Security Class Initialized
INFO - 2021-03-17 17:11:05 --> Config Class Initialized
INFO - 2021-03-17 17:11:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:05 --> Input Class Initialized
INFO - 2021-03-17 17:11:05 --> Output Class Initialized
DEBUG - 2021-03-17 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:05 --> Language Class Initialized
INFO - 2021-03-17 17:11:05 --> Input Class Initialized
DEBUG - 2021-03-17 17:11:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:05 --> Security Class Initialized
INFO - 2021-03-17 17:11:05 --> Language Class Initialized
ERROR - 2021-03-17 17:11:05 --> 404 Page Not Found: Adminassets/css
DEBUG - 2021-03-17 17:11:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:05 --> URI Class Initialized
DEBUG - 2021-03-17 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:05 --> Input Class Initialized
INFO - 2021-03-17 17:11:05 --> URI Class Initialized
INFO - 2021-03-17 17:11:05 --> Language Class Initialized
ERROR - 2021-03-17 17:11:05 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:11:05 --> Router Class Initialized
ERROR - 2021-03-17 17:11:05 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:05 --> Router Class Initialized
DEBUG - 2021-03-17 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:05 --> Output Class Initialized
INFO - 2021-03-17 17:11:05 --> Input Class Initialized
INFO - 2021-03-17 17:11:05 --> Language Class Initialized
INFO - 2021-03-17 17:11:05 --> Output Class Initialized
INFO - 2021-03-17 17:11:05 --> Security Class Initialized
ERROR - 2021-03-17 17:11:05 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:11:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:05 --> Input Class Initialized
INFO - 2021-03-17 17:11:05 --> Language Class Initialized
DEBUG - 2021-03-17 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:05 --> Input Class Initialized
INFO - 2021-03-17 17:11:05 --> Language Class Initialized
ERROR - 2021-03-17 17:11:05 --> 404 Page Not Found: Adminassets/img
ERROR - 2021-03-17 17:11:05 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:11:05 --> Config Class Initialized
INFO - 2021-03-17 17:11:05 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:05 --> Config Class Initialized
INFO - 2021-03-17 17:11:05 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:05 --> Config Class Initialized
INFO - 2021-03-17 17:11:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:05 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:11:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:05 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:11:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:05 --> URI Class Initialized
INFO - 2021-03-17 17:11:05 --> URI Class Initialized
INFO - 2021-03-17 17:11:05 --> Config Class Initialized
INFO - 2021-03-17 17:11:05 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:05 --> Router Class Initialized
INFO - 2021-03-17 17:11:05 --> Router Class Initialized
DEBUG - 2021-03-17 17:11:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:05 --> Output Class Initialized
INFO - 2021-03-17 17:11:05 --> Output Class Initialized
INFO - 2021-03-17 17:11:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:05 --> URI Class Initialized
INFO - 2021-03-17 17:11:05 --> Security Class Initialized
INFO - 2021-03-17 17:11:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:05 --> Input Class Initialized
DEBUG - 2021-03-17 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:05 --> Router Class Initialized
INFO - 2021-03-17 17:11:05 --> Input Class Initialized
INFO - 2021-03-17 17:11:05 --> Language Class Initialized
INFO - 2021-03-17 17:11:05 --> Language Class Initialized
ERROR - 2021-03-17 17:11:05 --> 404 Page Not Found: Img/a4.jpg
INFO - 2021-03-17 17:11:05 --> Output Class Initialized
ERROR - 2021-03-17 17:11:05 --> 404 Page Not Found: Img/a7.jpg
INFO - 2021-03-17 17:11:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:05 --> Input Class Initialized
INFO - 2021-03-17 17:11:05 --> Language Class Initialized
ERROR - 2021-03-17 17:11:05 --> 404 Page Not Found: Img/a2.jpg
INFO - 2021-03-17 17:11:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:05 --> Config Class Initialized
INFO - 2021-03-17 17:11:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:05 --> URI Class Initialized
INFO - 2021-03-17 17:11:05 --> Router Class Initialized
INFO - 2021-03-17 17:11:05 --> Output Class Initialized
INFO - 2021-03-17 17:11:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:05 --> Input Class Initialized
INFO - 2021-03-17 17:11:05 --> Language Class Initialized
INFO - 2021-03-17 17:11:05 --> Config Class Initialized
INFO - 2021-03-17 17:11:05 --> Hooks Class Initialized
ERROR - 2021-03-17 17:11:05 --> 404 Page Not Found: Img/a3.jpg
DEBUG - 2021-03-17 17:11:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:05 --> URI Class Initialized
INFO - 2021-03-17 17:11:05 --> Router Class Initialized
INFO - 2021-03-17 17:11:05 --> Output Class Initialized
INFO - 2021-03-17 17:11:05 --> URI Class Initialized
INFO - 2021-03-17 17:11:05 --> Router Class Initialized
INFO - 2021-03-17 17:11:05 --> Output Class Initialized
INFO - 2021-03-17 17:11:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:05 --> Input Class Initialized
INFO - 2021-03-17 17:11:05 --> Language Class Initialized
ERROR - 2021-03-17 17:11:05 --> 404 Page Not Found: Img/profile.jpg
INFO - 2021-03-17 17:11:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:05 --> Input Class Initialized
INFO - 2021-03-17 17:11:06 --> Language Class Initialized
ERROR - 2021-03-17 17:11:06 --> 404 Page Not Found: Img/a5.jpg
INFO - 2021-03-17 17:11:27 --> Config Class Initialized
INFO - 2021-03-17 17:11:27 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:27 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:27 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:27 --> URI Class Initialized
INFO - 2021-03-17 17:11:27 --> Router Class Initialized
INFO - 2021-03-17 17:11:27 --> Output Class Initialized
INFO - 2021-03-17 17:11:27 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:27 --> Input Class Initialized
INFO - 2021-03-17 17:11:27 --> Language Class Initialized
INFO - 2021-03-17 17:11:27 --> Loader Class Initialized
INFO - 2021-03-17 17:11:27 --> Helper loaded: url_helper
INFO - 2021-03-17 17:11:27 --> Helper loaded: file_helper
INFO - 2021-03-17 17:11:27 --> Helper loaded: form_helper
INFO - 2021-03-17 17:11:27 --> Helper loaded: text_helper
INFO - 2021-03-17 17:11:27 --> Helper loaded: security_helper
INFO - 2021-03-17 17:11:27 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:11:27 --> Database Driver Class Initialized
INFO - 2021-03-17 17:11:27 --> Email Class Initialized
DEBUG - 2021-03-17 17:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:11:27 --> Form Validation Class Initialized
INFO - 2021-03-17 17:11:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:11:27 --> Pagination Class Initialized
INFO - 2021-03-17 17:11:27 --> Model Class Initialized
INFO - 2021-03-17 17:11:27 --> Controller Class Initialized
INFO - 2021-03-17 17:11:28 --> Model Class Initialized
INFO - 2021-03-17 17:11:28 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:11:28 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:11:28 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:11:28 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:11:28 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:11:28 --> Final output sent to browser
DEBUG - 2021-03-17 17:11:28 --> Total execution time: 1.1893
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/css
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/font-awesome
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/img
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Img/a7.jpg
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Img/a4.jpg
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Img/profile.jpg
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Img/a2.jpg
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/css
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Img/a5.jpg
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:28 --> Output Class Initialized
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:28 --> Input Class Initialized
INFO - 2021-03-17 17:11:28 --> Language Class Initialized
ERROR - 2021-03-17 17:11:28 --> 404 Page Not Found: Img/a3.jpg
INFO - 2021-03-17 17:11:28 --> Config Class Initialized
INFO - 2021-03-17 17:11:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:28 --> URI Class Initialized
INFO - 2021-03-17 17:11:28 --> Router Class Initialized
INFO - 2021-03-17 17:11:29 --> Output Class Initialized
INFO - 2021-03-17 17:11:29 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:29 --> Input Class Initialized
INFO - 2021-03-17 17:11:29 --> Language Class Initialized
ERROR - 2021-03-17 17:11:29 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:29 --> Config Class Initialized
INFO - 2021-03-17 17:11:29 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:29 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:29 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:29 --> URI Class Initialized
INFO - 2021-03-17 17:11:29 --> Router Class Initialized
INFO - 2021-03-17 17:11:29 --> Output Class Initialized
INFO - 2021-03-17 17:11:29 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:29 --> Input Class Initialized
INFO - 2021-03-17 17:11:29 --> Language Class Initialized
ERROR - 2021-03-17 17:11:29 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:29 --> Config Class Initialized
INFO - 2021-03-17 17:11:29 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:29 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:29 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:29 --> URI Class Initialized
INFO - 2021-03-17 17:11:29 --> Router Class Initialized
INFO - 2021-03-17 17:11:29 --> Output Class Initialized
INFO - 2021-03-17 17:11:29 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:30 --> Input Class Initialized
INFO - 2021-03-17 17:11:30 --> Language Class Initialized
ERROR - 2021-03-17 17:11:30 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:30 --> Config Class Initialized
INFO - 2021-03-17 17:11:30 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:30 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:30 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:30 --> URI Class Initialized
INFO - 2021-03-17 17:11:30 --> Router Class Initialized
INFO - 2021-03-17 17:11:30 --> Output Class Initialized
INFO - 2021-03-17 17:11:30 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:30 --> Input Class Initialized
INFO - 2021-03-17 17:11:30 --> Language Class Initialized
ERROR - 2021-03-17 17:11:30 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:30 --> Config Class Initialized
INFO - 2021-03-17 17:11:30 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:30 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:30 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:30 --> URI Class Initialized
INFO - 2021-03-17 17:11:30 --> Router Class Initialized
INFO - 2021-03-17 17:11:30 --> Output Class Initialized
INFO - 2021-03-17 17:11:30 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:31 --> Input Class Initialized
INFO - 2021-03-17 17:11:31 --> Language Class Initialized
ERROR - 2021-03-17 17:11:31 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:31 --> Config Class Initialized
INFO - 2021-03-17 17:11:31 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:31 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:31 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:31 --> URI Class Initialized
INFO - 2021-03-17 17:11:31 --> Router Class Initialized
INFO - 2021-03-17 17:11:31 --> Output Class Initialized
INFO - 2021-03-17 17:11:31 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:31 --> Input Class Initialized
INFO - 2021-03-17 17:11:31 --> Language Class Initialized
ERROR - 2021-03-17 17:11:31 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:31 --> Config Class Initialized
INFO - 2021-03-17 17:11:31 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:31 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:31 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:31 --> URI Class Initialized
INFO - 2021-03-17 17:11:31 --> Router Class Initialized
INFO - 2021-03-17 17:11:31 --> Output Class Initialized
INFO - 2021-03-17 17:11:31 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:32 --> Input Class Initialized
INFO - 2021-03-17 17:11:32 --> Language Class Initialized
ERROR - 2021-03-17 17:11:32 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:32 --> Config Class Initialized
INFO - 2021-03-17 17:11:32 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:32 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:32 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:32 --> URI Class Initialized
INFO - 2021-03-17 17:11:32 --> Router Class Initialized
INFO - 2021-03-17 17:11:32 --> Output Class Initialized
INFO - 2021-03-17 17:11:32 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:32 --> Input Class Initialized
INFO - 2021-03-17 17:11:32 --> Language Class Initialized
ERROR - 2021-03-17 17:11:32 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:32 --> Config Class Initialized
INFO - 2021-03-17 17:11:32 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:32 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:32 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:32 --> URI Class Initialized
INFO - 2021-03-17 17:11:32 --> Router Class Initialized
INFO - 2021-03-17 17:11:32 --> Output Class Initialized
INFO - 2021-03-17 17:11:32 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:32 --> Input Class Initialized
INFO - 2021-03-17 17:11:33 --> Language Class Initialized
ERROR - 2021-03-17 17:11:33 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:33 --> Config Class Initialized
INFO - 2021-03-17 17:11:33 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:33 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:33 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:33 --> URI Class Initialized
INFO - 2021-03-17 17:11:33 --> Router Class Initialized
INFO - 2021-03-17 17:11:33 --> Output Class Initialized
INFO - 2021-03-17 17:11:33 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:33 --> Input Class Initialized
INFO - 2021-03-17 17:11:33 --> Language Class Initialized
ERROR - 2021-03-17 17:11:33 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:33 --> Config Class Initialized
INFO - 2021-03-17 17:11:33 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:33 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:33 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:33 --> URI Class Initialized
INFO - 2021-03-17 17:11:33 --> Router Class Initialized
INFO - 2021-03-17 17:11:33 --> Output Class Initialized
INFO - 2021-03-17 17:11:33 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:33 --> Input Class Initialized
INFO - 2021-03-17 17:11:33 --> Language Class Initialized
ERROR - 2021-03-17 17:11:34 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:34 --> Config Class Initialized
INFO - 2021-03-17 17:11:34 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:34 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:34 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:34 --> URI Class Initialized
INFO - 2021-03-17 17:11:34 --> Router Class Initialized
INFO - 2021-03-17 17:11:34 --> Output Class Initialized
INFO - 2021-03-17 17:11:34 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:34 --> Input Class Initialized
INFO - 2021-03-17 17:11:34 --> Language Class Initialized
ERROR - 2021-03-17 17:11:34 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:34 --> Config Class Initialized
INFO - 2021-03-17 17:11:34 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:34 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:34 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:34 --> URI Class Initialized
INFO - 2021-03-17 17:11:34 --> Router Class Initialized
INFO - 2021-03-17 17:11:34 --> Output Class Initialized
INFO - 2021-03-17 17:11:34 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:34 --> Input Class Initialized
INFO - 2021-03-17 17:11:34 --> Language Class Initialized
ERROR - 2021-03-17 17:11:34 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:34 --> Config Class Initialized
INFO - 2021-03-17 17:11:35 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:35 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:35 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:35 --> URI Class Initialized
INFO - 2021-03-17 17:11:35 --> Router Class Initialized
INFO - 2021-03-17 17:11:35 --> Output Class Initialized
INFO - 2021-03-17 17:11:35 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:35 --> Input Class Initialized
INFO - 2021-03-17 17:11:35 --> Language Class Initialized
ERROR - 2021-03-17 17:11:35 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:35 --> Config Class Initialized
INFO - 2021-03-17 17:11:35 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:35 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:35 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:35 --> URI Class Initialized
INFO - 2021-03-17 17:11:35 --> Router Class Initialized
INFO - 2021-03-17 17:11:35 --> Output Class Initialized
INFO - 2021-03-17 17:11:35 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:35 --> Input Class Initialized
INFO - 2021-03-17 17:11:35 --> Language Class Initialized
ERROR - 2021-03-17 17:11:35 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:35 --> Config Class Initialized
INFO - 2021-03-17 17:11:35 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:36 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:36 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:36 --> URI Class Initialized
INFO - 2021-03-17 17:11:36 --> Router Class Initialized
INFO - 2021-03-17 17:11:36 --> Output Class Initialized
INFO - 2021-03-17 17:11:36 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:36 --> Input Class Initialized
INFO - 2021-03-17 17:11:36 --> Language Class Initialized
ERROR - 2021-03-17 17:11:36 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:11:36 --> Config Class Initialized
INFO - 2021-03-17 17:11:36 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:11:36 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:11:36 --> Utf8 Class Initialized
INFO - 2021-03-17 17:11:36 --> URI Class Initialized
INFO - 2021-03-17 17:11:36 --> Router Class Initialized
INFO - 2021-03-17 17:11:36 --> Output Class Initialized
INFO - 2021-03-17 17:11:36 --> Security Class Initialized
DEBUG - 2021-03-17 17:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:11:36 --> Input Class Initialized
INFO - 2021-03-17 17:11:36 --> Language Class Initialized
ERROR - 2021-03-17 17:11:36 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:12:01 --> Config Class Initialized
INFO - 2021-03-17 17:12:01 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:01 --> URI Class Initialized
INFO - 2021-03-17 17:12:01 --> Router Class Initialized
INFO - 2021-03-17 17:12:01 --> Output Class Initialized
INFO - 2021-03-17 17:12:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:01 --> Input Class Initialized
INFO - 2021-03-17 17:12:01 --> Language Class Initialized
INFO - 2021-03-17 17:12:02 --> Loader Class Initialized
INFO - 2021-03-17 17:12:02 --> Helper loaded: url_helper
INFO - 2021-03-17 17:12:02 --> Helper loaded: file_helper
INFO - 2021-03-17 17:12:02 --> Helper loaded: form_helper
INFO - 2021-03-17 17:12:02 --> Helper loaded: text_helper
INFO - 2021-03-17 17:12:02 --> Helper loaded: security_helper
INFO - 2021-03-17 17:12:02 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:12:02 --> Database Driver Class Initialized
INFO - 2021-03-17 17:12:02 --> Email Class Initialized
DEBUG - 2021-03-17 17:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:12:02 --> Form Validation Class Initialized
INFO - 2021-03-17 17:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:12:02 --> Pagination Class Initialized
INFO - 2021-03-17 17:12:02 --> Model Class Initialized
INFO - 2021-03-17 17:12:02 --> Controller Class Initialized
INFO - 2021-03-17 17:12:02 --> Model Class Initialized
INFO - 2021-03-17 17:12:02 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:12:02 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:12:02 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:12:02 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:12:02 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:12:02 --> Final output sent to browser
DEBUG - 2021-03-17 17:12:02 --> Total execution time: 1.2244
INFO - 2021-03-17 17:12:02 --> Config Class Initialized
INFO - 2021-03-17 17:12:02 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:02 --> Config Class Initialized
INFO - 2021-03-17 17:12:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:02 --> Config Class Initialized
INFO - 2021-03-17 17:12:02 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:02 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:02 --> Config Class Initialized
INFO - 2021-03-17 17:12:02 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:02 --> Config Class Initialized
INFO - 2021-03-17 17:12:02 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:02 --> URI Class Initialized
INFO - 2021-03-17 17:12:02 --> Router Class Initialized
DEBUG - 2021-03-17 17:12:02 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:12:02 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:12:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:02 --> Output Class Initialized
INFO - 2021-03-17 17:12:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:02 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:12:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:02 --> URI Class Initialized
INFO - 2021-03-17 17:12:02 --> Security Class Initialized
INFO - 2021-03-17 17:12:02 --> URI Class Initialized
INFO - 2021-03-17 17:12:02 --> Router Class Initialized
DEBUG - 2021-03-17 17:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:02 --> Input Class Initialized
INFO - 2021-03-17 17:12:02 --> Router Class Initialized
INFO - 2021-03-17 17:12:02 --> URI Class Initialized
INFO - 2021-03-17 17:12:02 --> Output Class Initialized
INFO - 2021-03-17 17:12:02 --> Language Class Initialized
INFO - 2021-03-17 17:12:02 --> Output Class Initialized
INFO - 2021-03-17 17:12:02 --> Security Class Initialized
INFO - 2021-03-17 17:12:02 --> Router Class Initialized
ERROR - 2021-03-17 17:12:02 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:12:02 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:02 --> Input Class Initialized
INFO - 2021-03-17 17:12:02 --> Output Class Initialized
INFO - 2021-03-17 17:12:02 --> Language Class Initialized
DEBUG - 2021-03-17 17:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:02 --> Input Class Initialized
INFO - 2021-03-17 17:12:02 --> Language Class Initialized
INFO - 2021-03-17 17:12:02 --> Security Class Initialized
ERROR - 2021-03-17 17:12:02 --> 404 Page Not Found: Adminassets/font-awesome
ERROR - 2021-03-17 17:12:02 --> 404 Page Not Found: Adminassets/css
DEBUG - 2021-03-17 17:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:02 --> Input Class Initialized
INFO - 2021-03-17 17:12:02 --> Config Class Initialized
INFO - 2021-03-17 17:12:02 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:02 --> Language Class Initialized
ERROR - 2021-03-17 17:12:02 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:12:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:02 --> URI Class Initialized
INFO - 2021-03-17 17:12:02 --> Router Class Initialized
INFO - 2021-03-17 17:12:02 --> Config Class Initialized
INFO - 2021-03-17 17:12:02 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:02 --> Config Class Initialized
INFO - 2021-03-17 17:12:02 --> URI Class Initialized
INFO - 2021-03-17 17:12:02 --> Config Class Initialized
INFO - 2021-03-17 17:12:02 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:02 --> Output Class Initialized
INFO - 2021-03-17 17:12:02 --> Router Class Initialized
DEBUG - 2021-03-17 17:12:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:02 --> Security Class Initialized
INFO - 2021-03-17 17:12:02 --> URI Class Initialized
DEBUG - 2021-03-17 17:12:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:02 --> Output Class Initialized
INFO - 2021-03-17 17:12:02 --> Config Class Initialized
DEBUG - 2021-03-17 17:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:02 --> URI Class Initialized
INFO - 2021-03-17 17:12:02 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:02 --> Router Class Initialized
INFO - 2021-03-17 17:12:02 --> Input Class Initialized
INFO - 2021-03-17 17:12:02 --> Security Class Initialized
INFO - 2021-03-17 17:12:02 --> Language Class Initialized
INFO - 2021-03-17 17:12:02 --> Router Class Initialized
INFO - 2021-03-17 17:12:02 --> Output Class Initialized
DEBUG - 2021-03-17 17:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:02 --> Input Class Initialized
ERROR - 2021-03-17 17:12:02 --> 404 Page Not Found: Adminassets/css
DEBUG - 2021-03-17 17:12:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:02 --> Language Class Initialized
INFO - 2021-03-17 17:12:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:02 --> Output Class Initialized
INFO - 2021-03-17 17:12:02 --> Security Class Initialized
ERROR - 2021-03-17 17:12:02 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:12:02 --> URI Class Initialized
DEBUG - 2021-03-17 17:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:02 --> Security Class Initialized
INFO - 2021-03-17 17:12:02 --> Input Class Initialized
INFO - 2021-03-17 17:12:02 --> Language Class Initialized
DEBUG - 2021-03-17 17:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:02 --> Input Class Initialized
INFO - 2021-03-17 17:12:02 --> Router Class Initialized
INFO - 2021-03-17 17:12:02 --> Language Class Initialized
ERROR - 2021-03-17 17:12:02 --> 404 Page Not Found: Css/bootstrap.min.css
ERROR - 2021-03-17 17:12:02 --> 404 Page Not Found: Css/plugins
INFO - 2021-03-17 17:12:02 --> Output Class Initialized
INFO - 2021-03-17 17:12:02 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:02 --> Input Class Initialized
INFO - 2021-03-17 17:12:02 --> Language Class Initialized
ERROR - 2021-03-17 17:12:02 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:02 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Css/animate.css
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/jquery-3.1.1.min.js
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Css/style.css
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/popper.min.js
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Font-awesome/css
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/plugins
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/plugins
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/plugins
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/plugins
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/bootstrap.js
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/plugins
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/plugins
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/plugins
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/plugins
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/inspinia.js
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Adminassets/img
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/plugins
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/demo
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/plugins
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Css/plugins
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Img/profile.jpg
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Img/a4.jpg
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Img/a7.jpg
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Img/a2.jpg
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Img/a3.jpg
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Img/a5.jpg
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Img/profile_small.jpg
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Img/a8.jpg
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Css/animate.css
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Img/a1.jpg
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Css/style.css
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Img/a3.jpg
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Img/a2.jpg
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Img/profile.jpg
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Img/a5.jpg
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Img/a4.jpg
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/jquery-3.1.1.min.js
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/popper.min.js
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/bootstrap.js
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:03 --> URI Class Initialized
INFO - 2021-03-17 17:12:03 --> Router Class Initialized
INFO - 2021-03-17 17:12:03 --> Output Class Initialized
INFO - 2021-03-17 17:12:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Input Class Initialized
INFO - 2021-03-17 17:12:03 --> Language Class Initialized
ERROR - 2021-03-17 17:12:03 --> 404 Page Not Found: Js/plugins
DEBUG - 2021-03-17 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:03 --> Config Class Initialized
INFO - 2021-03-17 17:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:04 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:04 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:04 --> URI Class Initialized
INFO - 2021-03-17 17:12:04 --> Router Class Initialized
INFO - 2021-03-17 17:12:04 --> Output Class Initialized
INFO - 2021-03-17 17:12:04 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:04 --> Input Class Initialized
INFO - 2021-03-17 17:12:04 --> Language Class Initialized
ERROR - 2021-03-17 17:12:04 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:04 --> Input Class Initialized
INFO - 2021-03-17 17:12:04 --> Config Class Initialized
INFO - 2021-03-17 17:12:04 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:04 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:04 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:04 --> URI Class Initialized
INFO - 2021-03-17 17:12:04 --> Router Class Initialized
INFO - 2021-03-17 17:12:04 --> Output Class Initialized
INFO - 2021-03-17 17:12:04 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:04 --> Input Class Initialized
INFO - 2021-03-17 17:12:04 --> Language Class Initialized
ERROR - 2021-03-17 17:12:04 --> 404 Page Not Found: Img/a7.jpg
INFO - 2021-03-17 17:12:04 --> Language Class Initialized
ERROR - 2021-03-17 17:12:04 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:04 --> Config Class Initialized
INFO - 2021-03-17 17:12:04 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:04 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:04 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:04 --> URI Class Initialized
INFO - 2021-03-17 17:12:04 --> Router Class Initialized
INFO - 2021-03-17 17:12:04 --> Output Class Initialized
INFO - 2021-03-17 17:12:04 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:04 --> Input Class Initialized
INFO - 2021-03-17 17:12:04 --> Language Class Initialized
ERROR - 2021-03-17 17:12:04 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:04 --> Config Class Initialized
INFO - 2021-03-17 17:12:04 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:04 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:04 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:04 --> URI Class Initialized
INFO - 2021-03-17 17:12:04 --> Router Class Initialized
INFO - 2021-03-17 17:12:04 --> Output Class Initialized
INFO - 2021-03-17 17:12:04 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:05 --> Input Class Initialized
INFO - 2021-03-17 17:12:05 --> Language Class Initialized
ERROR - 2021-03-17 17:12:05 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:05 --> Config Class Initialized
INFO - 2021-03-17 17:12:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:05 --> URI Class Initialized
INFO - 2021-03-17 17:12:05 --> Router Class Initialized
INFO - 2021-03-17 17:12:05 --> Output Class Initialized
INFO - 2021-03-17 17:12:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:05 --> Input Class Initialized
INFO - 2021-03-17 17:12:05 --> Language Class Initialized
ERROR - 2021-03-17 17:12:05 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:05 --> Config Class Initialized
INFO - 2021-03-17 17:12:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:05 --> URI Class Initialized
INFO - 2021-03-17 17:12:05 --> Router Class Initialized
INFO - 2021-03-17 17:12:05 --> Output Class Initialized
INFO - 2021-03-17 17:12:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:06 --> Input Class Initialized
INFO - 2021-03-17 17:12:06 --> Language Class Initialized
ERROR - 2021-03-17 17:12:06 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:06 --> Config Class Initialized
INFO - 2021-03-17 17:12:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:06 --> URI Class Initialized
INFO - 2021-03-17 17:12:06 --> Router Class Initialized
INFO - 2021-03-17 17:12:06 --> Output Class Initialized
INFO - 2021-03-17 17:12:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:06 --> Input Class Initialized
INFO - 2021-03-17 17:12:06 --> Language Class Initialized
ERROR - 2021-03-17 17:12:06 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 17:12:06 --> Config Class Initialized
INFO - 2021-03-17 17:12:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:06 --> URI Class Initialized
INFO - 2021-03-17 17:12:06 --> Router Class Initialized
INFO - 2021-03-17 17:12:06 --> Output Class Initialized
INFO - 2021-03-17 17:12:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:07 --> Input Class Initialized
INFO - 2021-03-17 17:12:07 --> Language Class Initialized
ERROR - 2021-03-17 17:12:07 --> 404 Page Not Found: Js/inspinia.js
INFO - 2021-03-17 17:12:07 --> Config Class Initialized
INFO - 2021-03-17 17:12:07 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:07 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:07 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:07 --> URI Class Initialized
INFO - 2021-03-17 17:12:07 --> Router Class Initialized
INFO - 2021-03-17 17:12:07 --> Output Class Initialized
INFO - 2021-03-17 17:12:07 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:07 --> Input Class Initialized
INFO - 2021-03-17 17:12:07 --> Language Class Initialized
ERROR - 2021-03-17 17:12:07 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:07 --> Config Class Initialized
INFO - 2021-03-17 17:12:07 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:07 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:07 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:07 --> URI Class Initialized
INFO - 2021-03-17 17:12:07 --> Router Class Initialized
INFO - 2021-03-17 17:12:07 --> Output Class Initialized
INFO - 2021-03-17 17:12:08 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:08 --> Input Class Initialized
INFO - 2021-03-17 17:12:08 --> Language Class Initialized
ERROR - 2021-03-17 17:12:08 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:08 --> Config Class Initialized
INFO - 2021-03-17 17:12:08 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:08 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:08 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:08 --> URI Class Initialized
INFO - 2021-03-17 17:12:08 --> Router Class Initialized
INFO - 2021-03-17 17:12:08 --> Output Class Initialized
INFO - 2021-03-17 17:12:08 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:08 --> Input Class Initialized
INFO - 2021-03-17 17:12:08 --> Language Class Initialized
ERROR - 2021-03-17 17:12:08 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:08 --> Config Class Initialized
INFO - 2021-03-17 17:12:08 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:08 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:08 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:08 --> URI Class Initialized
INFO - 2021-03-17 17:12:08 --> Router Class Initialized
INFO - 2021-03-17 17:12:08 --> Output Class Initialized
INFO - 2021-03-17 17:12:09 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:09 --> Input Class Initialized
INFO - 2021-03-17 17:12:09 --> Language Class Initialized
ERROR - 2021-03-17 17:12:09 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:09 --> Config Class Initialized
INFO - 2021-03-17 17:12:09 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:09 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:09 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:09 --> URI Class Initialized
INFO - 2021-03-17 17:12:09 --> Router Class Initialized
INFO - 2021-03-17 17:12:09 --> Output Class Initialized
INFO - 2021-03-17 17:12:09 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:09 --> Input Class Initialized
INFO - 2021-03-17 17:12:09 --> Language Class Initialized
ERROR - 2021-03-17 17:12:09 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 17:12:09 --> Config Class Initialized
INFO - 2021-03-17 17:12:09 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:09 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:09 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:09 --> URI Class Initialized
INFO - 2021-03-17 17:12:09 --> Router Class Initialized
INFO - 2021-03-17 17:12:10 --> Output Class Initialized
INFO - 2021-03-17 17:12:10 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:10 --> Input Class Initialized
INFO - 2021-03-17 17:12:10 --> Language Class Initialized
ERROR - 2021-03-17 17:12:10 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:12:10 --> Config Class Initialized
INFO - 2021-03-17 17:12:10 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:12:10 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:12:10 --> Utf8 Class Initialized
INFO - 2021-03-17 17:12:10 --> URI Class Initialized
INFO - 2021-03-17 17:12:10 --> Router Class Initialized
INFO - 2021-03-17 17:12:10 --> Output Class Initialized
INFO - 2021-03-17 17:12:10 --> Security Class Initialized
DEBUG - 2021-03-17 17:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:12:10 --> Input Class Initialized
INFO - 2021-03-17 17:12:10 --> Language Class Initialized
ERROR - 2021-03-17 17:12:10 --> 404 Page Not Found: Js/plugins
INFO - 2021-03-17 17:16:13 --> Config Class Initialized
INFO - 2021-03-17 17:16:13 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:13 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:13 --> URI Class Initialized
INFO - 2021-03-17 17:16:13 --> Router Class Initialized
INFO - 2021-03-17 17:16:13 --> Output Class Initialized
INFO - 2021-03-17 17:16:13 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:13 --> Input Class Initialized
INFO - 2021-03-17 17:16:13 --> Language Class Initialized
INFO - 2021-03-17 17:16:13 --> Loader Class Initialized
INFO - 2021-03-17 17:16:13 --> Helper loaded: url_helper
INFO - 2021-03-17 17:16:13 --> Helper loaded: file_helper
INFO - 2021-03-17 17:16:13 --> Helper loaded: form_helper
INFO - 2021-03-17 17:16:13 --> Helper loaded: text_helper
INFO - 2021-03-17 17:16:13 --> Helper loaded: security_helper
INFO - 2021-03-17 17:16:13 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:16:13 --> Database Driver Class Initialized
INFO - 2021-03-17 17:16:13 --> Email Class Initialized
DEBUG - 2021-03-17 17:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:16:13 --> Form Validation Class Initialized
INFO - 2021-03-17 17:16:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:16:14 --> Pagination Class Initialized
INFO - 2021-03-17 17:16:14 --> Model Class Initialized
INFO - 2021-03-17 17:16:14 --> Controller Class Initialized
INFO - 2021-03-17 17:16:14 --> Model Class Initialized
INFO - 2021-03-17 17:16:14 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:16:14 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:16:14 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:16:14 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:16:14 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:16:14 --> Final output sent to browser
DEBUG - 2021-03-17 17:16:14 --> Total execution time: 1.3408
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/css
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/font-awesome
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Img/a4.jpg
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Img/a7.jpg
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/img
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Img/profile.jpg
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Img/a2.jpg
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Img/a3.jpg
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:14 --> Input Class Initialized
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Img/a5.jpg
INFO - 2021-03-17 17:16:14 --> Language Class Initialized
INFO - 2021-03-17 17:16:14 --> Config Class Initialized
INFO - 2021-03-17 17:16:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:14 --> UTF-8 Support Enabled
ERROR - 2021-03-17 17:16:14 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:14 --> URI Class Initialized
INFO - 2021-03-17 17:16:14 --> Router Class Initialized
INFO - 2021-03-17 17:16:14 --> Output Class Initialized
INFO - 2021-03-17 17:16:14 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:15 --> Input Class Initialized
INFO - 2021-03-17 17:16:15 --> Language Class Initialized
ERROR - 2021-03-17 17:16:15 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:15 --> Config Class Initialized
INFO - 2021-03-17 17:16:15 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:15 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:15 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:15 --> URI Class Initialized
INFO - 2021-03-17 17:16:15 --> Router Class Initialized
INFO - 2021-03-17 17:16:15 --> Output Class Initialized
INFO - 2021-03-17 17:16:15 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:15 --> Input Class Initialized
INFO - 2021-03-17 17:16:15 --> Language Class Initialized
ERROR - 2021-03-17 17:16:15 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:15 --> Config Class Initialized
INFO - 2021-03-17 17:16:15 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:15 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:15 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:15 --> URI Class Initialized
INFO - 2021-03-17 17:16:15 --> Router Class Initialized
INFO - 2021-03-17 17:16:15 --> Output Class Initialized
INFO - 2021-03-17 17:16:15 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:16 --> Input Class Initialized
INFO - 2021-03-17 17:16:16 --> Language Class Initialized
ERROR - 2021-03-17 17:16:16 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:16 --> Config Class Initialized
INFO - 2021-03-17 17:16:16 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:16 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:16 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:16 --> URI Class Initialized
INFO - 2021-03-17 17:16:16 --> Router Class Initialized
INFO - 2021-03-17 17:16:16 --> Output Class Initialized
INFO - 2021-03-17 17:16:16 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:16 --> Input Class Initialized
INFO - 2021-03-17 17:16:16 --> Language Class Initialized
ERROR - 2021-03-17 17:16:16 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:16 --> Config Class Initialized
INFO - 2021-03-17 17:16:16 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:16 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:16 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:16 --> URI Class Initialized
INFO - 2021-03-17 17:16:16 --> Router Class Initialized
INFO - 2021-03-17 17:16:16 --> Output Class Initialized
INFO - 2021-03-17 17:16:16 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:17 --> Input Class Initialized
INFO - 2021-03-17 17:16:17 --> Language Class Initialized
ERROR - 2021-03-17 17:16:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:17 --> Config Class Initialized
INFO - 2021-03-17 17:16:17 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:17 --> URI Class Initialized
INFO - 2021-03-17 17:16:17 --> Router Class Initialized
INFO - 2021-03-17 17:16:17 --> Output Class Initialized
INFO - 2021-03-17 17:16:17 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:17 --> Input Class Initialized
INFO - 2021-03-17 17:16:17 --> Language Class Initialized
ERROR - 2021-03-17 17:16:17 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:17 --> Config Class Initialized
INFO - 2021-03-17 17:16:17 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:17 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:17 --> URI Class Initialized
INFO - 2021-03-17 17:16:17 --> Router Class Initialized
INFO - 2021-03-17 17:16:17 --> Output Class Initialized
INFO - 2021-03-17 17:16:17 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:17 --> Input Class Initialized
INFO - 2021-03-17 17:16:17 --> Language Class Initialized
ERROR - 2021-03-17 17:16:18 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:18 --> Config Class Initialized
INFO - 2021-03-17 17:16:18 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:18 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:18 --> URI Class Initialized
INFO - 2021-03-17 17:16:18 --> Router Class Initialized
INFO - 2021-03-17 17:16:18 --> Output Class Initialized
INFO - 2021-03-17 17:16:18 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:18 --> Input Class Initialized
INFO - 2021-03-17 17:16:18 --> Language Class Initialized
ERROR - 2021-03-17 17:16:18 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:18 --> Config Class Initialized
INFO - 2021-03-17 17:16:18 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:18 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:18 --> URI Class Initialized
INFO - 2021-03-17 17:16:18 --> Router Class Initialized
INFO - 2021-03-17 17:16:18 --> Output Class Initialized
INFO - 2021-03-17 17:16:18 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:18 --> Input Class Initialized
INFO - 2021-03-17 17:16:18 --> Language Class Initialized
ERROR - 2021-03-17 17:16:19 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:19 --> Config Class Initialized
INFO - 2021-03-17 17:16:19 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:19 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:19 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:19 --> URI Class Initialized
INFO - 2021-03-17 17:16:19 --> Router Class Initialized
INFO - 2021-03-17 17:16:19 --> Output Class Initialized
INFO - 2021-03-17 17:16:19 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:19 --> Input Class Initialized
INFO - 2021-03-17 17:16:19 --> Language Class Initialized
ERROR - 2021-03-17 17:16:19 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:19 --> Config Class Initialized
INFO - 2021-03-17 17:16:19 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:19 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:19 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:19 --> URI Class Initialized
INFO - 2021-03-17 17:16:19 --> Router Class Initialized
INFO - 2021-03-17 17:16:19 --> Output Class Initialized
INFO - 2021-03-17 17:16:19 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:19 --> Input Class Initialized
INFO - 2021-03-17 17:16:19 --> Language Class Initialized
ERROR - 2021-03-17 17:16:19 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:20 --> Config Class Initialized
INFO - 2021-03-17 17:16:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:20 --> URI Class Initialized
INFO - 2021-03-17 17:16:20 --> Router Class Initialized
INFO - 2021-03-17 17:16:20 --> Output Class Initialized
INFO - 2021-03-17 17:16:20 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:20 --> Input Class Initialized
INFO - 2021-03-17 17:16:20 --> Language Class Initialized
ERROR - 2021-03-17 17:16:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:20 --> Config Class Initialized
INFO - 2021-03-17 17:16:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:20 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:20 --> URI Class Initialized
INFO - 2021-03-17 17:16:20 --> Router Class Initialized
INFO - 2021-03-17 17:16:20 --> Output Class Initialized
INFO - 2021-03-17 17:16:20 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:20 --> Input Class Initialized
INFO - 2021-03-17 17:16:20 --> Language Class Initialized
ERROR - 2021-03-17 17:16:20 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:21 --> Config Class Initialized
INFO - 2021-03-17 17:16:21 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:21 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:21 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:21 --> URI Class Initialized
INFO - 2021-03-17 17:16:21 --> Router Class Initialized
INFO - 2021-03-17 17:16:21 --> Output Class Initialized
INFO - 2021-03-17 17:16:21 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:21 --> Input Class Initialized
INFO - 2021-03-17 17:16:21 --> Language Class Initialized
ERROR - 2021-03-17 17:16:21 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:21 --> Config Class Initialized
INFO - 2021-03-17 17:16:21 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:21 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:21 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:21 --> URI Class Initialized
INFO - 2021-03-17 17:16:21 --> Router Class Initialized
INFO - 2021-03-17 17:16:21 --> Output Class Initialized
INFO - 2021-03-17 17:16:21 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:21 --> Input Class Initialized
INFO - 2021-03-17 17:16:21 --> Language Class Initialized
ERROR - 2021-03-17 17:16:21 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:22 --> Config Class Initialized
INFO - 2021-03-17 17:16:22 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:22 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:22 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:22 --> URI Class Initialized
INFO - 2021-03-17 17:16:22 --> Router Class Initialized
INFO - 2021-03-17 17:16:22 --> Output Class Initialized
INFO - 2021-03-17 17:16:22 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:22 --> Input Class Initialized
INFO - 2021-03-17 17:16:22 --> Language Class Initialized
ERROR - 2021-03-17 17:16:22 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:22 --> Config Class Initialized
INFO - 2021-03-17 17:16:22 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:22 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:22 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:22 --> URI Class Initialized
INFO - 2021-03-17 17:16:22 --> Router Class Initialized
INFO - 2021-03-17 17:16:22 --> Output Class Initialized
INFO - 2021-03-17 17:16:22 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:22 --> Input Class Initialized
INFO - 2021-03-17 17:16:22 --> Language Class Initialized
ERROR - 2021-03-17 17:16:22 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:22 --> Config Class Initialized
INFO - 2021-03-17 17:16:22 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:23 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:23 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:23 --> URI Class Initialized
INFO - 2021-03-17 17:16:23 --> Router Class Initialized
INFO - 2021-03-17 17:16:23 --> Output Class Initialized
INFO - 2021-03-17 17:16:23 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:23 --> Input Class Initialized
INFO - 2021-03-17 17:16:23 --> Language Class Initialized
ERROR - 2021-03-17 17:16:23 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:23 --> Config Class Initialized
INFO - 2021-03-17 17:16:23 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:23 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:23 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:23 --> URI Class Initialized
INFO - 2021-03-17 17:16:23 --> Router Class Initialized
INFO - 2021-03-17 17:16:23 --> Output Class Initialized
INFO - 2021-03-17 17:16:23 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:23 --> Input Class Initialized
INFO - 2021-03-17 17:16:23 --> Language Class Initialized
ERROR - 2021-03-17 17:16:23 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:55 --> Config Class Initialized
INFO - 2021-03-17 17:16:56 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:56 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:56 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:56 --> URI Class Initialized
INFO - 2021-03-17 17:16:56 --> Router Class Initialized
INFO - 2021-03-17 17:16:56 --> Output Class Initialized
INFO - 2021-03-17 17:16:56 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:56 --> Input Class Initialized
INFO - 2021-03-17 17:16:56 --> Language Class Initialized
INFO - 2021-03-17 17:16:56 --> Loader Class Initialized
INFO - 2021-03-17 17:16:56 --> Helper loaded: url_helper
INFO - 2021-03-17 17:16:56 --> Helper loaded: file_helper
INFO - 2021-03-17 17:16:56 --> Helper loaded: form_helper
INFO - 2021-03-17 17:16:56 --> Helper loaded: text_helper
INFO - 2021-03-17 17:16:56 --> Helper loaded: security_helper
INFO - 2021-03-17 17:16:56 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:16:56 --> Database Driver Class Initialized
INFO - 2021-03-17 17:16:56 --> Email Class Initialized
DEBUG - 2021-03-17 17:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:16:56 --> Form Validation Class Initialized
INFO - 2021-03-17 17:16:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:16:56 --> Pagination Class Initialized
INFO - 2021-03-17 17:16:56 --> Model Class Initialized
INFO - 2021-03-17 17:16:56 --> Controller Class Initialized
INFO - 2021-03-17 17:16:57 --> Model Class Initialized
INFO - 2021-03-17 17:16:57 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:16:57 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:16:57 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:16:57 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:16:57 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:16:57 --> Final output sent to browser
DEBUG - 2021-03-17 17:16:57 --> Total execution time: 1.2319
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/img
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Img/a7.jpg
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Img/a4.jpg
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:57 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Img/profile.jpg
DEBUG - 2021-03-17 17:16:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
INFO - 2021-03-17 17:16:57 --> URI Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Img/a2.jpg
INFO - 2021-03-17 17:16:57 --> Router Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
INFO - 2021-03-17 17:16:57 --> Output Class Initialized
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
INFO - 2021-03-17 17:16:57 --> Security Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Img/a3.jpg
DEBUG - 2021-03-17 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:57 --> Input Class Initialized
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Img/a5.jpg
INFO - 2021-03-17 17:16:57 --> Language Class Initialized
ERROR - 2021-03-17 17:16:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:57 --> Config Class Initialized
INFO - 2021-03-17 17:16:58 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:58 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:58 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:58 --> URI Class Initialized
INFO - 2021-03-17 17:16:58 --> Router Class Initialized
INFO - 2021-03-17 17:16:58 --> Output Class Initialized
INFO - 2021-03-17 17:16:58 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:58 --> Input Class Initialized
INFO - 2021-03-17 17:16:58 --> Language Class Initialized
ERROR - 2021-03-17 17:16:58 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:58 --> Config Class Initialized
INFO - 2021-03-17 17:16:58 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:58 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:58 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:58 --> URI Class Initialized
INFO - 2021-03-17 17:16:58 --> Router Class Initialized
INFO - 2021-03-17 17:16:58 --> Output Class Initialized
INFO - 2021-03-17 17:16:58 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:58 --> Input Class Initialized
INFO - 2021-03-17 17:16:58 --> Language Class Initialized
ERROR - 2021-03-17 17:16:58 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:59 --> Config Class Initialized
INFO - 2021-03-17 17:16:59 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:59 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:59 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:59 --> URI Class Initialized
INFO - 2021-03-17 17:16:59 --> Router Class Initialized
INFO - 2021-03-17 17:16:59 --> Output Class Initialized
INFO - 2021-03-17 17:16:59 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:59 --> Input Class Initialized
INFO - 2021-03-17 17:16:59 --> Language Class Initialized
ERROR - 2021-03-17 17:16:59 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:59 --> Config Class Initialized
INFO - 2021-03-17 17:16:59 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:59 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:59 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:59 --> URI Class Initialized
INFO - 2021-03-17 17:16:59 --> Router Class Initialized
INFO - 2021-03-17 17:16:59 --> Output Class Initialized
INFO - 2021-03-17 17:16:59 --> Security Class Initialized
DEBUG - 2021-03-17 17:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:16:59 --> Input Class Initialized
INFO - 2021-03-17 17:16:59 --> Language Class Initialized
ERROR - 2021-03-17 17:16:59 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:16:59 --> Config Class Initialized
INFO - 2021-03-17 17:16:59 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:16:59 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:16:59 --> Utf8 Class Initialized
INFO - 2021-03-17 17:16:59 --> URI Class Initialized
INFO - 2021-03-17 17:17:00 --> Router Class Initialized
INFO - 2021-03-17 17:17:00 --> Output Class Initialized
INFO - 2021-03-17 17:17:00 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:00 --> Input Class Initialized
INFO - 2021-03-17 17:17:00 --> Language Class Initialized
ERROR - 2021-03-17 17:17:00 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:00 --> Config Class Initialized
INFO - 2021-03-17 17:17:00 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:00 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:00 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:00 --> URI Class Initialized
INFO - 2021-03-17 17:17:00 --> Router Class Initialized
INFO - 2021-03-17 17:17:00 --> Output Class Initialized
INFO - 2021-03-17 17:17:00 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:00 --> Input Class Initialized
INFO - 2021-03-17 17:17:00 --> Language Class Initialized
ERROR - 2021-03-17 17:17:00 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:00 --> Config Class Initialized
INFO - 2021-03-17 17:17:00 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:00 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:00 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:00 --> URI Class Initialized
INFO - 2021-03-17 17:17:00 --> Router Class Initialized
INFO - 2021-03-17 17:17:00 --> Output Class Initialized
INFO - 2021-03-17 17:17:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:01 --> Input Class Initialized
INFO - 2021-03-17 17:17:01 --> Language Class Initialized
ERROR - 2021-03-17 17:17:01 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:01 --> Config Class Initialized
INFO - 2021-03-17 17:17:01 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:01 --> URI Class Initialized
INFO - 2021-03-17 17:17:01 --> Router Class Initialized
INFO - 2021-03-17 17:17:01 --> Output Class Initialized
INFO - 2021-03-17 17:17:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:01 --> Input Class Initialized
INFO - 2021-03-17 17:17:01 --> Language Class Initialized
ERROR - 2021-03-17 17:17:01 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:01 --> Config Class Initialized
INFO - 2021-03-17 17:17:01 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:01 --> URI Class Initialized
INFO - 2021-03-17 17:17:01 --> Router Class Initialized
INFO - 2021-03-17 17:17:02 --> Output Class Initialized
INFO - 2021-03-17 17:17:02 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:02 --> Input Class Initialized
INFO - 2021-03-17 17:17:02 --> Language Class Initialized
ERROR - 2021-03-17 17:17:02 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:02 --> Config Class Initialized
INFO - 2021-03-17 17:17:02 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:02 --> URI Class Initialized
INFO - 2021-03-17 17:17:02 --> Router Class Initialized
INFO - 2021-03-17 17:17:02 --> Output Class Initialized
INFO - 2021-03-17 17:17:02 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:02 --> Input Class Initialized
INFO - 2021-03-17 17:17:02 --> Language Class Initialized
ERROR - 2021-03-17 17:17:02 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:02 --> Config Class Initialized
INFO - 2021-03-17 17:17:02 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:02 --> URI Class Initialized
INFO - 2021-03-17 17:17:02 --> Router Class Initialized
INFO - 2021-03-17 17:17:03 --> Output Class Initialized
INFO - 2021-03-17 17:17:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:03 --> Input Class Initialized
INFO - 2021-03-17 17:17:03 --> Language Class Initialized
ERROR - 2021-03-17 17:17:03 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:03 --> Config Class Initialized
INFO - 2021-03-17 17:17:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:03 --> URI Class Initialized
INFO - 2021-03-17 17:17:03 --> Router Class Initialized
INFO - 2021-03-17 17:17:03 --> Output Class Initialized
INFO - 2021-03-17 17:17:03 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:03 --> Input Class Initialized
INFO - 2021-03-17 17:17:03 --> Language Class Initialized
ERROR - 2021-03-17 17:17:03 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:03 --> Config Class Initialized
INFO - 2021-03-17 17:17:03 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:03 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:03 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:03 --> URI Class Initialized
INFO - 2021-03-17 17:17:03 --> Router Class Initialized
INFO - 2021-03-17 17:17:03 --> Output Class Initialized
INFO - 2021-03-17 17:17:04 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:04 --> Input Class Initialized
INFO - 2021-03-17 17:17:04 --> Language Class Initialized
ERROR - 2021-03-17 17:17:04 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:04 --> Config Class Initialized
INFO - 2021-03-17 17:17:04 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:04 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:04 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:04 --> URI Class Initialized
INFO - 2021-03-17 17:17:04 --> Router Class Initialized
INFO - 2021-03-17 17:17:04 --> Output Class Initialized
INFO - 2021-03-17 17:17:04 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:04 --> Input Class Initialized
INFO - 2021-03-17 17:17:04 --> Language Class Initialized
ERROR - 2021-03-17 17:17:04 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:04 --> Config Class Initialized
INFO - 2021-03-17 17:17:04 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:04 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:04 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:04 --> URI Class Initialized
INFO - 2021-03-17 17:17:04 --> Router Class Initialized
INFO - 2021-03-17 17:17:04 --> Output Class Initialized
INFO - 2021-03-17 17:17:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:05 --> Input Class Initialized
INFO - 2021-03-17 17:17:05 --> Language Class Initialized
ERROR - 2021-03-17 17:17:05 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:05 --> Config Class Initialized
INFO - 2021-03-17 17:17:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:05 --> URI Class Initialized
INFO - 2021-03-17 17:17:05 --> Router Class Initialized
INFO - 2021-03-17 17:17:05 --> Output Class Initialized
INFO - 2021-03-17 17:17:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:05 --> Input Class Initialized
INFO - 2021-03-17 17:17:05 --> Language Class Initialized
ERROR - 2021-03-17 17:17:05 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:05 --> Config Class Initialized
INFO - 2021-03-17 17:17:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:05 --> URI Class Initialized
INFO - 2021-03-17 17:17:05 --> Router Class Initialized
INFO - 2021-03-17 17:17:05 --> Output Class Initialized
INFO - 2021-03-17 17:17:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:06 --> Input Class Initialized
INFO - 2021-03-17 17:17:06 --> Language Class Initialized
ERROR - 2021-03-17 17:17:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:06 --> Config Class Initialized
INFO - 2021-03-17 17:17:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:06 --> URI Class Initialized
INFO - 2021-03-17 17:17:06 --> Router Class Initialized
INFO - 2021-03-17 17:17:06 --> Output Class Initialized
INFO - 2021-03-17 17:17:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:06 --> Input Class Initialized
INFO - 2021-03-17 17:17:06 --> Language Class Initialized
ERROR - 2021-03-17 17:17:06 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:06 --> Config Class Initialized
INFO - 2021-03-17 17:17:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:06 --> URI Class Initialized
INFO - 2021-03-17 17:17:06 --> Router Class Initialized
INFO - 2021-03-17 17:17:06 --> Output Class Initialized
INFO - 2021-03-17 17:17:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:07 --> Input Class Initialized
INFO - 2021-03-17 17:17:07 --> Language Class Initialized
ERROR - 2021-03-17 17:17:07 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:50 --> Config Class Initialized
INFO - 2021-03-17 17:17:50 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:50 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:50 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:50 --> URI Class Initialized
INFO - 2021-03-17 17:17:50 --> Router Class Initialized
INFO - 2021-03-17 17:17:50 --> Output Class Initialized
INFO - 2021-03-17 17:17:50 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:50 --> Input Class Initialized
INFO - 2021-03-17 17:17:50 --> Language Class Initialized
INFO - 2021-03-17 17:17:50 --> Loader Class Initialized
INFO - 2021-03-17 17:17:50 --> Helper loaded: url_helper
INFO - 2021-03-17 17:17:50 --> Helper loaded: file_helper
INFO - 2021-03-17 17:17:50 --> Helper loaded: form_helper
INFO - 2021-03-17 17:17:50 --> Helper loaded: text_helper
INFO - 2021-03-17 17:17:50 --> Helper loaded: security_helper
INFO - 2021-03-17 17:17:50 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:17:50 --> Database Driver Class Initialized
INFO - 2021-03-17 17:17:50 --> Email Class Initialized
DEBUG - 2021-03-17 17:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:17:50 --> Form Validation Class Initialized
INFO - 2021-03-17 17:17:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:17:51 --> Pagination Class Initialized
INFO - 2021-03-17 17:17:51 --> Model Class Initialized
INFO - 2021-03-17 17:17:51 --> Controller Class Initialized
INFO - 2021-03-17 17:17:51 --> Model Class Initialized
INFO - 2021-03-17 17:17:51 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:17:51 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:17:51 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:17:51 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:17:51 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:17:51 --> Final output sent to browser
DEBUG - 2021-03-17 17:17:51 --> Total execution time: 1.2159
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Img/a4.jpg
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Img/profile.jpg
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Img/a7.jpg
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
INFO - 2021-03-17 17:17:51 --> Config Class Initialized
INFO - 2021-03-17 17:17:51 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
DEBUG - 2021-03-17 17:17:51 --> UTF-8 Support Enabled
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Img/a2.jpg
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Img/a3.jpg
INFO - 2021-03-17 17:17:51 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:51 --> URI Class Initialized
INFO - 2021-03-17 17:17:51 --> Router Class Initialized
INFO - 2021-03-17 17:17:51 --> Output Class Initialized
INFO - 2021-03-17 17:17:51 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:51 --> Input Class Initialized
INFO - 2021-03-17 17:17:51 --> Language Class Initialized
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Img/a5.jpg
ERROR - 2021-03-17 17:17:51 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:52 --> Config Class Initialized
INFO - 2021-03-17 17:17:52 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:52 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:52 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:52 --> URI Class Initialized
INFO - 2021-03-17 17:17:52 --> Router Class Initialized
INFO - 2021-03-17 17:17:52 --> Output Class Initialized
INFO - 2021-03-17 17:17:52 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:52 --> Input Class Initialized
INFO - 2021-03-17 17:17:52 --> Language Class Initialized
ERROR - 2021-03-17 17:17:52 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:52 --> Config Class Initialized
INFO - 2021-03-17 17:17:52 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:52 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:52 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:52 --> URI Class Initialized
INFO - 2021-03-17 17:17:52 --> Router Class Initialized
INFO - 2021-03-17 17:17:52 --> Output Class Initialized
INFO - 2021-03-17 17:17:52 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:52 --> Input Class Initialized
INFO - 2021-03-17 17:17:52 --> Language Class Initialized
ERROR - 2021-03-17 17:17:52 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:52 --> Config Class Initialized
INFO - 2021-03-17 17:17:52 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:53 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:53 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:53 --> URI Class Initialized
INFO - 2021-03-17 17:17:53 --> Router Class Initialized
INFO - 2021-03-17 17:17:53 --> Output Class Initialized
INFO - 2021-03-17 17:17:53 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:53 --> Input Class Initialized
INFO - 2021-03-17 17:17:53 --> Language Class Initialized
ERROR - 2021-03-17 17:17:53 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:53 --> Config Class Initialized
INFO - 2021-03-17 17:17:53 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:53 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:53 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:53 --> URI Class Initialized
INFO - 2021-03-17 17:17:53 --> Router Class Initialized
INFO - 2021-03-17 17:17:53 --> Output Class Initialized
INFO - 2021-03-17 17:17:53 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:53 --> Input Class Initialized
INFO - 2021-03-17 17:17:53 --> Language Class Initialized
ERROR - 2021-03-17 17:17:53 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:53 --> Config Class Initialized
INFO - 2021-03-17 17:17:53 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:53 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:53 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:54 --> URI Class Initialized
INFO - 2021-03-17 17:17:54 --> Router Class Initialized
INFO - 2021-03-17 17:17:54 --> Output Class Initialized
INFO - 2021-03-17 17:17:54 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:54 --> Input Class Initialized
INFO - 2021-03-17 17:17:54 --> Language Class Initialized
ERROR - 2021-03-17 17:17:54 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:54 --> Config Class Initialized
INFO - 2021-03-17 17:17:54 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:54 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:54 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:54 --> URI Class Initialized
INFO - 2021-03-17 17:17:54 --> Router Class Initialized
INFO - 2021-03-17 17:17:54 --> Output Class Initialized
INFO - 2021-03-17 17:17:54 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:54 --> Input Class Initialized
INFO - 2021-03-17 17:17:54 --> Language Class Initialized
ERROR - 2021-03-17 17:17:54 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:54 --> Config Class Initialized
INFO - 2021-03-17 17:17:54 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:54 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:54 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:55 --> URI Class Initialized
INFO - 2021-03-17 17:17:55 --> Router Class Initialized
INFO - 2021-03-17 17:17:55 --> Output Class Initialized
INFO - 2021-03-17 17:17:55 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:55 --> Input Class Initialized
INFO - 2021-03-17 17:17:55 --> Language Class Initialized
ERROR - 2021-03-17 17:17:55 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:55 --> Config Class Initialized
INFO - 2021-03-17 17:17:55 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:55 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:55 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:55 --> URI Class Initialized
INFO - 2021-03-17 17:17:55 --> Router Class Initialized
INFO - 2021-03-17 17:17:55 --> Output Class Initialized
INFO - 2021-03-17 17:17:55 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:55 --> Input Class Initialized
INFO - 2021-03-17 17:17:55 --> Language Class Initialized
ERROR - 2021-03-17 17:17:55 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:55 --> Config Class Initialized
INFO - 2021-03-17 17:17:55 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:55 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:55 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:55 --> URI Class Initialized
INFO - 2021-03-17 17:17:55 --> Router Class Initialized
INFO - 2021-03-17 17:17:55 --> Output Class Initialized
INFO - 2021-03-17 17:17:56 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:56 --> Input Class Initialized
INFO - 2021-03-17 17:17:56 --> Language Class Initialized
ERROR - 2021-03-17 17:17:56 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:56 --> Config Class Initialized
INFO - 2021-03-17 17:17:56 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:56 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:56 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:56 --> URI Class Initialized
INFO - 2021-03-17 17:17:56 --> Router Class Initialized
INFO - 2021-03-17 17:17:56 --> Output Class Initialized
INFO - 2021-03-17 17:17:56 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:56 --> Input Class Initialized
INFO - 2021-03-17 17:17:56 --> Language Class Initialized
ERROR - 2021-03-17 17:17:56 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:56 --> Config Class Initialized
INFO - 2021-03-17 17:17:56 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:56 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:56 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:56 --> URI Class Initialized
INFO - 2021-03-17 17:17:56 --> Router Class Initialized
INFO - 2021-03-17 17:17:56 --> Output Class Initialized
INFO - 2021-03-17 17:17:56 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:57 --> Input Class Initialized
INFO - 2021-03-17 17:17:57 --> Language Class Initialized
ERROR - 2021-03-17 17:17:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:57 --> Config Class Initialized
INFO - 2021-03-17 17:17:57 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:57 --> URI Class Initialized
INFO - 2021-03-17 17:17:57 --> Router Class Initialized
INFO - 2021-03-17 17:17:57 --> Output Class Initialized
INFO - 2021-03-17 17:17:57 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:57 --> Input Class Initialized
INFO - 2021-03-17 17:17:57 --> Language Class Initialized
ERROR - 2021-03-17 17:17:57 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:57 --> Config Class Initialized
INFO - 2021-03-17 17:17:57 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:57 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:57 --> URI Class Initialized
INFO - 2021-03-17 17:17:57 --> Router Class Initialized
INFO - 2021-03-17 17:17:57 --> Output Class Initialized
INFO - 2021-03-17 17:17:57 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:57 --> Input Class Initialized
INFO - 2021-03-17 17:17:57 --> Language Class Initialized
ERROR - 2021-03-17 17:17:58 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:58 --> Config Class Initialized
INFO - 2021-03-17 17:17:58 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:58 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:58 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:58 --> URI Class Initialized
INFO - 2021-03-17 17:17:58 --> Router Class Initialized
INFO - 2021-03-17 17:17:58 --> Output Class Initialized
INFO - 2021-03-17 17:17:58 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:58 --> Input Class Initialized
INFO - 2021-03-17 17:17:58 --> Language Class Initialized
ERROR - 2021-03-17 17:17:58 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:58 --> Config Class Initialized
INFO - 2021-03-17 17:17:58 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:58 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:58 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:58 --> URI Class Initialized
INFO - 2021-03-17 17:17:58 --> Router Class Initialized
INFO - 2021-03-17 17:17:58 --> Output Class Initialized
INFO - 2021-03-17 17:17:58 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:58 --> Input Class Initialized
INFO - 2021-03-17 17:17:58 --> Language Class Initialized
ERROR - 2021-03-17 17:17:58 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:58 --> Config Class Initialized
INFO - 2021-03-17 17:17:58 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:59 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:59 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:59 --> URI Class Initialized
INFO - 2021-03-17 17:17:59 --> Router Class Initialized
INFO - 2021-03-17 17:17:59 --> Output Class Initialized
INFO - 2021-03-17 17:17:59 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:59 --> Input Class Initialized
INFO - 2021-03-17 17:17:59 --> Language Class Initialized
ERROR - 2021-03-17 17:17:59 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:59 --> Config Class Initialized
INFO - 2021-03-17 17:17:59 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:59 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:59 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:59 --> URI Class Initialized
INFO - 2021-03-17 17:17:59 --> Router Class Initialized
INFO - 2021-03-17 17:17:59 --> Output Class Initialized
INFO - 2021-03-17 17:17:59 --> Security Class Initialized
DEBUG - 2021-03-17 17:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:17:59 --> Input Class Initialized
INFO - 2021-03-17 17:17:59 --> Language Class Initialized
ERROR - 2021-03-17 17:17:59 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:17:59 --> Config Class Initialized
INFO - 2021-03-17 17:17:59 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:17:59 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:17:59 --> Utf8 Class Initialized
INFO - 2021-03-17 17:17:59 --> URI Class Initialized
INFO - 2021-03-17 17:18:00 --> Router Class Initialized
INFO - 2021-03-17 17:18:00 --> Output Class Initialized
INFO - 2021-03-17 17:18:00 --> Security Class Initialized
DEBUG - 2021-03-17 17:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:18:00 --> Input Class Initialized
INFO - 2021-03-17 17:18:00 --> Language Class Initialized
ERROR - 2021-03-17 17:18:00 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:18:00 --> Config Class Initialized
INFO - 2021-03-17 17:18:00 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:18:00 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:18:00 --> Utf8 Class Initialized
INFO - 2021-03-17 17:18:00 --> URI Class Initialized
INFO - 2021-03-17 17:18:00 --> Router Class Initialized
INFO - 2021-03-17 17:18:00 --> Output Class Initialized
INFO - 2021-03-17 17:18:00 --> Security Class Initialized
DEBUG - 2021-03-17 17:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:18:00 --> Input Class Initialized
INFO - 2021-03-17 17:18:00 --> Language Class Initialized
ERROR - 2021-03-17 17:18:00 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-17 17:19:00 --> Config Class Initialized
INFO - 2021-03-17 17:19:00 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:19:00 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:19:00 --> Utf8 Class Initialized
INFO - 2021-03-17 17:19:00 --> URI Class Initialized
INFO - 2021-03-17 17:19:00 --> Router Class Initialized
INFO - 2021-03-17 17:19:00 --> Output Class Initialized
INFO - 2021-03-17 17:19:00 --> Security Class Initialized
DEBUG - 2021-03-17 17:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:19:00 --> Input Class Initialized
INFO - 2021-03-17 17:19:00 --> Language Class Initialized
INFO - 2021-03-17 17:19:00 --> Loader Class Initialized
INFO - 2021-03-17 17:19:00 --> Helper loaded: url_helper
INFO - 2021-03-17 17:19:00 --> Helper loaded: file_helper
INFO - 2021-03-17 17:19:00 --> Helper loaded: form_helper
INFO - 2021-03-17 17:19:00 --> Helper loaded: text_helper
INFO - 2021-03-17 17:19:00 --> Helper loaded: security_helper
INFO - 2021-03-17 17:19:01 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:19:01 --> Database Driver Class Initialized
INFO - 2021-03-17 17:19:01 --> Email Class Initialized
DEBUG - 2021-03-17 17:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:19:01 --> Form Validation Class Initialized
INFO - 2021-03-17 17:19:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:19:01 --> Pagination Class Initialized
INFO - 2021-03-17 17:19:01 --> Model Class Initialized
INFO - 2021-03-17 17:19:01 --> Controller Class Initialized
INFO - 2021-03-17 17:19:01 --> Model Class Initialized
INFO - 2021-03-17 17:19:01 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:19:01 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:19:01 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:19:01 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:19:01 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:19:01 --> Final output sent to browser
DEBUG - 2021-03-17 17:19:01 --> Total execution time: 1.2453
INFO - 2021-03-17 17:19:01 --> Config Class Initialized
INFO - 2021-03-17 17:19:01 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:19:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:19:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:19:01 --> URI Class Initialized
INFO - 2021-03-17 17:19:01 --> Router Class Initialized
INFO - 2021-03-17 17:19:01 --> Output Class Initialized
INFO - 2021-03-17 17:19:01 --> Security Class Initialized
DEBUG - 2021-03-17 17:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:19:02 --> Input Class Initialized
INFO - 2021-03-17 17:19:02 --> Language Class Initialized
ERROR - 2021-03-17 17:19:02 --> 404 Page Not Found: Img/a7.jpg
INFO - 2021-03-17 17:19:02 --> Config Class Initialized
INFO - 2021-03-17 17:19:02 --> Config Class Initialized
INFO - 2021-03-17 17:19:02 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:19:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:19:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:19:02 --> URI Class Initialized
INFO - 2021-03-17 17:19:02 --> Router Class Initialized
INFO - 2021-03-17 17:19:02 --> Output Class Initialized
INFO - 2021-03-17 17:19:02 --> Security Class Initialized
DEBUG - 2021-03-17 17:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:19:02 --> Input Class Initialized
INFO - 2021-03-17 17:19:02 --> Language Class Initialized
ERROR - 2021-03-17 17:19:02 --> 404 Page Not Found: Img/profile.jpg
INFO - 2021-03-17 17:19:02 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:19:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:19:02 --> Config Class Initialized
INFO - 2021-03-17 17:19:02 --> Hooks Class Initialized
INFO - 2021-03-17 17:19:02 --> Config Class Initialized
INFO - 2021-03-17 17:19:02 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:19:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:19:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:19:02 --> URI Class Initialized
DEBUG - 2021-03-17 17:19:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:19:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:19:02 --> Router Class Initialized
INFO - 2021-03-17 17:19:02 --> URI Class Initialized
INFO - 2021-03-17 17:19:02 --> Router Class Initialized
INFO - 2021-03-17 17:19:02 --> Output Class Initialized
INFO - 2021-03-17 17:19:02 --> Security Class Initialized
INFO - 2021-03-17 17:19:02 --> Output Class Initialized
DEBUG - 2021-03-17 17:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:19:02 --> Input Class Initialized
INFO - 2021-03-17 17:19:02 --> Security Class Initialized
INFO - 2021-03-17 17:19:02 --> Language Class Initialized
DEBUG - 2021-03-17 17:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:19:02 --> Input Class Initialized
ERROR - 2021-03-17 17:19:02 --> 404 Page Not Found: Img/a3.jpg
INFO - 2021-03-17 17:19:02 --> Language Class Initialized
ERROR - 2021-03-17 17:19:02 --> 404 Page Not Found: Img/a2.jpg
INFO - 2021-03-17 17:19:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:19:02 --> URI Class Initialized
INFO - 2021-03-17 17:19:02 --> Config Class Initialized
INFO - 2021-03-17 17:19:02 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:19:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:19:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:19:02 --> URI Class Initialized
INFO - 2021-03-17 17:19:02 --> Router Class Initialized
INFO - 2021-03-17 17:19:02 --> Output Class Initialized
INFO - 2021-03-17 17:19:02 --> Security Class Initialized
DEBUG - 2021-03-17 17:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:19:02 --> Router Class Initialized
INFO - 2021-03-17 17:19:02 --> Output Class Initialized
INFO - 2021-03-17 17:19:02 --> Security Class Initialized
DEBUG - 2021-03-17 17:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:19:02 --> Input Class Initialized
INFO - 2021-03-17 17:19:02 --> Language Class Initialized
ERROR - 2021-03-17 17:19:02 --> 404 Page Not Found: Img/a4.jpg
INFO - 2021-03-17 17:19:02 --> Input Class Initialized
INFO - 2021-03-17 17:19:02 --> Language Class Initialized
ERROR - 2021-03-17 17:19:02 --> 404 Page Not Found: Img/a5.jpg
INFO - 2021-03-17 17:19:02 --> Config Class Initialized
INFO - 2021-03-17 17:19:02 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:19:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:19:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:19:02 --> URI Class Initialized
INFO - 2021-03-17 17:19:02 --> Router Class Initialized
INFO - 2021-03-17 17:19:02 --> Output Class Initialized
INFO - 2021-03-17 17:19:02 --> Security Class Initialized
DEBUG - 2021-03-17 17:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:19:03 --> Input Class Initialized
INFO - 2021-03-17 17:19:03 --> Language Class Initialized
ERROR - 2021-03-17 17:19:03 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 17:19:30 --> Config Class Initialized
INFO - 2021-03-17 17:19:30 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:19:30 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:19:30 --> Utf8 Class Initialized
INFO - 2021-03-17 17:19:30 --> URI Class Initialized
INFO - 2021-03-17 17:19:30 --> Router Class Initialized
INFO - 2021-03-17 17:19:31 --> Output Class Initialized
INFO - 2021-03-17 17:19:31 --> Security Class Initialized
DEBUG - 2021-03-17 17:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:19:31 --> Input Class Initialized
INFO - 2021-03-17 17:19:31 --> Language Class Initialized
INFO - 2021-03-17 17:19:31 --> Loader Class Initialized
INFO - 2021-03-17 17:19:31 --> Helper loaded: url_helper
INFO - 2021-03-17 17:19:31 --> Helper loaded: file_helper
INFO - 2021-03-17 17:19:31 --> Helper loaded: form_helper
INFO - 2021-03-17 17:19:31 --> Helper loaded: text_helper
INFO - 2021-03-17 17:19:31 --> Helper loaded: security_helper
INFO - 2021-03-17 17:19:31 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:19:31 --> Database Driver Class Initialized
INFO - 2021-03-17 17:19:31 --> Email Class Initialized
DEBUG - 2021-03-17 17:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:19:31 --> Form Validation Class Initialized
INFO - 2021-03-17 17:19:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:19:31 --> Pagination Class Initialized
INFO - 2021-03-17 17:19:31 --> Model Class Initialized
INFO - 2021-03-17 17:19:31 --> Controller Class Initialized
INFO - 2021-03-17 17:19:31 --> Model Class Initialized
INFO - 2021-03-17 17:19:31 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:19:31 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:19:32 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:19:32 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:19:32 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:19:32 --> Final output sent to browser
DEBUG - 2021-03-17 17:19:32 --> Total execution time: 1.7996
INFO - 2021-03-17 17:19:37 --> Config Class Initialized
INFO - 2021-03-17 17:19:37 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:19:37 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:19:37 --> Utf8 Class Initialized
INFO - 2021-03-17 17:19:37 --> URI Class Initialized
INFO - 2021-03-17 17:19:37 --> Router Class Initialized
INFO - 2021-03-17 17:19:37 --> Output Class Initialized
INFO - 2021-03-17 17:19:37 --> Security Class Initialized
DEBUG - 2021-03-17 17:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:19:37 --> Input Class Initialized
INFO - 2021-03-17 17:19:37 --> Language Class Initialized
ERROR - 2021-03-17 17:19:37 --> 404 Page Not Found: Img/a7.jpg
INFO - 2021-03-17 17:19:37 --> Config Class Initialized
INFO - 2021-03-17 17:19:37 --> Config Class Initialized
INFO - 2021-03-17 17:19:37 --> Hooks Class Initialized
INFO - 2021-03-17 17:19:37 --> Config Class Initialized
INFO - 2021-03-17 17:19:37 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:19:37 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:19:37 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:19:37 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:19:37 --> Utf8 Class Initialized
INFO - 2021-03-17 17:19:37 --> URI Class Initialized
INFO - 2021-03-17 17:19:37 --> URI Class Initialized
INFO - 2021-03-17 17:19:37 --> Router Class Initialized
INFO - 2021-03-17 17:19:37 --> Router Class Initialized
INFO - 2021-03-17 17:19:37 --> Output Class Initialized
INFO - 2021-03-17 17:19:37 --> Output Class Initialized
INFO - 2021-03-17 17:19:37 --> Security Class Initialized
INFO - 2021-03-17 17:19:37 --> Security Class Initialized
DEBUG - 2021-03-17 17:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:19:37 --> Input Class Initialized
INFO - 2021-03-17 17:19:37 --> Input Class Initialized
INFO - 2021-03-17 17:19:37 --> Language Class Initialized
INFO - 2021-03-17 17:19:37 --> Language Class Initialized
ERROR - 2021-03-17 17:19:37 --> 404 Page Not Found: Img/a2.jpg
ERROR - 2021-03-17 17:19:37 --> 404 Page Not Found: Img/profile.jpg
INFO - 2021-03-17 17:19:37 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:19:37 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:19:37 --> Utf8 Class Initialized
INFO - 2021-03-17 17:19:37 --> URI Class Initialized
INFO - 2021-03-17 17:19:37 --> Config Class Initialized
INFO - 2021-03-17 17:19:37 --> Hooks Class Initialized
INFO - 2021-03-17 17:19:37 --> Config Class Initialized
INFO - 2021-03-17 17:19:37 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:19:37 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:19:37 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:19:37 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:19:37 --> URI Class Initialized
INFO - 2021-03-17 17:19:37 --> Utf8 Class Initialized
INFO - 2021-03-17 17:19:37 --> Router Class Initialized
INFO - 2021-03-17 17:19:37 --> URI Class Initialized
INFO - 2021-03-17 17:19:37 --> Output Class Initialized
INFO - 2021-03-17 17:19:37 --> Security Class Initialized
INFO - 2021-03-17 17:19:37 --> Router Class Initialized
DEBUG - 2021-03-17 17:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:19:37 --> Input Class Initialized
INFO - 2021-03-17 17:19:37 --> Language Class Initialized
INFO - 2021-03-17 17:19:37 --> Output Class Initialized
ERROR - 2021-03-17 17:19:37 --> 404 Page Not Found: Img/a3.jpg
INFO - 2021-03-17 17:19:37 --> Security Class Initialized
DEBUG - 2021-03-17 17:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:19:37 --> Input Class Initialized
INFO - 2021-03-17 17:19:37 --> Language Class Initialized
ERROR - 2021-03-17 17:19:38 --> 404 Page Not Found: Img/a5.jpg
INFO - 2021-03-17 17:19:38 --> Router Class Initialized
INFO - 2021-03-17 17:19:38 --> Output Class Initialized
INFO - 2021-03-17 17:19:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:19:38 --> Input Class Initialized
INFO - 2021-03-17 17:19:38 --> Language Class Initialized
ERROR - 2021-03-17 17:19:38 --> 404 Page Not Found: Img/a4.jpg
INFO - 2021-03-17 17:19:38 --> Config Class Initialized
INFO - 2021-03-17 17:19:38 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:19:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:19:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:19:38 --> URI Class Initialized
INFO - 2021-03-17 17:19:38 --> Router Class Initialized
INFO - 2021-03-17 17:19:38 --> Output Class Initialized
INFO - 2021-03-17 17:19:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:19:38 --> Input Class Initialized
INFO - 2021-03-17 17:19:38 --> Language Class Initialized
ERROR - 2021-03-17 17:19:38 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 17:20:16 --> Config Class Initialized
INFO - 2021-03-17 17:20:16 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:20:16 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:20:16 --> Utf8 Class Initialized
INFO - 2021-03-17 17:20:16 --> URI Class Initialized
INFO - 2021-03-17 17:20:16 --> Router Class Initialized
INFO - 2021-03-17 17:20:16 --> Output Class Initialized
INFO - 2021-03-17 17:20:16 --> Security Class Initialized
DEBUG - 2021-03-17 17:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:20:16 --> Input Class Initialized
INFO - 2021-03-17 17:20:16 --> Language Class Initialized
INFO - 2021-03-17 17:20:16 --> Loader Class Initialized
INFO - 2021-03-17 17:20:16 --> Helper loaded: url_helper
INFO - 2021-03-17 17:20:16 --> Helper loaded: file_helper
INFO - 2021-03-17 17:20:16 --> Helper loaded: form_helper
INFO - 2021-03-17 17:20:16 --> Helper loaded: text_helper
INFO - 2021-03-17 17:20:16 --> Helper loaded: security_helper
INFO - 2021-03-17 17:20:16 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:20:16 --> Database Driver Class Initialized
INFO - 2021-03-17 17:20:16 --> Email Class Initialized
DEBUG - 2021-03-17 17:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:20:16 --> Form Validation Class Initialized
INFO - 2021-03-17 17:20:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:20:17 --> Pagination Class Initialized
INFO - 2021-03-17 17:20:17 --> Model Class Initialized
INFO - 2021-03-17 17:20:17 --> Controller Class Initialized
INFO - 2021-03-17 17:20:17 --> Model Class Initialized
INFO - 2021-03-17 17:20:17 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:20:17 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:20:17 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:20:17 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 17:20:17 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:20:17 --> Final output sent to browser
DEBUG - 2021-03-17 17:20:17 --> Total execution time: 0.9618
INFO - 2021-03-17 17:20:28 --> Config Class Initialized
INFO - 2021-03-17 17:20:28 --> Config Class Initialized
INFO - 2021-03-17 17:20:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:20:28 --> Config Class Initialized
INFO - 2021-03-17 17:20:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:20:28 --> Config Class Initialized
INFO - 2021-03-17 17:20:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:20:28 --> Config Class Initialized
INFO - 2021-03-17 17:20:28 --> Config Class Initialized
INFO - 2021-03-17 17:20:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:20:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:20:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:20:28 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:20:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:20:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:20:28 --> URI Class Initialized
DEBUG - 2021-03-17 17:20:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:20:28 --> URI Class Initialized
INFO - 2021-03-17 17:20:28 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:20:28 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:20:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:20:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:20:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:20:28 --> Router Class Initialized
INFO - 2021-03-17 17:20:28 --> URI Class Initialized
INFO - 2021-03-17 17:20:28 --> Router Class Initialized
INFO - 2021-03-17 17:20:28 --> URI Class Initialized
INFO - 2021-03-17 17:20:28 --> URI Class Initialized
INFO - 2021-03-17 17:20:28 --> Output Class Initialized
INFO - 2021-03-17 17:20:28 --> Router Class Initialized
INFO - 2021-03-17 17:20:28 --> Router Class Initialized
INFO - 2021-03-17 17:20:28 --> Router Class Initialized
INFO - 2021-03-17 17:20:28 --> Output Class Initialized
INFO - 2021-03-17 17:20:28 --> Security Class Initialized
INFO - 2021-03-17 17:20:28 --> Output Class Initialized
INFO - 2021-03-17 17:20:28 --> Output Class Initialized
INFO - 2021-03-17 17:20:28 --> Security Class Initialized
INFO - 2021-03-17 17:20:28 --> Output Class Initialized
DEBUG - 2021-03-17 17:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:20:28 --> Input Class Initialized
INFO - 2021-03-17 17:20:28 --> Security Class Initialized
INFO - 2021-03-17 17:20:28 --> Security Class Initialized
INFO - 2021-03-17 17:20:28 --> Language Class Initialized
INFO - 2021-03-17 17:20:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:20:28 --> Input Class Initialized
ERROR - 2021-03-17 17:20:28 --> 404 Page Not Found: Img/a4.jpg
INFO - 2021-03-17 17:20:28 --> Input Class Initialized
DEBUG - 2021-03-17 17:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:20:28 --> Input Class Initialized
DEBUG - 2021-03-17 17:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:20:28 --> Input Class Initialized
INFO - 2021-03-17 17:20:28 --> Language Class Initialized
INFO - 2021-03-17 17:20:28 --> Language Class Initialized
INFO - 2021-03-17 17:20:28 --> Language Class Initialized
INFO - 2021-03-17 17:20:28 --> Language Class Initialized
ERROR - 2021-03-17 17:20:28 --> 404 Page Not Found: Img/profile.jpg
ERROR - 2021-03-17 17:20:28 --> 404 Page Not Found: Img/a5.jpg
ERROR - 2021-03-17 17:20:28 --> 404 Page Not Found: Img/a3.jpg
ERROR - 2021-03-17 17:20:28 --> 404 Page Not Found: Img/a2.jpg
INFO - 2021-03-17 17:20:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:20:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:20:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:20:28 --> URI Class Initialized
INFO - 2021-03-17 17:20:28 --> Router Class Initialized
INFO - 2021-03-17 17:20:28 --> Output Class Initialized
INFO - 2021-03-17 17:20:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:20:28 --> Input Class Initialized
INFO - 2021-03-17 17:20:28 --> Language Class Initialized
ERROR - 2021-03-17 17:20:28 --> 404 Page Not Found: Img/a7.jpg
INFO - 2021-03-17 17:20:28 --> Config Class Initialized
INFO - 2021-03-17 17:20:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:20:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:20:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:20:28 --> URI Class Initialized
INFO - 2021-03-17 17:20:28 --> Router Class Initialized
INFO - 2021-03-17 17:20:28 --> Output Class Initialized
INFO - 2021-03-17 17:20:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:20:28 --> Input Class Initialized
INFO - 2021-03-17 17:20:28 --> Language Class Initialized
ERROR - 2021-03-17 17:20:28 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 17:21:05 --> Config Class Initialized
INFO - 2021-03-17 17:21:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:21:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:21:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:21:05 --> URI Class Initialized
INFO - 2021-03-17 17:21:05 --> Router Class Initialized
INFO - 2021-03-17 17:21:05 --> Output Class Initialized
INFO - 2021-03-17 17:21:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:21:05 --> Input Class Initialized
INFO - 2021-03-17 17:21:06 --> Language Class Initialized
INFO - 2021-03-17 17:21:06 --> Loader Class Initialized
INFO - 2021-03-17 17:21:06 --> Helper loaded: url_helper
INFO - 2021-03-17 17:21:06 --> Helper loaded: file_helper
INFO - 2021-03-17 17:21:06 --> Helper loaded: form_helper
INFO - 2021-03-17 17:21:06 --> Helper loaded: text_helper
INFO - 2021-03-17 17:21:06 --> Helper loaded: security_helper
INFO - 2021-03-17 17:21:06 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:21:06 --> Database Driver Class Initialized
INFO - 2021-03-17 17:21:06 --> Email Class Initialized
DEBUG - 2021-03-17 17:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:21:06 --> Form Validation Class Initialized
INFO - 2021-03-17 17:21:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:21:06 --> Pagination Class Initialized
INFO - 2021-03-17 17:21:06 --> Model Class Initialized
INFO - 2021-03-17 17:21:06 --> Controller Class Initialized
INFO - 2021-03-17 17:21:06 --> Model Class Initialized
INFO - 2021-03-17 17:21:06 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:21:06 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:21:06 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/header.php
INFO - 2021-03-17 17:21:06 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:21:06 --> Final output sent to browser
DEBUG - 2021-03-17 17:21:06 --> Total execution time: 1.1593
INFO - 2021-03-17 17:21:11 --> Config Class Initialized
INFO - 2021-03-17 17:21:11 --> Config Class Initialized
INFO - 2021-03-17 17:21:11 --> Hooks Class Initialized
INFO - 2021-03-17 17:21:11 --> Config Class Initialized
INFO - 2021-03-17 17:21:11 --> Hooks Class Initialized
INFO - 2021-03-17 17:21:11 --> Config Class Initialized
INFO - 2021-03-17 17:21:11 --> Hooks Class Initialized
INFO - 2021-03-17 17:21:11 --> Config Class Initialized
INFO - 2021-03-17 17:21:11 --> Hooks Class Initialized
INFO - 2021-03-17 17:21:11 --> Config Class Initialized
INFO - 2021-03-17 17:21:11 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:21:11 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:21:11 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:21:11 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:21:11 --> Utf8 Class Initialized
INFO - 2021-03-17 17:21:11 --> URI Class Initialized
DEBUG - 2021-03-17 17:21:11 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:21:11 --> Utf8 Class Initialized
INFO - 2021-03-17 17:21:11 --> URI Class Initialized
DEBUG - 2021-03-17 17:21:11 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:21:11 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:21:11 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:21:11 --> Utf8 Class Initialized
INFO - 2021-03-17 17:21:11 --> Router Class Initialized
INFO - 2021-03-17 17:21:11 --> URI Class Initialized
INFO - 2021-03-17 17:21:11 --> Router Class Initialized
INFO - 2021-03-17 17:21:11 --> URI Class Initialized
INFO - 2021-03-17 17:21:11 --> URI Class Initialized
INFO - 2021-03-17 17:21:11 --> Router Class Initialized
INFO - 2021-03-17 17:21:11 --> Output Class Initialized
INFO - 2021-03-17 17:21:11 --> Router Class Initialized
INFO - 2021-03-17 17:21:11 --> Router Class Initialized
INFO - 2021-03-17 17:21:11 --> Output Class Initialized
INFO - 2021-03-17 17:21:11 --> Output Class Initialized
INFO - 2021-03-17 17:21:11 --> Security Class Initialized
INFO - 2021-03-17 17:21:11 --> Output Class Initialized
INFO - 2021-03-17 17:21:11 --> Security Class Initialized
INFO - 2021-03-17 17:21:11 --> Output Class Initialized
INFO - 2021-03-17 17:21:11 --> Security Class Initialized
DEBUG - 2021-03-17 17:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:21:11 --> Input Class Initialized
DEBUG - 2021-03-17 17:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:21:11 --> Security Class Initialized
INFO - 2021-03-17 17:21:11 --> Security Class Initialized
INFO - 2021-03-17 17:21:11 --> Input Class Initialized
DEBUG - 2021-03-17 17:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:21:11 --> Input Class Initialized
INFO - 2021-03-17 17:21:11 --> Language Class Initialized
INFO - 2021-03-17 17:21:11 --> Language Class Initialized
INFO - 2021-03-17 17:21:11 --> Language Class Initialized
DEBUG - 2021-03-17 17:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:21:11 --> Input Class Initialized
INFO - 2021-03-17 17:21:11 --> Input Class Initialized
ERROR - 2021-03-17 17:21:11 --> 404 Page Not Found: Img/profile.jpg
ERROR - 2021-03-17 17:21:11 --> 404 Page Not Found: Img/a4.jpg
INFO - 2021-03-17 17:21:11 --> Language Class Initialized
INFO - 2021-03-17 17:21:11 --> Language Class Initialized
ERROR - 2021-03-17 17:21:11 --> 404 Page Not Found: Img/a2.jpg
ERROR - 2021-03-17 17:21:11 --> 404 Page Not Found: Img/a5.jpg
ERROR - 2021-03-17 17:21:11 --> 404 Page Not Found: Img/a3.jpg
INFO - 2021-03-17 17:21:11 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:21:11 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:21:11 --> Utf8 Class Initialized
INFO - 2021-03-17 17:21:11 --> URI Class Initialized
INFO - 2021-03-17 17:21:11 --> Router Class Initialized
INFO - 2021-03-17 17:21:11 --> Output Class Initialized
INFO - 2021-03-17 17:21:11 --> Security Class Initialized
DEBUG - 2021-03-17 17:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:21:11 --> Config Class Initialized
INFO - 2021-03-17 17:21:11 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:21:11 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:21:11 --> Utf8 Class Initialized
INFO - 2021-03-17 17:21:11 --> URI Class Initialized
INFO - 2021-03-17 17:21:11 --> Router Class Initialized
INFO - 2021-03-17 17:21:11 --> Output Class Initialized
INFO - 2021-03-17 17:21:11 --> Security Class Initialized
DEBUG - 2021-03-17 17:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:21:11 --> Input Class Initialized
INFO - 2021-03-17 17:21:11 --> Language Class Initialized
ERROR - 2021-03-17 17:21:11 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 17:21:11 --> Input Class Initialized
INFO - 2021-03-17 17:21:11 --> Language Class Initialized
ERROR - 2021-03-17 17:21:11 --> 404 Page Not Found: Img/a7.jpg
INFO - 2021-03-17 17:21:31 --> Config Class Initialized
INFO - 2021-03-17 17:21:31 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:21:31 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:21:31 --> Utf8 Class Initialized
INFO - 2021-03-17 17:21:31 --> URI Class Initialized
INFO - 2021-03-17 17:21:31 --> Router Class Initialized
INFO - 2021-03-17 17:21:31 --> Output Class Initialized
INFO - 2021-03-17 17:21:32 --> Security Class Initialized
DEBUG - 2021-03-17 17:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:21:32 --> Input Class Initialized
INFO - 2021-03-17 17:21:32 --> Language Class Initialized
INFO - 2021-03-17 17:21:32 --> Loader Class Initialized
INFO - 2021-03-17 17:21:32 --> Helper loaded: url_helper
INFO - 2021-03-17 17:21:32 --> Helper loaded: file_helper
INFO - 2021-03-17 17:21:32 --> Helper loaded: form_helper
INFO - 2021-03-17 17:21:32 --> Helper loaded: text_helper
INFO - 2021-03-17 17:21:32 --> Helper loaded: security_helper
INFO - 2021-03-17 17:21:32 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:21:32 --> Database Driver Class Initialized
INFO - 2021-03-17 17:21:32 --> Email Class Initialized
DEBUG - 2021-03-17 17:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:21:32 --> Form Validation Class Initialized
INFO - 2021-03-17 17:21:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:21:32 --> Pagination Class Initialized
INFO - 2021-03-17 17:21:32 --> Model Class Initialized
INFO - 2021-03-17 17:21:32 --> Controller Class Initialized
INFO - 2021-03-17 17:21:32 --> Model Class Initialized
INFO - 2021-03-17 17:21:32 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:21:32 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/sidebar.php
INFO - 2021-03-17 17:21:32 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:21:32 --> Final output sent to browser
DEBUG - 2021-03-17 17:21:32 --> Total execution time: 1.1018
INFO - 2021-03-17 17:21:34 --> Config Class Initialized
INFO - 2021-03-17 17:21:34 --> Config Class Initialized
INFO - 2021-03-17 17:21:34 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:21:34 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:21:34 --> Utf8 Class Initialized
INFO - 2021-03-17 17:21:34 --> URI Class Initialized
INFO - 2021-03-17 17:21:34 --> Router Class Initialized
INFO - 2021-03-17 17:21:34 --> Output Class Initialized
INFO - 2021-03-17 17:21:34 --> Security Class Initialized
DEBUG - 2021-03-17 17:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:21:34 --> Input Class Initialized
INFO - 2021-03-17 17:21:34 --> Language Class Initialized
ERROR - 2021-03-17 17:21:34 --> 404 Page Not Found: Img/a2.jpg
INFO - 2021-03-17 17:21:34 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:21:34 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:21:34 --> Utf8 Class Initialized
INFO - 2021-03-17 17:21:34 --> URI Class Initialized
INFO - 2021-03-17 17:21:34 --> Router Class Initialized
INFO - 2021-03-17 17:21:34 --> Output Class Initialized
INFO - 2021-03-17 17:21:34 --> Config Class Initialized
INFO - 2021-03-17 17:21:34 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:21:34 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:21:34 --> Utf8 Class Initialized
INFO - 2021-03-17 17:21:34 --> URI Class Initialized
INFO - 2021-03-17 17:21:34 --> Router Class Initialized
INFO - 2021-03-17 17:21:34 --> Output Class Initialized
INFO - 2021-03-17 17:21:34 --> Security Class Initialized
DEBUG - 2021-03-17 17:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:21:34 --> Input Class Initialized
INFO - 2021-03-17 17:21:34 --> Config Class Initialized
INFO - 2021-03-17 17:21:34 --> Config Class Initialized
INFO - 2021-03-17 17:21:34 --> Hooks Class Initialized
INFO - 2021-03-17 17:21:34 --> Hooks Class Initialized
INFO - 2021-03-17 17:21:34 --> Language Class Initialized
INFO - 2021-03-17 17:21:34 --> Security Class Initialized
DEBUG - 2021-03-17 17:21:34 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:21:34 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:21:34 --> Utf8 Class Initialized
INFO - 2021-03-17 17:21:34 --> Utf8 Class Initialized
DEBUG - 2021-03-17 17:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:21:34 --> Input Class Initialized
INFO - 2021-03-17 17:21:34 --> URI Class Initialized
INFO - 2021-03-17 17:21:34 --> URI Class Initialized
INFO - 2021-03-17 17:21:34 --> Language Class Initialized
INFO - 2021-03-17 17:21:34 --> Router Class Initialized
INFO - 2021-03-17 17:21:34 --> Router Class Initialized
ERROR - 2021-03-17 17:21:34 --> 404 Page Not Found: Img/a4.jpg
INFO - 2021-03-17 17:21:34 --> Output Class Initialized
INFO - 2021-03-17 17:21:34 --> Output Class Initialized
INFO - 2021-03-17 17:21:34 --> Security Class Initialized
INFO - 2021-03-17 17:21:34 --> Security Class Initialized
DEBUG - 2021-03-17 17:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-17 17:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:21:34 --> Input Class Initialized
INFO - 2021-03-17 17:21:34 --> Input Class Initialized
INFO - 2021-03-17 17:21:34 --> Language Class Initialized
INFO - 2021-03-17 17:21:34 --> Language Class Initialized
ERROR - 2021-03-17 17:21:34 --> 404 Page Not Found: Img/a5.jpg
ERROR - 2021-03-17 17:21:34 --> 404 Page Not Found: Img/profile.jpg
ERROR - 2021-03-17 17:21:34 --> 404 Page Not Found: Img/a3.jpg
INFO - 2021-03-17 17:21:34 --> Config Class Initialized
INFO - 2021-03-17 17:21:34 --> Hooks Class Initialized
INFO - 2021-03-17 17:21:34 --> Config Class Initialized
INFO - 2021-03-17 17:21:34 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:21:34 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:21:34 --> Utf8 Class Initialized
INFO - 2021-03-17 17:21:34 --> URI Class Initialized
INFO - 2021-03-17 17:21:34 --> Router Class Initialized
INFO - 2021-03-17 17:21:34 --> Output Class Initialized
INFO - 2021-03-17 17:21:34 --> Security Class Initialized
DEBUG - 2021-03-17 17:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:21:34 --> Input Class Initialized
INFO - 2021-03-17 17:21:34 --> Language Class Initialized
ERROR - 2021-03-17 17:21:34 --> 404 Page Not Found: Skin-config2html/index
DEBUG - 2021-03-17 17:21:34 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:21:34 --> Utf8 Class Initialized
INFO - 2021-03-17 17:21:34 --> URI Class Initialized
INFO - 2021-03-17 17:21:34 --> Router Class Initialized
INFO - 2021-03-17 17:21:34 --> Output Class Initialized
INFO - 2021-03-17 17:21:34 --> Security Class Initialized
DEBUG - 2021-03-17 17:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:21:34 --> Input Class Initialized
INFO - 2021-03-17 17:21:34 --> Language Class Initialized
ERROR - 2021-03-17 17:21:34 --> 404 Page Not Found: Img/a7.jpg
INFO - 2021-03-17 17:31:38 --> Config Class Initialized
INFO - 2021-03-17 17:31:38 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:31:38 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:31:38 --> Utf8 Class Initialized
INFO - 2021-03-17 17:31:38 --> URI Class Initialized
INFO - 2021-03-17 17:31:38 --> Router Class Initialized
INFO - 2021-03-17 17:31:38 --> Output Class Initialized
INFO - 2021-03-17 17:31:38 --> Security Class Initialized
DEBUG - 2021-03-17 17:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:31:38 --> Input Class Initialized
INFO - 2021-03-17 17:31:38 --> Language Class Initialized
INFO - 2021-03-17 17:31:38 --> Loader Class Initialized
INFO - 2021-03-17 17:31:38 --> Helper loaded: url_helper
INFO - 2021-03-17 17:31:38 --> Helper loaded: file_helper
INFO - 2021-03-17 17:31:38 --> Helper loaded: form_helper
INFO - 2021-03-17 17:31:38 --> Helper loaded: text_helper
INFO - 2021-03-17 17:31:38 --> Helper loaded: security_helper
INFO - 2021-03-17 17:31:38 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:31:38 --> Database Driver Class Initialized
INFO - 2021-03-17 17:31:38 --> Email Class Initialized
DEBUG - 2021-03-17 17:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:31:39 --> Form Validation Class Initialized
INFO - 2021-03-17 17:31:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:31:39 --> Pagination Class Initialized
INFO - 2021-03-17 17:31:39 --> Model Class Initialized
INFO - 2021-03-17 17:31:39 --> Controller Class Initialized
INFO - 2021-03-17 17:31:39 --> Model Class Initialized
INFO - 2021-03-17 17:31:39 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:32:26 --> Config Class Initialized
INFO - 2021-03-17 17:32:26 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:32:26 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:32:26 --> Utf8 Class Initialized
INFO - 2021-03-17 17:32:26 --> URI Class Initialized
INFO - 2021-03-17 17:32:26 --> Router Class Initialized
INFO - 2021-03-17 17:32:26 --> Output Class Initialized
INFO - 2021-03-17 17:32:26 --> Security Class Initialized
DEBUG - 2021-03-17 17:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:32:26 --> Input Class Initialized
INFO - 2021-03-17 17:32:26 --> Language Class Initialized
INFO - 2021-03-17 17:32:26 --> Loader Class Initialized
INFO - 2021-03-17 17:32:26 --> Helper loaded: url_helper
INFO - 2021-03-17 17:32:27 --> Helper loaded: file_helper
INFO - 2021-03-17 17:32:27 --> Helper loaded: form_helper
INFO - 2021-03-17 17:32:27 --> Helper loaded: text_helper
INFO - 2021-03-17 17:32:27 --> Helper loaded: security_helper
INFO - 2021-03-17 17:32:27 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:32:27 --> Database Driver Class Initialized
INFO - 2021-03-17 17:32:27 --> Email Class Initialized
DEBUG - 2021-03-17 17:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:32:27 --> Form Validation Class Initialized
INFO - 2021-03-17 17:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:32:27 --> Pagination Class Initialized
INFO - 2021-03-17 17:32:27 --> Model Class Initialized
INFO - 2021-03-17 17:32:27 --> Controller Class Initialized
INFO - 2021-03-17 17:32:27 --> Model Class Initialized
INFO - 2021-03-17 17:32:27 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:32:27 --> Final output sent to browser
DEBUG - 2021-03-17 17:32:27 --> Total execution time: 1.1545
INFO - 2021-03-17 17:32:27 --> Config Class Initialized
INFO - 2021-03-17 17:32:27 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:32:27 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:32:27 --> Utf8 Class Initialized
INFO - 2021-03-17 17:32:27 --> Config Class Initialized
INFO - 2021-03-17 17:32:27 --> Hooks Class Initialized
INFO - 2021-03-17 17:32:27 --> URI Class Initialized
INFO - 2021-03-17 17:32:27 --> Router Class Initialized
DEBUG - 2021-03-17 17:32:27 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:32:27 --> Utf8 Class Initialized
INFO - 2021-03-17 17:32:27 --> Output Class Initialized
INFO - 2021-03-17 17:32:27 --> URI Class Initialized
INFO - 2021-03-17 17:32:27 --> Security Class Initialized
DEBUG - 2021-03-17 17:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:32:27 --> Router Class Initialized
INFO - 2021-03-17 17:32:27 --> Input Class Initialized
INFO - 2021-03-17 17:32:27 --> Language Class Initialized
INFO - 2021-03-17 17:32:27 --> Output Class Initialized
ERROR - 2021-03-17 17:32:27 --> 404 Page Not Found: Img/profile.jpg
INFO - 2021-03-17 17:32:27 --> Security Class Initialized
DEBUG - 2021-03-17 17:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:32:27 --> Input Class Initialized
INFO - 2021-03-17 17:32:27 --> Language Class Initialized
ERROR - 2021-03-17 17:32:27 --> 404 Page Not Found: Img/a2.jpg
INFO - 2021-03-17 17:32:28 --> Config Class Initialized
INFO - 2021-03-17 17:32:28 --> Config Class Initialized
INFO - 2021-03-17 17:32:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:32:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:32:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:32:28 --> URI Class Initialized
INFO - 2021-03-17 17:32:28 --> Router Class Initialized
INFO - 2021-03-17 17:32:28 --> Output Class Initialized
INFO - 2021-03-17 17:32:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:32:28 --> Input Class Initialized
INFO - 2021-03-17 17:32:28 --> Language Class Initialized
ERROR - 2021-03-17 17:32:28 --> 404 Page Not Found: Img/a4.jpg
INFO - 2021-03-17 17:32:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:32:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:32:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:32:28 --> URI Class Initialized
INFO - 2021-03-17 17:32:28 --> Config Class Initialized
INFO - 2021-03-17 17:32:28 --> Hooks Class Initialized
INFO - 2021-03-17 17:32:28 --> Config Class Initialized
INFO - 2021-03-17 17:32:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:32:28 --> UTF-8 Support Enabled
DEBUG - 2021-03-17 17:32:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:32:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:32:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:32:28 --> URI Class Initialized
INFO - 2021-03-17 17:32:28 --> URI Class Initialized
INFO - 2021-03-17 17:32:28 --> Router Class Initialized
INFO - 2021-03-17 17:32:28 --> Router Class Initialized
INFO - 2021-03-17 17:32:28 --> Output Class Initialized
INFO - 2021-03-17 17:32:28 --> Output Class Initialized
INFO - 2021-03-17 17:32:28 --> Security Class Initialized
INFO - 2021-03-17 17:32:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:32:28 --> Input Class Initialized
INFO - 2021-03-17 17:32:28 --> Language Class Initialized
DEBUG - 2021-03-17 17:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:32:28 --> Input Class Initialized
ERROR - 2021-03-17 17:32:28 --> 404 Page Not Found: Img/a7.jpg
INFO - 2021-03-17 17:32:28 --> Language Class Initialized
ERROR - 2021-03-17 17:32:28 --> 404 Page Not Found: Img/a3.jpg
INFO - 2021-03-17 17:32:28 --> Router Class Initialized
INFO - 2021-03-17 17:32:28 --> Output Class Initialized
INFO - 2021-03-17 17:32:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:32:28 --> Config Class Initialized
INFO - 2021-03-17 17:32:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:32:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:32:28 --> Utf8 Class Initialized
INFO - 2021-03-17 17:32:28 --> URI Class Initialized
INFO - 2021-03-17 17:32:28 --> Router Class Initialized
INFO - 2021-03-17 17:32:28 --> Output Class Initialized
INFO - 2021-03-17 17:32:28 --> Security Class Initialized
DEBUG - 2021-03-17 17:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:32:28 --> Input Class Initialized
INFO - 2021-03-17 17:32:28 --> Language Class Initialized
ERROR - 2021-03-17 17:32:28 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 17:32:28 --> Input Class Initialized
INFO - 2021-03-17 17:32:28 --> Language Class Initialized
ERROR - 2021-03-17 17:32:28 --> 404 Page Not Found: Img/a5.jpg
INFO - 2021-03-17 17:33:14 --> Config Class Initialized
INFO - 2021-03-17 17:33:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:33:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:33:14 --> Utf8 Class Initialized
INFO - 2021-03-17 17:33:14 --> URI Class Initialized
INFO - 2021-03-17 17:33:14 --> Router Class Initialized
INFO - 2021-03-17 17:33:14 --> Output Class Initialized
INFO - 2021-03-17 17:33:14 --> Security Class Initialized
DEBUG - 2021-03-17 17:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:33:14 --> Input Class Initialized
INFO - 2021-03-17 17:33:15 --> Language Class Initialized
INFO - 2021-03-17 17:33:15 --> Loader Class Initialized
INFO - 2021-03-17 17:33:15 --> Helper loaded: url_helper
INFO - 2021-03-17 17:33:15 --> Helper loaded: file_helper
INFO - 2021-03-17 17:33:15 --> Helper loaded: form_helper
INFO - 2021-03-17 17:33:15 --> Helper loaded: text_helper
INFO - 2021-03-17 17:33:15 --> Helper loaded: security_helper
INFO - 2021-03-17 17:33:15 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:33:15 --> Database Driver Class Initialized
INFO - 2021-03-17 17:33:15 --> Email Class Initialized
DEBUG - 2021-03-17 17:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:33:15 --> Form Validation Class Initialized
INFO - 2021-03-17 17:33:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:33:15 --> Pagination Class Initialized
INFO - 2021-03-17 17:33:15 --> Model Class Initialized
INFO - 2021-03-17 17:33:15 --> Controller Class Initialized
INFO - 2021-03-17 17:33:15 --> Model Class Initialized
ERROR - 2021-03-17 17:33:15 --> Severity: Warning --> include(admin_include/head.php): Failed to open stream: No such file or directory E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php 7
ERROR - 2021-03-17 17:33:15 --> Severity: Warning --> include(): Failed opening 'admin_include/head.php' for inclusion (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php 7
ERROR - 2021-03-17 17:33:15 --> Severity: Warning --> include(admin_include/side_bar.php): Failed to open stream: No such file or directory E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php 8
ERROR - 2021-03-17 17:33:15 --> Severity: Warning --> include(): Failed opening 'admin_include/side_bar.php' for inclusion (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php 8
ERROR - 2021-03-17 17:33:15 --> Severity: Warning --> include(admin_include/upper_header.php): Failed to open stream: No such file or directory E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php 12
ERROR - 2021-03-17 17:33:15 --> Severity: Warning --> include(): Failed opening 'admin_include/upper_header.php' for inclusion (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php 12
ERROR - 2021-03-17 17:33:16 --> Severity: Warning --> include(admin_include/footer.php): Failed to open stream: No such file or directory E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php 439
ERROR - 2021-03-17 17:33:16 --> Severity: Warning --> include(): Failed opening 'admin_include/footer.php' for inclusion (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php 439
INFO - 2021-03-17 17:33:16 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:33:16 --> Final output sent to browser
DEBUG - 2021-03-17 17:33:16 --> Total execution time: 1.5017
INFO - 2021-03-17 17:34:05 --> Config Class Initialized
INFO - 2021-03-17 17:34:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:34:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:34:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:34:05 --> URI Class Initialized
INFO - 2021-03-17 17:34:05 --> Router Class Initialized
INFO - 2021-03-17 17:34:05 --> Output Class Initialized
INFO - 2021-03-17 17:34:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:34:05 --> Input Class Initialized
INFO - 2021-03-17 17:34:06 --> Language Class Initialized
INFO - 2021-03-17 17:34:06 --> Loader Class Initialized
INFO - 2021-03-17 17:34:06 --> Helper loaded: url_helper
INFO - 2021-03-17 17:34:06 --> Helper loaded: file_helper
INFO - 2021-03-17 17:34:06 --> Helper loaded: form_helper
INFO - 2021-03-17 17:34:06 --> Helper loaded: text_helper
INFO - 2021-03-17 17:34:06 --> Helper loaded: security_helper
INFO - 2021-03-17 17:34:06 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:34:06 --> Database Driver Class Initialized
INFO - 2021-03-17 17:34:06 --> Email Class Initialized
DEBUG - 2021-03-17 17:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:34:06 --> Form Validation Class Initialized
INFO - 2021-03-17 17:34:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:34:06 --> Pagination Class Initialized
INFO - 2021-03-17 17:34:06 --> Model Class Initialized
INFO - 2021-03-17 17:34:06 --> Controller Class Initialized
INFO - 2021-03-17 17:34:06 --> Model Class Initialized
INFO - 2021-03-17 17:34:06 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:34:06 --> Final output sent to browser
DEBUG - 2021-03-17 17:34:06 --> Total execution time: 1.2655
INFO - 2021-03-17 17:35:58 --> Config Class Initialized
INFO - 2021-03-17 17:35:58 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:35:58 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:35:58 --> Utf8 Class Initialized
INFO - 2021-03-17 17:35:58 --> URI Class Initialized
INFO - 2021-03-17 17:35:58 --> Router Class Initialized
INFO - 2021-03-17 17:35:58 --> Output Class Initialized
INFO - 2021-03-17 17:35:58 --> Security Class Initialized
DEBUG - 2021-03-17 17:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:35:59 --> Input Class Initialized
INFO - 2021-03-17 17:35:59 --> Language Class Initialized
INFO - 2021-03-17 17:35:59 --> Loader Class Initialized
INFO - 2021-03-17 17:35:59 --> Helper loaded: url_helper
INFO - 2021-03-17 17:35:59 --> Helper loaded: file_helper
INFO - 2021-03-17 17:35:59 --> Helper loaded: form_helper
INFO - 2021-03-17 17:35:59 --> Helper loaded: text_helper
INFO - 2021-03-17 17:35:59 --> Helper loaded: security_helper
INFO - 2021-03-17 17:35:59 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:35:59 --> Database Driver Class Initialized
INFO - 2021-03-17 17:35:59 --> Email Class Initialized
DEBUG - 2021-03-17 17:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:35:59 --> Form Validation Class Initialized
INFO - 2021-03-17 17:35:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:35:59 --> Pagination Class Initialized
INFO - 2021-03-17 17:35:59 --> Model Class Initialized
INFO - 2021-03-17 17:35:59 --> Controller Class Initialized
INFO - 2021-03-17 17:35:59 --> Model Class Initialized
INFO - 2021-03-17 17:35:59 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:35:59 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 17:35:59 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:35:59 --> Final output sent to browser
DEBUG - 2021-03-17 17:35:59 --> Total execution time: 1.2567
INFO - 2021-03-17 17:36:00 --> Config Class Initialized
INFO - 2021-03-17 17:36:00 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:36:00 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:36:00 --> Utf8 Class Initialized
INFO - 2021-03-17 17:36:01 --> Config Class Initialized
INFO - 2021-03-17 17:36:01 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:36:01 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:36:01 --> Utf8 Class Initialized
INFO - 2021-03-17 17:37:02 --> Config Class Initialized
INFO - 2021-03-17 17:37:02 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:37:02 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:37:02 --> Utf8 Class Initialized
INFO - 2021-03-17 17:37:02 --> URI Class Initialized
INFO - 2021-03-17 17:37:02 --> Router Class Initialized
INFO - 2021-03-17 17:37:02 --> Output Class Initialized
INFO - 2021-03-17 17:37:02 --> Security Class Initialized
DEBUG - 2021-03-17 17:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:37:02 --> Input Class Initialized
INFO - 2021-03-17 17:37:03 --> Language Class Initialized
INFO - 2021-03-17 17:37:03 --> Loader Class Initialized
INFO - 2021-03-17 17:37:03 --> Helper loaded: url_helper
INFO - 2021-03-17 17:37:03 --> Helper loaded: file_helper
INFO - 2021-03-17 17:37:03 --> Helper loaded: form_helper
INFO - 2021-03-17 17:37:03 --> Helper loaded: text_helper
INFO - 2021-03-17 17:37:03 --> Helper loaded: security_helper
INFO - 2021-03-17 17:37:03 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:37:03 --> Database Driver Class Initialized
INFO - 2021-03-17 17:37:03 --> Email Class Initialized
DEBUG - 2021-03-17 17:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:37:03 --> Form Validation Class Initialized
INFO - 2021-03-17 17:37:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:37:03 --> Pagination Class Initialized
INFO - 2021-03-17 17:37:03 --> Model Class Initialized
INFO - 2021-03-17 17:37:03 --> Controller Class Initialized
INFO - 2021-03-17 17:37:03 --> Model Class Initialized
INFO - 2021-03-17 17:37:03 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:37:03 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 17:37:03 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:37:03 --> Final output sent to browser
DEBUG - 2021-03-17 17:37:03 --> Total execution time: 1.2272
INFO - 2021-03-17 17:37:04 --> Config Class Initialized
INFO - 2021-03-17 17:37:04 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:37:04 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:37:04 --> Utf8 Class Initialized
INFO - 2021-03-17 17:37:04 --> URI Class Initialized
INFO - 2021-03-17 17:37:04 --> Router Class Initialized
INFO - 2021-03-17 17:37:04 --> Output Class Initialized
INFO - 2021-03-17 17:37:04 --> Security Class Initialized
DEBUG - 2021-03-17 17:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:37:04 --> Input Class Initialized
INFO - 2021-03-17 17:37:04 --> Language Class Initialized
ERROR - 2021-03-17 17:37:04 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 17:37:05 --> Config Class Initialized
INFO - 2021-03-17 17:37:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:37:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:37:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:37:05 --> URI Class Initialized
INFO - 2021-03-17 17:37:05 --> Router Class Initialized
INFO - 2021-03-17 17:37:05 --> Output Class Initialized
INFO - 2021-03-17 17:37:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:37:05 --> Input Class Initialized
INFO - 2021-03-17 17:37:05 --> Language Class Initialized
ERROR - 2021-03-17 17:37:05 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 17:37:05 --> Config Class Initialized
INFO - 2021-03-17 17:37:05 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:37:05 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:37:05 --> Utf8 Class Initialized
INFO - 2021-03-17 17:37:05 --> URI Class Initialized
INFO - 2021-03-17 17:37:05 --> Router Class Initialized
INFO - 2021-03-17 17:37:05 --> Output Class Initialized
INFO - 2021-03-17 17:37:05 --> Security Class Initialized
DEBUG - 2021-03-17 17:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:37:05 --> Input Class Initialized
INFO - 2021-03-17 17:37:06 --> Language Class Initialized
ERROR - 2021-03-17 17:37:06 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 17:37:47 --> Config Class Initialized
INFO - 2021-03-17 17:37:47 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:37:47 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:37:47 --> Utf8 Class Initialized
INFO - 2021-03-17 17:37:47 --> URI Class Initialized
INFO - 2021-03-17 17:37:47 --> Router Class Initialized
INFO - 2021-03-17 17:37:47 --> Output Class Initialized
INFO - 2021-03-17 17:37:47 --> Security Class Initialized
DEBUG - 2021-03-17 17:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:37:47 --> Input Class Initialized
INFO - 2021-03-17 17:37:48 --> Language Class Initialized
INFO - 2021-03-17 17:37:48 --> Loader Class Initialized
INFO - 2021-03-17 17:37:48 --> Helper loaded: url_helper
INFO - 2021-03-17 17:37:48 --> Helper loaded: file_helper
INFO - 2021-03-17 17:37:48 --> Helper loaded: form_helper
INFO - 2021-03-17 17:37:48 --> Helper loaded: text_helper
INFO - 2021-03-17 17:37:48 --> Helper loaded: security_helper
INFO - 2021-03-17 17:37:48 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:37:48 --> Database Driver Class Initialized
INFO - 2021-03-17 17:37:48 --> Email Class Initialized
DEBUG - 2021-03-17 17:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:37:48 --> Form Validation Class Initialized
INFO - 2021-03-17 17:37:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:37:48 --> Pagination Class Initialized
INFO - 2021-03-17 17:37:48 --> Model Class Initialized
INFO - 2021-03-17 17:37:48 --> Controller Class Initialized
INFO - 2021-03-17 17:37:48 --> Model Class Initialized
INFO - 2021-03-17 17:37:48 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:37:48 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 17:37:48 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:37:48 --> Final output sent to browser
DEBUG - 2021-03-17 17:37:48 --> Total execution time: 1.1768
INFO - 2021-03-17 17:37:49 --> Config Class Initialized
INFO - 2021-03-17 17:37:49 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:37:49 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:37:49 --> Utf8 Class Initialized
INFO - 2021-03-17 17:37:49 --> URI Class Initialized
INFO - 2021-03-17 17:37:49 --> Router Class Initialized
INFO - 2021-03-17 17:37:49 --> Output Class Initialized
INFO - 2021-03-17 17:37:49 --> Security Class Initialized
DEBUG - 2021-03-17 17:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:37:49 --> Input Class Initialized
INFO - 2021-03-17 17:37:49 --> Language Class Initialized
ERROR - 2021-03-17 17:37:49 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 17:37:49 --> Config Class Initialized
INFO - 2021-03-17 17:37:49 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:37:50 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:37:50 --> Utf8 Class Initialized
INFO - 2021-03-17 17:37:50 --> URI Class Initialized
INFO - 2021-03-17 17:37:50 --> Router Class Initialized
INFO - 2021-03-17 17:37:50 --> Output Class Initialized
INFO - 2021-03-17 17:37:50 --> Security Class Initialized
DEBUG - 2021-03-17 17:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:37:50 --> Input Class Initialized
INFO - 2021-03-17 17:37:50 --> Language Class Initialized
ERROR - 2021-03-17 17:37:50 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 17:38:04 --> Config Class Initialized
INFO - 2021-03-17 17:38:04 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:38:04 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:38:04 --> Utf8 Class Initialized
INFO - 2021-03-17 17:38:04 --> URI Class Initialized
INFO - 2021-03-17 17:38:04 --> Router Class Initialized
INFO - 2021-03-17 17:38:04 --> Output Class Initialized
INFO - 2021-03-17 17:38:04 --> Security Class Initialized
DEBUG - 2021-03-17 17:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:38:04 --> Input Class Initialized
INFO - 2021-03-17 17:38:04 --> Language Class Initialized
INFO - 2021-03-17 17:38:04 --> Loader Class Initialized
INFO - 2021-03-17 17:38:04 --> Helper loaded: url_helper
INFO - 2021-03-17 17:38:04 --> Helper loaded: file_helper
INFO - 2021-03-17 17:38:05 --> Helper loaded: form_helper
INFO - 2021-03-17 17:38:05 --> Helper loaded: text_helper
INFO - 2021-03-17 17:38:05 --> Helper loaded: security_helper
INFO - 2021-03-17 17:38:05 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 17:38:05 --> Database Driver Class Initialized
INFO - 2021-03-17 17:38:05 --> Email Class Initialized
DEBUG - 2021-03-17 17:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 17:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 17:38:05 --> Form Validation Class Initialized
INFO - 2021-03-17 17:38:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 17:38:05 --> Pagination Class Initialized
INFO - 2021-03-17 17:38:05 --> Model Class Initialized
INFO - 2021-03-17 17:38:05 --> Controller Class Initialized
INFO - 2021-03-17 17:38:05 --> Model Class Initialized
INFO - 2021-03-17 17:38:05 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 17:38:05 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 17:38:05 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 17:38:05 --> Final output sent to browser
DEBUG - 2021-03-17 17:38:05 --> Total execution time: 1.2861
INFO - 2021-03-17 17:38:06 --> Config Class Initialized
INFO - 2021-03-17 17:38:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:38:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:38:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:38:06 --> URI Class Initialized
INFO - 2021-03-17 17:38:06 --> Router Class Initialized
INFO - 2021-03-17 17:38:06 --> Output Class Initialized
INFO - 2021-03-17 17:38:06 --> Security Class Initialized
DEBUG - 2021-03-17 17:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:38:06 --> Input Class Initialized
INFO - 2021-03-17 17:38:06 --> Language Class Initialized
ERROR - 2021-03-17 17:38:06 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 17:38:06 --> Config Class Initialized
INFO - 2021-03-17 17:38:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 17:38:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 17:38:06 --> Utf8 Class Initialized
INFO - 2021-03-17 17:38:06 --> URI Class Initialized
INFO - 2021-03-17 17:38:07 --> Router Class Initialized
INFO - 2021-03-17 17:38:07 --> Output Class Initialized
INFO - 2021-03-17 17:38:07 --> Security Class Initialized
DEBUG - 2021-03-17 17:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 17:38:07 --> Input Class Initialized
INFO - 2021-03-17 17:38:07 --> Language Class Initialized
ERROR - 2021-03-17 17:38:07 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 20:32:46 --> Config Class Initialized
INFO - 2021-03-17 20:32:46 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:32:46 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:32:46 --> Utf8 Class Initialized
INFO - 2021-03-17 20:32:46 --> URI Class Initialized
INFO - 2021-03-17 20:32:46 --> Router Class Initialized
INFO - 2021-03-17 20:32:46 --> Output Class Initialized
INFO - 2021-03-17 20:32:46 --> Security Class Initialized
DEBUG - 2021-03-17 20:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:32:46 --> Input Class Initialized
INFO - 2021-03-17 20:32:46 --> Language Class Initialized
INFO - 2021-03-17 20:32:46 --> Loader Class Initialized
INFO - 2021-03-17 20:32:46 --> Helper loaded: url_helper
INFO - 2021-03-17 20:32:46 --> Helper loaded: file_helper
INFO - 2021-03-17 20:32:46 --> Helper loaded: form_helper
INFO - 2021-03-17 20:32:46 --> Helper loaded: text_helper
INFO - 2021-03-17 20:32:46 --> Helper loaded: security_helper
INFO - 2021-03-17 20:32:46 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 20:32:46 --> Database Driver Class Initialized
INFO - 2021-03-17 20:32:46 --> Email Class Initialized
DEBUG - 2021-03-17 20:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 20:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 20:32:46 --> Form Validation Class Initialized
INFO - 2021-03-17 20:32:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 20:32:46 --> Pagination Class Initialized
INFO - 2021-03-17 20:32:46 --> Model Class Initialized
INFO - 2021-03-17 20:32:46 --> Controller Class Initialized
INFO - 2021-03-17 20:32:46 --> Model Class Initialized
INFO - 2021-03-17 20:32:46 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 20:32:46 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 20:32:46 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-17 20:32:46 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 20:32:46 --> Final output sent to browser
DEBUG - 2021-03-17 20:32:46 --> Total execution time: 0.8601
INFO - 2021-03-17 20:32:47 --> Config Class Initialized
INFO - 2021-03-17 20:32:47 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:32:47 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:32:47 --> Utf8 Class Initialized
INFO - 2021-03-17 20:32:47 --> URI Class Initialized
INFO - 2021-03-17 20:32:47 --> Router Class Initialized
INFO - 2021-03-17 20:32:47 --> Output Class Initialized
INFO - 2021-03-17 20:32:47 --> Security Class Initialized
DEBUG - 2021-03-17 20:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:32:47 --> Input Class Initialized
INFO - 2021-03-17 20:32:47 --> Language Class Initialized
ERROR - 2021-03-17 20:32:48 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:32:48 --> Config Class Initialized
INFO - 2021-03-17 20:32:48 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:32:48 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:32:48 --> Utf8 Class Initialized
INFO - 2021-03-17 20:32:48 --> URI Class Initialized
INFO - 2021-03-17 20:32:48 --> Router Class Initialized
INFO - 2021-03-17 20:32:48 --> Output Class Initialized
INFO - 2021-03-17 20:32:48 --> Security Class Initialized
DEBUG - 2021-03-17 20:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:32:48 --> Input Class Initialized
INFO - 2021-03-17 20:32:48 --> Language Class Initialized
ERROR - 2021-03-17 20:32:48 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 20:33:27 --> Config Class Initialized
INFO - 2021-03-17 20:33:27 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:33:27 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:33:27 --> Utf8 Class Initialized
INFO - 2021-03-17 20:33:27 --> URI Class Initialized
INFO - 2021-03-17 20:33:27 --> Router Class Initialized
INFO - 2021-03-17 20:33:27 --> Output Class Initialized
INFO - 2021-03-17 20:33:27 --> Security Class Initialized
DEBUG - 2021-03-17 20:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:33:27 --> Input Class Initialized
INFO - 2021-03-17 20:33:27 --> Language Class Initialized
INFO - 2021-03-17 20:33:27 --> Loader Class Initialized
INFO - 2021-03-17 20:33:27 --> Helper loaded: url_helper
INFO - 2021-03-17 20:33:27 --> Helper loaded: file_helper
INFO - 2021-03-17 20:33:27 --> Helper loaded: form_helper
INFO - 2021-03-17 20:33:27 --> Helper loaded: text_helper
INFO - 2021-03-17 20:33:27 --> Helper loaded: security_helper
INFO - 2021-03-17 20:33:27 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 20:33:27 --> Database Driver Class Initialized
INFO - 2021-03-17 20:33:27 --> Email Class Initialized
DEBUG - 2021-03-17 20:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 20:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 20:33:28 --> Form Validation Class Initialized
INFO - 2021-03-17 20:33:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 20:33:28 --> Pagination Class Initialized
INFO - 2021-03-17 20:33:28 --> Model Class Initialized
INFO - 2021-03-17 20:33:28 --> Controller Class Initialized
INFO - 2021-03-17 20:33:28 --> Model Class Initialized
INFO - 2021-03-17 20:33:28 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 20:33:28 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 20:33:28 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-17 20:33:28 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 20:33:28 --> Final output sent to browser
DEBUG - 2021-03-17 20:33:28 --> Total execution time: 1.3187
INFO - 2021-03-17 20:33:28 --> Config Class Initialized
INFO - 2021-03-17 20:33:28 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:33:28 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:33:28 --> Utf8 Class Initialized
INFO - 2021-03-17 20:33:28 --> URI Class Initialized
INFO - 2021-03-17 20:33:28 --> Router Class Initialized
INFO - 2021-03-17 20:33:29 --> Output Class Initialized
INFO - 2021-03-17 20:33:29 --> Security Class Initialized
DEBUG - 2021-03-17 20:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:33:29 --> Input Class Initialized
INFO - 2021-03-17 20:33:29 --> Language Class Initialized
ERROR - 2021-03-17 20:33:29 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:33:29 --> Config Class Initialized
INFO - 2021-03-17 20:33:29 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:33:29 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:33:29 --> Utf8 Class Initialized
INFO - 2021-03-17 20:33:29 --> URI Class Initialized
INFO - 2021-03-17 20:33:29 --> Router Class Initialized
INFO - 2021-03-17 20:33:29 --> Output Class Initialized
INFO - 2021-03-17 20:33:29 --> Security Class Initialized
DEBUG - 2021-03-17 20:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:33:29 --> Input Class Initialized
INFO - 2021-03-17 20:33:29 --> Language Class Initialized
ERROR - 2021-03-17 20:33:29 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 20:34:50 --> Config Class Initialized
INFO - 2021-03-17 20:34:50 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:34:50 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:34:50 --> Utf8 Class Initialized
INFO - 2021-03-17 20:34:50 --> URI Class Initialized
INFO - 2021-03-17 20:34:50 --> Router Class Initialized
INFO - 2021-03-17 20:34:50 --> Output Class Initialized
INFO - 2021-03-17 20:34:50 --> Security Class Initialized
DEBUG - 2021-03-17 20:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:34:50 --> Input Class Initialized
INFO - 2021-03-17 20:34:50 --> Language Class Initialized
INFO - 2021-03-17 20:34:50 --> Loader Class Initialized
INFO - 2021-03-17 20:34:50 --> Helper loaded: url_helper
INFO - 2021-03-17 20:34:50 --> Helper loaded: file_helper
INFO - 2021-03-17 20:34:50 --> Helper loaded: form_helper
INFO - 2021-03-17 20:34:50 --> Helper loaded: text_helper
INFO - 2021-03-17 20:34:50 --> Helper loaded: security_helper
INFO - 2021-03-17 20:34:50 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 20:34:50 --> Database Driver Class Initialized
INFO - 2021-03-17 20:34:50 --> Email Class Initialized
DEBUG - 2021-03-17 20:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 20:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 20:34:51 --> Form Validation Class Initialized
INFO - 2021-03-17 20:34:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 20:34:51 --> Pagination Class Initialized
INFO - 2021-03-17 20:34:51 --> Model Class Initialized
INFO - 2021-03-17 20:34:51 --> Controller Class Initialized
INFO - 2021-03-17 20:34:51 --> Model Class Initialized
INFO - 2021-03-17 20:34:51 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 20:34:51 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 20:34:51 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-17 20:34:51 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 20:34:51 --> Final output sent to browser
DEBUG - 2021-03-17 20:34:51 --> Total execution time: 1.3231
INFO - 2021-03-17 20:34:51 --> Config Class Initialized
INFO - 2021-03-17 20:34:51 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:34:51 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:34:51 --> Utf8 Class Initialized
INFO - 2021-03-17 20:34:52 --> URI Class Initialized
INFO - 2021-03-17 20:34:52 --> Router Class Initialized
INFO - 2021-03-17 20:34:52 --> Output Class Initialized
INFO - 2021-03-17 20:34:52 --> Security Class Initialized
DEBUG - 2021-03-17 20:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:34:52 --> Input Class Initialized
INFO - 2021-03-17 20:34:52 --> Language Class Initialized
ERROR - 2021-03-17 20:34:52 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:34:52 --> Config Class Initialized
INFO - 2021-03-17 20:34:52 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:34:52 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:34:52 --> Utf8 Class Initialized
INFO - 2021-03-17 20:34:52 --> URI Class Initialized
INFO - 2021-03-17 20:34:52 --> Router Class Initialized
INFO - 2021-03-17 20:34:52 --> Output Class Initialized
INFO - 2021-03-17 20:34:52 --> Security Class Initialized
DEBUG - 2021-03-17 20:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:34:52 --> Input Class Initialized
INFO - 2021-03-17 20:34:53 --> Language Class Initialized
ERROR - 2021-03-17 20:34:53 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 20:38:55 --> Config Class Initialized
INFO - 2021-03-17 20:38:55 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:38:55 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:38:55 --> Utf8 Class Initialized
INFO - 2021-03-17 20:38:55 --> URI Class Initialized
INFO - 2021-03-17 20:38:55 --> Router Class Initialized
INFO - 2021-03-17 20:38:55 --> Output Class Initialized
INFO - 2021-03-17 20:38:55 --> Security Class Initialized
DEBUG - 2021-03-17 20:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:38:55 --> Input Class Initialized
INFO - 2021-03-17 20:38:55 --> Language Class Initialized
INFO - 2021-03-17 20:38:56 --> Loader Class Initialized
INFO - 2021-03-17 20:38:56 --> Helper loaded: url_helper
INFO - 2021-03-17 20:38:56 --> Helper loaded: file_helper
INFO - 2021-03-17 20:38:56 --> Helper loaded: form_helper
INFO - 2021-03-17 20:38:56 --> Helper loaded: text_helper
INFO - 2021-03-17 20:38:56 --> Helper loaded: security_helper
INFO - 2021-03-17 20:38:56 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 20:38:56 --> Database Driver Class Initialized
INFO - 2021-03-17 20:38:56 --> Email Class Initialized
DEBUG - 2021-03-17 20:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 20:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 20:38:56 --> Form Validation Class Initialized
INFO - 2021-03-17 20:38:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 20:38:56 --> Pagination Class Initialized
INFO - 2021-03-17 20:38:56 --> Model Class Initialized
INFO - 2021-03-17 20:38:56 --> Controller Class Initialized
INFO - 2021-03-17 20:38:56 --> Model Class Initialized
INFO - 2021-03-17 20:38:56 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 20:38:56 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 20:38:56 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-17 20:38:56 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 20:38:56 --> Final output sent to browser
DEBUG - 2021-03-17 20:38:56 --> Total execution time: 1.3826
INFO - 2021-03-17 20:38:57 --> Config Class Initialized
INFO - 2021-03-17 20:38:57 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:38:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:38:57 --> Utf8 Class Initialized
INFO - 2021-03-17 20:38:57 --> URI Class Initialized
INFO - 2021-03-17 20:38:57 --> Router Class Initialized
INFO - 2021-03-17 20:38:57 --> Output Class Initialized
INFO - 2021-03-17 20:38:57 --> Security Class Initialized
DEBUG - 2021-03-17 20:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:38:57 --> Input Class Initialized
INFO - 2021-03-17 20:38:57 --> Language Class Initialized
ERROR - 2021-03-17 20:38:57 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:38:57 --> Config Class Initialized
INFO - 2021-03-17 20:38:58 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:38:58 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:38:58 --> Utf8 Class Initialized
INFO - 2021-03-17 20:38:58 --> URI Class Initialized
INFO - 2021-03-17 20:38:58 --> Router Class Initialized
INFO - 2021-03-17 20:38:58 --> Output Class Initialized
INFO - 2021-03-17 20:38:58 --> Security Class Initialized
DEBUG - 2021-03-17 20:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:38:58 --> Input Class Initialized
INFO - 2021-03-17 20:38:58 --> Language Class Initialized
ERROR - 2021-03-17 20:38:58 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 20:39:11 --> Config Class Initialized
INFO - 2021-03-17 20:39:11 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:39:11 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:39:11 --> Utf8 Class Initialized
INFO - 2021-03-17 20:39:11 --> URI Class Initialized
INFO - 2021-03-17 20:39:11 --> Router Class Initialized
INFO - 2021-03-17 20:39:11 --> Output Class Initialized
INFO - 2021-03-17 20:39:11 --> Security Class Initialized
DEBUG - 2021-03-17 20:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:39:11 --> Input Class Initialized
INFO - 2021-03-17 20:39:11 --> Language Class Initialized
INFO - 2021-03-17 20:39:11 --> Loader Class Initialized
INFO - 2021-03-17 20:39:11 --> Helper loaded: url_helper
INFO - 2021-03-17 20:39:11 --> Helper loaded: file_helper
INFO - 2021-03-17 20:39:11 --> Helper loaded: form_helper
INFO - 2021-03-17 20:39:12 --> Helper loaded: text_helper
INFO - 2021-03-17 20:39:12 --> Helper loaded: security_helper
INFO - 2021-03-17 20:39:12 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 20:39:12 --> Database Driver Class Initialized
INFO - 2021-03-17 20:39:12 --> Email Class Initialized
DEBUG - 2021-03-17 20:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 20:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 20:39:12 --> Form Validation Class Initialized
INFO - 2021-03-17 20:39:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 20:39:12 --> Pagination Class Initialized
INFO - 2021-03-17 20:39:12 --> Model Class Initialized
INFO - 2021-03-17 20:39:12 --> Controller Class Initialized
INFO - 2021-03-17 20:39:12 --> Model Class Initialized
INFO - 2021-03-17 20:39:12 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 20:39:12 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 20:39:12 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-17 20:39:12 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 20:39:12 --> Final output sent to browser
DEBUG - 2021-03-17 20:39:12 --> Total execution time: 1.3173
INFO - 2021-03-17 20:39:13 --> Config Class Initialized
INFO - 2021-03-17 20:39:13 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:39:13 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:39:13 --> Utf8 Class Initialized
INFO - 2021-03-17 20:39:13 --> URI Class Initialized
INFO - 2021-03-17 20:39:13 --> Router Class Initialized
INFO - 2021-03-17 20:39:13 --> Output Class Initialized
INFO - 2021-03-17 20:39:13 --> Security Class Initialized
DEBUG - 2021-03-17 20:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:39:13 --> Input Class Initialized
INFO - 2021-03-17 20:39:13 --> Language Class Initialized
ERROR - 2021-03-17 20:39:13 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:39:14 --> Config Class Initialized
INFO - 2021-03-17 20:39:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:39:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:39:14 --> Utf8 Class Initialized
INFO - 2021-03-17 20:39:14 --> URI Class Initialized
INFO - 2021-03-17 20:39:14 --> Router Class Initialized
INFO - 2021-03-17 20:39:14 --> Output Class Initialized
INFO - 2021-03-17 20:39:14 --> Security Class Initialized
DEBUG - 2021-03-17 20:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:39:14 --> Input Class Initialized
INFO - 2021-03-17 20:39:14 --> Language Class Initialized
ERROR - 2021-03-17 20:39:14 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:39:14 --> Config Class Initialized
INFO - 2021-03-17 20:39:14 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:39:14 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:39:14 --> Utf8 Class Initialized
INFO - 2021-03-17 20:39:14 --> URI Class Initialized
INFO - 2021-03-17 20:39:14 --> Router Class Initialized
INFO - 2021-03-17 20:39:14 --> Output Class Initialized
INFO - 2021-03-17 20:39:14 --> Security Class Initialized
DEBUG - 2021-03-17 20:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:39:15 --> Input Class Initialized
INFO - 2021-03-17 20:39:15 --> Language Class Initialized
ERROR - 2021-03-17 20:39:15 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 20:39:30 --> Config Class Initialized
INFO - 2021-03-17 20:39:30 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:39:30 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:39:31 --> Utf8 Class Initialized
INFO - 2021-03-17 20:39:31 --> URI Class Initialized
INFO - 2021-03-17 20:39:31 --> Router Class Initialized
INFO - 2021-03-17 20:39:31 --> Output Class Initialized
INFO - 2021-03-17 20:39:31 --> Security Class Initialized
DEBUG - 2021-03-17 20:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:39:31 --> Input Class Initialized
INFO - 2021-03-17 20:39:31 --> Language Class Initialized
INFO - 2021-03-17 20:39:31 --> Loader Class Initialized
INFO - 2021-03-17 20:39:31 --> Helper loaded: url_helper
INFO - 2021-03-17 20:39:31 --> Helper loaded: file_helper
INFO - 2021-03-17 20:39:31 --> Helper loaded: form_helper
INFO - 2021-03-17 20:39:31 --> Helper loaded: text_helper
INFO - 2021-03-17 20:39:31 --> Helper loaded: security_helper
INFO - 2021-03-17 20:39:31 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 20:39:31 --> Database Driver Class Initialized
INFO - 2021-03-17 20:39:31 --> Email Class Initialized
DEBUG - 2021-03-17 20:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 20:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 20:39:31 --> Form Validation Class Initialized
INFO - 2021-03-17 20:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 20:39:31 --> Pagination Class Initialized
INFO - 2021-03-17 20:39:31 --> Model Class Initialized
INFO - 2021-03-17 20:39:31 --> Controller Class Initialized
INFO - 2021-03-17 20:39:32 --> Model Class Initialized
INFO - 2021-03-17 20:39:32 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 20:39:32 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 20:39:32 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-17 20:39:32 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 20:39:32 --> Final output sent to browser
DEBUG - 2021-03-17 20:39:32 --> Total execution time: 1.3684
INFO - 2021-03-17 20:39:32 --> Config Class Initialized
INFO - 2021-03-17 20:39:32 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:39:32 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:39:32 --> Utf8 Class Initialized
INFO - 2021-03-17 20:39:32 --> URI Class Initialized
INFO - 2021-03-17 20:39:32 --> Router Class Initialized
INFO - 2021-03-17 20:39:32 --> Output Class Initialized
INFO - 2021-03-17 20:39:32 --> Security Class Initialized
DEBUG - 2021-03-17 20:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:39:32 --> Input Class Initialized
INFO - 2021-03-17 20:39:33 --> Language Class Initialized
ERROR - 2021-03-17 20:39:33 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:39:34 --> Config Class Initialized
INFO - 2021-03-17 20:39:34 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:39:34 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:39:34 --> Utf8 Class Initialized
INFO - 2021-03-17 20:39:34 --> URI Class Initialized
INFO - 2021-03-17 20:39:34 --> Router Class Initialized
INFO - 2021-03-17 20:39:34 --> Output Class Initialized
INFO - 2021-03-17 20:39:34 --> Security Class Initialized
DEBUG - 2021-03-17 20:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:39:34 --> Input Class Initialized
INFO - 2021-03-17 20:39:34 --> Language Class Initialized
ERROR - 2021-03-17 20:39:34 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:39:34 --> Config Class Initialized
INFO - 2021-03-17 20:39:35 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:39:35 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:39:35 --> Utf8 Class Initialized
INFO - 2021-03-17 20:39:35 --> URI Class Initialized
INFO - 2021-03-17 20:39:35 --> Router Class Initialized
INFO - 2021-03-17 20:39:35 --> Output Class Initialized
INFO - 2021-03-17 20:39:35 --> Security Class Initialized
DEBUG - 2021-03-17 20:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:39:35 --> Input Class Initialized
INFO - 2021-03-17 20:39:35 --> Language Class Initialized
ERROR - 2021-03-17 20:39:35 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 20:39:55 --> Config Class Initialized
INFO - 2021-03-17 20:39:55 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:39:55 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:39:55 --> Utf8 Class Initialized
INFO - 2021-03-17 20:39:55 --> URI Class Initialized
INFO - 2021-03-17 20:39:55 --> Router Class Initialized
INFO - 2021-03-17 20:39:55 --> Output Class Initialized
INFO - 2021-03-17 20:39:55 --> Security Class Initialized
DEBUG - 2021-03-17 20:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:39:55 --> Input Class Initialized
INFO - 2021-03-17 20:39:55 --> Language Class Initialized
INFO - 2021-03-17 20:39:56 --> Loader Class Initialized
INFO - 2021-03-17 20:39:56 --> Helper loaded: url_helper
INFO - 2021-03-17 20:39:56 --> Helper loaded: file_helper
INFO - 2021-03-17 20:39:56 --> Helper loaded: form_helper
INFO - 2021-03-17 20:39:56 --> Helper loaded: text_helper
INFO - 2021-03-17 20:39:56 --> Helper loaded: security_helper
INFO - 2021-03-17 20:39:56 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 20:39:56 --> Database Driver Class Initialized
INFO - 2021-03-17 20:39:56 --> Email Class Initialized
DEBUG - 2021-03-17 20:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 20:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 20:39:56 --> Form Validation Class Initialized
INFO - 2021-03-17 20:39:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 20:39:56 --> Pagination Class Initialized
INFO - 2021-03-17 20:39:56 --> Model Class Initialized
INFO - 2021-03-17 20:39:56 --> Controller Class Initialized
INFO - 2021-03-17 20:39:56 --> Model Class Initialized
INFO - 2021-03-17 20:39:56 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 20:39:56 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 20:39:56 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-17 20:39:56 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 20:39:56 --> Final output sent to browser
DEBUG - 2021-03-17 20:39:56 --> Total execution time: 1.3110
INFO - 2021-03-17 20:39:57 --> Config Class Initialized
INFO - 2021-03-17 20:39:57 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:39:57 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:39:57 --> Utf8 Class Initialized
INFO - 2021-03-17 20:39:57 --> URI Class Initialized
INFO - 2021-03-17 20:39:57 --> Router Class Initialized
INFO - 2021-03-17 20:39:57 --> Output Class Initialized
INFO - 2021-03-17 20:39:57 --> Security Class Initialized
DEBUG - 2021-03-17 20:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:39:57 --> Input Class Initialized
INFO - 2021-03-17 20:39:57 --> Language Class Initialized
ERROR - 2021-03-17 20:39:57 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:40:09 --> Config Class Initialized
INFO - 2021-03-17 20:40:09 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:40:09 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:40:09 --> Utf8 Class Initialized
INFO - 2021-03-17 20:40:09 --> URI Class Initialized
INFO - 2021-03-17 20:40:09 --> Router Class Initialized
INFO - 2021-03-17 20:40:09 --> Output Class Initialized
INFO - 2021-03-17 20:40:09 --> Security Class Initialized
DEBUG - 2021-03-17 20:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:40:09 --> Input Class Initialized
INFO - 2021-03-17 20:40:09 --> Language Class Initialized
INFO - 2021-03-17 20:40:09 --> Loader Class Initialized
INFO - 2021-03-17 20:40:09 --> Helper loaded: url_helper
INFO - 2021-03-17 20:40:09 --> Helper loaded: file_helper
INFO - 2021-03-17 20:40:09 --> Helper loaded: form_helper
INFO - 2021-03-17 20:40:09 --> Helper loaded: text_helper
INFO - 2021-03-17 20:40:09 --> Helper loaded: security_helper
INFO - 2021-03-17 20:40:09 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 20:40:10 --> Database Driver Class Initialized
INFO - 2021-03-17 20:40:10 --> Email Class Initialized
DEBUG - 2021-03-17 20:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 20:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 20:40:10 --> Form Validation Class Initialized
INFO - 2021-03-17 20:40:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 20:40:10 --> Pagination Class Initialized
INFO - 2021-03-17 20:40:10 --> Model Class Initialized
INFO - 2021-03-17 20:40:10 --> Controller Class Initialized
INFO - 2021-03-17 20:40:10 --> Model Class Initialized
INFO - 2021-03-17 20:40:10 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 20:40:10 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 20:40:10 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-17 20:40:10 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 20:40:10 --> Final output sent to browser
DEBUG - 2021-03-17 20:40:10 --> Total execution time: 1.3928
INFO - 2021-03-17 20:40:10 --> Config Class Initialized
INFO - 2021-03-17 20:40:10 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:40:10 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:40:10 --> Utf8 Class Initialized
INFO - 2021-03-17 20:40:10 --> URI Class Initialized
INFO - 2021-03-17 20:40:10 --> Router Class Initialized
INFO - 2021-03-17 20:40:10 --> Output Class Initialized
INFO - 2021-03-17 20:40:10 --> Security Class Initialized
DEBUG - 2021-03-17 20:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:40:10 --> Input Class Initialized
INFO - 2021-03-17 20:40:10 --> Language Class Initialized
ERROR - 2021-03-17 20:40:10 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:40:49 --> Config Class Initialized
INFO - 2021-03-17 20:40:49 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:40:49 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:40:49 --> Utf8 Class Initialized
INFO - 2021-03-17 20:40:49 --> URI Class Initialized
INFO - 2021-03-17 20:40:49 --> Router Class Initialized
INFO - 2021-03-17 20:40:49 --> Output Class Initialized
INFO - 2021-03-17 20:40:49 --> Security Class Initialized
DEBUG - 2021-03-17 20:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:40:49 --> Input Class Initialized
INFO - 2021-03-17 20:40:50 --> Language Class Initialized
ERROR - 2021-03-17 20:40:50 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:40:50 --> Config Class Initialized
INFO - 2021-03-17 20:40:50 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:40:50 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:40:50 --> Utf8 Class Initialized
INFO - 2021-03-17 20:40:50 --> URI Class Initialized
INFO - 2021-03-17 20:40:50 --> Router Class Initialized
INFO - 2021-03-17 20:40:50 --> Output Class Initialized
INFO - 2021-03-17 20:40:50 --> Security Class Initialized
DEBUG - 2021-03-17 20:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:40:50 --> Input Class Initialized
INFO - 2021-03-17 20:40:50 --> Language Class Initialized
ERROR - 2021-03-17 20:40:50 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 20:41:37 --> Config Class Initialized
INFO - 2021-03-17 20:41:37 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:41:37 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:41:37 --> Utf8 Class Initialized
INFO - 2021-03-17 20:41:37 --> URI Class Initialized
INFO - 2021-03-17 20:41:37 --> Router Class Initialized
INFO - 2021-03-17 20:41:37 --> Output Class Initialized
INFO - 2021-03-17 20:41:37 --> Security Class Initialized
DEBUG - 2021-03-17 20:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:41:37 --> Input Class Initialized
INFO - 2021-03-17 20:41:37 --> Language Class Initialized
INFO - 2021-03-17 20:41:37 --> Loader Class Initialized
INFO - 2021-03-17 20:41:37 --> Helper loaded: url_helper
INFO - 2021-03-17 20:41:37 --> Helper loaded: file_helper
INFO - 2021-03-17 20:41:37 --> Helper loaded: form_helper
INFO - 2021-03-17 20:41:37 --> Helper loaded: text_helper
INFO - 2021-03-17 20:41:38 --> Helper loaded: security_helper
INFO - 2021-03-17 20:41:38 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 20:41:38 --> Database Driver Class Initialized
INFO - 2021-03-17 20:41:38 --> Email Class Initialized
DEBUG - 2021-03-17 20:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 20:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 20:41:38 --> Form Validation Class Initialized
INFO - 2021-03-17 20:41:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 20:41:38 --> Pagination Class Initialized
INFO - 2021-03-17 20:41:38 --> Model Class Initialized
INFO - 2021-03-17 20:41:38 --> Controller Class Initialized
INFO - 2021-03-17 20:41:38 --> Model Class Initialized
INFO - 2021-03-17 20:41:38 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 20:41:38 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 20:41:38 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-17 20:41:38 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 20:41:38 --> Final output sent to browser
DEBUG - 2021-03-17 20:41:38 --> Total execution time: 1.3762
INFO - 2021-03-17 20:41:39 --> Config Class Initialized
INFO - 2021-03-17 20:41:39 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:41:39 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:41:39 --> Utf8 Class Initialized
INFO - 2021-03-17 20:41:39 --> URI Class Initialized
INFO - 2021-03-17 20:41:39 --> Router Class Initialized
INFO - 2021-03-17 20:41:39 --> Output Class Initialized
INFO - 2021-03-17 20:41:39 --> Security Class Initialized
DEBUG - 2021-03-17 20:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:41:39 --> Input Class Initialized
INFO - 2021-03-17 20:41:39 --> Language Class Initialized
ERROR - 2021-03-17 20:41:39 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:41:45 --> Config Class Initialized
INFO - 2021-03-17 20:41:45 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:41:45 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:41:45 --> Utf8 Class Initialized
INFO - 2021-03-17 20:41:45 --> URI Class Initialized
INFO - 2021-03-17 20:41:45 --> Router Class Initialized
INFO - 2021-03-17 20:41:45 --> Output Class Initialized
INFO - 2021-03-17 20:41:45 --> Security Class Initialized
DEBUG - 2021-03-17 20:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:41:45 --> Input Class Initialized
INFO - 2021-03-17 20:41:45 --> Language Class Initialized
ERROR - 2021-03-17 20:41:45 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:41:45 --> Config Class Initialized
INFO - 2021-03-17 20:41:45 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:41:45 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:41:45 --> Utf8 Class Initialized
INFO - 2021-03-17 20:41:45 --> URI Class Initialized
INFO - 2021-03-17 20:41:45 --> Router Class Initialized
INFO - 2021-03-17 20:41:45 --> Output Class Initialized
INFO - 2021-03-17 20:41:46 --> Security Class Initialized
DEBUG - 2021-03-17 20:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:41:46 --> Input Class Initialized
INFO - 2021-03-17 20:41:46 --> Language Class Initialized
ERROR - 2021-03-17 20:41:46 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 20:42:08 --> Config Class Initialized
INFO - 2021-03-17 20:42:08 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:42:09 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:42:09 --> Utf8 Class Initialized
INFO - 2021-03-17 20:42:09 --> URI Class Initialized
INFO - 2021-03-17 20:42:09 --> Router Class Initialized
INFO - 2021-03-17 20:42:09 --> Output Class Initialized
INFO - 2021-03-17 20:42:09 --> Security Class Initialized
DEBUG - 2021-03-17 20:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:42:09 --> Input Class Initialized
INFO - 2021-03-17 20:42:09 --> Language Class Initialized
INFO - 2021-03-17 20:42:09 --> Loader Class Initialized
INFO - 2021-03-17 20:42:09 --> Helper loaded: url_helper
INFO - 2021-03-17 20:42:09 --> Helper loaded: file_helper
INFO - 2021-03-17 20:42:09 --> Helper loaded: form_helper
INFO - 2021-03-17 20:42:09 --> Helper loaded: text_helper
INFO - 2021-03-17 20:42:09 --> Helper loaded: security_helper
INFO - 2021-03-17 20:42:09 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 20:42:09 --> Database Driver Class Initialized
INFO - 2021-03-17 20:42:09 --> Email Class Initialized
DEBUG - 2021-03-17 20:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 20:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 20:42:09 --> Form Validation Class Initialized
INFO - 2021-03-17 20:42:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 20:42:09 --> Pagination Class Initialized
INFO - 2021-03-17 20:42:09 --> Model Class Initialized
INFO - 2021-03-17 20:42:10 --> Controller Class Initialized
INFO - 2021-03-17 20:42:10 --> Model Class Initialized
INFO - 2021-03-17 20:42:10 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 20:42:10 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 20:42:10 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-17 20:42:10 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 20:42:10 --> Final output sent to browser
DEBUG - 2021-03-17 20:42:10 --> Total execution time: 1.3378
INFO - 2021-03-17 20:42:10 --> Config Class Initialized
INFO - 2021-03-17 20:42:10 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:42:10 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:42:10 --> Utf8 Class Initialized
INFO - 2021-03-17 20:42:10 --> URI Class Initialized
INFO - 2021-03-17 20:42:10 --> Router Class Initialized
INFO - 2021-03-17 20:42:10 --> Output Class Initialized
INFO - 2021-03-17 20:42:10 --> Security Class Initialized
DEBUG - 2021-03-17 20:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:42:10 --> Input Class Initialized
INFO - 2021-03-17 20:42:11 --> Language Class Initialized
ERROR - 2021-03-17 20:42:11 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:42:14 --> Config Class Initialized
INFO - 2021-03-17 20:42:15 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:42:15 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:42:15 --> Utf8 Class Initialized
INFO - 2021-03-17 20:42:15 --> URI Class Initialized
INFO - 2021-03-17 20:42:15 --> Router Class Initialized
INFO - 2021-03-17 20:42:15 --> Output Class Initialized
INFO - 2021-03-17 20:42:15 --> Security Class Initialized
DEBUG - 2021-03-17 20:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:42:15 --> Input Class Initialized
INFO - 2021-03-17 20:42:15 --> Language Class Initialized
ERROR - 2021-03-17 20:42:15 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:42:15 --> Config Class Initialized
INFO - 2021-03-17 20:42:15 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:42:15 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:42:15 --> Utf8 Class Initialized
INFO - 2021-03-17 20:42:15 --> URI Class Initialized
INFO - 2021-03-17 20:42:15 --> Router Class Initialized
INFO - 2021-03-17 20:42:15 --> Output Class Initialized
INFO - 2021-03-17 20:42:15 --> Security Class Initialized
DEBUG - 2021-03-17 20:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:42:15 --> Input Class Initialized
INFO - 2021-03-17 20:42:16 --> Language Class Initialized
ERROR - 2021-03-17 20:42:16 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 20:45:04 --> Config Class Initialized
INFO - 2021-03-17 20:45:04 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:45:04 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:45:04 --> Utf8 Class Initialized
INFO - 2021-03-17 20:45:04 --> URI Class Initialized
INFO - 2021-03-17 20:45:05 --> Router Class Initialized
INFO - 2021-03-17 20:45:05 --> Output Class Initialized
INFO - 2021-03-17 20:45:05 --> Security Class Initialized
DEBUG - 2021-03-17 20:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:45:05 --> Input Class Initialized
INFO - 2021-03-17 20:45:05 --> Language Class Initialized
INFO - 2021-03-17 20:45:05 --> Loader Class Initialized
INFO - 2021-03-17 20:45:05 --> Helper loaded: url_helper
INFO - 2021-03-17 20:45:05 --> Helper loaded: file_helper
INFO - 2021-03-17 20:45:05 --> Helper loaded: form_helper
INFO - 2021-03-17 20:45:05 --> Helper loaded: text_helper
INFO - 2021-03-17 20:45:05 --> Helper loaded: security_helper
INFO - 2021-03-17 20:45:05 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 20:45:05 --> Database Driver Class Initialized
INFO - 2021-03-17 20:45:05 --> Email Class Initialized
DEBUG - 2021-03-17 20:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 20:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 20:45:05 --> Form Validation Class Initialized
INFO - 2021-03-17 20:45:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 20:45:05 --> Pagination Class Initialized
INFO - 2021-03-17 20:45:05 --> Model Class Initialized
INFO - 2021-03-17 20:45:05 --> Controller Class Initialized
INFO - 2021-03-17 20:45:05 --> Model Class Initialized
INFO - 2021-03-17 20:45:06 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 20:45:06 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 20:45:06 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-17 20:45:06 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 20:45:06 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 20:45:06 --> Final output sent to browser
DEBUG - 2021-03-17 20:45:06 --> Total execution time: 1.4360
INFO - 2021-03-17 20:45:06 --> Config Class Initialized
INFO - 2021-03-17 20:45:06 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:45:06 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:45:06 --> Utf8 Class Initialized
INFO - 2021-03-17 20:45:06 --> URI Class Initialized
INFO - 2021-03-17 20:45:06 --> Router Class Initialized
INFO - 2021-03-17 20:45:06 --> Output Class Initialized
INFO - 2021-03-17 20:45:06 --> Security Class Initialized
DEBUG - 2021-03-17 20:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:45:06 --> Input Class Initialized
INFO - 2021-03-17 20:45:07 --> Language Class Initialized
ERROR - 2021-03-17 20:45:07 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:45:07 --> Config Class Initialized
INFO - 2021-03-17 20:45:07 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:45:07 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:45:07 --> Utf8 Class Initialized
INFO - 2021-03-17 20:45:07 --> URI Class Initialized
INFO - 2021-03-17 20:45:07 --> Router Class Initialized
INFO - 2021-03-17 20:45:07 --> Output Class Initialized
INFO - 2021-03-17 20:45:07 --> Security Class Initialized
DEBUG - 2021-03-17 20:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:45:07 --> Input Class Initialized
INFO - 2021-03-17 20:45:07 --> Language Class Initialized
ERROR - 2021-03-17 20:45:07 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 20:47:08 --> Config Class Initialized
INFO - 2021-03-17 20:47:08 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:47:09 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:47:09 --> Utf8 Class Initialized
INFO - 2021-03-17 20:47:09 --> URI Class Initialized
INFO - 2021-03-17 20:47:09 --> Router Class Initialized
INFO - 2021-03-17 20:47:09 --> Output Class Initialized
INFO - 2021-03-17 20:47:09 --> Security Class Initialized
DEBUG - 2021-03-17 20:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:47:09 --> Input Class Initialized
INFO - 2021-03-17 20:47:09 --> Language Class Initialized
INFO - 2021-03-17 20:47:09 --> Loader Class Initialized
INFO - 2021-03-17 20:47:09 --> Helper loaded: url_helper
INFO - 2021-03-17 20:47:09 --> Helper loaded: file_helper
INFO - 2021-03-17 20:47:09 --> Helper loaded: form_helper
INFO - 2021-03-17 20:47:09 --> Helper loaded: text_helper
INFO - 2021-03-17 20:47:09 --> Helper loaded: security_helper
INFO - 2021-03-17 20:47:09 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 20:47:09 --> Database Driver Class Initialized
INFO - 2021-03-17 20:47:09 --> Email Class Initialized
DEBUG - 2021-03-17 20:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 20:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 20:47:09 --> Form Validation Class Initialized
INFO - 2021-03-17 20:47:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 20:47:10 --> Pagination Class Initialized
INFO - 2021-03-17 20:47:10 --> Model Class Initialized
INFO - 2021-03-17 20:47:10 --> Controller Class Initialized
INFO - 2021-03-17 20:47:10 --> Model Class Initialized
INFO - 2021-03-17 20:47:10 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 20:47:10 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 20:47:10 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-17 20:47:10 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 20:47:10 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 20:47:10 --> Final output sent to browser
DEBUG - 2021-03-17 20:47:10 --> Total execution time: 1.4921
INFO - 2021-03-17 20:47:10 --> Config Class Initialized
INFO - 2021-03-17 20:47:10 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:47:10 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:47:11 --> Utf8 Class Initialized
INFO - 2021-03-17 20:47:11 --> URI Class Initialized
INFO - 2021-03-17 20:47:11 --> Router Class Initialized
INFO - 2021-03-17 20:47:11 --> Output Class Initialized
INFO - 2021-03-17 20:47:11 --> Security Class Initialized
DEBUG - 2021-03-17 20:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:47:11 --> Input Class Initialized
INFO - 2021-03-17 20:47:11 --> Language Class Initialized
ERROR - 2021-03-17 20:47:11 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:47:11 --> Config Class Initialized
INFO - 2021-03-17 20:47:11 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:47:11 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:47:11 --> Utf8 Class Initialized
INFO - 2021-03-17 20:47:11 --> URI Class Initialized
INFO - 2021-03-17 20:47:11 --> Router Class Initialized
INFO - 2021-03-17 20:47:11 --> Output Class Initialized
INFO - 2021-03-17 20:47:12 --> Security Class Initialized
DEBUG - 2021-03-17 20:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:47:12 --> Input Class Initialized
INFO - 2021-03-17 20:47:12 --> Language Class Initialized
ERROR - 2021-03-17 20:47:12 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 20:47:56 --> Config Class Initialized
INFO - 2021-03-17 20:47:56 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:47:56 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:47:56 --> Utf8 Class Initialized
INFO - 2021-03-17 20:47:56 --> URI Class Initialized
INFO - 2021-03-17 20:47:56 --> Router Class Initialized
INFO - 2021-03-17 20:47:56 --> Output Class Initialized
INFO - 2021-03-17 20:47:56 --> Security Class Initialized
DEBUG - 2021-03-17 20:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:47:56 --> Input Class Initialized
INFO - 2021-03-17 20:47:56 --> Language Class Initialized
INFO - 2021-03-17 20:47:56 --> Loader Class Initialized
INFO - 2021-03-17 20:47:56 --> Helper loaded: url_helper
INFO - 2021-03-17 20:47:57 --> Helper loaded: file_helper
INFO - 2021-03-17 20:47:57 --> Helper loaded: form_helper
INFO - 2021-03-17 20:47:57 --> Helper loaded: text_helper
INFO - 2021-03-17 20:47:57 --> Helper loaded: security_helper
INFO - 2021-03-17 20:47:57 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 20:47:57 --> Database Driver Class Initialized
INFO - 2021-03-17 20:47:57 --> Email Class Initialized
DEBUG - 2021-03-17 20:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 20:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 20:47:57 --> Form Validation Class Initialized
INFO - 2021-03-17 20:47:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 20:47:57 --> Pagination Class Initialized
INFO - 2021-03-17 20:47:57 --> Model Class Initialized
INFO - 2021-03-17 20:47:57 --> Controller Class Initialized
INFO - 2021-03-17 20:47:57 --> Model Class Initialized
INFO - 2021-03-17 20:47:57 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 20:47:57 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 20:47:57 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-17 20:47:57 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 20:47:57 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 20:47:57 --> Final output sent to browser
DEBUG - 2021-03-17 20:47:57 --> Total execution time: 1.4538
INFO - 2021-03-17 20:47:58 --> Config Class Initialized
INFO - 2021-03-17 20:47:58 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:47:58 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:47:58 --> Utf8 Class Initialized
INFO - 2021-03-17 20:47:58 --> URI Class Initialized
INFO - 2021-03-17 20:47:58 --> Router Class Initialized
INFO - 2021-03-17 20:47:58 --> Output Class Initialized
INFO - 2021-03-17 20:47:58 --> Security Class Initialized
DEBUG - 2021-03-17 20:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:47:58 --> Input Class Initialized
INFO - 2021-03-17 20:47:58 --> Language Class Initialized
ERROR - 2021-03-17 20:47:58 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:47:59 --> Config Class Initialized
INFO - 2021-03-17 20:47:59 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:47:59 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:47:59 --> Utf8 Class Initialized
INFO - 2021-03-17 20:47:59 --> URI Class Initialized
INFO - 2021-03-17 20:47:59 --> Router Class Initialized
INFO - 2021-03-17 20:47:59 --> Output Class Initialized
INFO - 2021-03-17 20:47:59 --> Security Class Initialized
DEBUG - 2021-03-17 20:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:47:59 --> Input Class Initialized
INFO - 2021-03-17 20:47:59 --> Language Class Initialized
ERROR - 2021-03-17 20:47:59 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 20:48:18 --> Config Class Initialized
INFO - 2021-03-17 20:48:18 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:48:18 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:48:18 --> Utf8 Class Initialized
INFO - 2021-03-17 20:48:18 --> URI Class Initialized
INFO - 2021-03-17 20:48:18 --> Router Class Initialized
INFO - 2021-03-17 20:48:18 --> Output Class Initialized
INFO - 2021-03-17 20:48:18 --> Security Class Initialized
DEBUG - 2021-03-17 20:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:48:19 --> Input Class Initialized
INFO - 2021-03-17 20:48:19 --> Language Class Initialized
INFO - 2021-03-17 20:48:19 --> Loader Class Initialized
INFO - 2021-03-17 20:48:19 --> Helper loaded: url_helper
INFO - 2021-03-17 20:48:19 --> Helper loaded: file_helper
INFO - 2021-03-17 20:48:19 --> Helper loaded: form_helper
INFO - 2021-03-17 20:48:19 --> Helper loaded: text_helper
INFO - 2021-03-17 20:48:19 --> Helper loaded: security_helper
INFO - 2021-03-17 20:48:19 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 20:48:19 --> Database Driver Class Initialized
INFO - 2021-03-17 20:48:19 --> Email Class Initialized
DEBUG - 2021-03-17 20:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 20:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 20:48:19 --> Form Validation Class Initialized
INFO - 2021-03-17 20:48:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 20:48:19 --> Pagination Class Initialized
INFO - 2021-03-17 20:48:19 --> Model Class Initialized
INFO - 2021-03-17 20:48:19 --> Controller Class Initialized
INFO - 2021-03-17 20:48:19 --> Model Class Initialized
INFO - 2021-03-17 20:48:19 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 20:48:19 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 20:48:19 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-17 20:48:20 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 20:48:20 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 20:48:20 --> Final output sent to browser
DEBUG - 2021-03-17 20:48:20 --> Total execution time: 1.4085
INFO - 2021-03-17 20:48:20 --> Config Class Initialized
INFO - 2021-03-17 20:48:20 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:48:20 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:48:20 --> Utf8 Class Initialized
INFO - 2021-03-17 20:48:20 --> URI Class Initialized
INFO - 2021-03-17 20:48:20 --> Router Class Initialized
INFO - 2021-03-17 20:48:20 --> Output Class Initialized
INFO - 2021-03-17 20:48:20 --> Security Class Initialized
DEBUG - 2021-03-17 20:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:48:20 --> Input Class Initialized
INFO - 2021-03-17 20:48:20 --> Language Class Initialized
ERROR - 2021-03-17 20:48:21 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:48:21 --> Config Class Initialized
INFO - 2021-03-17 20:48:21 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:48:21 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:48:21 --> Utf8 Class Initialized
INFO - 2021-03-17 20:48:21 --> URI Class Initialized
INFO - 2021-03-17 20:48:21 --> Router Class Initialized
INFO - 2021-03-17 20:48:21 --> Output Class Initialized
INFO - 2021-03-17 20:48:21 --> Security Class Initialized
DEBUG - 2021-03-17 20:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:48:21 --> Input Class Initialized
INFO - 2021-03-17 20:48:21 --> Language Class Initialized
ERROR - 2021-03-17 20:48:21 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 20:49:15 --> Config Class Initialized
INFO - 2021-03-17 20:49:15 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:49:15 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:49:15 --> Utf8 Class Initialized
INFO - 2021-03-17 20:49:15 --> URI Class Initialized
INFO - 2021-03-17 20:49:15 --> Router Class Initialized
INFO - 2021-03-17 20:49:15 --> Output Class Initialized
INFO - 2021-03-17 20:49:15 --> Security Class Initialized
DEBUG - 2021-03-17 20:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:49:15 --> Input Class Initialized
INFO - 2021-03-17 20:49:15 --> Language Class Initialized
INFO - 2021-03-17 20:49:15 --> Loader Class Initialized
INFO - 2021-03-17 20:49:15 --> Helper loaded: url_helper
INFO - 2021-03-17 20:49:15 --> Helper loaded: file_helper
INFO - 2021-03-17 20:49:15 --> Helper loaded: form_helper
INFO - 2021-03-17 20:49:15 --> Helper loaded: text_helper
INFO - 2021-03-17 20:49:16 --> Helper loaded: security_helper
INFO - 2021-03-17 20:49:16 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 20:49:16 --> Database Driver Class Initialized
INFO - 2021-03-17 20:49:16 --> Email Class Initialized
DEBUG - 2021-03-17 20:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 20:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 20:49:16 --> Form Validation Class Initialized
INFO - 2021-03-17 20:49:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 20:49:16 --> Pagination Class Initialized
INFO - 2021-03-17 20:49:16 --> Model Class Initialized
INFO - 2021-03-17 20:49:16 --> Controller Class Initialized
INFO - 2021-03-17 20:49:16 --> Model Class Initialized
INFO - 2021-03-17 20:49:16 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 20:49:16 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 20:49:16 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-17 20:49:16 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 20:49:16 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 20:49:16 --> Final output sent to browser
DEBUG - 2021-03-17 20:49:16 --> Total execution time: 1.4828
INFO - 2021-03-17 20:49:17 --> Config Class Initialized
INFO - 2021-03-17 20:49:17 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:49:17 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:49:17 --> Utf8 Class Initialized
INFO - 2021-03-17 20:49:17 --> URI Class Initialized
INFO - 2021-03-17 20:49:17 --> Router Class Initialized
INFO - 2021-03-17 20:49:17 --> Output Class Initialized
INFO - 2021-03-17 20:49:17 --> Security Class Initialized
DEBUG - 2021-03-17 20:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:49:17 --> Input Class Initialized
INFO - 2021-03-17 20:49:17 --> Language Class Initialized
ERROR - 2021-03-17 20:49:17 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:49:18 --> Config Class Initialized
INFO - 2021-03-17 20:49:18 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:49:18 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:49:18 --> Utf8 Class Initialized
INFO - 2021-03-17 20:49:18 --> URI Class Initialized
INFO - 2021-03-17 20:49:18 --> Router Class Initialized
INFO - 2021-03-17 20:49:18 --> Output Class Initialized
INFO - 2021-03-17 20:49:18 --> Security Class Initialized
DEBUG - 2021-03-17 20:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:49:18 --> Input Class Initialized
INFO - 2021-03-17 20:49:18 --> Language Class Initialized
ERROR - 2021-03-17 20:49:18 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-17 20:52:27 --> Config Class Initialized
INFO - 2021-03-17 20:52:27 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:52:27 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:52:27 --> Utf8 Class Initialized
INFO - 2021-03-17 20:52:27 --> URI Class Initialized
INFO - 2021-03-17 20:52:27 --> Router Class Initialized
INFO - 2021-03-17 20:52:27 --> Output Class Initialized
INFO - 2021-03-17 20:52:27 --> Security Class Initialized
DEBUG - 2021-03-17 20:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:52:27 --> Input Class Initialized
INFO - 2021-03-17 20:52:27 --> Language Class Initialized
INFO - 2021-03-17 20:52:28 --> Loader Class Initialized
INFO - 2021-03-17 20:52:28 --> Helper loaded: url_helper
INFO - 2021-03-17 20:52:28 --> Helper loaded: file_helper
INFO - 2021-03-17 20:52:28 --> Helper loaded: form_helper
INFO - 2021-03-17 20:52:28 --> Helper loaded: text_helper
INFO - 2021-03-17 20:52:28 --> Helper loaded: security_helper
INFO - 2021-03-17 20:52:28 --> Helper loaded: ipaddress_helper
INFO - 2021-03-17 20:52:28 --> Database Driver Class Initialized
INFO - 2021-03-17 20:52:28 --> Email Class Initialized
DEBUG - 2021-03-17 20:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-17 20:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-17 20:52:28 --> Form Validation Class Initialized
INFO - 2021-03-17 20:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-17 20:52:28 --> Pagination Class Initialized
INFO - 2021-03-17 20:52:28 --> Model Class Initialized
INFO - 2021-03-17 20:52:28 --> Controller Class Initialized
INFO - 2021-03-17 20:52:28 --> Model Class Initialized
INFO - 2021-03-17 20:52:28 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-17 20:52:28 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-17 20:52:28 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-17 20:52:28 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-17 20:52:28 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-17 20:52:28 --> Final output sent to browser
DEBUG - 2021-03-17 20:52:29 --> Total execution time: 1.3855
INFO - 2021-03-17 20:52:29 --> Config Class Initialized
INFO - 2021-03-17 20:52:29 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:52:29 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:52:29 --> Utf8 Class Initialized
INFO - 2021-03-17 20:52:29 --> URI Class Initialized
INFO - 2021-03-17 20:52:29 --> Router Class Initialized
INFO - 2021-03-17 20:52:29 --> Output Class Initialized
INFO - 2021-03-17 20:52:29 --> Security Class Initialized
DEBUG - 2021-03-17 20:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:52:29 --> Input Class Initialized
INFO - 2021-03-17 20:52:29 --> Language Class Initialized
ERROR - 2021-03-17 20:52:29 --> 404 Page Not Found: Js/demo
INFO - 2021-03-17 20:52:30 --> Config Class Initialized
INFO - 2021-03-17 20:52:30 --> Hooks Class Initialized
DEBUG - 2021-03-17 20:52:30 --> UTF-8 Support Enabled
INFO - 2021-03-17 20:52:30 --> Utf8 Class Initialized
INFO - 2021-03-17 20:52:30 --> URI Class Initialized
INFO - 2021-03-17 20:52:30 --> Router Class Initialized
INFO - 2021-03-17 20:52:30 --> Output Class Initialized
INFO - 2021-03-17 20:52:30 --> Security Class Initialized
DEBUG - 2021-03-17 20:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-17 20:52:30 --> Input Class Initialized
INFO - 2021-03-17 20:52:30 --> Language Class Initialized
ERROR - 2021-03-17 20:52:30 --> 404 Page Not Found: Skin-config2html/index
