<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-03-24 15:28:27 --> Config Class Initialized
INFO - 2021-03-24 15:28:27 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:28:27 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:28:27 --> Utf8 Class Initialized
INFO - 2021-03-24 15:28:27 --> URI Class Initialized
DEBUG - 2021-03-24 15:28:27 --> No URI present. Default controller set.
INFO - 2021-03-24 15:28:27 --> Router Class Initialized
INFO - 2021-03-24 15:28:27 --> Output Class Initialized
INFO - 2021-03-24 15:28:27 --> Security Class Initialized
DEBUG - 2021-03-24 15:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:28:27 --> Input Class Initialized
INFO - 2021-03-24 15:28:27 --> Language Class Initialized
INFO - 2021-03-24 15:28:27 --> Loader Class Initialized
INFO - 2021-03-24 15:28:27 --> Helper loaded: url_helper
INFO - 2021-03-24 15:28:27 --> Helper loaded: file_helper
INFO - 2021-03-24 15:28:27 --> Helper loaded: form_helper
INFO - 2021-03-24 15:28:27 --> Helper loaded: text_helper
INFO - 2021-03-24 15:28:27 --> Helper loaded: security_helper
INFO - 2021-03-24 15:28:27 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 15:28:27 --> Database Driver Class Initialized
INFO - 2021-03-24 15:28:27 --> Email Class Initialized
DEBUG - 2021-03-24 15:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 15:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 15:28:27 --> Form Validation Class Initialized
INFO - 2021-03-24 15:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 15:28:27 --> Pagination Class Initialized
INFO - 2021-03-24 15:28:27 --> Model Class Initialized
INFO - 2021-03-24 15:28:27 --> Controller Class Initialized
INFO - 2021-03-24 15:28:27 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-24 15:28:27 --> Final output sent to browser
DEBUG - 2021-03-24 15:28:27 --> Total execution time: 0.6937
INFO - 2021-03-24 15:28:58 --> Config Class Initialized
INFO - 2021-03-24 15:28:58 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:28:58 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:28:58 --> Utf8 Class Initialized
INFO - 2021-03-24 15:28:58 --> URI Class Initialized
DEBUG - 2021-03-24 15:28:58 --> No URI present. Default controller set.
INFO - 2021-03-24 15:28:58 --> Router Class Initialized
INFO - 2021-03-24 15:28:58 --> Output Class Initialized
INFO - 2021-03-24 15:28:58 --> Security Class Initialized
DEBUG - 2021-03-24 15:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:28:58 --> Input Class Initialized
INFO - 2021-03-24 15:28:58 --> Language Class Initialized
INFO - 2021-03-24 15:28:58 --> Loader Class Initialized
INFO - 2021-03-24 15:28:58 --> Helper loaded: url_helper
INFO - 2021-03-24 15:28:58 --> Helper loaded: file_helper
INFO - 2021-03-24 15:28:58 --> Helper loaded: form_helper
INFO - 2021-03-24 15:28:58 --> Helper loaded: text_helper
INFO - 2021-03-24 15:28:58 --> Helper loaded: security_helper
INFO - 2021-03-24 15:28:58 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 15:28:58 --> Database Driver Class Initialized
INFO - 2021-03-24 15:28:58 --> Email Class Initialized
DEBUG - 2021-03-24 15:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 15:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 15:28:58 --> Form Validation Class Initialized
INFO - 2021-03-24 15:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 15:28:58 --> Pagination Class Initialized
INFO - 2021-03-24 15:28:58 --> Model Class Initialized
INFO - 2021-03-24 15:28:58 --> Controller Class Initialized
INFO - 2021-03-24 15:28:58 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-24 15:28:58 --> Final output sent to browser
DEBUG - 2021-03-24 15:28:58 --> Total execution time: 0.2314
INFO - 2021-03-24 15:29:18 --> Config Class Initialized
INFO - 2021-03-24 15:29:18 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:29:18 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:29:18 --> Utf8 Class Initialized
INFO - 2021-03-24 15:29:18 --> URI Class Initialized
INFO - 2021-03-24 15:29:18 --> Router Class Initialized
INFO - 2021-03-24 15:29:18 --> Output Class Initialized
INFO - 2021-03-24 15:29:18 --> Security Class Initialized
DEBUG - 2021-03-24 15:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:29:18 --> Input Class Initialized
INFO - 2021-03-24 15:29:18 --> Language Class Initialized
ERROR - 2021-03-24 15:29:18 --> 404 Page Not Found: Dashboard/index
INFO - 2021-03-24 15:29:28 --> Config Class Initialized
INFO - 2021-03-24 15:29:28 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:29:28 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:29:28 --> Utf8 Class Initialized
INFO - 2021-03-24 15:29:28 --> URI Class Initialized
INFO - 2021-03-24 15:29:28 --> Router Class Initialized
INFO - 2021-03-24 15:29:28 --> Output Class Initialized
INFO - 2021-03-24 15:29:28 --> Security Class Initialized
DEBUG - 2021-03-24 15:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:29:28 --> Input Class Initialized
INFO - 2021-03-24 15:29:28 --> Language Class Initialized
INFO - 2021-03-24 15:29:28 --> Loader Class Initialized
INFO - 2021-03-24 15:29:28 --> Helper loaded: url_helper
INFO - 2021-03-24 15:29:28 --> Helper loaded: file_helper
INFO - 2021-03-24 15:29:28 --> Helper loaded: form_helper
INFO - 2021-03-24 15:29:28 --> Helper loaded: text_helper
INFO - 2021-03-24 15:29:28 --> Helper loaded: security_helper
INFO - 2021-03-24 15:29:28 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 15:29:28 --> Database Driver Class Initialized
INFO - 2021-03-24 15:29:28 --> Email Class Initialized
DEBUG - 2021-03-24 15:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 15:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 15:29:28 --> Form Validation Class Initialized
INFO - 2021-03-24 15:29:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 15:29:28 --> Pagination Class Initialized
INFO - 2021-03-24 15:29:28 --> Model Class Initialized
INFO - 2021-03-24 15:29:28 --> Controller Class Initialized
INFO - 2021-03-24 15:29:28 --> Model Class Initialized
INFO - 2021-03-24 15:29:28 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-24 15:29:28 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-24 15:29:28 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-24 15:29:28 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-24 15:29:28 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-24 15:29:29 --> Final output sent to browser
DEBUG - 2021-03-24 15:29:29 --> Total execution time: 0.2859
INFO - 2021-03-24 15:29:29 --> Config Class Initialized
INFO - 2021-03-24 15:29:29 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:29:29 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:29:29 --> Utf8 Class Initialized
INFO - 2021-03-24 15:29:29 --> URI Class Initialized
INFO - 2021-03-24 15:29:29 --> Router Class Initialized
INFO - 2021-03-24 15:29:29 --> Output Class Initialized
INFO - 2021-03-24 15:29:29 --> Security Class Initialized
DEBUG - 2021-03-24 15:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:29:29 --> Input Class Initialized
INFO - 2021-03-24 15:29:29 --> Language Class Initialized
ERROR - 2021-03-24 15:29:29 --> 404 Page Not Found: Js/demo
INFO - 2021-03-24 15:29:30 --> Config Class Initialized
INFO - 2021-03-24 15:29:30 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:29:30 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:29:30 --> Utf8 Class Initialized
INFO - 2021-03-24 15:29:30 --> URI Class Initialized
INFO - 2021-03-24 15:29:30 --> Router Class Initialized
INFO - 2021-03-24 15:29:30 --> Output Class Initialized
INFO - 2021-03-24 15:29:30 --> Security Class Initialized
DEBUG - 2021-03-24 15:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:29:30 --> Input Class Initialized
INFO - 2021-03-24 15:29:30 --> Language Class Initialized
ERROR - 2021-03-24 15:29:30 --> 404 Page Not Found: Js/demo
INFO - 2021-03-24 15:29:30 --> Config Class Initialized
INFO - 2021-03-24 15:29:30 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:29:30 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:29:30 --> Utf8 Class Initialized
INFO - 2021-03-24 15:29:30 --> URI Class Initialized
INFO - 2021-03-24 15:29:30 --> Router Class Initialized
INFO - 2021-03-24 15:29:30 --> Output Class Initialized
INFO - 2021-03-24 15:29:30 --> Security Class Initialized
DEBUG - 2021-03-24 15:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:29:30 --> Input Class Initialized
INFO - 2021-03-24 15:29:30 --> Language Class Initialized
ERROR - 2021-03-24 15:29:30 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-24 15:29:55 --> Config Class Initialized
INFO - 2021-03-24 15:29:55 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:29:55 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:29:55 --> Utf8 Class Initialized
INFO - 2021-03-24 15:29:55 --> URI Class Initialized
INFO - 2021-03-24 15:29:55 --> Router Class Initialized
INFO - 2021-03-24 15:29:55 --> Output Class Initialized
INFO - 2021-03-24 15:29:55 --> Security Class Initialized
DEBUG - 2021-03-24 15:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:29:55 --> Input Class Initialized
INFO - 2021-03-24 15:29:55 --> Language Class Initialized
ERROR - 2021-03-24 15:29:55 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-24 15:31:13 --> Config Class Initialized
INFO - 2021-03-24 15:31:13 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:31:13 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:31:13 --> Utf8 Class Initialized
INFO - 2021-03-24 15:31:13 --> URI Class Initialized
INFO - 2021-03-24 15:31:13 --> Router Class Initialized
INFO - 2021-03-24 15:31:13 --> Output Class Initialized
INFO - 2021-03-24 15:31:13 --> Security Class Initialized
DEBUG - 2021-03-24 15:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:31:13 --> Input Class Initialized
INFO - 2021-03-24 15:31:13 --> Language Class Initialized
INFO - 2021-03-24 15:31:13 --> Loader Class Initialized
INFO - 2021-03-24 15:31:13 --> Helper loaded: url_helper
INFO - 2021-03-24 15:31:13 --> Helper loaded: file_helper
INFO - 2021-03-24 15:31:13 --> Helper loaded: form_helper
INFO - 2021-03-24 15:31:13 --> Helper loaded: text_helper
INFO - 2021-03-24 15:31:13 --> Helper loaded: security_helper
INFO - 2021-03-24 15:31:13 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 15:31:13 --> Database Driver Class Initialized
INFO - 2021-03-24 15:31:13 --> Email Class Initialized
DEBUG - 2021-03-24 15:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 15:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 15:31:13 --> Form Validation Class Initialized
INFO - 2021-03-24 15:31:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 15:31:13 --> Pagination Class Initialized
INFO - 2021-03-24 15:31:13 --> Model Class Initialized
INFO - 2021-03-24 15:31:13 --> Controller Class Initialized
INFO - 2021-03-24 15:31:13 --> Model Class Initialized
INFO - 2021-03-24 15:31:13 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-24 15:31:13 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-24 15:31:13 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-24 15:31:13 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-24 15:31:13 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-24 15:31:13 --> Final output sent to browser
DEBUG - 2021-03-24 15:31:13 --> Total execution time: 0.2876
INFO - 2021-03-24 15:31:13 --> Config Class Initialized
INFO - 2021-03-24 15:31:13 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:31:13 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:31:13 --> Utf8 Class Initialized
INFO - 2021-03-24 15:31:13 --> URI Class Initialized
INFO - 2021-03-24 15:31:13 --> Router Class Initialized
INFO - 2021-03-24 15:31:13 --> Output Class Initialized
INFO - 2021-03-24 15:31:13 --> Security Class Initialized
DEBUG - 2021-03-24 15:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:31:13 --> Input Class Initialized
INFO - 2021-03-24 15:31:13 --> Language Class Initialized
ERROR - 2021-03-24 15:31:13 --> 404 Page Not Found: Js/demo
INFO - 2021-03-24 15:31:13 --> Config Class Initialized
INFO - 2021-03-24 15:31:13 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:31:13 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:31:13 --> Utf8 Class Initialized
INFO - 2021-03-24 15:31:13 --> URI Class Initialized
INFO - 2021-03-24 15:31:13 --> Router Class Initialized
INFO - 2021-03-24 15:31:13 --> Output Class Initialized
INFO - 2021-03-24 15:31:13 --> Security Class Initialized
DEBUG - 2021-03-24 15:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:31:13 --> Input Class Initialized
INFO - 2021-03-24 15:31:13 --> Language Class Initialized
ERROR - 2021-03-24 15:31:13 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-24 15:51:47 --> Config Class Initialized
INFO - 2021-03-24 15:51:47 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:51:47 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:51:47 --> Utf8 Class Initialized
INFO - 2021-03-24 15:51:47 --> URI Class Initialized
INFO - 2021-03-24 15:51:47 --> Router Class Initialized
INFO - 2021-03-24 15:51:47 --> Output Class Initialized
INFO - 2021-03-24 15:51:47 --> Security Class Initialized
DEBUG - 2021-03-24 15:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:51:47 --> Input Class Initialized
INFO - 2021-03-24 15:51:47 --> Language Class Initialized
INFO - 2021-03-24 15:51:47 --> Loader Class Initialized
INFO - 2021-03-24 15:51:47 --> Helper loaded: url_helper
INFO - 2021-03-24 15:51:47 --> Helper loaded: file_helper
INFO - 2021-03-24 15:51:47 --> Helper loaded: form_helper
INFO - 2021-03-24 15:51:47 --> Helper loaded: text_helper
INFO - 2021-03-24 15:51:47 --> Helper loaded: security_helper
INFO - 2021-03-24 15:51:47 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 15:51:47 --> Database Driver Class Initialized
INFO - 2021-03-24 15:51:47 --> Email Class Initialized
DEBUG - 2021-03-24 15:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 15:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 15:51:47 --> Form Validation Class Initialized
INFO - 2021-03-24 15:51:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 15:51:47 --> Pagination Class Initialized
INFO - 2021-03-24 15:51:47 --> Model Class Initialized
INFO - 2021-03-24 15:51:47 --> Controller Class Initialized
INFO - 2021-03-24 15:51:47 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-24 15:51:47 --> Final output sent to browser
DEBUG - 2021-03-24 15:51:47 --> Total execution time: 0.2549
INFO - 2021-03-24 15:51:51 --> Config Class Initialized
INFO - 2021-03-24 15:51:51 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:51:51 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:51:51 --> Utf8 Class Initialized
INFO - 2021-03-24 15:51:51 --> URI Class Initialized
INFO - 2021-03-24 15:51:51 --> Router Class Initialized
INFO - 2021-03-24 15:51:51 --> Output Class Initialized
INFO - 2021-03-24 15:51:51 --> Security Class Initialized
DEBUG - 2021-03-24 15:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:51:51 --> Input Class Initialized
INFO - 2021-03-24 15:51:51 --> Language Class Initialized
INFO - 2021-03-24 15:51:51 --> Loader Class Initialized
INFO - 2021-03-24 15:51:51 --> Helper loaded: url_helper
INFO - 2021-03-24 15:51:51 --> Helper loaded: file_helper
INFO - 2021-03-24 15:51:51 --> Helper loaded: form_helper
INFO - 2021-03-24 15:51:51 --> Helper loaded: text_helper
INFO - 2021-03-24 15:51:51 --> Helper loaded: security_helper
INFO - 2021-03-24 15:51:51 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 15:51:51 --> Database Driver Class Initialized
INFO - 2021-03-24 15:51:51 --> Email Class Initialized
DEBUG - 2021-03-24 15:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 15:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 15:51:51 --> Form Validation Class Initialized
INFO - 2021-03-24 15:51:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 15:51:51 --> Pagination Class Initialized
INFO - 2021-03-24 15:51:51 --> Model Class Initialized
INFO - 2021-03-24 15:51:51 --> Controller Class Initialized
INFO - 2021-03-24 15:51:51 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-24 15:51:51 --> Final output sent to browser
DEBUG - 2021-03-24 15:51:51 --> Total execution time: 0.2754
INFO - 2021-03-24 15:53:27 --> Config Class Initialized
INFO - 2021-03-24 15:53:27 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:53:27 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:53:27 --> Utf8 Class Initialized
INFO - 2021-03-24 15:53:27 --> URI Class Initialized
INFO - 2021-03-24 15:53:27 --> Router Class Initialized
INFO - 2021-03-24 15:53:27 --> Output Class Initialized
INFO - 2021-03-24 15:53:27 --> Security Class Initialized
DEBUG - 2021-03-24 15:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:53:27 --> Input Class Initialized
INFO - 2021-03-24 15:53:27 --> Language Class Initialized
INFO - 2021-03-24 15:53:27 --> Loader Class Initialized
INFO - 2021-03-24 15:53:27 --> Helper loaded: url_helper
INFO - 2021-03-24 15:53:27 --> Helper loaded: file_helper
INFO - 2021-03-24 15:53:27 --> Helper loaded: form_helper
INFO - 2021-03-24 15:53:27 --> Helper loaded: text_helper
INFO - 2021-03-24 15:53:27 --> Helper loaded: security_helper
INFO - 2021-03-24 15:53:27 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 15:53:27 --> Database Driver Class Initialized
INFO - 2021-03-24 15:53:27 --> Email Class Initialized
DEBUG - 2021-03-24 15:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 15:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 15:53:28 --> Form Validation Class Initialized
INFO - 2021-03-24 15:53:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 15:53:28 --> Pagination Class Initialized
INFO - 2021-03-24 15:53:28 --> Model Class Initialized
INFO - 2021-03-24 15:53:28 --> Controller Class Initialized
INFO - 2021-03-24 15:53:28 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-24 15:53:28 --> Final output sent to browser
DEBUG - 2021-03-24 15:53:28 --> Total execution time: 0.2602
INFO - 2021-03-24 15:54:13 --> Config Class Initialized
INFO - 2021-03-24 15:54:13 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:54:13 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:54:13 --> Utf8 Class Initialized
INFO - 2021-03-24 15:54:13 --> URI Class Initialized
INFO - 2021-03-24 15:54:13 --> Router Class Initialized
INFO - 2021-03-24 15:54:13 --> Output Class Initialized
INFO - 2021-03-24 15:54:13 --> Security Class Initialized
DEBUG - 2021-03-24 15:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:54:13 --> Input Class Initialized
INFO - 2021-03-24 15:54:13 --> Language Class Initialized
INFO - 2021-03-24 15:54:13 --> Loader Class Initialized
INFO - 2021-03-24 15:54:13 --> Helper loaded: url_helper
INFO - 2021-03-24 15:54:13 --> Helper loaded: file_helper
INFO - 2021-03-24 15:54:13 --> Helper loaded: form_helper
INFO - 2021-03-24 15:54:13 --> Helper loaded: text_helper
INFO - 2021-03-24 15:54:13 --> Helper loaded: security_helper
INFO - 2021-03-24 15:54:13 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 15:54:13 --> Database Driver Class Initialized
INFO - 2021-03-24 15:54:13 --> Email Class Initialized
DEBUG - 2021-03-24 15:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 15:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 15:54:13 --> Form Validation Class Initialized
INFO - 2021-03-24 15:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 15:54:13 --> Pagination Class Initialized
INFO - 2021-03-24 15:54:13 --> Model Class Initialized
INFO - 2021-03-24 15:54:13 --> Controller Class Initialized
INFO - 2021-03-24 15:54:13 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-24 15:54:13 --> Final output sent to browser
DEBUG - 2021-03-24 15:54:13 --> Total execution time: 0.2597
INFO - 2021-03-24 15:54:13 --> Config Class Initialized
INFO - 2021-03-24 15:54:13 --> Config Class Initialized
INFO - 2021-03-24 15:54:13 --> Hooks Class Initialized
INFO - 2021-03-24 15:54:13 --> Config Class Initialized
INFO - 2021-03-24 15:54:13 --> Hooks Class Initialized
INFO - 2021-03-24 15:54:13 --> Config Class Initialized
INFO - 2021-03-24 15:54:13 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:54:13 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:54:13 --> Utf8 Class Initialized
INFO - 2021-03-24 15:54:13 --> URI Class Initialized
DEBUG - 2021-03-24 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2021-03-24 15:54:13 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:54:13 --> Utf8 Class Initialized
INFO - 2021-03-24 15:54:13 --> Utf8 Class Initialized
INFO - 2021-03-24 15:54:13 --> Router Class Initialized
INFO - 2021-03-24 15:54:13 --> URI Class Initialized
INFO - 2021-03-24 15:54:13 --> URI Class Initialized
INFO - 2021-03-24 15:54:13 --> Output Class Initialized
INFO - 2021-03-24 15:54:13 --> Router Class Initialized
INFO - 2021-03-24 15:54:13 --> Router Class Initialized
INFO - 2021-03-24 15:54:13 --> Security Class Initialized
INFO - 2021-03-24 15:54:13 --> Output Class Initialized
INFO - 2021-03-24 15:54:13 --> Output Class Initialized
DEBUG - 2021-03-24 15:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:54:13 --> Input Class Initialized
INFO - 2021-03-24 15:54:13 --> Security Class Initialized
INFO - 2021-03-24 15:54:13 --> Security Class Initialized
INFO - 2021-03-24 15:54:13 --> Language Class Initialized
DEBUG - 2021-03-24 15:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:54:13 --> Input Class Initialized
DEBUG - 2021-03-24 15:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:54:13 --> Input Class Initialized
ERROR - 2021-03-24 15:54:13 --> 404 Page Not Found: Font-awesome/css
INFO - 2021-03-24 15:54:13 --> Language Class Initialized
INFO - 2021-03-24 15:54:13 --> Language Class Initialized
ERROR - 2021-03-24 15:54:13 --> 404 Page Not Found: Css/style.css
ERROR - 2021-03-24 15:54:13 --> 404 Page Not Found: Css/animate.css
INFO - 2021-03-24 15:54:13 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:54:13 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:54:13 --> Utf8 Class Initialized
INFO - 2021-03-24 15:54:13 --> URI Class Initialized
INFO - 2021-03-24 15:54:13 --> Router Class Initialized
INFO - 2021-03-24 15:54:13 --> Output Class Initialized
INFO - 2021-03-24 15:54:13 --> Security Class Initialized
DEBUG - 2021-03-24 15:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:54:13 --> Input Class Initialized
INFO - 2021-03-24 15:54:13 --> Language Class Initialized
ERROR - 2021-03-24 15:54:13 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2021-03-24 15:56:18 --> Config Class Initialized
INFO - 2021-03-24 15:56:18 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:56:18 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:56:18 --> Utf8 Class Initialized
INFO - 2021-03-24 15:56:18 --> URI Class Initialized
INFO - 2021-03-24 15:56:18 --> Router Class Initialized
INFO - 2021-03-24 15:56:18 --> Output Class Initialized
INFO - 2021-03-24 15:56:18 --> Security Class Initialized
DEBUG - 2021-03-24 15:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:56:18 --> Input Class Initialized
INFO - 2021-03-24 15:56:18 --> Language Class Initialized
INFO - 2021-03-24 15:56:18 --> Loader Class Initialized
INFO - 2021-03-24 15:56:18 --> Helper loaded: url_helper
INFO - 2021-03-24 15:56:18 --> Helper loaded: file_helper
INFO - 2021-03-24 15:56:18 --> Helper loaded: form_helper
INFO - 2021-03-24 15:56:18 --> Helper loaded: text_helper
INFO - 2021-03-24 15:56:18 --> Helper loaded: security_helper
INFO - 2021-03-24 15:56:18 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 15:56:18 --> Database Driver Class Initialized
INFO - 2021-03-24 15:56:19 --> Email Class Initialized
DEBUG - 2021-03-24 15:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 15:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 15:56:19 --> Form Validation Class Initialized
INFO - 2021-03-24 15:56:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 15:56:19 --> Pagination Class Initialized
INFO - 2021-03-24 15:56:19 --> Model Class Initialized
INFO - 2021-03-24 15:56:19 --> Controller Class Initialized
INFO - 2021-03-24 15:56:19 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-24 15:56:19 --> Final output sent to browser
DEBUG - 2021-03-24 15:56:19 --> Total execution time: 0.2827
INFO - 2021-03-24 15:56:19 --> Config Class Initialized
INFO - 2021-03-24 15:56:19 --> Config Class Initialized
INFO - 2021-03-24 15:56:19 --> Hooks Class Initialized
INFO - 2021-03-24 15:56:19 --> Config Class Initialized
INFO - 2021-03-24 15:56:19 --> Hooks Class Initialized
INFO - 2021-03-24 15:56:19 --> Config Class Initialized
INFO - 2021-03-24 15:56:19 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:56:19 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:56:19 --> Utf8 Class Initialized
DEBUG - 2021-03-24 15:56:19 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:56:19 --> Utf8 Class Initialized
DEBUG - 2021-03-24 15:56:19 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:56:19 --> URI Class Initialized
INFO - 2021-03-24 15:56:19 --> Utf8 Class Initialized
INFO - 2021-03-24 15:56:19 --> URI Class Initialized
INFO - 2021-03-24 15:56:19 --> Router Class Initialized
INFO - 2021-03-24 15:56:19 --> URI Class Initialized
INFO - 2021-03-24 15:56:19 --> Router Class Initialized
INFO - 2021-03-24 15:56:19 --> Router Class Initialized
INFO - 2021-03-24 15:56:19 --> Output Class Initialized
INFO - 2021-03-24 15:56:19 --> Output Class Initialized
INFO - 2021-03-24 15:56:19 --> Output Class Initialized
INFO - 2021-03-24 15:56:19 --> Security Class Initialized
INFO - 2021-03-24 15:56:19 --> Security Class Initialized
INFO - 2021-03-24 15:56:19 --> Security Class Initialized
DEBUG - 2021-03-24 15:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-24 15:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:56:19 --> Input Class Initialized
INFO - 2021-03-24 15:56:19 --> Input Class Initialized
DEBUG - 2021-03-24 15:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:56:19 --> Language Class Initialized
INFO - 2021-03-24 15:56:19 --> Input Class Initialized
INFO - 2021-03-24 15:56:19 --> Language Class Initialized
INFO - 2021-03-24 15:56:19 --> Language Class Initialized
ERROR - 2021-03-24 15:56:19 --> 404 Page Not Found: Adminassets/css
ERROR - 2021-03-24 15:56:19 --> 404 Page Not Found: Adminassets/font-awesome
ERROR - 2021-03-24 15:56:19 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-24 15:56:19 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:56:19 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:56:19 --> Utf8 Class Initialized
INFO - 2021-03-24 15:56:19 --> URI Class Initialized
INFO - 2021-03-24 15:56:19 --> Router Class Initialized
INFO - 2021-03-24 15:56:19 --> Output Class Initialized
INFO - 2021-03-24 15:56:19 --> Security Class Initialized
DEBUG - 2021-03-24 15:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:56:19 --> Input Class Initialized
INFO - 2021-03-24 15:56:19 --> Language Class Initialized
ERROR - 2021-03-24 15:56:19 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-24 15:56:20 --> Config Class Initialized
INFO - 2021-03-24 15:56:20 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:56:20 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:56:20 --> Utf8 Class Initialized
INFO - 2021-03-24 15:56:20 --> URI Class Initialized
INFO - 2021-03-24 15:56:20 --> Router Class Initialized
INFO - 2021-03-24 15:56:20 --> Output Class Initialized
INFO - 2021-03-24 15:56:20 --> Security Class Initialized
DEBUG - 2021-03-24 15:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:56:20 --> Input Class Initialized
INFO - 2021-03-24 15:56:20 --> Language Class Initialized
INFO - 2021-03-24 15:56:20 --> Loader Class Initialized
INFO - 2021-03-24 15:56:20 --> Helper loaded: url_helper
INFO - 2021-03-24 15:56:20 --> Helper loaded: file_helper
INFO - 2021-03-24 15:56:20 --> Helper loaded: form_helper
INFO - 2021-03-24 15:56:20 --> Helper loaded: text_helper
INFO - 2021-03-24 15:56:20 --> Helper loaded: security_helper
INFO - 2021-03-24 15:56:20 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 15:56:20 --> Database Driver Class Initialized
INFO - 2021-03-24 15:56:20 --> Email Class Initialized
DEBUG - 2021-03-24 15:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 15:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 15:56:20 --> Form Validation Class Initialized
INFO - 2021-03-24 15:56:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 15:56:20 --> Pagination Class Initialized
INFO - 2021-03-24 15:56:20 --> Model Class Initialized
INFO - 2021-03-24 15:56:20 --> Controller Class Initialized
INFO - 2021-03-24 15:56:20 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-24 15:56:20 --> Final output sent to browser
DEBUG - 2021-03-24 15:56:20 --> Total execution time: 0.2507
INFO - 2021-03-24 15:56:20 --> Config Class Initialized
INFO - 2021-03-24 15:56:20 --> Config Class Initialized
INFO - 2021-03-24 15:56:20 --> Hooks Class Initialized
INFO - 2021-03-24 15:56:20 --> Config Class Initialized
INFO - 2021-03-24 15:56:20 --> Config Class Initialized
INFO - 2021-03-24 15:56:20 --> Hooks Class Initialized
INFO - 2021-03-24 15:56:20 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:56:20 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:56:20 --> Utf8 Class Initialized
DEBUG - 2021-03-24 15:56:20 --> UTF-8 Support Enabled
DEBUG - 2021-03-24 15:56:20 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:56:20 --> Utf8 Class Initialized
INFO - 2021-03-24 15:56:20 --> Utf8 Class Initialized
INFO - 2021-03-24 15:56:20 --> URI Class Initialized
INFO - 2021-03-24 15:56:20 --> URI Class Initialized
INFO - 2021-03-24 15:56:20 --> URI Class Initialized
INFO - 2021-03-24 15:56:20 --> Router Class Initialized
INFO - 2021-03-24 15:56:20 --> Router Class Initialized
INFO - 2021-03-24 15:56:20 --> Router Class Initialized
INFO - 2021-03-24 15:56:20 --> Output Class Initialized
INFO - 2021-03-24 15:56:20 --> Output Class Initialized
INFO - 2021-03-24 15:56:20 --> Output Class Initialized
INFO - 2021-03-24 15:56:20 --> Security Class Initialized
INFO - 2021-03-24 15:56:20 --> Security Class Initialized
INFO - 2021-03-24 15:56:20 --> Security Class Initialized
DEBUG - 2021-03-24 15:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:56:20 --> Input Class Initialized
INFO - 2021-03-24 15:56:20 --> Language Class Initialized
DEBUG - 2021-03-24 15:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-24 15:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:56:20 --> Input Class Initialized
INFO - 2021-03-24 15:56:20 --> Input Class Initialized
INFO - 2021-03-24 15:56:20 --> Language Class Initialized
INFO - 2021-03-24 15:56:20 --> Language Class Initialized
ERROR - 2021-03-24 15:56:20 --> 404 Page Not Found: Adminassets/font-awesome
ERROR - 2021-03-24 15:56:20 --> 404 Page Not Found: Adminassets/css
ERROR - 2021-03-24 15:56:20 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-24 15:56:21 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:56:21 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:56:21 --> Utf8 Class Initialized
INFO - 2021-03-24 15:56:21 --> URI Class Initialized
INFO - 2021-03-24 15:56:21 --> Router Class Initialized
INFO - 2021-03-24 15:56:21 --> Output Class Initialized
INFO - 2021-03-24 15:56:21 --> Security Class Initialized
DEBUG - 2021-03-24 15:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:56:21 --> Input Class Initialized
INFO - 2021-03-24 15:56:21 --> Language Class Initialized
ERROR - 2021-03-24 15:56:21 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-24 15:56:22 --> Config Class Initialized
INFO - 2021-03-24 15:56:22 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:56:22 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:56:22 --> Utf8 Class Initialized
INFO - 2021-03-24 15:56:22 --> URI Class Initialized
INFO - 2021-03-24 15:56:22 --> Router Class Initialized
INFO - 2021-03-24 15:56:22 --> Output Class Initialized
INFO - 2021-03-24 15:56:22 --> Security Class Initialized
DEBUG - 2021-03-24 15:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:56:22 --> Input Class Initialized
INFO - 2021-03-24 15:56:22 --> Language Class Initialized
INFO - 2021-03-24 15:56:22 --> Loader Class Initialized
INFO - 2021-03-24 15:56:22 --> Helper loaded: url_helper
INFO - 2021-03-24 15:56:22 --> Helper loaded: file_helper
INFO - 2021-03-24 15:56:22 --> Helper loaded: form_helper
INFO - 2021-03-24 15:56:22 --> Helper loaded: text_helper
INFO - 2021-03-24 15:56:22 --> Helper loaded: security_helper
INFO - 2021-03-24 15:56:22 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 15:56:22 --> Database Driver Class Initialized
INFO - 2021-03-24 15:56:22 --> Email Class Initialized
DEBUG - 2021-03-24 15:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 15:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 15:56:22 --> Form Validation Class Initialized
INFO - 2021-03-24 15:56:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 15:56:22 --> Pagination Class Initialized
INFO - 2021-03-24 15:56:22 --> Model Class Initialized
INFO - 2021-03-24 15:56:22 --> Controller Class Initialized
INFO - 2021-03-24 15:56:22 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-24 15:56:22 --> Final output sent to browser
DEBUG - 2021-03-24 15:56:22 --> Total execution time: 0.2877
INFO - 2021-03-24 15:56:52 --> Config Class Initialized
INFO - 2021-03-24 15:56:52 --> Hooks Class Initialized
DEBUG - 2021-03-24 15:56:52 --> UTF-8 Support Enabled
INFO - 2021-03-24 15:56:52 --> Utf8 Class Initialized
INFO - 2021-03-24 15:56:52 --> URI Class Initialized
INFO - 2021-03-24 15:56:52 --> Router Class Initialized
INFO - 2021-03-24 15:56:52 --> Output Class Initialized
INFO - 2021-03-24 15:56:52 --> Security Class Initialized
DEBUG - 2021-03-24 15:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 15:56:52 --> Input Class Initialized
INFO - 2021-03-24 15:56:52 --> Language Class Initialized
INFO - 2021-03-24 15:56:52 --> Loader Class Initialized
INFO - 2021-03-24 15:56:52 --> Helper loaded: url_helper
INFO - 2021-03-24 15:56:52 --> Helper loaded: file_helper
INFO - 2021-03-24 15:56:52 --> Helper loaded: form_helper
INFO - 2021-03-24 15:56:52 --> Helper loaded: text_helper
INFO - 2021-03-24 15:56:52 --> Helper loaded: security_helper
INFO - 2021-03-24 15:56:52 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 15:56:52 --> Database Driver Class Initialized
INFO - 2021-03-24 15:56:52 --> Email Class Initialized
DEBUG - 2021-03-24 15:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 15:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 15:56:52 --> Form Validation Class Initialized
INFO - 2021-03-24 15:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 15:56:52 --> Pagination Class Initialized
INFO - 2021-03-24 15:56:52 --> Model Class Initialized
INFO - 2021-03-24 15:56:52 --> Controller Class Initialized
INFO - 2021-03-24 15:56:52 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-24 15:56:52 --> Final output sent to browser
DEBUG - 2021-03-24 15:56:52 --> Total execution time: 0.2690
INFO - 2021-03-24 16:01:28 --> Config Class Initialized
INFO - 2021-03-24 16:01:28 --> Hooks Class Initialized
DEBUG - 2021-03-24 16:01:28 --> UTF-8 Support Enabled
INFO - 2021-03-24 16:01:28 --> Utf8 Class Initialized
INFO - 2021-03-24 16:01:28 --> URI Class Initialized
INFO - 2021-03-24 16:01:28 --> Router Class Initialized
INFO - 2021-03-24 16:01:28 --> Output Class Initialized
INFO - 2021-03-24 16:01:28 --> Security Class Initialized
DEBUG - 2021-03-24 16:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 16:01:28 --> Input Class Initialized
INFO - 2021-03-24 16:01:28 --> Language Class Initialized
INFO - 2021-03-24 16:01:28 --> Loader Class Initialized
INFO - 2021-03-24 16:01:28 --> Helper loaded: url_helper
INFO - 2021-03-24 16:01:28 --> Helper loaded: file_helper
INFO - 2021-03-24 16:01:28 --> Helper loaded: form_helper
INFO - 2021-03-24 16:01:28 --> Helper loaded: text_helper
INFO - 2021-03-24 16:01:28 --> Helper loaded: security_helper
INFO - 2021-03-24 16:01:28 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 16:01:28 --> Database Driver Class Initialized
INFO - 2021-03-24 16:01:28 --> Email Class Initialized
DEBUG - 2021-03-24 16:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 16:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 16:01:28 --> Form Validation Class Initialized
INFO - 2021-03-24 16:01:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 16:01:28 --> Pagination Class Initialized
INFO - 2021-03-24 16:01:28 --> Model Class Initialized
INFO - 2021-03-24 16:01:28 --> Controller Class Initialized
INFO - 2021-03-24 16:01:28 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-24 16:01:28 --> Final output sent to browser
DEBUG - 2021-03-24 16:01:28 --> Total execution time: 0.2755
INFO - 2021-03-24 16:02:05 --> Config Class Initialized
INFO - 2021-03-24 16:02:05 --> Hooks Class Initialized
DEBUG - 2021-03-24 16:02:05 --> UTF-8 Support Enabled
INFO - 2021-03-24 16:02:05 --> Utf8 Class Initialized
INFO - 2021-03-24 16:02:05 --> URI Class Initialized
INFO - 2021-03-24 16:02:05 --> Router Class Initialized
INFO - 2021-03-24 16:02:05 --> Output Class Initialized
INFO - 2021-03-24 16:02:05 --> Security Class Initialized
DEBUG - 2021-03-24 16:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 16:02:05 --> Input Class Initialized
INFO - 2021-03-24 16:02:05 --> Language Class Initialized
INFO - 2021-03-24 16:02:05 --> Loader Class Initialized
INFO - 2021-03-24 16:02:05 --> Helper loaded: url_helper
INFO - 2021-03-24 16:02:05 --> Helper loaded: file_helper
INFO - 2021-03-24 16:02:05 --> Helper loaded: form_helper
INFO - 2021-03-24 16:02:05 --> Helper loaded: text_helper
INFO - 2021-03-24 16:02:05 --> Helper loaded: security_helper
INFO - 2021-03-24 16:02:05 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 16:02:05 --> Database Driver Class Initialized
INFO - 2021-03-24 16:02:05 --> Email Class Initialized
DEBUG - 2021-03-24 16:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 16:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 16:02:05 --> Form Validation Class Initialized
INFO - 2021-03-24 16:02:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 16:02:05 --> Pagination Class Initialized
INFO - 2021-03-24 16:02:05 --> Model Class Initialized
INFO - 2021-03-24 16:02:05 --> Controller Class Initialized
INFO - 2021-03-24 16:02:05 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-24 16:02:05 --> Final output sent to browser
DEBUG - 2021-03-24 16:02:05 --> Total execution time: 0.2823
INFO - 2021-03-24 16:02:32 --> Config Class Initialized
INFO - 2021-03-24 16:02:32 --> Hooks Class Initialized
DEBUG - 2021-03-24 16:02:32 --> UTF-8 Support Enabled
INFO - 2021-03-24 16:02:32 --> Utf8 Class Initialized
INFO - 2021-03-24 16:02:32 --> URI Class Initialized
INFO - 2021-03-24 16:02:32 --> Router Class Initialized
INFO - 2021-03-24 16:02:32 --> Output Class Initialized
INFO - 2021-03-24 16:02:33 --> Security Class Initialized
DEBUG - 2021-03-24 16:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 16:02:33 --> Input Class Initialized
INFO - 2021-03-24 16:02:33 --> Language Class Initialized
INFO - 2021-03-24 16:02:33 --> Loader Class Initialized
INFO - 2021-03-24 16:02:33 --> Helper loaded: url_helper
INFO - 2021-03-24 16:02:33 --> Helper loaded: file_helper
INFO - 2021-03-24 16:02:33 --> Helper loaded: form_helper
INFO - 2021-03-24 16:02:33 --> Helper loaded: text_helper
INFO - 2021-03-24 16:02:33 --> Helper loaded: security_helper
INFO - 2021-03-24 16:02:33 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 16:02:33 --> Database Driver Class Initialized
INFO - 2021-03-24 16:02:33 --> Email Class Initialized
DEBUG - 2021-03-24 16:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 16:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 16:02:33 --> Form Validation Class Initialized
INFO - 2021-03-24 16:02:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 16:02:33 --> Pagination Class Initialized
INFO - 2021-03-24 16:02:33 --> Model Class Initialized
INFO - 2021-03-24 16:02:33 --> Controller Class Initialized
INFO - 2021-03-24 16:02:33 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-24 16:02:33 --> Final output sent to browser
DEBUG - 2021-03-24 16:02:33 --> Total execution time: 0.2656
INFO - 2021-03-24 16:02:43 --> Config Class Initialized
INFO - 2021-03-24 16:02:43 --> Hooks Class Initialized
DEBUG - 2021-03-24 16:02:43 --> UTF-8 Support Enabled
INFO - 2021-03-24 16:02:43 --> Utf8 Class Initialized
INFO - 2021-03-24 16:02:43 --> URI Class Initialized
INFO - 2021-03-24 16:02:43 --> Router Class Initialized
INFO - 2021-03-24 16:02:43 --> Output Class Initialized
INFO - 2021-03-24 16:02:43 --> Security Class Initialized
DEBUG - 2021-03-24 16:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 16:02:43 --> Input Class Initialized
INFO - 2021-03-24 16:02:43 --> Language Class Initialized
INFO - 2021-03-24 16:02:43 --> Loader Class Initialized
INFO - 2021-03-24 16:02:43 --> Helper loaded: url_helper
INFO - 2021-03-24 16:02:43 --> Helper loaded: file_helper
INFO - 2021-03-24 16:02:43 --> Helper loaded: form_helper
INFO - 2021-03-24 16:02:43 --> Helper loaded: text_helper
INFO - 2021-03-24 16:02:43 --> Helper loaded: security_helper
INFO - 2021-03-24 16:02:43 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 16:02:43 --> Database Driver Class Initialized
INFO - 2021-03-24 16:02:43 --> Email Class Initialized
DEBUG - 2021-03-24 16:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 16:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 16:02:43 --> Form Validation Class Initialized
INFO - 2021-03-24 16:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 16:02:43 --> Pagination Class Initialized
INFO - 2021-03-24 16:02:43 --> Model Class Initialized
INFO - 2021-03-24 16:02:43 --> Controller Class Initialized
INFO - 2021-03-24 16:03:00 --> Config Class Initialized
INFO - 2021-03-24 16:03:00 --> Hooks Class Initialized
DEBUG - 2021-03-24 16:03:00 --> UTF-8 Support Enabled
INFO - 2021-03-24 16:03:00 --> Utf8 Class Initialized
INFO - 2021-03-24 16:03:00 --> URI Class Initialized
INFO - 2021-03-24 16:03:00 --> Router Class Initialized
INFO - 2021-03-24 16:03:00 --> Output Class Initialized
INFO - 2021-03-24 16:03:00 --> Security Class Initialized
DEBUG - 2021-03-24 16:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 16:03:00 --> Input Class Initialized
INFO - 2021-03-24 16:03:00 --> Language Class Initialized
INFO - 2021-03-24 16:03:00 --> Loader Class Initialized
INFO - 2021-03-24 16:03:00 --> Helper loaded: url_helper
INFO - 2021-03-24 16:03:00 --> Helper loaded: file_helper
INFO - 2021-03-24 16:03:00 --> Helper loaded: form_helper
INFO - 2021-03-24 16:03:00 --> Helper loaded: text_helper
INFO - 2021-03-24 16:03:00 --> Helper loaded: security_helper
INFO - 2021-03-24 16:03:00 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 16:03:00 --> Database Driver Class Initialized
INFO - 2021-03-24 16:03:00 --> Email Class Initialized
DEBUG - 2021-03-24 16:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 16:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 16:03:00 --> Form Validation Class Initialized
INFO - 2021-03-24 16:03:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 16:03:00 --> Pagination Class Initialized
INFO - 2021-03-24 16:03:00 --> Model Class Initialized
INFO - 2021-03-24 16:03:00 --> Controller Class Initialized
INFO - 2021-03-24 16:03:00 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-24 16:03:00 --> Final output sent to browser
DEBUG - 2021-03-24 16:03:00 --> Total execution time: 0.2645
INFO - 2021-03-24 16:12:15 --> Config Class Initialized
INFO - 2021-03-24 16:12:15 --> Hooks Class Initialized
DEBUG - 2021-03-24 16:12:15 --> UTF-8 Support Enabled
INFO - 2021-03-24 16:12:15 --> Utf8 Class Initialized
INFO - 2021-03-24 16:12:15 --> URI Class Initialized
INFO - 2021-03-24 16:12:15 --> Router Class Initialized
INFO - 2021-03-24 16:12:15 --> Output Class Initialized
INFO - 2021-03-24 16:12:15 --> Security Class Initialized
DEBUG - 2021-03-24 16:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 16:12:15 --> Input Class Initialized
INFO - 2021-03-24 16:12:15 --> Language Class Initialized
INFO - 2021-03-24 16:12:15 --> Loader Class Initialized
INFO - 2021-03-24 16:12:15 --> Helper loaded: url_helper
INFO - 2021-03-24 16:12:15 --> Helper loaded: file_helper
INFO - 2021-03-24 16:12:15 --> Helper loaded: form_helper
INFO - 2021-03-24 16:12:15 --> Helper loaded: text_helper
INFO - 2021-03-24 16:12:15 --> Helper loaded: security_helper
INFO - 2021-03-24 16:12:15 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 16:12:15 --> Database Driver Class Initialized
INFO - 2021-03-24 16:12:15 --> Email Class Initialized
DEBUG - 2021-03-24 16:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 16:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 16:12:15 --> Form Validation Class Initialized
INFO - 2021-03-24 16:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 16:12:15 --> Pagination Class Initialized
INFO - 2021-03-24 16:12:15 --> Model Class Initialized
INFO - 2021-03-24 16:12:15 --> Controller Class Initialized
INFO - 2021-03-24 16:53:44 --> Config Class Initialized
INFO - 2021-03-24 16:53:44 --> Hooks Class Initialized
DEBUG - 2021-03-24 16:53:44 --> UTF-8 Support Enabled
INFO - 2021-03-24 16:53:44 --> Utf8 Class Initialized
INFO - 2021-03-24 16:53:44 --> URI Class Initialized
INFO - 2021-03-24 16:53:44 --> Router Class Initialized
INFO - 2021-03-24 16:53:44 --> Output Class Initialized
INFO - 2021-03-24 16:53:44 --> Security Class Initialized
DEBUG - 2021-03-24 16:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 16:53:44 --> Input Class Initialized
INFO - 2021-03-24 16:53:44 --> Language Class Initialized
INFO - 2021-03-24 16:53:44 --> Loader Class Initialized
INFO - 2021-03-24 16:53:44 --> Helper loaded: url_helper
INFO - 2021-03-24 16:53:44 --> Helper loaded: file_helper
INFO - 2021-03-24 16:53:44 --> Helper loaded: form_helper
INFO - 2021-03-24 16:53:44 --> Helper loaded: text_helper
INFO - 2021-03-24 16:53:44 --> Helper loaded: security_helper
INFO - 2021-03-24 16:53:44 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 16:53:44 --> Database Driver Class Initialized
INFO - 2021-03-24 16:53:44 --> Email Class Initialized
DEBUG - 2021-03-24 16:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 16:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 16:53:45 --> Form Validation Class Initialized
INFO - 2021-03-24 16:53:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 16:53:45 --> Pagination Class Initialized
INFO - 2021-03-24 16:53:45 --> Model Class Initialized
INFO - 2021-03-24 16:53:45 --> Controller Class Initialized
INFO - 2021-03-24 16:53:45 --> Model Class Initialized
INFO - 2021-03-24 16:53:46 --> Config Class Initialized
INFO - 2021-03-24 16:53:46 --> Hooks Class Initialized
DEBUG - 2021-03-24 16:53:46 --> UTF-8 Support Enabled
INFO - 2021-03-24 16:53:46 --> Utf8 Class Initialized
INFO - 2021-03-24 16:53:46 --> URI Class Initialized
INFO - 2021-03-24 16:53:46 --> Router Class Initialized
INFO - 2021-03-24 16:53:46 --> Output Class Initialized
INFO - 2021-03-24 16:53:46 --> Security Class Initialized
DEBUG - 2021-03-24 16:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 16:53:46 --> Input Class Initialized
INFO - 2021-03-24 16:53:46 --> Language Class Initialized
INFO - 2021-03-24 16:53:46 --> Loader Class Initialized
INFO - 2021-03-24 16:53:46 --> Helper loaded: url_helper
INFO - 2021-03-24 16:53:46 --> Helper loaded: file_helper
INFO - 2021-03-24 16:53:46 --> Helper loaded: form_helper
INFO - 2021-03-24 16:53:46 --> Helper loaded: text_helper
INFO - 2021-03-24 16:53:46 --> Helper loaded: security_helper
INFO - 2021-03-24 16:53:46 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 16:53:46 --> Database Driver Class Initialized
INFO - 2021-03-24 16:53:46 --> Email Class Initialized
DEBUG - 2021-03-24 16:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 16:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 16:53:46 --> Form Validation Class Initialized
INFO - 2021-03-24 16:53:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 16:53:47 --> Pagination Class Initialized
INFO - 2021-03-24 16:53:47 --> Model Class Initialized
INFO - 2021-03-24 16:53:47 --> Controller Class Initialized
INFO - 2021-03-24 16:53:47 --> Model Class Initialized
INFO - 2021-03-24 16:54:33 --> Config Class Initialized
INFO - 2021-03-24 16:54:33 --> Hooks Class Initialized
DEBUG - 2021-03-24 16:54:33 --> UTF-8 Support Enabled
INFO - 2021-03-24 16:54:33 --> Utf8 Class Initialized
INFO - 2021-03-24 16:54:33 --> URI Class Initialized
INFO - 2021-03-24 16:54:33 --> Router Class Initialized
INFO - 2021-03-24 16:54:34 --> Output Class Initialized
INFO - 2021-03-24 16:54:34 --> Security Class Initialized
DEBUG - 2021-03-24 16:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 16:54:34 --> Input Class Initialized
INFO - 2021-03-24 16:54:34 --> Language Class Initialized
INFO - 2021-03-24 16:54:34 --> Loader Class Initialized
INFO - 2021-03-24 16:54:34 --> Helper loaded: url_helper
INFO - 2021-03-24 16:54:34 --> Helper loaded: file_helper
INFO - 2021-03-24 16:54:34 --> Helper loaded: form_helper
INFO - 2021-03-24 16:54:34 --> Helper loaded: text_helper
INFO - 2021-03-24 16:54:34 --> Helper loaded: security_helper
INFO - 2021-03-24 16:54:34 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 16:54:34 --> Database Driver Class Initialized
INFO - 2021-03-24 16:54:34 --> Email Class Initialized
DEBUG - 2021-03-24 16:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 16:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 16:54:34 --> Form Validation Class Initialized
INFO - 2021-03-24 16:54:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 16:54:34 --> Pagination Class Initialized
INFO - 2021-03-24 16:54:34 --> Model Class Initialized
INFO - 2021-03-24 16:54:34 --> Controller Class Initialized
ERROR - 2021-03-24 16:54:34 --> Severity: error --> Exception: syntax error, unexpected '?>', expecting function (T_FUNCTION) or const (T_CONST) C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 89
INFO - 2021-03-24 16:55:19 --> Config Class Initialized
INFO - 2021-03-24 16:55:19 --> Hooks Class Initialized
DEBUG - 2021-03-24 16:55:19 --> UTF-8 Support Enabled
INFO - 2021-03-24 16:55:19 --> Utf8 Class Initialized
INFO - 2021-03-24 16:55:19 --> URI Class Initialized
INFO - 2021-03-24 16:55:19 --> Router Class Initialized
INFO - 2021-03-24 16:55:19 --> Output Class Initialized
INFO - 2021-03-24 16:55:19 --> Security Class Initialized
DEBUG - 2021-03-24 16:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 16:55:19 --> Input Class Initialized
INFO - 2021-03-24 16:55:19 --> Language Class Initialized
INFO - 2021-03-24 16:55:19 --> Loader Class Initialized
INFO - 2021-03-24 16:55:19 --> Helper loaded: url_helper
INFO - 2021-03-24 16:55:19 --> Helper loaded: file_helper
INFO - 2021-03-24 16:55:19 --> Helper loaded: form_helper
INFO - 2021-03-24 16:55:19 --> Helper loaded: text_helper
INFO - 2021-03-24 16:55:19 --> Helper loaded: security_helper
INFO - 2021-03-24 16:55:19 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 16:55:19 --> Database Driver Class Initialized
INFO - 2021-03-24 16:55:19 --> Email Class Initialized
DEBUG - 2021-03-24 16:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 16:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 16:55:19 --> Form Validation Class Initialized
INFO - 2021-03-24 16:55:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 16:55:19 --> Pagination Class Initialized
INFO - 2021-03-24 16:55:19 --> Model Class Initialized
INFO - 2021-03-24 16:55:19 --> Controller Class Initialized
INFO - 2021-03-24 16:55:19 --> Model Class Initialized
INFO - 2021-03-24 16:55:33 --> Config Class Initialized
INFO - 2021-03-24 16:55:33 --> Hooks Class Initialized
DEBUG - 2021-03-24 16:55:33 --> UTF-8 Support Enabled
INFO - 2021-03-24 16:55:33 --> Utf8 Class Initialized
INFO - 2021-03-24 16:55:33 --> URI Class Initialized
INFO - 2021-03-24 16:55:33 --> Router Class Initialized
INFO - 2021-03-24 16:55:33 --> Output Class Initialized
INFO - 2021-03-24 16:55:33 --> Security Class Initialized
DEBUG - 2021-03-24 16:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 16:55:33 --> Input Class Initialized
INFO - 2021-03-24 16:55:33 --> Language Class Initialized
INFO - 2021-03-24 16:55:33 --> Loader Class Initialized
INFO - 2021-03-24 16:55:33 --> Helper loaded: url_helper
INFO - 2021-03-24 16:55:33 --> Helper loaded: file_helper
INFO - 2021-03-24 16:55:33 --> Helper loaded: form_helper
INFO - 2021-03-24 16:55:33 --> Helper loaded: text_helper
INFO - 2021-03-24 16:55:33 --> Helper loaded: security_helper
INFO - 2021-03-24 16:55:33 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 16:55:33 --> Database Driver Class Initialized
INFO - 2021-03-24 16:55:33 --> Email Class Initialized
DEBUG - 2021-03-24 16:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 16:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 16:55:33 --> Form Validation Class Initialized
INFO - 2021-03-24 16:55:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 16:55:33 --> Pagination Class Initialized
INFO - 2021-03-24 16:55:33 --> Model Class Initialized
INFO - 2021-03-24 16:55:33 --> Controller Class Initialized
INFO - 2021-03-24 16:55:33 --> Model Class Initialized
INFO - 2021-03-24 16:55:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 16:55:33 --> Query error: No database selected - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.generated_user_id = '12345'
ERROR - 2021-03-24 16:55:33 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 45
INFO - 2021-03-24 16:56:01 --> Config Class Initialized
INFO - 2021-03-24 16:56:01 --> Hooks Class Initialized
DEBUG - 2021-03-24 16:56:01 --> UTF-8 Support Enabled
INFO - 2021-03-24 16:56:01 --> Utf8 Class Initialized
INFO - 2021-03-24 16:56:01 --> URI Class Initialized
INFO - 2021-03-24 16:56:01 --> Router Class Initialized
INFO - 2021-03-24 16:56:01 --> Output Class Initialized
INFO - 2021-03-24 16:56:01 --> Security Class Initialized
DEBUG - 2021-03-24 16:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 16:56:01 --> Input Class Initialized
INFO - 2021-03-24 16:56:01 --> Language Class Initialized
INFO - 2021-03-24 16:56:01 --> Loader Class Initialized
INFO - 2021-03-24 16:56:01 --> Helper loaded: url_helper
INFO - 2021-03-24 16:56:01 --> Helper loaded: file_helper
INFO - 2021-03-24 16:56:02 --> Helper loaded: form_helper
INFO - 2021-03-24 16:56:02 --> Helper loaded: text_helper
INFO - 2021-03-24 16:56:02 --> Helper loaded: security_helper
INFO - 2021-03-24 16:56:02 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 16:56:02 --> Database Driver Class Initialized
INFO - 2021-03-24 16:56:02 --> Email Class Initialized
DEBUG - 2021-03-24 16:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 16:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 16:56:02 --> Form Validation Class Initialized
INFO - 2021-03-24 16:56:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 16:56:02 --> Pagination Class Initialized
INFO - 2021-03-24 16:56:02 --> Model Class Initialized
INFO - 2021-03-24 16:56:02 --> Controller Class Initialized
INFO - 2021-03-24 16:56:02 --> Model Class Initialized
INFO - 2021-03-24 16:56:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 16:56:02 --> Query error: No database selected - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = '12345'
ERROR - 2021-03-24 16:56:02 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 45
INFO - 2021-03-24 16:56:20 --> Config Class Initialized
INFO - 2021-03-24 16:56:20 --> Hooks Class Initialized
DEBUG - 2021-03-24 16:56:20 --> UTF-8 Support Enabled
INFO - 2021-03-24 16:56:20 --> Utf8 Class Initialized
INFO - 2021-03-24 16:56:20 --> URI Class Initialized
INFO - 2021-03-24 16:56:20 --> Router Class Initialized
INFO - 2021-03-24 16:56:20 --> Output Class Initialized
INFO - 2021-03-24 16:56:20 --> Security Class Initialized
DEBUG - 2021-03-24 16:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 16:56:20 --> Input Class Initialized
INFO - 2021-03-24 16:56:20 --> Language Class Initialized
INFO - 2021-03-24 16:56:20 --> Loader Class Initialized
INFO - 2021-03-24 16:56:20 --> Helper loaded: url_helper
INFO - 2021-03-24 16:56:20 --> Helper loaded: file_helper
INFO - 2021-03-24 16:56:20 --> Helper loaded: form_helper
INFO - 2021-03-24 16:56:20 --> Helper loaded: text_helper
INFO - 2021-03-24 16:56:20 --> Helper loaded: security_helper
INFO - 2021-03-24 16:56:20 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 16:56:20 --> Database Driver Class Initialized
INFO - 2021-03-24 16:56:21 --> Email Class Initialized
DEBUG - 2021-03-24 16:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 16:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 16:56:21 --> Form Validation Class Initialized
INFO - 2021-03-24 16:56:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 16:56:21 --> Pagination Class Initialized
INFO - 2021-03-24 16:56:21 --> Model Class Initialized
INFO - 2021-03-24 16:56:21 --> Controller Class Initialized
INFO - 2021-03-24 16:56:21 --> Model Class Initialized
INFO - 2021-03-24 16:56:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 16:56:21 --> Query error: No database selected - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = '12345'
ERROR - 2021-03-24 16:56:21 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 45
INFO - 2021-03-24 16:56:30 --> Config Class Initialized
INFO - 2021-03-24 16:56:30 --> Hooks Class Initialized
DEBUG - 2021-03-24 16:56:30 --> UTF-8 Support Enabled
INFO - 2021-03-24 16:56:30 --> Utf8 Class Initialized
INFO - 2021-03-24 16:56:30 --> URI Class Initialized
INFO - 2021-03-24 16:56:30 --> Router Class Initialized
INFO - 2021-03-24 16:56:30 --> Output Class Initialized
INFO - 2021-03-24 16:56:30 --> Security Class Initialized
DEBUG - 2021-03-24 16:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 16:56:30 --> Input Class Initialized
INFO - 2021-03-24 16:56:30 --> Language Class Initialized
INFO - 2021-03-24 16:56:30 --> Loader Class Initialized
INFO - 2021-03-24 16:56:30 --> Helper loaded: url_helper
INFO - 2021-03-24 16:56:30 --> Helper loaded: file_helper
INFO - 2021-03-24 16:56:30 --> Helper loaded: form_helper
INFO - 2021-03-24 16:56:30 --> Helper loaded: text_helper
INFO - 2021-03-24 16:56:30 --> Helper loaded: security_helper
INFO - 2021-03-24 16:56:30 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 16:56:30 --> Database Driver Class Initialized
INFO - 2021-03-24 16:56:30 --> Email Class Initialized
DEBUG - 2021-03-24 16:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 16:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 16:56:30 --> Form Validation Class Initialized
INFO - 2021-03-24 16:56:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 16:56:30 --> Pagination Class Initialized
INFO - 2021-03-24 16:56:30 --> Model Class Initialized
INFO - 2021-03-24 16:56:30 --> Controller Class Initialized
INFO - 2021-03-24 16:56:30 --> Model Class Initialized
INFO - 2021-03-24 16:56:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 16:56:30 --> Query error: No database selected - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = '12345'
INFO - 2021-03-24 16:57:28 --> Config Class Initialized
INFO - 2021-03-24 16:57:28 --> Hooks Class Initialized
DEBUG - 2021-03-24 16:57:28 --> UTF-8 Support Enabled
INFO - 2021-03-24 16:57:28 --> Utf8 Class Initialized
INFO - 2021-03-24 16:57:28 --> URI Class Initialized
INFO - 2021-03-24 16:57:28 --> Router Class Initialized
INFO - 2021-03-24 16:57:28 --> Output Class Initialized
INFO - 2021-03-24 16:57:28 --> Security Class Initialized
DEBUG - 2021-03-24 16:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 16:57:28 --> Input Class Initialized
INFO - 2021-03-24 16:57:28 --> Language Class Initialized
INFO - 2021-03-24 16:57:28 --> Loader Class Initialized
INFO - 2021-03-24 16:57:28 --> Helper loaded: url_helper
INFO - 2021-03-24 16:57:28 --> Helper loaded: file_helper
INFO - 2021-03-24 16:57:28 --> Helper loaded: form_helper
INFO - 2021-03-24 16:57:28 --> Helper loaded: text_helper
INFO - 2021-03-24 16:57:28 --> Helper loaded: security_helper
INFO - 2021-03-24 16:57:28 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 16:57:28 --> Database Driver Class Initialized
INFO - 2021-03-24 16:57:28 --> Email Class Initialized
DEBUG - 2021-03-24 16:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 16:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 16:57:28 --> Form Validation Class Initialized
INFO - 2021-03-24 16:57:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 16:57:28 --> Pagination Class Initialized
INFO - 2021-03-24 16:57:28 --> Model Class Initialized
INFO - 2021-03-24 16:57:28 --> Controller Class Initialized
INFO - 2021-03-24 16:57:28 --> Model Class Initialized
INFO - 2021-03-24 16:57:28 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 16:57:28 --> Query error: No database selected - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = '12345'
ERROR - 2021-03-24 16:57:28 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 45
INFO - 2021-03-24 16:58:13 --> Config Class Initialized
INFO - 2021-03-24 16:58:13 --> Hooks Class Initialized
DEBUG - 2021-03-24 16:58:13 --> UTF-8 Support Enabled
INFO - 2021-03-24 16:58:13 --> Utf8 Class Initialized
INFO - 2021-03-24 16:58:13 --> URI Class Initialized
INFO - 2021-03-24 16:58:13 --> Router Class Initialized
INFO - 2021-03-24 16:58:13 --> Output Class Initialized
INFO - 2021-03-24 16:58:13 --> Security Class Initialized
DEBUG - 2021-03-24 16:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 16:58:13 --> Input Class Initialized
INFO - 2021-03-24 16:58:13 --> Language Class Initialized
INFO - 2021-03-24 16:58:13 --> Loader Class Initialized
INFO - 2021-03-24 16:58:13 --> Helper loaded: url_helper
INFO - 2021-03-24 16:58:13 --> Helper loaded: file_helper
INFO - 2021-03-24 16:58:13 --> Helper loaded: form_helper
INFO - 2021-03-24 16:58:13 --> Helper loaded: text_helper
INFO - 2021-03-24 16:58:13 --> Helper loaded: security_helper
INFO - 2021-03-24 16:58:13 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 16:58:13 --> Database Driver Class Initialized
INFO - 2021-03-24 16:58:13 --> Email Class Initialized
DEBUG - 2021-03-24 16:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 16:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 16:58:13 --> Form Validation Class Initialized
INFO - 2021-03-24 16:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 16:58:13 --> Pagination Class Initialized
INFO - 2021-03-24 16:58:13 --> Model Class Initialized
INFO - 2021-03-24 16:58:13 --> Controller Class Initialized
INFO - 2021-03-24 16:58:13 --> Model Class Initialized
INFO - 2021-03-24 16:58:13 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-24 16:58:13 --> Final output sent to browser
DEBUG - 2021-03-24 16:58:13 --> Total execution time: 0.2874
INFO - 2021-03-24 16:58:22 --> Config Class Initialized
INFO - 2021-03-24 16:58:22 --> Hooks Class Initialized
DEBUG - 2021-03-24 16:58:22 --> UTF-8 Support Enabled
INFO - 2021-03-24 16:58:22 --> Utf8 Class Initialized
INFO - 2021-03-24 16:58:22 --> URI Class Initialized
INFO - 2021-03-24 16:58:22 --> Router Class Initialized
INFO - 2021-03-24 16:58:22 --> Output Class Initialized
INFO - 2021-03-24 16:58:22 --> Security Class Initialized
DEBUG - 2021-03-24 16:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 16:58:22 --> Input Class Initialized
INFO - 2021-03-24 16:58:22 --> Language Class Initialized
INFO - 2021-03-24 16:58:22 --> Loader Class Initialized
INFO - 2021-03-24 16:58:22 --> Helper loaded: url_helper
INFO - 2021-03-24 16:58:22 --> Helper loaded: file_helper
INFO - 2021-03-24 16:58:22 --> Helper loaded: form_helper
INFO - 2021-03-24 16:58:22 --> Helper loaded: text_helper
INFO - 2021-03-24 16:58:22 --> Helper loaded: security_helper
INFO - 2021-03-24 16:58:22 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 16:58:22 --> Database Driver Class Initialized
INFO - 2021-03-24 16:58:22 --> Email Class Initialized
DEBUG - 2021-03-24 16:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 16:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 16:58:22 --> Form Validation Class Initialized
INFO - 2021-03-24 16:58:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 16:58:22 --> Pagination Class Initialized
INFO - 2021-03-24 16:58:22 --> Model Class Initialized
INFO - 2021-03-24 16:58:22 --> Controller Class Initialized
INFO - 2021-03-24 16:58:22 --> Model Class Initialized
INFO - 2021-03-24 16:58:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 16:58:22 --> Query error: No database selected - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = '123456'
ERROR - 2021-03-24 16:58:22 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 45
INFO - 2021-03-24 17:00:23 --> Config Class Initialized
INFO - 2021-03-24 17:00:23 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:00:23 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:00:23 --> Utf8 Class Initialized
INFO - 2021-03-24 17:00:23 --> URI Class Initialized
INFO - 2021-03-24 17:00:23 --> Router Class Initialized
INFO - 2021-03-24 17:00:23 --> Output Class Initialized
INFO - 2021-03-24 17:00:23 --> Security Class Initialized
DEBUG - 2021-03-24 17:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:00:23 --> Input Class Initialized
INFO - 2021-03-24 17:00:23 --> Language Class Initialized
INFO - 2021-03-24 17:00:23 --> Loader Class Initialized
INFO - 2021-03-24 17:00:24 --> Helper loaded: url_helper
INFO - 2021-03-24 17:00:24 --> Helper loaded: file_helper
INFO - 2021-03-24 17:00:24 --> Helper loaded: form_helper
INFO - 2021-03-24 17:00:24 --> Helper loaded: text_helper
INFO - 2021-03-24 17:00:24 --> Helper loaded: security_helper
INFO - 2021-03-24 17:00:24 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:00:24 --> Database Driver Class Initialized
INFO - 2021-03-24 17:00:24 --> Email Class Initialized
DEBUG - 2021-03-24 17:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:00:24 --> Form Validation Class Initialized
INFO - 2021-03-24 17:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:00:24 --> Pagination Class Initialized
INFO - 2021-03-24 17:00:24 --> Model Class Initialized
INFO - 2021-03-24 17:00:24 --> Controller Class Initialized
INFO - 2021-03-24 17:00:24 --> Model Class Initialized
INFO - 2021-03-24 17:00:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:00:24 --> Query error: No database selected - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = '123456'
ERROR - 2021-03-24 17:00:24 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 45
INFO - 2021-03-24 17:00:27 --> Config Class Initialized
INFO - 2021-03-24 17:00:27 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:00:27 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:00:27 --> Utf8 Class Initialized
INFO - 2021-03-24 17:00:27 --> URI Class Initialized
INFO - 2021-03-24 17:00:27 --> Router Class Initialized
INFO - 2021-03-24 17:00:27 --> Output Class Initialized
INFO - 2021-03-24 17:00:27 --> Security Class Initialized
DEBUG - 2021-03-24 17:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:00:27 --> Input Class Initialized
INFO - 2021-03-24 17:00:27 --> Language Class Initialized
INFO - 2021-03-24 17:00:27 --> Loader Class Initialized
INFO - 2021-03-24 17:00:27 --> Helper loaded: url_helper
INFO - 2021-03-24 17:00:27 --> Helper loaded: file_helper
INFO - 2021-03-24 17:00:27 --> Helper loaded: form_helper
INFO - 2021-03-24 17:00:27 --> Helper loaded: text_helper
INFO - 2021-03-24 17:00:27 --> Helper loaded: security_helper
INFO - 2021-03-24 17:00:27 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:00:27 --> Database Driver Class Initialized
INFO - 2021-03-24 17:00:27 --> Email Class Initialized
DEBUG - 2021-03-24 17:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:00:27 --> Form Validation Class Initialized
INFO - 2021-03-24 17:00:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:00:27 --> Pagination Class Initialized
INFO - 2021-03-24 17:00:27 --> Model Class Initialized
INFO - 2021-03-24 17:00:27 --> Controller Class Initialized
INFO - 2021-03-24 17:00:27 --> Model Class Initialized
INFO - 2021-03-24 17:00:27 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:00:27 --> Query error: No database selected - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = '123456'
ERROR - 2021-03-24 17:00:27 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 45
INFO - 2021-03-24 17:00:50 --> Config Class Initialized
INFO - 2021-03-24 17:00:50 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:00:50 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:00:50 --> Utf8 Class Initialized
INFO - 2021-03-24 17:00:50 --> URI Class Initialized
INFO - 2021-03-24 17:00:51 --> Router Class Initialized
INFO - 2021-03-24 17:00:51 --> Output Class Initialized
INFO - 2021-03-24 17:00:51 --> Security Class Initialized
DEBUG - 2021-03-24 17:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:00:51 --> Input Class Initialized
INFO - 2021-03-24 17:00:51 --> Language Class Initialized
INFO - 2021-03-24 17:00:51 --> Loader Class Initialized
INFO - 2021-03-24 17:00:51 --> Helper loaded: url_helper
INFO - 2021-03-24 17:00:51 --> Helper loaded: file_helper
INFO - 2021-03-24 17:00:51 --> Helper loaded: form_helper
INFO - 2021-03-24 17:00:51 --> Helper loaded: text_helper
INFO - 2021-03-24 17:00:51 --> Helper loaded: security_helper
INFO - 2021-03-24 17:00:51 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:00:51 --> Database Driver Class Initialized
INFO - 2021-03-24 17:00:51 --> Email Class Initialized
DEBUG - 2021-03-24 17:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:00:51 --> Form Validation Class Initialized
INFO - 2021-03-24 17:00:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:00:51 --> Pagination Class Initialized
INFO - 2021-03-24 17:00:51 --> Model Class Initialized
INFO - 2021-03-24 17:00:51 --> Controller Class Initialized
INFO - 2021-03-24 17:00:51 --> Model Class Initialized
INFO - 2021-03-24 17:00:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:00:51 --> Query error: No database selected - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = '123456'
INFO - 2021-03-24 17:01:16 --> Config Class Initialized
INFO - 2021-03-24 17:01:16 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:01:16 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:01:16 --> Utf8 Class Initialized
INFO - 2021-03-24 17:01:16 --> URI Class Initialized
INFO - 2021-03-24 17:01:16 --> Router Class Initialized
INFO - 2021-03-24 17:01:16 --> Output Class Initialized
INFO - 2021-03-24 17:01:16 --> Security Class Initialized
DEBUG - 2021-03-24 17:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:01:16 --> Input Class Initialized
INFO - 2021-03-24 17:01:16 --> Language Class Initialized
INFO - 2021-03-24 17:01:16 --> Loader Class Initialized
INFO - 2021-03-24 17:01:16 --> Helper loaded: url_helper
INFO - 2021-03-24 17:01:16 --> Helper loaded: file_helper
INFO - 2021-03-24 17:01:16 --> Helper loaded: form_helper
INFO - 2021-03-24 17:01:16 --> Helper loaded: text_helper
INFO - 2021-03-24 17:01:16 --> Helper loaded: security_helper
INFO - 2021-03-24 17:01:16 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:01:16 --> Database Driver Class Initialized
INFO - 2021-03-24 17:01:16 --> Email Class Initialized
DEBUG - 2021-03-24 17:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:01:16 --> Form Validation Class Initialized
INFO - 2021-03-24 17:01:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:01:16 --> Pagination Class Initialized
INFO - 2021-03-24 17:01:16 --> Model Class Initialized
INFO - 2021-03-24 17:01:16 --> Controller Class Initialized
INFO - 2021-03-24 17:01:16 --> Model Class Initialized
INFO - 2021-03-24 17:01:16 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:01:16 --> Query error: No database selected - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = '123456'
ERROR - 2021-03-24 17:01:16 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 46
INFO - 2021-03-24 17:02:13 --> Config Class Initialized
INFO - 2021-03-24 17:02:13 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:02:13 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:02:13 --> Utf8 Class Initialized
INFO - 2021-03-24 17:02:13 --> URI Class Initialized
INFO - 2021-03-24 17:02:13 --> Router Class Initialized
INFO - 2021-03-24 17:02:13 --> Output Class Initialized
INFO - 2021-03-24 17:02:13 --> Security Class Initialized
DEBUG - 2021-03-24 17:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:02:13 --> Input Class Initialized
INFO - 2021-03-24 17:02:13 --> Language Class Initialized
INFO - 2021-03-24 17:02:13 --> Loader Class Initialized
INFO - 2021-03-24 17:02:13 --> Helper loaded: url_helper
INFO - 2021-03-24 17:02:13 --> Helper loaded: file_helper
INFO - 2021-03-24 17:02:13 --> Helper loaded: form_helper
INFO - 2021-03-24 17:02:13 --> Helper loaded: text_helper
INFO - 2021-03-24 17:02:13 --> Helper loaded: security_helper
INFO - 2021-03-24 17:02:13 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:02:13 --> Database Driver Class Initialized
INFO - 2021-03-24 17:02:13 --> Email Class Initialized
DEBUG - 2021-03-24 17:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:02:13 --> Form Validation Class Initialized
INFO - 2021-03-24 17:02:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:02:13 --> Pagination Class Initialized
INFO - 2021-03-24 17:02:13 --> Model Class Initialized
INFO - 2021-03-24 17:02:13 --> Controller Class Initialized
INFO - 2021-03-24 17:02:13 --> Model Class Initialized
INFO - 2021-03-24 17:02:13 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:02:13 --> Query error: No database selected - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = '123456'
ERROR - 2021-03-24 17:02:13 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 44
INFO - 2021-03-24 17:02:49 --> Config Class Initialized
INFO - 2021-03-24 17:02:49 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:02:49 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:02:49 --> Utf8 Class Initialized
INFO - 2021-03-24 17:02:49 --> URI Class Initialized
INFO - 2021-03-24 17:02:49 --> Router Class Initialized
INFO - 2021-03-24 17:02:49 --> Output Class Initialized
INFO - 2021-03-24 17:02:49 --> Security Class Initialized
DEBUG - 2021-03-24 17:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:02:49 --> Input Class Initialized
INFO - 2021-03-24 17:02:49 --> Language Class Initialized
INFO - 2021-03-24 17:02:49 --> Loader Class Initialized
INFO - 2021-03-24 17:02:49 --> Helper loaded: url_helper
INFO - 2021-03-24 17:02:49 --> Helper loaded: file_helper
INFO - 2021-03-24 17:02:49 --> Helper loaded: form_helper
INFO - 2021-03-24 17:02:49 --> Helper loaded: text_helper
INFO - 2021-03-24 17:02:49 --> Helper loaded: security_helper
INFO - 2021-03-24 17:02:49 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:02:49 --> Database Driver Class Initialized
INFO - 2021-03-24 17:02:49 --> Email Class Initialized
DEBUG - 2021-03-24 17:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:02:49 --> Form Validation Class Initialized
INFO - 2021-03-24 17:02:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:02:49 --> Pagination Class Initialized
INFO - 2021-03-24 17:02:49 --> Model Class Initialized
INFO - 2021-03-24 17:02:49 --> Controller Class Initialized
INFO - 2021-03-24 17:02:49 --> Model Class Initialized
INFO - 2021-03-24 17:02:49 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:02:49 --> Query error: No database selected - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = 123456
ERROR - 2021-03-24 17:02:49 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 44
INFO - 2021-03-24 17:03:28 --> Config Class Initialized
INFO - 2021-03-24 17:03:28 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:03:28 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:03:28 --> Utf8 Class Initialized
INFO - 2021-03-24 17:03:28 --> URI Class Initialized
INFO - 2021-03-24 17:03:28 --> Router Class Initialized
INFO - 2021-03-24 17:03:28 --> Output Class Initialized
INFO - 2021-03-24 17:03:28 --> Security Class Initialized
DEBUG - 2021-03-24 17:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:03:28 --> Input Class Initialized
INFO - 2021-03-24 17:03:28 --> Language Class Initialized
INFO - 2021-03-24 17:03:28 --> Loader Class Initialized
INFO - 2021-03-24 17:03:28 --> Helper loaded: url_helper
INFO - 2021-03-24 17:03:28 --> Helper loaded: file_helper
INFO - 2021-03-24 17:03:28 --> Helper loaded: form_helper
INFO - 2021-03-24 17:03:28 --> Helper loaded: text_helper
INFO - 2021-03-24 17:03:28 --> Helper loaded: security_helper
INFO - 2021-03-24 17:03:28 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:03:28 --> Database Driver Class Initialized
INFO - 2021-03-24 17:03:28 --> Email Class Initialized
DEBUG - 2021-03-24 17:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:03:28 --> Form Validation Class Initialized
INFO - 2021-03-24 17:03:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:03:28 --> Pagination Class Initialized
INFO - 2021-03-24 17:03:28 --> Model Class Initialized
INFO - 2021-03-24 17:03:28 --> Controller Class Initialized
INFO - 2021-03-24 17:03:28 --> Model Class Initialized
INFO - 2021-03-24 17:03:28 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:03:28 --> Query error: No database selected - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = '123456'
ERROR - 2021-03-24 17:03:28 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 44
INFO - 2021-03-24 17:05:24 --> Config Class Initialized
INFO - 2021-03-24 17:05:24 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:05:24 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:05:24 --> Utf8 Class Initialized
INFO - 2021-03-24 17:05:24 --> URI Class Initialized
INFO - 2021-03-24 17:05:24 --> Router Class Initialized
INFO - 2021-03-24 17:05:24 --> Output Class Initialized
INFO - 2021-03-24 17:05:24 --> Security Class Initialized
DEBUG - 2021-03-24 17:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:05:24 --> Input Class Initialized
INFO - 2021-03-24 17:05:24 --> Language Class Initialized
INFO - 2021-03-24 17:05:24 --> Loader Class Initialized
INFO - 2021-03-24 17:05:24 --> Helper loaded: url_helper
INFO - 2021-03-24 17:05:24 --> Helper loaded: file_helper
INFO - 2021-03-24 17:05:24 --> Helper loaded: form_helper
INFO - 2021-03-24 17:05:24 --> Helper loaded: text_helper
INFO - 2021-03-24 17:05:24 --> Helper loaded: security_helper
INFO - 2021-03-24 17:05:24 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:05:24 --> Database Driver Class Initialized
INFO - 2021-03-24 17:05:24 --> Email Class Initialized
DEBUG - 2021-03-24 17:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:05:24 --> Form Validation Class Initialized
INFO - 2021-03-24 17:05:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:05:24 --> Pagination Class Initialized
INFO - 2021-03-24 17:05:24 --> Model Class Initialized
INFO - 2021-03-24 17:05:24 --> Controller Class Initialized
INFO - 2021-03-24 17:05:24 --> Model Class Initialized
INFO - 2021-03-24 17:05:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:05:24 --> Query error: No database selected - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = '123456'
ERROR - 2021-03-24 17:05:24 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 44
INFO - 2021-03-24 17:05:38 --> Config Class Initialized
INFO - 2021-03-24 17:05:38 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:05:38 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:05:38 --> Utf8 Class Initialized
INFO - 2021-03-24 17:05:38 --> URI Class Initialized
INFO - 2021-03-24 17:05:38 --> Router Class Initialized
INFO - 2021-03-24 17:05:38 --> Output Class Initialized
INFO - 2021-03-24 17:05:38 --> Security Class Initialized
DEBUG - 2021-03-24 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:05:38 --> Input Class Initialized
INFO - 2021-03-24 17:05:38 --> Language Class Initialized
INFO - 2021-03-24 17:05:38 --> Loader Class Initialized
INFO - 2021-03-24 17:05:38 --> Helper loaded: url_helper
INFO - 2021-03-24 17:05:38 --> Helper loaded: file_helper
INFO - 2021-03-24 17:05:38 --> Helper loaded: form_helper
INFO - 2021-03-24 17:05:38 --> Helper loaded: text_helper
INFO - 2021-03-24 17:05:38 --> Helper loaded: security_helper
INFO - 2021-03-24 17:05:38 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:05:38 --> Database Driver Class Initialized
INFO - 2021-03-24 17:05:38 --> Email Class Initialized
DEBUG - 2021-03-24 17:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:05:38 --> Form Validation Class Initialized
INFO - 2021-03-24 17:05:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:05:38 --> Pagination Class Initialized
INFO - 2021-03-24 17:05:38 --> Model Class Initialized
INFO - 2021-03-24 17:05:38 --> Controller Class Initialized
INFO - 2021-03-24 17:05:38 --> Model Class Initialized
INFO - 2021-03-24 17:05:38 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:05:39 --> Query error: No database selected - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = '123456'
ERROR - 2021-03-24 17:05:39 --> Severity: error --> Exception: Call to a member function row_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 44
INFO - 2021-03-24 17:06:11 --> Config Class Initialized
INFO - 2021-03-24 17:06:11 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:06:11 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:06:11 --> Utf8 Class Initialized
INFO - 2021-03-24 17:06:11 --> URI Class Initialized
INFO - 2021-03-24 17:06:11 --> Router Class Initialized
INFO - 2021-03-24 17:06:11 --> Output Class Initialized
INFO - 2021-03-24 17:06:11 --> Security Class Initialized
DEBUG - 2021-03-24 17:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:06:11 --> Input Class Initialized
INFO - 2021-03-24 17:06:11 --> Language Class Initialized
INFO - 2021-03-24 17:06:11 --> Loader Class Initialized
INFO - 2021-03-24 17:06:11 --> Helper loaded: url_helper
INFO - 2021-03-24 17:06:11 --> Helper loaded: file_helper
INFO - 2021-03-24 17:06:11 --> Helper loaded: form_helper
INFO - 2021-03-24 17:06:11 --> Helper loaded: text_helper
INFO - 2021-03-24 17:06:11 --> Helper loaded: security_helper
INFO - 2021-03-24 17:06:11 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:06:11 --> Database Driver Class Initialized
INFO - 2021-03-24 17:06:11 --> Email Class Initialized
DEBUG - 2021-03-24 17:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:06:11 --> Form Validation Class Initialized
INFO - 2021-03-24 17:06:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:06:11 --> Pagination Class Initialized
INFO - 2021-03-24 17:06:11 --> Model Class Initialized
INFO - 2021-03-24 17:06:11 --> Controller Class Initialized
INFO - 2021-03-24 17:06:11 --> Model Class Initialized
INFO - 2021-03-24 17:06:11 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:06:11 --> Query error: Table 'chips_rda.master_role' doesn't exist - Invalid query: SELECT tl.login_id, tl.username,mr.role_id,mr.role_name,mr.role_type,mr.is_admin
                          FROM tbl_login AS tl
                          JOIN master_role AS mr ON mr.role_id = tl.fk_master_role_id  WHERE tl.username  = '123456' AND tl.password = '90be178a7593b9a476516c5cd8e359e8b6a9dff43e1a733e06aa96553264fffad72379821077f777b9db9f0d62f8964c960d875fa1f60bd3111cf110c41ec20e' 
ERROR - 2021-03-24 17:06:11 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 57
INFO - 2021-03-24 17:06:41 --> Config Class Initialized
INFO - 2021-03-24 17:06:41 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:06:41 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:06:41 --> Utf8 Class Initialized
INFO - 2021-03-24 17:06:41 --> URI Class Initialized
INFO - 2021-03-24 17:06:41 --> Router Class Initialized
INFO - 2021-03-24 17:06:41 --> Output Class Initialized
INFO - 2021-03-24 17:06:41 --> Security Class Initialized
DEBUG - 2021-03-24 17:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:06:41 --> Input Class Initialized
INFO - 2021-03-24 17:06:41 --> Language Class Initialized
INFO - 2021-03-24 17:06:41 --> Loader Class Initialized
INFO - 2021-03-24 17:06:41 --> Helper loaded: url_helper
INFO - 2021-03-24 17:06:41 --> Helper loaded: file_helper
INFO - 2021-03-24 17:06:41 --> Helper loaded: form_helper
INFO - 2021-03-24 17:06:41 --> Helper loaded: text_helper
INFO - 2021-03-24 17:06:41 --> Helper loaded: security_helper
INFO - 2021-03-24 17:06:41 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:06:41 --> Database Driver Class Initialized
INFO - 2021-03-24 17:06:41 --> Email Class Initialized
DEBUG - 2021-03-24 17:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:06:41 --> Form Validation Class Initialized
INFO - 2021-03-24 17:06:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:06:41 --> Pagination Class Initialized
INFO - 2021-03-24 17:06:41 --> Model Class Initialized
INFO - 2021-03-24 17:06:41 --> Controller Class Initialized
INFO - 2021-03-24 17:06:41 --> Model Class Initialized
INFO - 2021-03-24 17:06:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:06:41 --> Query error: Table 'chips_rda.master_role' doesn't exist - Invalid query: SELECT tl.login_id, tl.username,mr.role_id,mr.role_name,mr.role_type,mr.is_admin
                          FROM tbl_login AS tl
                          JOIN master_role AS mr ON mr.role_id = tl.fk_master_role_id  WHERE tl.username  = '123456' AND tl.password = '90be178a7593b9a476516c5cd8e359e8b6a9dff43e1a733e06aa96553264fffad72379821077f777b9db9f0d62f8964c960d875fa1f60bd3111cf110c41ec20e' 
ERROR - 2021-03-24 17:06:41 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 57
INFO - 2021-03-24 17:07:17 --> Config Class Initialized
INFO - 2021-03-24 17:07:17 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:07:17 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:07:17 --> Utf8 Class Initialized
INFO - 2021-03-24 17:07:17 --> URI Class Initialized
INFO - 2021-03-24 17:07:17 --> Router Class Initialized
INFO - 2021-03-24 17:07:17 --> Output Class Initialized
INFO - 2021-03-24 17:07:17 --> Security Class Initialized
DEBUG - 2021-03-24 17:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:07:17 --> Input Class Initialized
INFO - 2021-03-24 17:07:17 --> Language Class Initialized
INFO - 2021-03-24 17:07:17 --> Loader Class Initialized
INFO - 2021-03-24 17:07:17 --> Helper loaded: url_helper
INFO - 2021-03-24 17:07:17 --> Helper loaded: file_helper
INFO - 2021-03-24 17:07:17 --> Helper loaded: form_helper
INFO - 2021-03-24 17:07:17 --> Helper loaded: text_helper
INFO - 2021-03-24 17:07:17 --> Helper loaded: security_helper
INFO - 2021-03-24 17:07:17 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:07:17 --> Database Driver Class Initialized
INFO - 2021-03-24 17:07:17 --> Email Class Initialized
DEBUG - 2021-03-24 17:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:07:17 --> Form Validation Class Initialized
INFO - 2021-03-24 17:07:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:07:17 --> Pagination Class Initialized
INFO - 2021-03-24 17:07:17 --> Model Class Initialized
INFO - 2021-03-24 17:07:17 --> Controller Class Initialized
INFO - 2021-03-24 17:07:17 --> Model Class Initialized
INFO - 2021-03-24 17:07:17 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:07:17 --> Query error: Table 'chips_rda.master_role' doesn't exist - Invalid query: SELECT tl.login_id, tl.username,mr.role_id,mr.role_name,mr.role_type,mr.is_admin
                          FROM tbl_login AS tl
                          JOIN master_role AS mr ON mr.role_id = tl.fk_master_role_id  WHERE tl.username  = '123456' AND tl.password = '90be178a7593b9a476516c5cd8e359e8b6a9dff43e1a733e06aa96553264fffad72379821077f777b9db9f0d62f8964c960d875fa1f60bd3111cf110c41ec20e' 
ERROR - 2021-03-24 17:07:17 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 57
INFO - 2021-03-24 17:08:48 --> Config Class Initialized
INFO - 2021-03-24 17:08:48 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:08:48 --> Utf8 Class Initialized
INFO - 2021-03-24 17:08:48 --> URI Class Initialized
INFO - 2021-03-24 17:08:48 --> Router Class Initialized
INFO - 2021-03-24 17:08:48 --> Output Class Initialized
INFO - 2021-03-24 17:08:48 --> Security Class Initialized
DEBUG - 2021-03-24 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:08:48 --> Input Class Initialized
INFO - 2021-03-24 17:08:48 --> Language Class Initialized
INFO - 2021-03-24 17:08:48 --> Loader Class Initialized
INFO - 2021-03-24 17:08:48 --> Helper loaded: url_helper
INFO - 2021-03-24 17:08:48 --> Helper loaded: file_helper
INFO - 2021-03-24 17:08:48 --> Helper loaded: form_helper
INFO - 2021-03-24 17:08:48 --> Helper loaded: text_helper
INFO - 2021-03-24 17:08:48 --> Helper loaded: security_helper
INFO - 2021-03-24 17:08:48 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:08:48 --> Database Driver Class Initialized
INFO - 2021-03-24 17:08:48 --> Email Class Initialized
DEBUG - 2021-03-24 17:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:08:48 --> Form Validation Class Initialized
INFO - 2021-03-24 17:08:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:08:48 --> Pagination Class Initialized
INFO - 2021-03-24 17:08:48 --> Model Class Initialized
INFO - 2021-03-24 17:08:48 --> Controller Class Initialized
INFO - 2021-03-24 17:08:48 --> Model Class Initialized
INFO - 2021-03-24 17:08:48 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:08:48 --> Query error: Table 'chips_rda.master_role' doesn't exist - Invalid query: SELECT tl.login_id, tl.username,tl.fk_master_role_id,mr.role_id,mr.role_name,mr.role_type,mr.is_admin
                          FROM tbl_login AS tl
                          JOIN master_role AS mr ON mr.role_id = tl.fk_master_role_id  WHERE tl.username  = '123456' AND tl.password = '90be178a7593b9a476516c5cd8e359e8b6a9dff43e1a733e06aa96553264fffad72379821077f777b9db9f0d62f8964c960d875fa1f60bd3111cf110c41ec20e' 
ERROR - 2021-03-24 17:08:48 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 57
INFO - 2021-03-24 17:09:05 --> Config Class Initialized
INFO - 2021-03-24 17:09:05 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:09:05 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:09:05 --> Utf8 Class Initialized
INFO - 2021-03-24 17:09:05 --> URI Class Initialized
INFO - 2021-03-24 17:09:05 --> Router Class Initialized
INFO - 2021-03-24 17:09:05 --> Output Class Initialized
INFO - 2021-03-24 17:09:05 --> Security Class Initialized
DEBUG - 2021-03-24 17:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:09:05 --> Input Class Initialized
INFO - 2021-03-24 17:09:05 --> Language Class Initialized
INFO - 2021-03-24 17:09:05 --> Loader Class Initialized
INFO - 2021-03-24 17:09:05 --> Helper loaded: url_helper
INFO - 2021-03-24 17:09:05 --> Helper loaded: file_helper
INFO - 2021-03-24 17:09:05 --> Helper loaded: form_helper
INFO - 2021-03-24 17:09:05 --> Helper loaded: text_helper
INFO - 2021-03-24 17:09:05 --> Helper loaded: security_helper
INFO - 2021-03-24 17:09:05 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:09:05 --> Database Driver Class Initialized
INFO - 2021-03-24 17:09:05 --> Email Class Initialized
DEBUG - 2021-03-24 17:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:09:05 --> Form Validation Class Initialized
INFO - 2021-03-24 17:09:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:09:05 --> Pagination Class Initialized
INFO - 2021-03-24 17:09:05 --> Model Class Initialized
INFO - 2021-03-24 17:09:05 --> Controller Class Initialized
INFO - 2021-03-24 17:09:05 --> Model Class Initialized
INFO - 2021-03-24 17:09:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 17:09:24 --> Config Class Initialized
INFO - 2021-03-24 17:09:24 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:09:24 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:09:24 --> Utf8 Class Initialized
INFO - 2021-03-24 17:09:24 --> URI Class Initialized
INFO - 2021-03-24 17:09:24 --> Router Class Initialized
INFO - 2021-03-24 17:09:24 --> Output Class Initialized
INFO - 2021-03-24 17:09:24 --> Security Class Initialized
DEBUG - 2021-03-24 17:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:09:24 --> Input Class Initialized
INFO - 2021-03-24 17:09:24 --> Language Class Initialized
INFO - 2021-03-24 17:09:24 --> Loader Class Initialized
INFO - 2021-03-24 17:09:24 --> Helper loaded: url_helper
INFO - 2021-03-24 17:09:24 --> Helper loaded: file_helper
INFO - 2021-03-24 17:09:24 --> Helper loaded: form_helper
INFO - 2021-03-24 17:09:24 --> Helper loaded: text_helper
INFO - 2021-03-24 17:09:24 --> Helper loaded: security_helper
INFO - 2021-03-24 17:09:24 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:09:24 --> Database Driver Class Initialized
INFO - 2021-03-24 17:09:24 --> Email Class Initialized
DEBUG - 2021-03-24 17:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:09:24 --> Form Validation Class Initialized
INFO - 2021-03-24 17:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:09:24 --> Pagination Class Initialized
INFO - 2021-03-24 17:09:24 --> Model Class Initialized
INFO - 2021-03-24 17:09:24 --> Controller Class Initialized
INFO - 2021-03-24 17:09:24 --> Model Class Initialized
INFO - 2021-03-24 17:09:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 17:09:29 --> Config Class Initialized
INFO - 2021-03-24 17:09:29 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:09:29 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:09:29 --> Utf8 Class Initialized
INFO - 2021-03-24 17:09:29 --> URI Class Initialized
INFO - 2021-03-24 17:09:29 --> Router Class Initialized
INFO - 2021-03-24 17:09:29 --> Output Class Initialized
INFO - 2021-03-24 17:09:29 --> Security Class Initialized
DEBUG - 2021-03-24 17:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:09:30 --> Input Class Initialized
INFO - 2021-03-24 17:09:30 --> Language Class Initialized
INFO - 2021-03-24 17:09:30 --> Loader Class Initialized
INFO - 2021-03-24 17:09:30 --> Helper loaded: url_helper
INFO - 2021-03-24 17:09:30 --> Helper loaded: file_helper
INFO - 2021-03-24 17:09:30 --> Helper loaded: form_helper
INFO - 2021-03-24 17:09:30 --> Helper loaded: text_helper
INFO - 2021-03-24 17:09:30 --> Helper loaded: security_helper
INFO - 2021-03-24 17:09:30 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:09:30 --> Database Driver Class Initialized
INFO - 2021-03-24 17:09:30 --> Email Class Initialized
DEBUG - 2021-03-24 17:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:09:30 --> Form Validation Class Initialized
INFO - 2021-03-24 17:09:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:09:30 --> Pagination Class Initialized
INFO - 2021-03-24 17:09:30 --> Model Class Initialized
INFO - 2021-03-24 17:09:30 --> Controller Class Initialized
INFO - 2021-03-24 17:09:30 --> Model Class Initialized
INFO - 2021-03-24 17:09:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:09:30 --> Query error: Table 'chips_rda.master_role' doesn't exist - Invalid query: SELECT tl.login_id, tl.username,tl.fk_master_role_id,mr.role_id,mr.role_name,mr.role_type,mr.is_admin
                          FROM tbl_login AS tl
                          JOIN master_role AS mr ON mr.role_id = tl.fk_master_role_id  WHERE tl.username  = '123456' AND tl.password = '90be178a7593b9a476516c5cd8e359e8b6a9dff43e1a733e06aa96553264fffad72379821077f777b9db9f0d62f8964c960d875fa1f60bd3111cf110c41ec20e' 
ERROR - 2021-03-24 17:09:30 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 57
INFO - 2021-03-24 17:09:40 --> Config Class Initialized
INFO - 2021-03-24 17:09:40 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:09:40 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:09:40 --> Utf8 Class Initialized
INFO - 2021-03-24 17:09:40 --> URI Class Initialized
INFO - 2021-03-24 17:09:40 --> Router Class Initialized
INFO - 2021-03-24 17:09:40 --> Output Class Initialized
INFO - 2021-03-24 17:09:40 --> Security Class Initialized
DEBUG - 2021-03-24 17:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:09:40 --> Input Class Initialized
INFO - 2021-03-24 17:09:40 --> Language Class Initialized
INFO - 2021-03-24 17:09:40 --> Loader Class Initialized
INFO - 2021-03-24 17:09:40 --> Helper loaded: url_helper
INFO - 2021-03-24 17:09:40 --> Helper loaded: file_helper
INFO - 2021-03-24 17:09:40 --> Helper loaded: form_helper
INFO - 2021-03-24 17:09:40 --> Helper loaded: text_helper
INFO - 2021-03-24 17:09:40 --> Helper loaded: security_helper
INFO - 2021-03-24 17:09:40 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:09:40 --> Database Driver Class Initialized
INFO - 2021-03-24 17:09:40 --> Email Class Initialized
DEBUG - 2021-03-24 17:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:09:40 --> Form Validation Class Initialized
INFO - 2021-03-24 17:09:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:09:40 --> Pagination Class Initialized
INFO - 2021-03-24 17:09:40 --> Model Class Initialized
INFO - 2021-03-24 17:09:40 --> Controller Class Initialized
INFO - 2021-03-24 17:09:40 --> Model Class Initialized
INFO - 2021-03-24 17:09:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:09:40 --> Query error: Table 'chips_rda.master_role' doesn't exist - Invalid query: SELECT tl.login_id, tl.username,tl.fk_master_role_id,mr.role_id,mr.role_name,mr.role_type,mr.is_admin
                          FROM tbl_login AS tl
                          JOIN master_role AS mr ON mr.role_id = tl.fk_master_role_id  WHERE tl.username  = '123456' AND tl.password = '90be178a7593b9a476516c5cd8e359e8b6a9dff43e1a733e06aa96553264fffad72379821077f777b9db9f0d62f8964c960d875fa1f60bd3111cf110c41ec20e' 
INFO - 2021-03-24 17:10:16 --> Config Class Initialized
INFO - 2021-03-24 17:10:16 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:10:16 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:10:16 --> Utf8 Class Initialized
INFO - 2021-03-24 17:10:16 --> URI Class Initialized
INFO - 2021-03-24 17:10:16 --> Router Class Initialized
INFO - 2021-03-24 17:10:16 --> Output Class Initialized
INFO - 2021-03-24 17:10:16 --> Security Class Initialized
DEBUG - 2021-03-24 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:10:16 --> Input Class Initialized
INFO - 2021-03-24 17:10:16 --> Language Class Initialized
INFO - 2021-03-24 17:10:16 --> Loader Class Initialized
INFO - 2021-03-24 17:10:16 --> Helper loaded: url_helper
INFO - 2021-03-24 17:10:16 --> Helper loaded: file_helper
INFO - 2021-03-24 17:10:16 --> Helper loaded: form_helper
INFO - 2021-03-24 17:10:16 --> Helper loaded: text_helper
INFO - 2021-03-24 17:10:16 --> Helper loaded: security_helper
INFO - 2021-03-24 17:10:16 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:10:16 --> Database Driver Class Initialized
INFO - 2021-03-24 17:10:16 --> Email Class Initialized
DEBUG - 2021-03-24 17:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:10:16 --> Form Validation Class Initialized
INFO - 2021-03-24 17:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:10:16 --> Pagination Class Initialized
INFO - 2021-03-24 17:10:16 --> Model Class Initialized
INFO - 2021-03-24 17:10:16 --> Controller Class Initialized
INFO - 2021-03-24 17:10:16 --> Model Class Initialized
INFO - 2021-03-24 17:10:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 17:12:57 --> Config Class Initialized
INFO - 2021-03-24 17:12:57 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:12:57 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:12:57 --> Utf8 Class Initialized
INFO - 2021-03-24 17:12:57 --> URI Class Initialized
INFO - 2021-03-24 17:12:57 --> Router Class Initialized
INFO - 2021-03-24 17:12:57 --> Output Class Initialized
INFO - 2021-03-24 17:12:57 --> Security Class Initialized
DEBUG - 2021-03-24 17:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:12:57 --> Input Class Initialized
INFO - 2021-03-24 17:12:57 --> Language Class Initialized
INFO - 2021-03-24 17:12:57 --> Loader Class Initialized
INFO - 2021-03-24 17:12:57 --> Helper loaded: url_helper
INFO - 2021-03-24 17:12:57 --> Helper loaded: file_helper
INFO - 2021-03-24 17:12:57 --> Helper loaded: form_helper
INFO - 2021-03-24 17:12:57 --> Helper loaded: text_helper
INFO - 2021-03-24 17:12:57 --> Helper loaded: security_helper
INFO - 2021-03-24 17:12:57 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:12:57 --> Database Driver Class Initialized
INFO - 2021-03-24 17:12:57 --> Email Class Initialized
DEBUG - 2021-03-24 17:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:12:57 --> Form Validation Class Initialized
INFO - 2021-03-24 17:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:12:57 --> Pagination Class Initialized
INFO - 2021-03-24 17:12:57 --> Model Class Initialized
INFO - 2021-03-24 17:12:57 --> Controller Class Initialized
INFO - 2021-03-24 17:12:57 --> Model Class Initialized
INFO - 2021-03-24 17:12:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 17:14:04 --> Config Class Initialized
INFO - 2021-03-24 17:14:04 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:14:04 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:14:04 --> Utf8 Class Initialized
INFO - 2021-03-24 17:14:04 --> URI Class Initialized
INFO - 2021-03-24 17:14:04 --> Router Class Initialized
INFO - 2021-03-24 17:14:04 --> Output Class Initialized
INFO - 2021-03-24 17:14:04 --> Security Class Initialized
DEBUG - 2021-03-24 17:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:14:04 --> Input Class Initialized
INFO - 2021-03-24 17:14:04 --> Language Class Initialized
INFO - 2021-03-24 17:14:04 --> Loader Class Initialized
INFO - 2021-03-24 17:14:04 --> Helper loaded: url_helper
INFO - 2021-03-24 17:14:04 --> Helper loaded: file_helper
INFO - 2021-03-24 17:14:04 --> Helper loaded: form_helper
INFO - 2021-03-24 17:14:04 --> Helper loaded: text_helper
INFO - 2021-03-24 17:14:04 --> Helper loaded: security_helper
INFO - 2021-03-24 17:14:04 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:14:04 --> Database Driver Class Initialized
INFO - 2021-03-24 17:14:04 --> Email Class Initialized
DEBUG - 2021-03-24 17:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:14:05 --> Form Validation Class Initialized
INFO - 2021-03-24 17:14:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:14:05 --> Pagination Class Initialized
INFO - 2021-03-24 17:14:05 --> Model Class Initialized
INFO - 2021-03-24 17:14:05 --> Controller Class Initialized
INFO - 2021-03-24 17:14:05 --> Model Class Initialized
INFO - 2021-03-24 17:14:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 17:14:18 --> Config Class Initialized
INFO - 2021-03-24 17:14:18 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:14:18 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:14:18 --> Utf8 Class Initialized
INFO - 2021-03-24 17:14:18 --> URI Class Initialized
INFO - 2021-03-24 17:14:18 --> Router Class Initialized
INFO - 2021-03-24 17:14:18 --> Output Class Initialized
INFO - 2021-03-24 17:14:18 --> Security Class Initialized
DEBUG - 2021-03-24 17:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:14:18 --> Input Class Initialized
INFO - 2021-03-24 17:14:18 --> Language Class Initialized
INFO - 2021-03-24 17:14:18 --> Loader Class Initialized
INFO - 2021-03-24 17:14:18 --> Helper loaded: url_helper
INFO - 2021-03-24 17:14:18 --> Helper loaded: file_helper
INFO - 2021-03-24 17:14:18 --> Helper loaded: form_helper
INFO - 2021-03-24 17:14:18 --> Helper loaded: text_helper
INFO - 2021-03-24 17:14:18 --> Helper loaded: security_helper
INFO - 2021-03-24 17:14:18 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:14:18 --> Database Driver Class Initialized
INFO - 2021-03-24 17:14:18 --> Email Class Initialized
DEBUG - 2021-03-24 17:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:14:18 --> Form Validation Class Initialized
INFO - 2021-03-24 17:14:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:14:18 --> Pagination Class Initialized
INFO - 2021-03-24 17:14:18 --> Model Class Initialized
INFO - 2021-03-24 17:14:18 --> Controller Class Initialized
INFO - 2021-03-24 17:14:18 --> Model Class Initialized
INFO - 2021-03-24 17:14:18 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:14:18 --> Severity: Notice --> Undefined index: is_active C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 62
INFO - 2021-03-24 17:39:40 --> Config Class Initialized
INFO - 2021-03-24 17:39:40 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:39:40 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:39:40 --> Utf8 Class Initialized
INFO - 2021-03-24 17:39:40 --> URI Class Initialized
INFO - 2021-03-24 17:39:40 --> Router Class Initialized
INFO - 2021-03-24 17:39:40 --> Output Class Initialized
INFO - 2021-03-24 17:39:40 --> Security Class Initialized
DEBUG - 2021-03-24 17:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:39:40 --> Input Class Initialized
INFO - 2021-03-24 17:39:40 --> Language Class Initialized
INFO - 2021-03-24 17:39:40 --> Loader Class Initialized
INFO - 2021-03-24 17:39:40 --> Helper loaded: url_helper
INFO - 2021-03-24 17:39:40 --> Helper loaded: file_helper
INFO - 2021-03-24 17:39:40 --> Helper loaded: form_helper
INFO - 2021-03-24 17:39:40 --> Helper loaded: text_helper
INFO - 2021-03-24 17:39:40 --> Helper loaded: security_helper
INFO - 2021-03-24 17:39:40 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:39:40 --> Database Driver Class Initialized
INFO - 2021-03-24 17:39:40 --> Email Class Initialized
DEBUG - 2021-03-24 17:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:39:40 --> Form Validation Class Initialized
INFO - 2021-03-24 17:39:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:39:40 --> Pagination Class Initialized
INFO - 2021-03-24 17:39:40 --> Model Class Initialized
INFO - 2021-03-24 17:39:40 --> Controller Class Initialized
INFO - 2021-03-24 17:39:40 --> Model Class Initialized
INFO - 2021-03-24 17:39:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:39:40 --> Query error: Table 'chips_rda.tbl_login' doesn't exist - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = '123456'
ERROR - 2021-03-24 17:39:40 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 44
INFO - 2021-03-24 17:39:44 --> Config Class Initialized
INFO - 2021-03-24 17:39:44 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:39:44 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:39:44 --> Utf8 Class Initialized
INFO - 2021-03-24 17:39:44 --> URI Class Initialized
INFO - 2021-03-24 17:39:44 --> Router Class Initialized
INFO - 2021-03-24 17:39:44 --> Output Class Initialized
INFO - 2021-03-24 17:39:44 --> Security Class Initialized
DEBUG - 2021-03-24 17:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:39:44 --> Input Class Initialized
INFO - 2021-03-24 17:39:44 --> Language Class Initialized
INFO - 2021-03-24 17:39:44 --> Loader Class Initialized
INFO - 2021-03-24 17:39:45 --> Helper loaded: url_helper
INFO - 2021-03-24 17:39:45 --> Helper loaded: file_helper
INFO - 2021-03-24 17:39:45 --> Helper loaded: form_helper
INFO - 2021-03-24 17:39:45 --> Helper loaded: text_helper
INFO - 2021-03-24 17:39:45 --> Helper loaded: security_helper
INFO - 2021-03-24 17:39:45 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:39:45 --> Database Driver Class Initialized
INFO - 2021-03-24 17:39:45 --> Email Class Initialized
DEBUG - 2021-03-24 17:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:39:45 --> Form Validation Class Initialized
INFO - 2021-03-24 17:39:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:39:45 --> Pagination Class Initialized
INFO - 2021-03-24 17:39:45 --> Model Class Initialized
INFO - 2021-03-24 17:39:45 --> Controller Class Initialized
INFO - 2021-03-24 17:39:45 --> Model Class Initialized
INFO - 2021-03-24 17:39:45 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-24 17:39:45 --> Final output sent to browser
DEBUG - 2021-03-24 17:39:45 --> Total execution time: 0.3073
INFO - 2021-03-24 17:39:51 --> Config Class Initialized
INFO - 2021-03-24 17:39:51 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:39:51 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:39:51 --> Utf8 Class Initialized
INFO - 2021-03-24 17:39:51 --> URI Class Initialized
INFO - 2021-03-24 17:39:51 --> Router Class Initialized
INFO - 2021-03-24 17:39:51 --> Output Class Initialized
INFO - 2021-03-24 17:39:51 --> Security Class Initialized
DEBUG - 2021-03-24 17:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:39:51 --> Input Class Initialized
INFO - 2021-03-24 17:39:51 --> Language Class Initialized
INFO - 2021-03-24 17:39:51 --> Loader Class Initialized
INFO - 2021-03-24 17:39:51 --> Helper loaded: url_helper
INFO - 2021-03-24 17:39:51 --> Helper loaded: file_helper
INFO - 2021-03-24 17:39:51 --> Helper loaded: form_helper
INFO - 2021-03-24 17:39:51 --> Helper loaded: text_helper
INFO - 2021-03-24 17:39:51 --> Helper loaded: security_helper
INFO - 2021-03-24 17:39:51 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:39:51 --> Database Driver Class Initialized
INFO - 2021-03-24 17:39:51 --> Email Class Initialized
DEBUG - 2021-03-24 17:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:39:51 --> Form Validation Class Initialized
INFO - 2021-03-24 17:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:39:52 --> Pagination Class Initialized
INFO - 2021-03-24 17:39:52 --> Model Class Initialized
INFO - 2021-03-24 17:39:52 --> Controller Class Initialized
INFO - 2021-03-24 17:39:52 --> Model Class Initialized
INFO - 2021-03-24 17:39:52 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:39:52 --> Query error: Table 'chips_rda.tbl_login' doesn't exist - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = '123456'
ERROR - 2021-03-24 17:39:52 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 44
INFO - 2021-03-24 17:40:18 --> Config Class Initialized
INFO - 2021-03-24 17:40:18 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:40:18 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:40:18 --> Utf8 Class Initialized
INFO - 2021-03-24 17:40:18 --> URI Class Initialized
INFO - 2021-03-24 17:40:18 --> Router Class Initialized
INFO - 2021-03-24 17:40:18 --> Output Class Initialized
INFO - 2021-03-24 17:40:18 --> Security Class Initialized
DEBUG - 2021-03-24 17:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:40:18 --> Input Class Initialized
INFO - 2021-03-24 17:40:18 --> Language Class Initialized
INFO - 2021-03-24 17:40:18 --> Loader Class Initialized
INFO - 2021-03-24 17:40:18 --> Helper loaded: url_helper
INFO - 2021-03-24 17:40:18 --> Helper loaded: file_helper
INFO - 2021-03-24 17:40:18 --> Helper loaded: form_helper
INFO - 2021-03-24 17:40:18 --> Helper loaded: text_helper
INFO - 2021-03-24 17:40:18 --> Helper loaded: security_helper
INFO - 2021-03-24 17:40:18 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:40:18 --> Database Driver Class Initialized
INFO - 2021-03-24 17:40:18 --> Email Class Initialized
DEBUG - 2021-03-24 17:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:40:18 --> Form Validation Class Initialized
INFO - 2021-03-24 17:40:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:40:18 --> Pagination Class Initialized
INFO - 2021-03-24 17:40:18 --> Model Class Initialized
INFO - 2021-03-24 17:40:18 --> Controller Class Initialized
INFO - 2021-03-24 17:40:18 --> Model Class Initialized
INFO - 2021-03-24 17:40:18 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:40:18 --> Query error: Table 'chips_rda.tbl_login' doesn't exist - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = '123456'
ERROR - 2021-03-24 17:40:18 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 44
INFO - 2021-03-24 17:40:33 --> Config Class Initialized
INFO - 2021-03-24 17:40:33 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:40:33 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:40:33 --> Utf8 Class Initialized
INFO - 2021-03-24 17:40:33 --> URI Class Initialized
INFO - 2021-03-24 17:40:33 --> Router Class Initialized
INFO - 2021-03-24 17:40:33 --> Output Class Initialized
INFO - 2021-03-24 17:40:33 --> Security Class Initialized
DEBUG - 2021-03-24 17:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:40:33 --> Input Class Initialized
INFO - 2021-03-24 17:40:33 --> Language Class Initialized
INFO - 2021-03-24 17:40:33 --> Loader Class Initialized
INFO - 2021-03-24 17:40:33 --> Helper loaded: url_helper
INFO - 2021-03-24 17:40:33 --> Helper loaded: file_helper
INFO - 2021-03-24 17:40:33 --> Helper loaded: form_helper
INFO - 2021-03-24 17:40:33 --> Helper loaded: text_helper
INFO - 2021-03-24 17:40:33 --> Helper loaded: security_helper
INFO - 2021-03-24 17:40:33 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:40:33 --> Database Driver Class Initialized
INFO - 2021-03-24 17:40:33 --> Email Class Initialized
DEBUG - 2021-03-24 17:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:40:33 --> Form Validation Class Initialized
INFO - 2021-03-24 17:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:40:33 --> Pagination Class Initialized
INFO - 2021-03-24 17:40:33 --> Model Class Initialized
INFO - 2021-03-24 17:40:33 --> Controller Class Initialized
INFO - 2021-03-24 17:40:33 --> Model Class Initialized
INFO - 2021-03-24 17:40:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:40:33 --> Query error: Table 'chips_rda.tbl_login' doesn't exist - Invalid query: SELECT tl.salt FROM tbl_login AS tl
        WHERE tl.username = '123456'
INFO - 2021-03-24 17:41:08 --> Config Class Initialized
INFO - 2021-03-24 17:41:08 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:41:08 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:41:08 --> Utf8 Class Initialized
INFO - 2021-03-24 17:41:08 --> URI Class Initialized
INFO - 2021-03-24 17:41:08 --> Router Class Initialized
INFO - 2021-03-24 17:41:08 --> Output Class Initialized
INFO - 2021-03-24 17:41:08 --> Security Class Initialized
DEBUG - 2021-03-24 17:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:41:08 --> Input Class Initialized
INFO - 2021-03-24 17:41:08 --> Language Class Initialized
INFO - 2021-03-24 17:41:09 --> Loader Class Initialized
INFO - 2021-03-24 17:41:09 --> Helper loaded: url_helper
INFO - 2021-03-24 17:41:09 --> Helper loaded: file_helper
INFO - 2021-03-24 17:41:09 --> Helper loaded: form_helper
INFO - 2021-03-24 17:41:09 --> Helper loaded: text_helper
INFO - 2021-03-24 17:41:09 --> Helper loaded: security_helper
INFO - 2021-03-24 17:41:09 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:41:09 --> Database Driver Class Initialized
INFO - 2021-03-24 17:41:09 --> Email Class Initialized
DEBUG - 2021-03-24 17:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:41:09 --> Form Validation Class Initialized
INFO - 2021-03-24 17:41:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:41:09 --> Pagination Class Initialized
INFO - 2021-03-24 17:41:09 --> Model Class Initialized
INFO - 2021-03-24 17:41:09 --> Controller Class Initialized
INFO - 2021-03-24 17:41:09 --> Model Class Initialized
INFO - 2021-03-24 17:41:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 17:41:57 --> Config Class Initialized
INFO - 2021-03-24 17:41:57 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:41:57 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:41:57 --> Utf8 Class Initialized
INFO - 2021-03-24 17:41:57 --> URI Class Initialized
INFO - 2021-03-24 17:41:57 --> Router Class Initialized
INFO - 2021-03-24 17:41:57 --> Output Class Initialized
INFO - 2021-03-24 17:41:57 --> Security Class Initialized
DEBUG - 2021-03-24 17:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:41:57 --> Input Class Initialized
INFO - 2021-03-24 17:41:57 --> Language Class Initialized
INFO - 2021-03-24 17:41:57 --> Loader Class Initialized
INFO - 2021-03-24 17:41:57 --> Helper loaded: url_helper
INFO - 2021-03-24 17:41:57 --> Helper loaded: file_helper
INFO - 2021-03-24 17:41:57 --> Helper loaded: form_helper
INFO - 2021-03-24 17:41:57 --> Helper loaded: text_helper
INFO - 2021-03-24 17:41:57 --> Helper loaded: security_helper
INFO - 2021-03-24 17:41:57 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:41:57 --> Database Driver Class Initialized
INFO - 2021-03-24 17:41:57 --> Email Class Initialized
DEBUG - 2021-03-24 17:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:41:57 --> Form Validation Class Initialized
INFO - 2021-03-24 17:41:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:41:57 --> Pagination Class Initialized
INFO - 2021-03-24 17:41:57 --> Model Class Initialized
INFO - 2021-03-24 17:41:58 --> Controller Class Initialized
INFO - 2021-03-24 17:41:58 --> Model Class Initialized
INFO - 2021-03-24 17:41:58 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:41:58 --> Query error: Unknown column 'uw.is_deleted' in 'where clause' - Invalid query: SELECT tl.login_id, tl.username,tl.fk_master_role_id,tl.is_active,mr.role_id,mr.role_name,mr.role_type,mr.is_admin
                          FROM tbl_admin_login AS tl
                          JOIN master_roles AS mr ON mr.role_id = tl.fk_master_role_id  WHERE tl.username  = '123456' AND tl.password = '90be178a7593b9a476516c5cd8e359e8b6a9dff43e1a733e06aa96553264fffad72379821077f777b9db9f0d62f8964c960d875fa1f60bd3111cf110c41ec20e' AND uw.is_deleted = '0'
ERROR - 2021-03-24 17:41:58 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp64\www\RDA_Web\adminpoint\application\models\AdminLoginModel.php 58
INFO - 2021-03-24 17:42:38 --> Config Class Initialized
INFO - 2021-03-24 17:42:38 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:42:38 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:42:38 --> Utf8 Class Initialized
INFO - 2021-03-24 17:42:38 --> URI Class Initialized
INFO - 2021-03-24 17:42:38 --> Router Class Initialized
INFO - 2021-03-24 17:42:38 --> Output Class Initialized
INFO - 2021-03-24 17:42:38 --> Security Class Initialized
DEBUG - 2021-03-24 17:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:42:38 --> Input Class Initialized
INFO - 2021-03-24 17:42:38 --> Language Class Initialized
INFO - 2021-03-24 17:42:38 --> Loader Class Initialized
INFO - 2021-03-24 17:42:38 --> Helper loaded: url_helper
INFO - 2021-03-24 17:42:38 --> Helper loaded: file_helper
INFO - 2021-03-24 17:42:38 --> Helper loaded: form_helper
INFO - 2021-03-24 17:42:38 --> Helper loaded: text_helper
INFO - 2021-03-24 17:42:38 --> Helper loaded: security_helper
INFO - 2021-03-24 17:42:38 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:42:38 --> Database Driver Class Initialized
INFO - 2021-03-24 17:42:38 --> Email Class Initialized
DEBUG - 2021-03-24 17:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:42:38 --> Form Validation Class Initialized
INFO - 2021-03-24 17:42:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:42:38 --> Pagination Class Initialized
INFO - 2021-03-24 17:42:38 --> Model Class Initialized
INFO - 2021-03-24 17:42:38 --> Controller Class Initialized
INFO - 2021-03-24 17:42:38 --> Model Class Initialized
INFO - 2021-03-24 17:42:38 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-24 17:42:38 --> Query error: Unknown column 'uw.is_deleted' in 'where clause' - Invalid query: SELECT tl.login_id, tl.username,tl.fk_master_role_id,tl.is_active,mr.role_id,mr.role_name,mr.role_type,mr.is_admin
                          FROM tbl_admin_login AS tl
                          JOIN master_roles AS mr ON mr.role_id = tl.fk_master_role_id  WHERE tl.username  = '123456' AND tl.password = '90be178a7593b9a476516c5cd8e359e8b6a9dff43e1a733e06aa96553264fffad72379821077f777b9db9f0d62f8964c960d875fa1f60bd3111cf110c41ec20e' AND uw.is_deleted = '0'
INFO - 2021-03-24 17:43:17 --> Config Class Initialized
INFO - 2021-03-24 17:43:17 --> Hooks Class Initialized
DEBUG - 2021-03-24 17:43:17 --> UTF-8 Support Enabled
INFO - 2021-03-24 17:43:17 --> Utf8 Class Initialized
INFO - 2021-03-24 17:43:17 --> URI Class Initialized
INFO - 2021-03-24 17:43:17 --> Router Class Initialized
INFO - 2021-03-24 17:43:17 --> Output Class Initialized
INFO - 2021-03-24 17:43:17 --> Security Class Initialized
DEBUG - 2021-03-24 17:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 17:43:17 --> Input Class Initialized
INFO - 2021-03-24 17:43:17 --> Language Class Initialized
INFO - 2021-03-24 17:43:17 --> Loader Class Initialized
INFO - 2021-03-24 17:43:17 --> Helper loaded: url_helper
INFO - 2021-03-24 17:43:17 --> Helper loaded: file_helper
INFO - 2021-03-24 17:43:17 --> Helper loaded: form_helper
INFO - 2021-03-24 17:43:17 --> Helper loaded: text_helper
INFO - 2021-03-24 17:43:17 --> Helper loaded: security_helper
INFO - 2021-03-24 17:43:17 --> Helper loaded: ipaddress_helper
INFO - 2021-03-24 17:43:17 --> Database Driver Class Initialized
INFO - 2021-03-24 17:43:17 --> Email Class Initialized
DEBUG - 2021-03-24 17:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 17:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 17:43:17 --> Form Validation Class Initialized
INFO - 2021-03-24 17:43:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-24 17:43:17 --> Pagination Class Initialized
INFO - 2021-03-24 17:43:17 --> Model Class Initialized
INFO - 2021-03-24 17:43:17 --> Controller Class Initialized
INFO - 2021-03-24 17:43:17 --> Model Class Initialized
INFO - 2021-03-24 17:43:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 17:43:17 --> Final output sent to browser
DEBUG - 2021-03-24 17:43:17 --> Total execution time: 0.3246
