<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-03-20 21:39:12 --> Config Class Initialized
INFO - 2021-03-20 21:39:12 --> Hooks Class Initialized
DEBUG - 2021-03-20 21:39:13 --> UTF-8 Support Enabled
INFO - 2021-03-20 21:39:13 --> Utf8 Class Initialized
INFO - 2021-03-20 21:39:13 --> URI Class Initialized
INFO - 2021-03-20 21:39:13 --> Router Class Initialized
INFO - 2021-03-20 21:39:14 --> Output Class Initialized
INFO - 2021-03-20 21:39:14 --> Security Class Initialized
DEBUG - 2021-03-20 21:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-20 21:39:14 --> Input Class Initialized
INFO - 2021-03-20 21:39:14 --> Language Class Initialized
INFO - 2021-03-20 21:39:14 --> Loader Class Initialized
INFO - 2021-03-20 21:39:14 --> Helper loaded: url_helper
INFO - 2021-03-20 21:39:14 --> Helper loaded: file_helper
INFO - 2021-03-20 21:39:14 --> Helper loaded: form_helper
INFO - 2021-03-20 21:39:14 --> Helper loaded: text_helper
INFO - 2021-03-20 21:39:14 --> Helper loaded: security_helper
INFO - 2021-03-20 21:39:14 --> Helper loaded: ipaddress_helper
INFO - 2021-03-20 21:39:15 --> Database Driver Class Initialized
INFO - 2021-03-20 21:39:15 --> Email Class Initialized
DEBUG - 2021-03-20 21:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-20 21:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-20 21:39:15 --> Form Validation Class Initialized
INFO - 2021-03-20 21:39:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-20 21:39:15 --> Pagination Class Initialized
INFO - 2021-03-20 21:39:15 --> Model Class Initialized
INFO - 2021-03-20 21:39:15 --> Controller Class Initialized
INFO - 2021-03-20 21:39:15 --> Model Class Initialized
INFO - 2021-03-20 21:39:15 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-20 21:39:15 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-20 21:39:15 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-20 21:39:15 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-20 21:39:15 --> File loaded: E:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-20 21:39:15 --> Final output sent to browser
DEBUG - 2021-03-20 21:39:15 --> Total execution time: 3.1044
INFO - 2021-03-20 21:39:16 --> Config Class Initialized
INFO - 2021-03-20 21:39:16 --> Hooks Class Initialized
DEBUG - 2021-03-20 21:39:16 --> UTF-8 Support Enabled
INFO - 2021-03-20 21:39:16 --> Utf8 Class Initialized
INFO - 2021-03-20 21:39:16 --> URI Class Initialized
INFO - 2021-03-20 21:39:16 --> Router Class Initialized
INFO - 2021-03-20 21:39:16 --> Output Class Initialized
INFO - 2021-03-20 21:39:16 --> Security Class Initialized
DEBUG - 2021-03-20 21:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-20 21:39:16 --> Input Class Initialized
INFO - 2021-03-20 21:39:16 --> Language Class Initialized
ERROR - 2021-03-20 21:39:16 --> 404 Page Not Found: Js/demo
INFO - 2021-03-20 21:39:17 --> Config Class Initialized
INFO - 2021-03-20 21:39:17 --> Hooks Class Initialized
DEBUG - 2021-03-20 21:39:17 --> UTF-8 Support Enabled
INFO - 2021-03-20 21:39:17 --> Utf8 Class Initialized
INFO - 2021-03-20 21:39:17 --> URI Class Initialized
INFO - 2021-03-20 21:39:17 --> Router Class Initialized
INFO - 2021-03-20 21:39:17 --> Output Class Initialized
INFO - 2021-03-20 21:39:17 --> Security Class Initialized
DEBUG - 2021-03-20 21:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-20 21:39:17 --> Input Class Initialized
INFO - 2021-03-20 21:39:17 --> Language Class Initialized
ERROR - 2021-03-20 21:39:17 --> 404 Page Not Found: Skin-config2html/index
