<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-05-05 21:49:37 --> Config Class Initialized
INFO - 2021-05-05 21:49:37 --> Hooks Class Initialized
DEBUG - 2021-05-05 21:49:38 --> UTF-8 Support Enabled
INFO - 2021-05-05 21:49:38 --> Utf8 Class Initialized
INFO - 2021-05-05 21:49:38 --> URI Class Initialized
INFO - 2021-05-05 21:49:38 --> Router Class Initialized
INFO - 2021-05-05 21:49:38 --> Output Class Initialized
INFO - 2021-05-05 21:49:38 --> Security Class Initialized
DEBUG - 2021-05-05 21:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-05 21:49:38 --> Input Class Initialized
INFO - 2021-05-05 21:49:38 --> Language Class Initialized
INFO - 2021-05-05 21:49:38 --> Loader Class Initialized
INFO - 2021-05-05 21:49:38 --> Helper loaded: url_helper
INFO - 2021-05-05 21:49:39 --> Helper loaded: file_helper
INFO - 2021-05-05 21:49:39 --> Helper loaded: form_helper
INFO - 2021-05-05 21:49:39 --> Helper loaded: text_helper
INFO - 2021-05-05 21:49:39 --> Helper loaded: security_helper
INFO - 2021-05-05 21:49:39 --> Helper loaded: ipaddress_helper
INFO - 2021-05-05 21:49:39 --> Database Driver Class Initialized
INFO - 2021-05-05 21:49:39 --> Email Class Initialized
DEBUG - 2021-05-05 21:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-05-05 21:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-05-05 21:49:39 --> Form Validation Class Initialized
INFO - 2021-05-05 21:49:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-05-05 21:49:39 --> Pagination Class Initialized
INFO - 2021-05-05 21:49:39 --> Controller Class Initialized
INFO - 2021-05-05 21:49:39 --> Model Class Initialized
INFO - 2021-05-05 21:49:39 --> Model Class Initialized
INFO - 2021-05-05 21:49:39 --> File loaded: C:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-05-05 21:49:39 --> File loaded: C:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-05-05 21:49:40 --> File loaded: C:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-05-05 21:49:40 --> File loaded: C:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-05-05 21:49:40 --> File loaded: C:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-05-05 21:49:40 --> Final output sent to browser
DEBUG - 2021-05-05 21:49:40 --> Total execution time: 2.2423
INFO - 2021-05-05 21:49:40 --> Config Class Initialized
INFO - 2021-05-05 21:49:40 --> Hooks Class Initialized
DEBUG - 2021-05-05 21:49:40 --> UTF-8 Support Enabled
INFO - 2021-05-05 21:49:40 --> Utf8 Class Initialized
INFO - 2021-05-05 21:49:40 --> URI Class Initialized
INFO - 2021-05-05 21:49:40 --> Router Class Initialized
INFO - 2021-05-05 21:49:40 --> Output Class Initialized
INFO - 2021-05-05 21:49:40 --> Security Class Initialized
DEBUG - 2021-05-05 21:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-05 21:49:40 --> Input Class Initialized
INFO - 2021-05-05 21:49:40 --> Language Class Initialized
ERROR - 2021-05-05 21:49:40 --> 404 Page Not Found: Js/demo
INFO - 2021-05-05 21:49:41 --> Config Class Initialized
INFO - 2021-05-05 21:49:41 --> Hooks Class Initialized
DEBUG - 2021-05-05 21:49:41 --> UTF-8 Support Enabled
INFO - 2021-05-05 21:49:41 --> Utf8 Class Initialized
INFO - 2021-05-05 21:49:41 --> URI Class Initialized
INFO - 2021-05-05 21:49:41 --> Router Class Initialized
INFO - 2021-05-05 21:49:41 --> Output Class Initialized
INFO - 2021-05-05 21:49:41 --> Security Class Initialized
DEBUG - 2021-05-05 21:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-05-05 21:49:41 --> Input Class Initialized
INFO - 2021-05-05 21:49:41 --> Language Class Initialized
ERROR - 2021-05-05 21:49:41 --> 404 Page Not Found: Skin-config2html/index
