<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-03-25 11:13:54 --> Config Class Initialized
INFO - 2021-03-25 11:13:54 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:13:54 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:13:55 --> Utf8 Class Initialized
INFO - 2021-03-25 11:13:55 --> URI Class Initialized
INFO - 2021-03-25 11:13:55 --> Router Class Initialized
INFO - 2021-03-25 11:13:55 --> Output Class Initialized
INFO - 2021-03-25 11:13:55 --> Security Class Initialized
DEBUG - 2021-03-25 11:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:13:55 --> Input Class Initialized
INFO - 2021-03-25 11:13:55 --> Language Class Initialized
INFO - 2021-03-25 11:13:55 --> Loader Class Initialized
INFO - 2021-03-25 11:13:55 --> Helper loaded: url_helper
INFO - 2021-03-25 11:13:55 --> Helper loaded: file_helper
INFO - 2021-03-25 11:13:55 --> Helper loaded: form_helper
INFO - 2021-03-25 11:13:55 --> Helper loaded: text_helper
INFO - 2021-03-25 11:13:55 --> Helper loaded: security_helper
INFO - 2021-03-25 11:13:55 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:13:55 --> Database Driver Class Initialized
INFO - 2021-03-25 11:13:55 --> Email Class Initialized
DEBUG - 2021-03-25 11:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:13:55 --> Form Validation Class Initialized
INFO - 2021-03-25 11:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:13:55 --> Pagination Class Initialized
INFO - 2021-03-25 11:13:55 --> Model Class Initialized
INFO - 2021-03-25 11:13:55 --> Controller Class Initialized
INFO - 2021-03-25 11:13:55 --> Model Class Initialized
INFO - 2021-03-25 11:13:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-25 11:13:55 --> Severity: Notice --> Undefined index: login_id C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 35
ERROR - 2021-03-25 11:13:55 --> Severity: Notice --> Undefined index: username C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 35
ERROR - 2021-03-25 11:13:55 --> Severity: Notice --> Undefined index: role_id C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 36
ERROR - 2021-03-25 11:13:55 --> Severity: Notice --> Undefined index: role_name C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 36
ERROR - 2021-03-25 11:13:55 --> Severity: Notice --> Undefined index: role_type C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 37
ERROR - 2021-03-25 11:13:55 --> Severity: Notice --> Undefined index: is_admin C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 37
ERROR - 2021-03-25 11:13:55 --> Severity: Notice --> Undefined index: is_active C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 38
INFO - 2021-03-25 11:13:55 --> Final output sent to browser
DEBUG - 2021-03-25 11:13:55 --> Total execution time: 0.4538
INFO - 2021-03-25 11:14:29 --> Config Class Initialized
INFO - 2021-03-25 11:14:29 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:14:29 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:14:29 --> Utf8 Class Initialized
INFO - 2021-03-25 11:14:29 --> URI Class Initialized
INFO - 2021-03-25 11:14:29 --> Router Class Initialized
INFO - 2021-03-25 11:14:29 --> Output Class Initialized
INFO - 2021-03-25 11:14:29 --> Security Class Initialized
DEBUG - 2021-03-25 11:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:14:29 --> Input Class Initialized
INFO - 2021-03-25 11:14:29 --> Language Class Initialized
INFO - 2021-03-25 11:14:29 --> Loader Class Initialized
INFO - 2021-03-25 11:14:29 --> Helper loaded: url_helper
INFO - 2021-03-25 11:14:29 --> Helper loaded: file_helper
INFO - 2021-03-25 11:14:29 --> Helper loaded: form_helper
INFO - 2021-03-25 11:14:29 --> Helper loaded: text_helper
INFO - 2021-03-25 11:14:29 --> Helper loaded: security_helper
INFO - 2021-03-25 11:14:29 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:14:29 --> Database Driver Class Initialized
INFO - 2021-03-25 11:14:29 --> Email Class Initialized
DEBUG - 2021-03-25 11:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:14:29 --> Form Validation Class Initialized
INFO - 2021-03-25 11:14:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:14:29 --> Pagination Class Initialized
INFO - 2021-03-25 11:14:29 --> Model Class Initialized
INFO - 2021-03-25 11:14:29 --> Controller Class Initialized
INFO - 2021-03-25 11:14:29 --> Model Class Initialized
INFO - 2021-03-25 11:14:29 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-03-25 11:14:29 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 35
ERROR - 2021-03-25 11:14:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 35
ERROR - 2021-03-25 11:14:29 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 35
ERROR - 2021-03-25 11:14:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 35
ERROR - 2021-03-25 11:14:30 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 36
ERROR - 2021-03-25 11:14:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 36
ERROR - 2021-03-25 11:14:30 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 36
ERROR - 2021-03-25 11:14:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 36
ERROR - 2021-03-25 11:14:30 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 37
ERROR - 2021-03-25 11:14:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 37
ERROR - 2021-03-25 11:14:30 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 37
ERROR - 2021-03-25 11:14:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 37
ERROR - 2021-03-25 11:14:30 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 38
ERROR - 2021-03-25 11:14:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\wamp64\www\RDA_Web\adminpoint\application\controllers\AdminLoginController.php 38
INFO - 2021-03-25 11:14:30 --> Final output sent to browser
DEBUG - 2021-03-25 11:14:30 --> Total execution time: 0.5848
INFO - 2021-03-25 11:15:15 --> Config Class Initialized
INFO - 2021-03-25 11:15:15 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:15:15 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:15:15 --> Utf8 Class Initialized
INFO - 2021-03-25 11:15:15 --> URI Class Initialized
INFO - 2021-03-25 11:15:15 --> Router Class Initialized
INFO - 2021-03-25 11:15:15 --> Output Class Initialized
INFO - 2021-03-25 11:15:15 --> Security Class Initialized
DEBUG - 2021-03-25 11:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:15:15 --> Input Class Initialized
INFO - 2021-03-25 11:15:15 --> Language Class Initialized
INFO - 2021-03-25 11:15:15 --> Loader Class Initialized
INFO - 2021-03-25 11:15:15 --> Helper loaded: url_helper
INFO - 2021-03-25 11:15:15 --> Helper loaded: file_helper
INFO - 2021-03-25 11:15:15 --> Helper loaded: form_helper
INFO - 2021-03-25 11:15:15 --> Helper loaded: text_helper
INFO - 2021-03-25 11:15:15 --> Helper loaded: security_helper
INFO - 2021-03-25 11:15:15 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:15:15 --> Database Driver Class Initialized
INFO - 2021-03-25 11:15:15 --> Email Class Initialized
DEBUG - 2021-03-25 11:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:15:15 --> Form Validation Class Initialized
INFO - 2021-03-25 11:15:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:15:15 --> Pagination Class Initialized
INFO - 2021-03-25 11:15:16 --> Model Class Initialized
INFO - 2021-03-25 11:15:16 --> Controller Class Initialized
INFO - 2021-03-25 11:15:16 --> Model Class Initialized
INFO - 2021-03-25 11:15:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-25 11:15:16 --> Final output sent to browser
DEBUG - 2021-03-25 11:15:16 --> Total execution time: 0.4202
INFO - 2021-03-25 11:15:24 --> Config Class Initialized
INFO - 2021-03-25 11:15:24 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:15:24 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:15:24 --> Utf8 Class Initialized
INFO - 2021-03-25 11:15:24 --> URI Class Initialized
INFO - 2021-03-25 11:15:24 --> Router Class Initialized
INFO - 2021-03-25 11:15:24 --> Output Class Initialized
INFO - 2021-03-25 11:15:24 --> Security Class Initialized
DEBUG - 2021-03-25 11:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:15:24 --> Input Class Initialized
INFO - 2021-03-25 11:15:24 --> Language Class Initialized
INFO - 2021-03-25 11:15:24 --> Loader Class Initialized
INFO - 2021-03-25 11:15:24 --> Helper loaded: url_helper
INFO - 2021-03-25 11:15:24 --> Helper loaded: file_helper
INFO - 2021-03-25 11:15:24 --> Helper loaded: form_helper
INFO - 2021-03-25 11:15:24 --> Helper loaded: text_helper
INFO - 2021-03-25 11:15:24 --> Helper loaded: security_helper
INFO - 2021-03-25 11:15:24 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:15:24 --> Database Driver Class Initialized
INFO - 2021-03-25 11:15:24 --> Email Class Initialized
DEBUG - 2021-03-25 11:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:15:24 --> Form Validation Class Initialized
INFO - 2021-03-25 11:15:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:15:24 --> Pagination Class Initialized
INFO - 2021-03-25 11:15:24 --> Model Class Initialized
INFO - 2021-03-25 11:15:24 --> Controller Class Initialized
INFO - 2021-03-25 11:15:24 --> Model Class Initialized
INFO - 2021-03-25 11:15:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-25 11:15:24 --> Final output sent to browser
DEBUG - 2021-03-25 11:15:24 --> Total execution time: 0.4192
INFO - 2021-03-25 11:16:33 --> Config Class Initialized
INFO - 2021-03-25 11:16:33 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:16:33 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:16:33 --> Utf8 Class Initialized
INFO - 2021-03-25 11:16:33 --> URI Class Initialized
INFO - 2021-03-25 11:16:33 --> Router Class Initialized
INFO - 2021-03-25 11:16:33 --> Output Class Initialized
INFO - 2021-03-25 11:16:33 --> Security Class Initialized
DEBUG - 2021-03-25 11:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:16:33 --> Input Class Initialized
INFO - 2021-03-25 11:16:33 --> Language Class Initialized
INFO - 2021-03-25 11:16:33 --> Loader Class Initialized
INFO - 2021-03-25 11:16:33 --> Helper loaded: url_helper
INFO - 2021-03-25 11:16:33 --> Helper loaded: file_helper
INFO - 2021-03-25 11:16:33 --> Helper loaded: form_helper
INFO - 2021-03-25 11:16:33 --> Helper loaded: text_helper
INFO - 2021-03-25 11:16:33 --> Helper loaded: security_helper
INFO - 2021-03-25 11:16:33 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:16:33 --> Database Driver Class Initialized
INFO - 2021-03-25 11:16:33 --> Email Class Initialized
DEBUG - 2021-03-25 11:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:16:33 --> Form Validation Class Initialized
INFO - 2021-03-25 11:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:16:33 --> Pagination Class Initialized
INFO - 2021-03-25 11:16:33 --> Model Class Initialized
INFO - 2021-03-25 11:16:33 --> Controller Class Initialized
INFO - 2021-03-25 11:16:33 --> Model Class Initialized
INFO - 2021-03-25 11:16:33 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-25 11:16:33 --> Final output sent to browser
DEBUG - 2021-03-25 11:16:33 --> Total execution time: 0.4038
INFO - 2021-03-25 11:19:25 --> Config Class Initialized
INFO - 2021-03-25 11:19:25 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:19:25 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:19:25 --> Utf8 Class Initialized
INFO - 2021-03-25 11:19:25 --> URI Class Initialized
INFO - 2021-03-25 11:19:25 --> Router Class Initialized
INFO - 2021-03-25 11:19:25 --> Output Class Initialized
INFO - 2021-03-25 11:19:25 --> Security Class Initialized
DEBUG - 2021-03-25 11:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:19:25 --> Input Class Initialized
INFO - 2021-03-25 11:19:25 --> Language Class Initialized
INFO - 2021-03-25 11:19:25 --> Loader Class Initialized
INFO - 2021-03-25 11:19:25 --> Helper loaded: url_helper
INFO - 2021-03-25 11:19:25 --> Helper loaded: file_helper
INFO - 2021-03-25 11:19:25 --> Helper loaded: form_helper
INFO - 2021-03-25 11:19:25 --> Helper loaded: text_helper
INFO - 2021-03-25 11:19:25 --> Helper loaded: security_helper
INFO - 2021-03-25 11:19:25 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:19:25 --> Database Driver Class Initialized
INFO - 2021-03-25 11:19:25 --> Email Class Initialized
DEBUG - 2021-03-25 11:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:19:25 --> Form Validation Class Initialized
INFO - 2021-03-25 11:19:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:19:25 --> Pagination Class Initialized
INFO - 2021-03-25 11:19:25 --> Model Class Initialized
INFO - 2021-03-25 11:19:25 --> Controller Class Initialized
INFO - 2021-03-25 11:19:26 --> Model Class Initialized
INFO - 2021-03-25 11:19:26 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-25 11:19:26 --> Final output sent to browser
DEBUG - 2021-03-25 11:19:26 --> Total execution time: 0.4113
INFO - 2021-03-25 11:19:33 --> Config Class Initialized
INFO - 2021-03-25 11:19:33 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:19:33 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:19:33 --> Utf8 Class Initialized
INFO - 2021-03-25 11:19:33 --> URI Class Initialized
INFO - 2021-03-25 11:19:33 --> Router Class Initialized
INFO - 2021-03-25 11:19:33 --> Output Class Initialized
INFO - 2021-03-25 11:19:33 --> Security Class Initialized
DEBUG - 2021-03-25 11:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:19:33 --> Input Class Initialized
INFO - 2021-03-25 11:19:33 --> Language Class Initialized
INFO - 2021-03-25 11:19:33 --> Loader Class Initialized
INFO - 2021-03-25 11:19:33 --> Helper loaded: url_helper
INFO - 2021-03-25 11:19:33 --> Helper loaded: file_helper
INFO - 2021-03-25 11:19:33 --> Helper loaded: form_helper
INFO - 2021-03-25 11:19:33 --> Helper loaded: text_helper
INFO - 2021-03-25 11:19:33 --> Helper loaded: security_helper
INFO - 2021-03-25 11:19:33 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:19:33 --> Database Driver Class Initialized
INFO - 2021-03-25 11:19:34 --> Email Class Initialized
DEBUG - 2021-03-25 11:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:19:34 --> Form Validation Class Initialized
INFO - 2021-03-25 11:19:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:19:34 --> Pagination Class Initialized
INFO - 2021-03-25 11:19:34 --> Model Class Initialized
INFO - 2021-03-25 11:19:34 --> Controller Class Initialized
INFO - 2021-03-25 11:19:34 --> Model Class Initialized
INFO - 2021-03-25 11:19:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-25 11:19:34 --> Final output sent to browser
DEBUG - 2021-03-25 11:19:34 --> Total execution time: 0.4484
INFO - 2021-03-25 11:19:37 --> Config Class Initialized
INFO - 2021-03-25 11:19:37 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:19:37 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:19:37 --> Utf8 Class Initialized
INFO - 2021-03-25 11:19:37 --> URI Class Initialized
INFO - 2021-03-25 11:19:37 --> Router Class Initialized
INFO - 2021-03-25 11:19:37 --> Output Class Initialized
INFO - 2021-03-25 11:19:37 --> Security Class Initialized
DEBUG - 2021-03-25 11:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:19:37 --> Input Class Initialized
INFO - 2021-03-25 11:19:37 --> Language Class Initialized
INFO - 2021-03-25 11:19:37 --> Loader Class Initialized
INFO - 2021-03-25 11:19:37 --> Helper loaded: url_helper
INFO - 2021-03-25 11:19:37 --> Helper loaded: file_helper
INFO - 2021-03-25 11:19:37 --> Helper loaded: form_helper
INFO - 2021-03-25 11:19:37 --> Helper loaded: text_helper
INFO - 2021-03-25 11:19:37 --> Helper loaded: security_helper
INFO - 2021-03-25 11:19:37 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:19:37 --> Database Driver Class Initialized
INFO - 2021-03-25 11:19:38 --> Email Class Initialized
DEBUG - 2021-03-25 11:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:19:38 --> Form Validation Class Initialized
INFO - 2021-03-25 11:19:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:19:38 --> Pagination Class Initialized
INFO - 2021-03-25 11:19:38 --> Model Class Initialized
INFO - 2021-03-25 11:19:38 --> Controller Class Initialized
INFO - 2021-03-25 11:19:38 --> Model Class Initialized
INFO - 2021-03-25 11:19:38 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-25 11:19:38 --> Final output sent to browser
DEBUG - 2021-03-25 11:19:38 --> Total execution time: 0.4469
INFO - 2021-03-25 11:19:59 --> Config Class Initialized
INFO - 2021-03-25 11:19:59 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:19:59 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:19:59 --> Utf8 Class Initialized
INFO - 2021-03-25 11:19:59 --> URI Class Initialized
INFO - 2021-03-25 11:19:59 --> Router Class Initialized
INFO - 2021-03-25 11:19:59 --> Output Class Initialized
INFO - 2021-03-25 11:19:59 --> Security Class Initialized
DEBUG - 2021-03-25 11:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:19:59 --> Input Class Initialized
INFO - 2021-03-25 11:19:59 --> Language Class Initialized
INFO - 2021-03-25 11:19:59 --> Loader Class Initialized
INFO - 2021-03-25 11:19:59 --> Helper loaded: url_helper
INFO - 2021-03-25 11:19:59 --> Helper loaded: file_helper
INFO - 2021-03-25 11:19:59 --> Helper loaded: form_helper
INFO - 2021-03-25 11:19:59 --> Helper loaded: text_helper
INFO - 2021-03-25 11:19:59 --> Helper loaded: security_helper
INFO - 2021-03-25 11:19:59 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:19:59 --> Database Driver Class Initialized
INFO - 2021-03-25 11:19:59 --> Email Class Initialized
DEBUG - 2021-03-25 11:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:19:59 --> Form Validation Class Initialized
INFO - 2021-03-25 11:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:19:59 --> Pagination Class Initialized
INFO - 2021-03-25 11:19:59 --> Model Class Initialized
INFO - 2021-03-25 11:19:59 --> Controller Class Initialized
INFO - 2021-03-25 11:19:59 --> Model Class Initialized
INFO - 2021-03-25 11:19:59 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-25 11:19:59 --> Final output sent to browser
DEBUG - 2021-03-25 11:19:59 --> Total execution time: 0.4299
INFO - 2021-03-25 11:20:01 --> Config Class Initialized
INFO - 2021-03-25 11:20:01 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:20:01 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:20:01 --> Utf8 Class Initialized
INFO - 2021-03-25 11:20:01 --> URI Class Initialized
INFO - 2021-03-25 11:20:01 --> Router Class Initialized
INFO - 2021-03-25 11:20:01 --> Output Class Initialized
INFO - 2021-03-25 11:20:01 --> Security Class Initialized
DEBUG - 2021-03-25 11:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:20:01 --> Input Class Initialized
INFO - 2021-03-25 11:20:01 --> Language Class Initialized
INFO - 2021-03-25 11:20:01 --> Loader Class Initialized
INFO - 2021-03-25 11:20:01 --> Helper loaded: url_helper
INFO - 2021-03-25 11:20:01 --> Helper loaded: file_helper
INFO - 2021-03-25 11:20:01 --> Helper loaded: form_helper
INFO - 2021-03-25 11:20:01 --> Helper loaded: text_helper
INFO - 2021-03-25 11:20:01 --> Helper loaded: security_helper
INFO - 2021-03-25 11:20:01 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:20:01 --> Database Driver Class Initialized
INFO - 2021-03-25 11:20:01 --> Email Class Initialized
DEBUG - 2021-03-25 11:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:20:01 --> Form Validation Class Initialized
INFO - 2021-03-25 11:20:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:20:01 --> Pagination Class Initialized
INFO - 2021-03-25 11:20:01 --> Model Class Initialized
INFO - 2021-03-25 11:20:01 --> Controller Class Initialized
INFO - 2021-03-25 11:20:02 --> Model Class Initialized
INFO - 2021-03-25 11:20:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-25 11:20:02 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-25 11:20:02 --> Final output sent to browser
DEBUG - 2021-03-25 11:20:02 --> Total execution time: 0.4312
INFO - 2021-03-25 11:21:29 --> Config Class Initialized
INFO - 2021-03-25 11:21:29 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:21:29 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:21:29 --> Utf8 Class Initialized
INFO - 2021-03-25 11:21:29 --> URI Class Initialized
INFO - 2021-03-25 11:21:29 --> Router Class Initialized
INFO - 2021-03-25 11:21:29 --> Output Class Initialized
INFO - 2021-03-25 11:21:29 --> Security Class Initialized
DEBUG - 2021-03-25 11:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:21:29 --> Input Class Initialized
INFO - 2021-03-25 11:21:29 --> Language Class Initialized
INFO - 2021-03-25 11:21:30 --> Loader Class Initialized
INFO - 2021-03-25 11:21:30 --> Helper loaded: url_helper
INFO - 2021-03-25 11:21:30 --> Helper loaded: file_helper
INFO - 2021-03-25 11:21:30 --> Helper loaded: form_helper
INFO - 2021-03-25 11:21:30 --> Helper loaded: text_helper
INFO - 2021-03-25 11:21:30 --> Helper loaded: security_helper
INFO - 2021-03-25 11:21:30 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:21:30 --> Database Driver Class Initialized
INFO - 2021-03-25 11:21:30 --> Email Class Initialized
DEBUG - 2021-03-25 11:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:21:30 --> Form Validation Class Initialized
INFO - 2021-03-25 11:21:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:21:30 --> Pagination Class Initialized
INFO - 2021-03-25 11:21:30 --> Model Class Initialized
INFO - 2021-03-25 11:21:30 --> Controller Class Initialized
INFO - 2021-03-25 11:21:30 --> Model Class Initialized
INFO - 2021-03-25 11:21:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-25 11:21:30 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-25 11:21:30 --> Final output sent to browser
DEBUG - 2021-03-25 11:21:30 --> Total execution time: 0.4646
INFO - 2021-03-25 11:26:37 --> Config Class Initialized
INFO - 2021-03-25 11:26:37 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:26:37 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:26:37 --> Utf8 Class Initialized
INFO - 2021-03-25 11:26:37 --> URI Class Initialized
INFO - 2021-03-25 11:26:37 --> Router Class Initialized
INFO - 2021-03-25 11:26:37 --> Output Class Initialized
INFO - 2021-03-25 11:26:37 --> Security Class Initialized
DEBUG - 2021-03-25 11:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:26:38 --> Input Class Initialized
INFO - 2021-03-25 11:26:38 --> Language Class Initialized
INFO - 2021-03-25 11:26:38 --> Loader Class Initialized
INFO - 2021-03-25 11:26:38 --> Helper loaded: url_helper
INFO - 2021-03-25 11:26:38 --> Helper loaded: file_helper
INFO - 2021-03-25 11:26:38 --> Helper loaded: form_helper
INFO - 2021-03-25 11:26:38 --> Helper loaded: text_helper
INFO - 2021-03-25 11:26:38 --> Helper loaded: security_helper
INFO - 2021-03-25 11:26:38 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:26:38 --> Database Driver Class Initialized
INFO - 2021-03-25 11:26:38 --> Email Class Initialized
DEBUG - 2021-03-25 11:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:26:38 --> Form Validation Class Initialized
INFO - 2021-03-25 11:26:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:26:38 --> Pagination Class Initialized
INFO - 2021-03-25 11:26:38 --> Model Class Initialized
INFO - 2021-03-25 11:26:38 --> Controller Class Initialized
INFO - 2021-03-25 11:26:38 --> Model Class Initialized
INFO - 2021-03-25 11:26:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-25 11:26:38 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-25 11:26:38 --> Final output sent to browser
DEBUG - 2021-03-25 11:26:38 --> Total execution time: 0.4406
INFO - 2021-03-25 11:26:41 --> Config Class Initialized
INFO - 2021-03-25 11:26:41 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:26:41 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:26:41 --> Utf8 Class Initialized
INFO - 2021-03-25 11:26:41 --> URI Class Initialized
INFO - 2021-03-25 11:26:41 --> Router Class Initialized
INFO - 2021-03-25 11:26:41 --> Output Class Initialized
INFO - 2021-03-25 11:26:41 --> Security Class Initialized
DEBUG - 2021-03-25 11:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:26:41 --> Input Class Initialized
INFO - 2021-03-25 11:26:41 --> Language Class Initialized
INFO - 2021-03-25 11:26:41 --> Loader Class Initialized
INFO - 2021-03-25 11:26:41 --> Helper loaded: url_helper
INFO - 2021-03-25 11:26:41 --> Helper loaded: file_helper
INFO - 2021-03-25 11:26:41 --> Helper loaded: form_helper
INFO - 2021-03-25 11:26:41 --> Helper loaded: text_helper
INFO - 2021-03-25 11:26:41 --> Helper loaded: security_helper
INFO - 2021-03-25 11:26:41 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:26:41 --> Database Driver Class Initialized
INFO - 2021-03-25 11:26:41 --> Email Class Initialized
DEBUG - 2021-03-25 11:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:26:41 --> Form Validation Class Initialized
INFO - 2021-03-25 11:26:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:26:41 --> Pagination Class Initialized
INFO - 2021-03-25 11:26:41 --> Model Class Initialized
INFO - 2021-03-25 11:26:41 --> Controller Class Initialized
INFO - 2021-03-25 11:26:41 --> Model Class Initialized
INFO - 2021-03-25 11:26:41 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-25 11:26:41 --> Final output sent to browser
DEBUG - 2021-03-25 11:26:41 --> Total execution time: 0.4343
INFO - 2021-03-25 11:29:34 --> Config Class Initialized
INFO - 2021-03-25 11:29:34 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:29:34 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:29:34 --> Utf8 Class Initialized
INFO - 2021-03-25 11:29:34 --> URI Class Initialized
INFO - 2021-03-25 11:29:34 --> Router Class Initialized
INFO - 2021-03-25 11:29:34 --> Output Class Initialized
INFO - 2021-03-25 11:29:34 --> Security Class Initialized
DEBUG - 2021-03-25 11:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:29:34 --> Input Class Initialized
INFO - 2021-03-25 11:29:34 --> Language Class Initialized
INFO - 2021-03-25 11:29:34 --> Loader Class Initialized
INFO - 2021-03-25 11:29:34 --> Helper loaded: url_helper
INFO - 2021-03-25 11:29:34 --> Helper loaded: file_helper
INFO - 2021-03-25 11:29:34 --> Helper loaded: form_helper
INFO - 2021-03-25 11:29:34 --> Helper loaded: text_helper
INFO - 2021-03-25 11:29:34 --> Helper loaded: security_helper
INFO - 2021-03-25 11:29:34 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:29:34 --> Database Driver Class Initialized
INFO - 2021-03-25 11:29:34 --> Email Class Initialized
DEBUG - 2021-03-25 11:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:29:35 --> Form Validation Class Initialized
INFO - 2021-03-25 11:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:29:35 --> Pagination Class Initialized
INFO - 2021-03-25 11:29:35 --> Model Class Initialized
INFO - 2021-03-25 11:29:35 --> Controller Class Initialized
INFO - 2021-03-25 11:29:35 --> Model Class Initialized
INFO - 2021-03-25 11:29:35 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-25 11:29:35 --> Final output sent to browser
DEBUG - 2021-03-25 11:29:35 --> Total execution time: 0.4087
INFO - 2021-03-25 11:29:46 --> Config Class Initialized
INFO - 2021-03-25 11:29:46 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:29:46 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:29:46 --> Utf8 Class Initialized
INFO - 2021-03-25 11:29:46 --> URI Class Initialized
INFO - 2021-03-25 11:29:46 --> Router Class Initialized
INFO - 2021-03-25 11:29:46 --> Output Class Initialized
INFO - 2021-03-25 11:29:46 --> Security Class Initialized
DEBUG - 2021-03-25 11:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:29:46 --> Input Class Initialized
INFO - 2021-03-25 11:29:46 --> Language Class Initialized
INFO - 2021-03-25 11:29:46 --> Loader Class Initialized
INFO - 2021-03-25 11:29:46 --> Helper loaded: url_helper
INFO - 2021-03-25 11:29:46 --> Helper loaded: file_helper
INFO - 2021-03-25 11:29:46 --> Helper loaded: form_helper
INFO - 2021-03-25 11:29:46 --> Helper loaded: text_helper
INFO - 2021-03-25 11:29:46 --> Helper loaded: security_helper
INFO - 2021-03-25 11:29:46 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:29:46 --> Database Driver Class Initialized
INFO - 2021-03-25 11:29:46 --> Email Class Initialized
DEBUG - 2021-03-25 11:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:29:46 --> Form Validation Class Initialized
INFO - 2021-03-25 11:29:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:29:46 --> Pagination Class Initialized
INFO - 2021-03-25 11:29:46 --> Model Class Initialized
INFO - 2021-03-25 11:29:46 --> Controller Class Initialized
INFO - 2021-03-25 11:29:46 --> Model Class Initialized
INFO - 2021-03-25 11:29:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-25 11:29:47 --> Final output sent to browser
DEBUG - 2021-03-25 11:29:47 --> Total execution time: 0.4090
INFO - 2021-03-25 11:30:24 --> Config Class Initialized
INFO - 2021-03-25 11:30:24 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:30:24 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:30:24 --> Utf8 Class Initialized
INFO - 2021-03-25 11:30:24 --> URI Class Initialized
INFO - 2021-03-25 11:30:24 --> Router Class Initialized
INFO - 2021-03-25 11:30:24 --> Output Class Initialized
INFO - 2021-03-25 11:30:24 --> Security Class Initialized
DEBUG - 2021-03-25 11:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:30:24 --> Input Class Initialized
INFO - 2021-03-25 11:30:24 --> Language Class Initialized
INFO - 2021-03-25 11:30:24 --> Loader Class Initialized
INFO - 2021-03-25 11:30:24 --> Helper loaded: url_helper
INFO - 2021-03-25 11:30:24 --> Helper loaded: file_helper
INFO - 2021-03-25 11:30:24 --> Helper loaded: form_helper
INFO - 2021-03-25 11:30:24 --> Helper loaded: text_helper
INFO - 2021-03-25 11:30:24 --> Helper loaded: security_helper
INFO - 2021-03-25 11:30:24 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:30:24 --> Database Driver Class Initialized
INFO - 2021-03-25 11:30:24 --> Email Class Initialized
DEBUG - 2021-03-25 11:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:30:24 --> Form Validation Class Initialized
INFO - 2021-03-25 11:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:30:25 --> Pagination Class Initialized
INFO - 2021-03-25 11:30:25 --> Model Class Initialized
INFO - 2021-03-25 11:30:25 --> Controller Class Initialized
INFO - 2021-03-25 11:30:25 --> Model Class Initialized
INFO - 2021-03-25 11:30:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-25 11:30:25 --> Final output sent to browser
DEBUG - 2021-03-25 11:30:25 --> Total execution time: 0.4332
INFO - 2021-03-25 11:30:33 --> Config Class Initialized
INFO - 2021-03-25 11:30:33 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:30:33 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:30:33 --> Utf8 Class Initialized
INFO - 2021-03-25 11:30:33 --> URI Class Initialized
INFO - 2021-03-25 11:30:33 --> Router Class Initialized
INFO - 2021-03-25 11:30:33 --> Output Class Initialized
INFO - 2021-03-25 11:30:33 --> Security Class Initialized
DEBUG - 2021-03-25 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:30:33 --> Input Class Initialized
INFO - 2021-03-25 11:30:33 --> Language Class Initialized
INFO - 2021-03-25 11:30:33 --> Loader Class Initialized
INFO - 2021-03-25 11:30:33 --> Helper loaded: url_helper
INFO - 2021-03-25 11:30:33 --> Helper loaded: file_helper
INFO - 2021-03-25 11:30:33 --> Helper loaded: form_helper
INFO - 2021-03-25 11:30:33 --> Helper loaded: text_helper
INFO - 2021-03-25 11:30:33 --> Helper loaded: security_helper
INFO - 2021-03-25 11:30:33 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:30:33 --> Database Driver Class Initialized
INFO - 2021-03-25 11:30:33 --> Email Class Initialized
DEBUG - 2021-03-25 11:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:30:34 --> Form Validation Class Initialized
INFO - 2021-03-25 11:30:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:30:34 --> Pagination Class Initialized
INFO - 2021-03-25 11:30:34 --> Model Class Initialized
INFO - 2021-03-25 11:30:34 --> Controller Class Initialized
INFO - 2021-03-25 11:30:34 --> Model Class Initialized
INFO - 2021-03-25 11:30:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-25 11:30:34 --> Final output sent to browser
DEBUG - 2021-03-25 11:30:34 --> Total execution time: 0.4303
INFO - 2021-03-25 11:30:38 --> Config Class Initialized
INFO - 2021-03-25 11:30:38 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:30:38 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:30:38 --> Utf8 Class Initialized
INFO - 2021-03-25 11:30:38 --> URI Class Initialized
INFO - 2021-03-25 11:30:38 --> Router Class Initialized
INFO - 2021-03-25 11:30:38 --> Output Class Initialized
INFO - 2021-03-25 11:30:38 --> Security Class Initialized
DEBUG - 2021-03-25 11:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:30:38 --> Input Class Initialized
INFO - 2021-03-25 11:30:38 --> Language Class Initialized
INFO - 2021-03-25 11:30:38 --> Loader Class Initialized
INFO - 2021-03-25 11:30:38 --> Helper loaded: url_helper
INFO - 2021-03-25 11:30:38 --> Helper loaded: file_helper
INFO - 2021-03-25 11:30:38 --> Helper loaded: form_helper
INFO - 2021-03-25 11:30:38 --> Helper loaded: text_helper
INFO - 2021-03-25 11:30:38 --> Helper loaded: security_helper
INFO - 2021-03-25 11:30:38 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:30:38 --> Database Driver Class Initialized
INFO - 2021-03-25 11:30:38 --> Email Class Initialized
DEBUG - 2021-03-25 11:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:30:38 --> Form Validation Class Initialized
INFO - 2021-03-25 11:30:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:30:38 --> Pagination Class Initialized
INFO - 2021-03-25 11:30:38 --> Model Class Initialized
INFO - 2021-03-25 11:30:38 --> Controller Class Initialized
INFO - 2021-03-25 11:30:38 --> Model Class Initialized
INFO - 2021-03-25 11:30:38 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-25 11:30:38 --> Final output sent to browser
DEBUG - 2021-03-25 11:30:39 --> Total execution time: 0.4178
INFO - 2021-03-25 11:30:39 --> Config Class Initialized
INFO - 2021-03-25 11:30:39 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:30:39 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:30:39 --> Utf8 Class Initialized
INFO - 2021-03-25 11:30:39 --> URI Class Initialized
INFO - 2021-03-25 11:30:39 --> Router Class Initialized
INFO - 2021-03-25 11:30:39 --> Output Class Initialized
INFO - 2021-03-25 11:30:39 --> Security Class Initialized
DEBUG - 2021-03-25 11:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:30:39 --> Input Class Initialized
INFO - 2021-03-25 11:30:39 --> Language Class Initialized
ERROR - 2021-03-25 11:30:39 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-25 11:30:53 --> Config Class Initialized
INFO - 2021-03-25 11:30:53 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:30:53 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:30:53 --> Utf8 Class Initialized
INFO - 2021-03-25 11:30:53 --> URI Class Initialized
INFO - 2021-03-25 11:30:53 --> Router Class Initialized
INFO - 2021-03-25 11:30:53 --> Output Class Initialized
INFO - 2021-03-25 11:30:53 --> Security Class Initialized
DEBUG - 2021-03-25 11:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:30:53 --> Input Class Initialized
INFO - 2021-03-25 11:30:53 --> Language Class Initialized
INFO - 2021-03-25 11:30:53 --> Loader Class Initialized
INFO - 2021-03-25 11:30:53 --> Helper loaded: url_helper
INFO - 2021-03-25 11:30:53 --> Helper loaded: file_helper
INFO - 2021-03-25 11:30:53 --> Helper loaded: form_helper
INFO - 2021-03-25 11:30:53 --> Helper loaded: text_helper
INFO - 2021-03-25 11:30:53 --> Helper loaded: security_helper
INFO - 2021-03-25 11:30:53 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:30:53 --> Database Driver Class Initialized
INFO - 2021-03-25 11:30:54 --> Email Class Initialized
DEBUG - 2021-03-25 11:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:30:54 --> Form Validation Class Initialized
INFO - 2021-03-25 11:30:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:30:54 --> Pagination Class Initialized
INFO - 2021-03-25 11:30:54 --> Model Class Initialized
INFO - 2021-03-25 11:30:54 --> Controller Class Initialized
INFO - 2021-03-25 11:30:54 --> Model Class Initialized
INFO - 2021-03-25 11:30:54 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-25 11:30:54 --> Final output sent to browser
DEBUG - 2021-03-25 11:30:54 --> Total execution time: 0.4160
INFO - 2021-03-25 11:30:54 --> Config Class Initialized
INFO - 2021-03-25 11:30:54 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:30:54 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:30:54 --> Utf8 Class Initialized
INFO - 2021-03-25 11:30:54 --> URI Class Initialized
INFO - 2021-03-25 11:30:54 --> Router Class Initialized
INFO - 2021-03-25 11:30:54 --> Output Class Initialized
INFO - 2021-03-25 11:30:54 --> Security Class Initialized
DEBUG - 2021-03-25 11:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:30:54 --> Input Class Initialized
INFO - 2021-03-25 11:30:54 --> Language Class Initialized
ERROR - 2021-03-25 11:30:54 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-25 11:31:00 --> Config Class Initialized
INFO - 2021-03-25 11:31:00 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:31:00 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:31:00 --> Utf8 Class Initialized
INFO - 2021-03-25 11:31:00 --> URI Class Initialized
INFO - 2021-03-25 11:31:00 --> Router Class Initialized
INFO - 2021-03-25 11:31:00 --> Output Class Initialized
INFO - 2021-03-25 11:31:00 --> Security Class Initialized
DEBUG - 2021-03-25 11:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:31:00 --> Input Class Initialized
INFO - 2021-03-25 11:31:00 --> Language Class Initialized
INFO - 2021-03-25 11:31:00 --> Loader Class Initialized
INFO - 2021-03-25 11:31:00 --> Helper loaded: url_helper
INFO - 2021-03-25 11:31:00 --> Helper loaded: file_helper
INFO - 2021-03-25 11:31:00 --> Helper loaded: form_helper
INFO - 2021-03-25 11:31:00 --> Helper loaded: text_helper
INFO - 2021-03-25 11:31:00 --> Helper loaded: security_helper
INFO - 2021-03-25 11:31:00 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:31:00 --> Database Driver Class Initialized
INFO - 2021-03-25 11:31:01 --> Email Class Initialized
DEBUG - 2021-03-25 11:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:31:01 --> Form Validation Class Initialized
INFO - 2021-03-25 11:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:31:01 --> Pagination Class Initialized
INFO - 2021-03-25 11:31:01 --> Model Class Initialized
INFO - 2021-03-25 11:31:01 --> Controller Class Initialized
INFO - 2021-03-25 11:31:01 --> Model Class Initialized
INFO - 2021-03-25 11:31:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-25 11:31:01 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-25 11:31:01 --> Final output sent to browser
DEBUG - 2021-03-25 11:31:01 --> Total execution time: 0.4424
INFO - 2021-03-25 11:31:01 --> Config Class Initialized
INFO - 2021-03-25 11:31:01 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:31:01 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:31:01 --> Utf8 Class Initialized
INFO - 2021-03-25 11:31:01 --> URI Class Initialized
INFO - 2021-03-25 11:31:01 --> Router Class Initialized
INFO - 2021-03-25 11:31:01 --> Output Class Initialized
INFO - 2021-03-25 11:31:01 --> Security Class Initialized
DEBUG - 2021-03-25 11:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:31:01 --> Input Class Initialized
INFO - 2021-03-25 11:31:01 --> Language Class Initialized
ERROR - 2021-03-25 11:31:01 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-25 11:31:29 --> Config Class Initialized
INFO - 2021-03-25 11:31:29 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:31:29 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:31:29 --> Utf8 Class Initialized
INFO - 2021-03-25 11:31:29 --> URI Class Initialized
INFO - 2021-03-25 11:31:29 --> Router Class Initialized
INFO - 2021-03-25 11:31:29 --> Output Class Initialized
INFO - 2021-03-25 11:31:29 --> Security Class Initialized
DEBUG - 2021-03-25 11:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:31:29 --> Input Class Initialized
INFO - 2021-03-25 11:31:29 --> Language Class Initialized
INFO - 2021-03-25 11:31:29 --> Loader Class Initialized
INFO - 2021-03-25 11:31:29 --> Helper loaded: url_helper
INFO - 2021-03-25 11:31:29 --> Helper loaded: file_helper
INFO - 2021-03-25 11:31:29 --> Helper loaded: form_helper
INFO - 2021-03-25 11:31:29 --> Helper loaded: text_helper
INFO - 2021-03-25 11:31:29 --> Helper loaded: security_helper
INFO - 2021-03-25 11:31:29 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:31:29 --> Database Driver Class Initialized
INFO - 2021-03-25 11:31:29 --> Email Class Initialized
DEBUG - 2021-03-25 11:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:31:29 --> Form Validation Class Initialized
INFO - 2021-03-25 11:31:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:31:29 --> Pagination Class Initialized
INFO - 2021-03-25 11:31:29 --> Model Class Initialized
INFO - 2021-03-25 11:31:29 --> Controller Class Initialized
INFO - 2021-03-25 11:31:29 --> Model Class Initialized
INFO - 2021-03-25 11:31:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-25 11:31:29 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-25 11:31:29 --> Final output sent to browser
DEBUG - 2021-03-25 11:31:29 --> Total execution time: 0.4536
INFO - 2021-03-25 11:31:29 --> Config Class Initialized
INFO - 2021-03-25 11:31:29 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:31:29 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:31:29 --> Utf8 Class Initialized
INFO - 2021-03-25 11:31:29 --> URI Class Initialized
INFO - 2021-03-25 11:31:30 --> Router Class Initialized
INFO - 2021-03-25 11:31:30 --> Output Class Initialized
INFO - 2021-03-25 11:31:30 --> Security Class Initialized
DEBUG - 2021-03-25 11:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:31:30 --> Input Class Initialized
INFO - 2021-03-25 11:31:30 --> Language Class Initialized
ERROR - 2021-03-25 11:31:30 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-25 11:31:35 --> Config Class Initialized
INFO - 2021-03-25 11:31:35 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:31:35 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:31:35 --> Utf8 Class Initialized
INFO - 2021-03-25 11:31:35 --> URI Class Initialized
INFO - 2021-03-25 11:31:35 --> Router Class Initialized
INFO - 2021-03-25 11:31:35 --> Output Class Initialized
INFO - 2021-03-25 11:31:35 --> Security Class Initialized
DEBUG - 2021-03-25 11:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:31:35 --> Input Class Initialized
INFO - 2021-03-25 11:31:35 --> Language Class Initialized
INFO - 2021-03-25 11:31:35 --> Loader Class Initialized
INFO - 2021-03-25 11:31:35 --> Helper loaded: url_helper
INFO - 2021-03-25 11:31:35 --> Helper loaded: file_helper
INFO - 2021-03-25 11:31:35 --> Helper loaded: form_helper
INFO - 2021-03-25 11:31:35 --> Helper loaded: text_helper
INFO - 2021-03-25 11:31:35 --> Helper loaded: security_helper
INFO - 2021-03-25 11:31:35 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:31:35 --> Database Driver Class Initialized
INFO - 2021-03-25 11:31:35 --> Email Class Initialized
DEBUG - 2021-03-25 11:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:31:36 --> Form Validation Class Initialized
INFO - 2021-03-25 11:31:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:31:36 --> Pagination Class Initialized
INFO - 2021-03-25 11:31:36 --> Model Class Initialized
INFO - 2021-03-25 11:31:36 --> Controller Class Initialized
INFO - 2021-03-25 11:31:36 --> Model Class Initialized
INFO - 2021-03-25 11:31:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-25 11:31:36 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-25 11:31:36 --> Final output sent to browser
DEBUG - 2021-03-25 11:31:36 --> Total execution time: 0.4446
INFO - 2021-03-25 11:31:36 --> Config Class Initialized
INFO - 2021-03-25 11:31:36 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:31:36 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:31:36 --> Utf8 Class Initialized
INFO - 2021-03-25 11:31:36 --> URI Class Initialized
INFO - 2021-03-25 11:31:36 --> Router Class Initialized
INFO - 2021-03-25 11:31:36 --> Output Class Initialized
INFO - 2021-03-25 11:31:36 --> Security Class Initialized
DEBUG - 2021-03-25 11:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:31:36 --> Input Class Initialized
INFO - 2021-03-25 11:31:36 --> Language Class Initialized
ERROR - 2021-03-25 11:31:36 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-25 11:32:06 --> Config Class Initialized
INFO - 2021-03-25 11:32:06 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:32:06 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:32:06 --> Utf8 Class Initialized
INFO - 2021-03-25 11:32:06 --> URI Class Initialized
INFO - 2021-03-25 11:32:06 --> Router Class Initialized
INFO - 2021-03-25 11:32:06 --> Output Class Initialized
INFO - 2021-03-25 11:32:06 --> Security Class Initialized
DEBUG - 2021-03-25 11:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:32:06 --> Input Class Initialized
INFO - 2021-03-25 11:32:06 --> Language Class Initialized
INFO - 2021-03-25 11:32:06 --> Loader Class Initialized
INFO - 2021-03-25 11:32:06 --> Helper loaded: url_helper
INFO - 2021-03-25 11:32:06 --> Helper loaded: file_helper
INFO - 2021-03-25 11:32:06 --> Helper loaded: form_helper
INFO - 2021-03-25 11:32:06 --> Helper loaded: text_helper
INFO - 2021-03-25 11:32:06 --> Helper loaded: security_helper
INFO - 2021-03-25 11:32:06 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:32:06 --> Database Driver Class Initialized
INFO - 2021-03-25 11:32:06 --> Email Class Initialized
DEBUG - 2021-03-25 11:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:32:06 --> Form Validation Class Initialized
INFO - 2021-03-25 11:32:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:32:06 --> Pagination Class Initialized
INFO - 2021-03-25 11:32:06 --> Model Class Initialized
INFO - 2021-03-25 11:32:06 --> Controller Class Initialized
INFO - 2021-03-25 11:32:06 --> Model Class Initialized
INFO - 2021-03-25 11:32:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-25 11:32:06 --> Final output sent to browser
DEBUG - 2021-03-25 11:32:06 --> Total execution time: 0.4339
INFO - 2021-03-25 11:39:42 --> Config Class Initialized
INFO - 2021-03-25 11:39:42 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:39:42 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:39:42 --> Utf8 Class Initialized
INFO - 2021-03-25 11:39:42 --> URI Class Initialized
INFO - 2021-03-25 11:39:42 --> Router Class Initialized
INFO - 2021-03-25 11:39:42 --> Output Class Initialized
INFO - 2021-03-25 11:39:42 --> Security Class Initialized
DEBUG - 2021-03-25 11:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:39:42 --> Input Class Initialized
INFO - 2021-03-25 11:39:42 --> Language Class Initialized
INFO - 2021-03-25 11:39:42 --> Loader Class Initialized
INFO - 2021-03-25 11:39:42 --> Helper loaded: url_helper
INFO - 2021-03-25 11:39:42 --> Helper loaded: file_helper
INFO - 2021-03-25 11:39:42 --> Helper loaded: form_helper
INFO - 2021-03-25 11:39:42 --> Helper loaded: text_helper
INFO - 2021-03-25 11:39:42 --> Helper loaded: security_helper
INFO - 2021-03-25 11:39:42 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:39:42 --> Database Driver Class Initialized
INFO - 2021-03-25 11:39:42 --> Email Class Initialized
DEBUG - 2021-03-25 11:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:39:42 --> Form Validation Class Initialized
INFO - 2021-03-25 11:39:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:39:42 --> Pagination Class Initialized
INFO - 2021-03-25 11:39:42 --> Model Class Initialized
INFO - 2021-03-25 11:39:42 --> Controller Class Initialized
INFO - 2021-03-25 11:39:42 --> Model Class Initialized
INFO - 2021-03-25 11:39:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-25 11:39:42 --> Final output sent to browser
DEBUG - 2021-03-25 11:39:42 --> Total execution time: 0.4473
INFO - 2021-03-25 11:39:44 --> Config Class Initialized
INFO - 2021-03-25 11:39:44 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:39:45 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:39:45 --> Utf8 Class Initialized
INFO - 2021-03-25 11:39:45 --> URI Class Initialized
INFO - 2021-03-25 11:39:45 --> Router Class Initialized
INFO - 2021-03-25 11:39:45 --> Output Class Initialized
INFO - 2021-03-25 11:39:45 --> Security Class Initialized
DEBUG - 2021-03-25 11:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:39:45 --> Input Class Initialized
INFO - 2021-03-25 11:39:45 --> Language Class Initialized
INFO - 2021-03-25 11:39:45 --> Loader Class Initialized
INFO - 2021-03-25 11:39:45 --> Helper loaded: url_helper
INFO - 2021-03-25 11:39:45 --> Helper loaded: file_helper
INFO - 2021-03-25 11:39:45 --> Helper loaded: form_helper
INFO - 2021-03-25 11:39:45 --> Helper loaded: text_helper
INFO - 2021-03-25 11:39:45 --> Helper loaded: security_helper
INFO - 2021-03-25 11:39:45 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:39:45 --> Database Driver Class Initialized
INFO - 2021-03-25 11:39:45 --> Email Class Initialized
DEBUG - 2021-03-25 11:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:39:45 --> Form Validation Class Initialized
INFO - 2021-03-25 11:39:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:39:45 --> Pagination Class Initialized
INFO - 2021-03-25 11:39:45 --> Model Class Initialized
INFO - 2021-03-25 11:39:45 --> Controller Class Initialized
INFO - 2021-03-25 11:39:45 --> Model Class Initialized
INFO - 2021-03-25 11:39:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-25 11:39:45 --> Final output sent to browser
DEBUG - 2021-03-25 11:39:45 --> Total execution time: 0.4138
INFO - 2021-03-25 11:40:06 --> Config Class Initialized
INFO - 2021-03-25 11:40:06 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:40:06 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:40:06 --> Utf8 Class Initialized
INFO - 2021-03-25 11:40:06 --> URI Class Initialized
INFO - 2021-03-25 11:40:06 --> Router Class Initialized
INFO - 2021-03-25 11:40:06 --> Output Class Initialized
INFO - 2021-03-25 11:40:06 --> Security Class Initialized
DEBUG - 2021-03-25 11:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:40:06 --> Input Class Initialized
INFO - 2021-03-25 11:40:06 --> Language Class Initialized
INFO - 2021-03-25 11:40:06 --> Loader Class Initialized
INFO - 2021-03-25 11:40:06 --> Helper loaded: url_helper
INFO - 2021-03-25 11:40:06 --> Helper loaded: file_helper
INFO - 2021-03-25 11:40:06 --> Helper loaded: form_helper
INFO - 2021-03-25 11:40:06 --> Helper loaded: text_helper
INFO - 2021-03-25 11:40:06 --> Helper loaded: security_helper
INFO - 2021-03-25 11:40:06 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:40:06 --> Database Driver Class Initialized
INFO - 2021-03-25 11:40:06 --> Email Class Initialized
DEBUG - 2021-03-25 11:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:40:06 --> Form Validation Class Initialized
INFO - 2021-03-25 11:40:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:40:06 --> Pagination Class Initialized
INFO - 2021-03-25 11:40:06 --> Model Class Initialized
INFO - 2021-03-25 11:40:06 --> Controller Class Initialized
INFO - 2021-03-25 11:40:06 --> Model Class Initialized
INFO - 2021-03-25 11:40:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-25 11:40:07 --> Config Class Initialized
INFO - 2021-03-25 11:40:07 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:40:07 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:40:07 --> Utf8 Class Initialized
INFO - 2021-03-25 11:40:07 --> URI Class Initialized
INFO - 2021-03-25 11:40:07 --> Router Class Initialized
INFO - 2021-03-25 11:40:07 --> Output Class Initialized
INFO - 2021-03-25 11:40:07 --> Security Class Initialized
DEBUG - 2021-03-25 11:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:40:07 --> Input Class Initialized
INFO - 2021-03-25 11:40:07 --> Language Class Initialized
INFO - 2021-03-25 11:40:07 --> Loader Class Initialized
INFO - 2021-03-25 11:40:07 --> Helper loaded: url_helper
INFO - 2021-03-25 11:40:07 --> Helper loaded: file_helper
INFO - 2021-03-25 11:40:07 --> Helper loaded: form_helper
INFO - 2021-03-25 11:40:07 --> Helper loaded: text_helper
INFO - 2021-03-25 11:40:07 --> Helper loaded: security_helper
INFO - 2021-03-25 11:40:07 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:40:07 --> Database Driver Class Initialized
INFO - 2021-03-25 11:40:07 --> Email Class Initialized
DEBUG - 2021-03-25 11:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:40:07 --> Form Validation Class Initialized
INFO - 2021-03-25 11:40:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:40:07 --> Pagination Class Initialized
INFO - 2021-03-25 11:40:07 --> Model Class Initialized
INFO - 2021-03-25 11:40:07 --> Controller Class Initialized
INFO - 2021-03-25 11:40:07 --> Model Class Initialized
INFO - 2021-03-25 11:40:07 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 11:40:07 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 11:40:07 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 11:40:07 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 11:40:07 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 11:40:07 --> Final output sent to browser
DEBUG - 2021-03-25 11:40:07 --> Total execution time: 0.5154
INFO - 2021-03-25 11:40:07 --> Config Class Initialized
INFO - 2021-03-25 11:40:07 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:40:07 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:40:07 --> Utf8 Class Initialized
INFO - 2021-03-25 11:40:07 --> URI Class Initialized
INFO - 2021-03-25 11:40:08 --> Router Class Initialized
INFO - 2021-03-25 11:40:08 --> Config Class Initialized
INFO - 2021-03-25 11:40:08 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:40:08 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:40:08 --> Utf8 Class Initialized
INFO - 2021-03-25 11:40:08 --> URI Class Initialized
INFO - 2021-03-25 11:40:08 --> Router Class Initialized
INFO - 2021-03-25 11:40:08 --> Output Class Initialized
INFO - 2021-03-25 11:40:08 --> Output Class Initialized
INFO - 2021-03-25 11:40:08 --> Security Class Initialized
DEBUG - 2021-03-25 11:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:40:08 --> Input Class Initialized
INFO - 2021-03-25 11:40:08 --> Language Class Initialized
ERROR - 2021-03-25 11:40:08 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 11:40:08 --> Security Class Initialized
DEBUG - 2021-03-25 11:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:40:08 --> Input Class Initialized
INFO - 2021-03-25 11:40:08 --> Language Class Initialized
INFO - 2021-03-25 11:40:08 --> Config Class Initialized
ERROR - 2021-03-25 11:40:08 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-25 11:40:08 --> Config Class Initialized
INFO - 2021-03-25 11:40:08 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:40:08 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:40:08 --> Utf8 Class Initialized
INFO - 2021-03-25 11:40:08 --> URI Class Initialized
INFO - 2021-03-25 11:40:08 --> Config Class Initialized
INFO - 2021-03-25 11:40:08 --> Router Class Initialized
INFO - 2021-03-25 11:40:08 --> Hooks Class Initialized
INFO - 2021-03-25 11:40:08 --> Output Class Initialized
DEBUG - 2021-03-25 11:40:08 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:40:08 --> Utf8 Class Initialized
INFO - 2021-03-25 11:40:08 --> Hooks Class Initialized
INFO - 2021-03-25 11:40:08 --> Security Class Initialized
INFO - 2021-03-25 11:40:08 --> URI Class Initialized
DEBUG - 2021-03-25 11:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:40:08 --> Input Class Initialized
INFO - 2021-03-25 11:40:08 --> Router Class Initialized
INFO - 2021-03-25 11:40:08 --> Language Class Initialized
ERROR - 2021-03-25 11:40:08 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-25 11:40:08 --> Output Class Initialized
INFO - 2021-03-25 11:40:08 --> Security Class Initialized
DEBUG - 2021-03-25 11:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:40:08 --> Input Class Initialized
INFO - 2021-03-25 11:40:08 --> Language Class Initialized
ERROR - 2021-03-25 11:40:08 --> 404 Page Not Found: Js/demo
DEBUG - 2021-03-25 11:40:08 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:40:08 --> Utf8 Class Initialized
INFO - 2021-03-25 11:40:08 --> URI Class Initialized
INFO - 2021-03-25 11:40:08 --> Router Class Initialized
INFO - 2021-03-25 11:40:08 --> Output Class Initialized
INFO - 2021-03-25 11:40:08 --> Security Class Initialized
DEBUG - 2021-03-25 11:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:40:08 --> Input Class Initialized
INFO - 2021-03-25 11:40:08 --> Language Class Initialized
INFO - 2021-03-25 11:40:08 --> Config Class Initialized
INFO - 2021-03-25 11:40:08 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:40:08 --> UTF-8 Support Enabled
ERROR - 2021-03-25 11:40:08 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-25 11:40:08 --> Utf8 Class Initialized
INFO - 2021-03-25 11:40:08 --> URI Class Initialized
INFO - 2021-03-25 11:40:08 --> Router Class Initialized
INFO - 2021-03-25 11:40:08 --> Output Class Initialized
INFO - 2021-03-25 11:40:08 --> Security Class Initialized
DEBUG - 2021-03-25 11:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:40:08 --> Input Class Initialized
INFO - 2021-03-25 11:40:08 --> Language Class Initialized
ERROR - 2021-03-25 11:40:08 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 11:43:30 --> Config Class Initialized
INFO - 2021-03-25 11:43:30 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:43:30 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:43:30 --> Utf8 Class Initialized
INFO - 2021-03-25 11:43:30 --> URI Class Initialized
INFO - 2021-03-25 11:43:30 --> Router Class Initialized
INFO - 2021-03-25 11:43:30 --> Output Class Initialized
INFO - 2021-03-25 11:43:30 --> Security Class Initialized
DEBUG - 2021-03-25 11:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:43:30 --> Input Class Initialized
INFO - 2021-03-25 11:43:30 --> Language Class Initialized
INFO - 2021-03-25 11:43:30 --> Loader Class Initialized
INFO - 2021-03-25 11:43:30 --> Helper loaded: url_helper
INFO - 2021-03-25 11:43:30 --> Helper loaded: file_helper
INFO - 2021-03-25 11:43:30 --> Helper loaded: form_helper
INFO - 2021-03-25 11:43:30 --> Helper loaded: text_helper
INFO - 2021-03-25 11:43:30 --> Helper loaded: security_helper
INFO - 2021-03-25 11:43:30 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:43:30 --> Database Driver Class Initialized
INFO - 2021-03-25 11:43:30 --> Email Class Initialized
DEBUG - 2021-03-25 11:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:43:30 --> Form Validation Class Initialized
INFO - 2021-03-25 11:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:43:30 --> Pagination Class Initialized
INFO - 2021-03-25 11:43:30 --> Model Class Initialized
INFO - 2021-03-25 11:43:30 --> Controller Class Initialized
INFO - 2021-03-25 11:43:30 --> Model Class Initialized
INFO - 2021-03-25 11:43:30 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 11:43:30 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 11:43:30 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 11:43:30 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 11:43:30 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 11:43:30 --> Final output sent to browser
DEBUG - 2021-03-25 11:43:30 --> Total execution time: 0.4925
INFO - 2021-03-25 11:43:30 --> Config Class Initialized
INFO - 2021-03-25 11:43:30 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:43:30 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:43:30 --> Utf8 Class Initialized
INFO - 2021-03-25 11:43:30 --> URI Class Initialized
INFO - 2021-03-25 11:43:30 --> Router Class Initialized
INFO - 2021-03-25 11:43:30 --> Output Class Initialized
INFO - 2021-03-25 11:43:31 --> Security Class Initialized
DEBUG - 2021-03-25 11:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:43:31 --> Input Class Initialized
INFO - 2021-03-25 11:43:31 --> Language Class Initialized
ERROR - 2021-03-25 11:43:31 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 11:43:31 --> Config Class Initialized
INFO - 2021-03-25 11:43:31 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:43:31 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:43:31 --> Utf8 Class Initialized
INFO - 2021-03-25 11:43:31 --> URI Class Initialized
INFO - 2021-03-25 11:43:31 --> Router Class Initialized
INFO - 2021-03-25 11:43:31 --> Output Class Initialized
INFO - 2021-03-25 11:43:31 --> Security Class Initialized
DEBUG - 2021-03-25 11:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:43:31 --> Input Class Initialized
INFO - 2021-03-25 11:43:31 --> Language Class Initialized
ERROR - 2021-03-25 11:43:31 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 11:44:55 --> Config Class Initialized
INFO - 2021-03-25 11:44:55 --> Config Class Initialized
INFO - 2021-03-25 11:44:55 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:44:55 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:44:55 --> Utf8 Class Initialized
INFO - 2021-03-25 11:44:55 --> URI Class Initialized
INFO - 2021-03-25 11:44:55 --> Router Class Initialized
INFO - 2021-03-25 11:44:55 --> Output Class Initialized
INFO - 2021-03-25 11:44:55 --> Security Class Initialized
DEBUG - 2021-03-25 11:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:44:55 --> Input Class Initialized
INFO - 2021-03-25 11:44:55 --> Language Class Initialized
INFO - 2021-03-25 11:44:55 --> Config Class Initialized
INFO - 2021-03-25 11:44:55 --> Hooks Class Initialized
INFO - 2021-03-25 11:44:55 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:44:55 --> UTF-8 Support Enabled
DEBUG - 2021-03-25 11:44:55 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:44:55 --> Utf8 Class Initialized
INFO - 2021-03-25 11:44:55 --> Utf8 Class Initialized
INFO - 2021-03-25 11:44:55 --> URI Class Initialized
INFO - 2021-03-25 11:44:55 --> URI Class Initialized
INFO - 2021-03-25 11:44:55 --> Router Class Initialized
INFO - 2021-03-25 11:44:55 --> Router Class Initialized
INFO - 2021-03-25 11:44:55 --> Output Class Initialized
INFO - 2021-03-25 11:44:55 --> Output Class Initialized
INFO - 2021-03-25 11:44:55 --> Security Class Initialized
INFO - 2021-03-25 11:44:55 --> Security Class Initialized
ERROR - 2021-03-25 11:44:55 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-25 11:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:44:55 --> Input Class Initialized
INFO - 2021-03-25 11:44:55 --> Language Class Initialized
ERROR - 2021-03-25 11:44:55 --> 404 Page Not Found: Adminassets/css
DEBUG - 2021-03-25 11:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:44:55 --> Input Class Initialized
INFO - 2021-03-25 11:44:55 --> Language Class Initialized
ERROR - 2021-03-25 11:44:55 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-25 11:45:04 --> Config Class Initialized
INFO - 2021-03-25 11:45:04 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:45:04 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:45:04 --> Utf8 Class Initialized
INFO - 2021-03-25 11:45:04 --> URI Class Initialized
INFO - 2021-03-25 11:45:04 --> Router Class Initialized
INFO - 2021-03-25 11:45:04 --> Output Class Initialized
INFO - 2021-03-25 11:45:04 --> Security Class Initialized
DEBUG - 2021-03-25 11:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:45:04 --> Input Class Initialized
INFO - 2021-03-25 11:45:04 --> Language Class Initialized
INFO - 2021-03-25 11:45:04 --> Loader Class Initialized
INFO - 2021-03-25 11:45:04 --> Helper loaded: url_helper
INFO - 2021-03-25 11:45:04 --> Helper loaded: file_helper
INFO - 2021-03-25 11:45:04 --> Helper loaded: form_helper
INFO - 2021-03-25 11:45:04 --> Helper loaded: text_helper
INFO - 2021-03-25 11:45:04 --> Helper loaded: security_helper
INFO - 2021-03-25 11:45:04 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:45:04 --> Database Driver Class Initialized
INFO - 2021-03-25 11:45:04 --> Email Class Initialized
DEBUG - 2021-03-25 11:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:45:04 --> Form Validation Class Initialized
INFO - 2021-03-25 11:45:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:45:04 --> Pagination Class Initialized
INFO - 2021-03-25 11:45:04 --> Model Class Initialized
INFO - 2021-03-25 11:45:04 --> Controller Class Initialized
INFO - 2021-03-25 11:45:04 --> Model Class Initialized
INFO - 2021-03-25 11:45:04 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 11:45:04 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 11:45:04 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 11:45:04 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 11:45:04 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 11:45:04 --> Final output sent to browser
DEBUG - 2021-03-25 11:45:04 --> Total execution time: 0.5021
INFO - 2021-03-25 11:45:05 --> Config Class Initialized
INFO - 2021-03-25 11:45:05 --> Hooks Class Initialized
INFO - 2021-03-25 11:45:05 --> Config Class Initialized
INFO - 2021-03-25 11:45:05 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:45:05 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:45:05 --> Utf8 Class Initialized
INFO - 2021-03-25 11:45:05 --> URI Class Initialized
DEBUG - 2021-03-25 11:45:05 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:45:05 --> Utf8 Class Initialized
INFO - 2021-03-25 11:45:05 --> URI Class Initialized
INFO - 2021-03-25 11:45:05 --> Router Class Initialized
INFO - 2021-03-25 11:45:05 --> Output Class Initialized
INFO - 2021-03-25 11:45:05 --> Security Class Initialized
DEBUG - 2021-03-25 11:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:45:05 --> Router Class Initialized
INFO - 2021-03-25 11:45:05 --> Output Class Initialized
INFO - 2021-03-25 11:45:05 --> Security Class Initialized
DEBUG - 2021-03-25 11:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:45:05 --> Input Class Initialized
INFO - 2021-03-25 11:45:05 --> Language Class Initialized
ERROR - 2021-03-25 11:45:05 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-25 11:45:05 --> Input Class Initialized
INFO - 2021-03-25 11:45:05 --> Language Class Initialized
ERROR - 2021-03-25 11:45:05 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 11:45:05 --> Config Class Initialized
INFO - 2021-03-25 11:45:05 --> Config Class Initialized
INFO - 2021-03-25 11:45:05 --> Config Class Initialized
INFO - 2021-03-25 11:45:05 --> Hooks Class Initialized
INFO - 2021-03-25 11:45:05 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:45:05 --> UTF-8 Support Enabled
DEBUG - 2021-03-25 11:45:05 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:45:05 --> Utf8 Class Initialized
INFO - 2021-03-25 11:45:05 --> Utf8 Class Initialized
INFO - 2021-03-25 11:45:05 --> URI Class Initialized
INFO - 2021-03-25 11:45:05 --> URI Class Initialized
INFO - 2021-03-25 11:45:05 --> Router Class Initialized
INFO - 2021-03-25 11:45:05 --> Router Class Initialized
INFO - 2021-03-25 11:45:05 --> Output Class Initialized
INFO - 2021-03-25 11:45:05 --> Output Class Initialized
INFO - 2021-03-25 11:45:05 --> Security Class Initialized
INFO - 2021-03-25 11:45:05 --> Security Class Initialized
DEBUG - 2021-03-25 11:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-25 11:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:45:05 --> Input Class Initialized
INFO - 2021-03-25 11:45:05 --> Input Class Initialized
INFO - 2021-03-25 11:45:05 --> Language Class Initialized
INFO - 2021-03-25 11:45:05 --> Language Class Initialized
ERROR - 2021-03-25 11:45:05 --> 404 Page Not Found: Adminassets/js
ERROR - 2021-03-25 11:45:05 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-25 11:45:05 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:45:05 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:45:05 --> Utf8 Class Initialized
INFO - 2021-03-25 11:45:05 --> URI Class Initialized
INFO - 2021-03-25 11:45:05 --> Router Class Initialized
INFO - 2021-03-25 11:45:05 --> Output Class Initialized
INFO - 2021-03-25 11:45:05 --> Security Class Initialized
DEBUG - 2021-03-25 11:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:45:05 --> Input Class Initialized
INFO - 2021-03-25 11:45:05 --> Language Class Initialized
ERROR - 2021-03-25 11:45:05 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 11:45:05 --> Config Class Initialized
INFO - 2021-03-25 11:45:05 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:45:05 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:45:05 --> Utf8 Class Initialized
INFO - 2021-03-25 11:45:05 --> URI Class Initialized
INFO - 2021-03-25 11:45:05 --> Router Class Initialized
INFO - 2021-03-25 11:45:05 --> Output Class Initialized
INFO - 2021-03-25 11:45:05 --> Security Class Initialized
DEBUG - 2021-03-25 11:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:45:05 --> Input Class Initialized
INFO - 2021-03-25 11:45:05 --> Language Class Initialized
ERROR - 2021-03-25 11:45:05 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 11:45:07 --> Config Class Initialized
INFO - 2021-03-25 11:45:07 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:45:07 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:45:07 --> Utf8 Class Initialized
INFO - 2021-03-25 11:45:07 --> URI Class Initialized
INFO - 2021-03-25 11:45:07 --> Router Class Initialized
INFO - 2021-03-25 11:45:07 --> Output Class Initialized
INFO - 2021-03-25 11:45:07 --> Security Class Initialized
DEBUG - 2021-03-25 11:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:45:07 --> Input Class Initialized
INFO - 2021-03-25 11:45:07 --> Language Class Initialized
INFO - 2021-03-25 11:45:07 --> Loader Class Initialized
INFO - 2021-03-25 11:45:07 --> Helper loaded: url_helper
INFO - 2021-03-25 11:45:07 --> Helper loaded: file_helper
INFO - 2021-03-25 11:45:07 --> Helper loaded: form_helper
INFO - 2021-03-25 11:45:07 --> Helper loaded: text_helper
INFO - 2021-03-25 11:45:07 --> Helper loaded: security_helper
INFO - 2021-03-25 11:45:07 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:45:07 --> Database Driver Class Initialized
INFO - 2021-03-25 11:45:07 --> Email Class Initialized
DEBUG - 2021-03-25 11:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:45:07 --> Form Validation Class Initialized
INFO - 2021-03-25 11:45:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:45:07 --> Pagination Class Initialized
INFO - 2021-03-25 11:45:07 --> Model Class Initialized
INFO - 2021-03-25 11:45:07 --> Controller Class Initialized
INFO - 2021-03-25 11:45:07 --> Model Class Initialized
INFO - 2021-03-25 11:45:07 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 11:45:07 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 11:45:07 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 11:45:07 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 11:45:07 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 11:45:07 --> Final output sent to browser
DEBUG - 2021-03-25 11:45:07 --> Total execution time: 0.5052
INFO - 2021-03-25 11:45:07 --> Config Class Initialized
INFO - 2021-03-25 11:45:07 --> Hooks Class Initialized
INFO - 2021-03-25 11:45:08 --> Config Class Initialized
DEBUG - 2021-03-25 11:45:08 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:45:08 --> Utf8 Class Initialized
INFO - 2021-03-25 11:45:08 --> URI Class Initialized
INFO - 2021-03-25 11:45:08 --> Router Class Initialized
INFO - 2021-03-25 11:45:08 --> Output Class Initialized
INFO - 2021-03-25 11:45:08 --> Security Class Initialized
INFO - 2021-03-25 11:45:08 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:45:08 --> Input Class Initialized
INFO - 2021-03-25 11:45:08 --> Language Class Initialized
ERROR - 2021-03-25 11:45:08 --> 404 Page Not Found: Js/demo
DEBUG - 2021-03-25 11:45:08 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:45:08 --> Utf8 Class Initialized
INFO - 2021-03-25 11:45:08 --> URI Class Initialized
INFO - 2021-03-25 11:45:08 --> Router Class Initialized
INFO - 2021-03-25 11:45:08 --> Output Class Initialized
INFO - 2021-03-25 11:45:08 --> Security Class Initialized
DEBUG - 2021-03-25 11:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:45:08 --> Input Class Initialized
INFO - 2021-03-25 11:45:08 --> Language Class Initialized
INFO - 2021-03-25 11:45:08 --> Config Class Initialized
INFO - 2021-03-25 11:45:08 --> Config Class Initialized
INFO - 2021-03-25 11:45:08 --> Hooks Class Initialized
INFO - 2021-03-25 11:45:08 --> Hooks Class Initialized
INFO - 2021-03-25 11:45:08 --> Config Class Initialized
INFO - 2021-03-25 11:45:08 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:45:08 --> UTF-8 Support Enabled
DEBUG - 2021-03-25 11:45:08 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:45:08 --> Utf8 Class Initialized
ERROR - 2021-03-25 11:45:08 --> 404 Page Not Found: Adminassets/css
DEBUG - 2021-03-25 11:45:08 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:45:08 --> Utf8 Class Initialized
INFO - 2021-03-25 11:45:08 --> URI Class Initialized
INFO - 2021-03-25 11:45:08 --> URI Class Initialized
INFO - 2021-03-25 11:45:08 --> Router Class Initialized
INFO - 2021-03-25 11:45:08 --> Router Class Initialized
INFO - 2021-03-25 11:45:08 --> Output Class Initialized
INFO - 2021-03-25 11:45:08 --> Output Class Initialized
INFO - 2021-03-25 11:45:08 --> Security Class Initialized
DEBUG - 2021-03-25 11:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:45:08 --> Security Class Initialized
INFO - 2021-03-25 11:45:08 --> Input Class Initialized
INFO - 2021-03-25 11:45:08 --> Language Class Initialized
DEBUG - 2021-03-25 11:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:45:08 --> Input Class Initialized
ERROR - 2021-03-25 11:45:08 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-25 11:45:08 --> Language Class Initialized
ERROR - 2021-03-25 11:45:08 --> 404 Page Not Found: Adminassets/js
INFO - 2021-03-25 11:45:08 --> Utf8 Class Initialized
INFO - 2021-03-25 11:45:08 --> URI Class Initialized
INFO - 2021-03-25 11:45:08 --> Router Class Initialized
INFO - 2021-03-25 11:45:08 --> Output Class Initialized
INFO - 2021-03-25 11:45:08 --> Security Class Initialized
DEBUG - 2021-03-25 11:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:45:08 --> Input Class Initialized
INFO - 2021-03-25 11:45:08 --> Language Class Initialized
ERROR - 2021-03-25 11:45:08 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 11:45:08 --> Config Class Initialized
INFO - 2021-03-25 11:45:08 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:45:08 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:45:08 --> Utf8 Class Initialized
INFO - 2021-03-25 11:45:08 --> URI Class Initialized
INFO - 2021-03-25 11:45:08 --> Router Class Initialized
INFO - 2021-03-25 11:45:08 --> Output Class Initialized
INFO - 2021-03-25 11:45:08 --> Security Class Initialized
DEBUG - 2021-03-25 11:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:45:08 --> Input Class Initialized
INFO - 2021-03-25 11:45:08 --> Language Class Initialized
ERROR - 2021-03-25 11:45:08 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 11:48:30 --> Config Class Initialized
INFO - 2021-03-25 11:48:30 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:48:30 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:48:30 --> Utf8 Class Initialized
INFO - 2021-03-25 11:48:30 --> URI Class Initialized
INFO - 2021-03-25 11:48:30 --> Router Class Initialized
INFO - 2021-03-25 11:48:30 --> Output Class Initialized
INFO - 2021-03-25 11:48:30 --> Security Class Initialized
DEBUG - 2021-03-25 11:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:48:30 --> Input Class Initialized
INFO - 2021-03-25 11:48:30 --> Language Class Initialized
INFO - 2021-03-25 11:48:30 --> Loader Class Initialized
INFO - 2021-03-25 11:48:30 --> Helper loaded: url_helper
INFO - 2021-03-25 11:48:30 --> Helper loaded: file_helper
INFO - 2021-03-25 11:48:30 --> Helper loaded: form_helper
INFO - 2021-03-25 11:48:30 --> Helper loaded: text_helper
INFO - 2021-03-25 11:48:30 --> Helper loaded: security_helper
INFO - 2021-03-25 11:48:30 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:48:30 --> Database Driver Class Initialized
INFO - 2021-03-25 11:48:30 --> Email Class Initialized
DEBUG - 2021-03-25 11:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:48:30 --> Form Validation Class Initialized
INFO - 2021-03-25 11:48:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:48:30 --> Pagination Class Initialized
INFO - 2021-03-25 11:48:30 --> Model Class Initialized
INFO - 2021-03-25 11:48:30 --> Controller Class Initialized
INFO - 2021-03-25 11:48:30 --> Model Class Initialized
INFO - 2021-03-25 11:48:30 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 11:48:30 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 11:48:30 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 11:48:30 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 11:48:30 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 11:48:31 --> Final output sent to browser
DEBUG - 2021-03-25 11:48:31 --> Total execution time: 0.5199
INFO - 2021-03-25 11:48:31 --> Config Class Initialized
INFO - 2021-03-25 11:48:31 --> Hooks Class Initialized
INFO - 2021-03-25 11:48:31 --> Config Class Initialized
INFO - 2021-03-25 11:48:31 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:48:31 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:48:31 --> Utf8 Class Initialized
INFO - 2021-03-25 11:48:31 --> URI Class Initialized
DEBUG - 2021-03-25 11:48:31 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:48:31 --> Utf8 Class Initialized
INFO - 2021-03-25 11:48:31 --> URI Class Initialized
INFO - 2021-03-25 11:48:31 --> Router Class Initialized
INFO - 2021-03-25 11:48:31 --> Output Class Initialized
INFO - 2021-03-25 11:48:31 --> Security Class Initialized
INFO - 2021-03-25 11:48:31 --> Router Class Initialized
INFO - 2021-03-25 11:48:31 --> Output Class Initialized
INFO - 2021-03-25 11:48:31 --> Security Class Initialized
DEBUG - 2021-03-25 11:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:48:31 --> Input Class Initialized
INFO - 2021-03-25 11:48:31 --> Language Class Initialized
ERROR - 2021-03-25 11:48:31 --> 404 Page Not Found: Adminassets/css
DEBUG - 2021-03-25 11:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:48:31 --> Input Class Initialized
INFO - 2021-03-25 11:48:31 --> Language Class Initialized
ERROR - 2021-03-25 11:48:31 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 11:48:31 --> Config Class Initialized
INFO - 2021-03-25 11:48:31 --> Config Class Initialized
INFO - 2021-03-25 11:48:31 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:48:31 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:48:31 --> Utf8 Class Initialized
INFO - 2021-03-25 11:48:31 --> Config Class Initialized
INFO - 2021-03-25 11:48:31 --> Hooks Class Initialized
INFO - 2021-03-25 11:48:31 --> URI Class Initialized
INFO - 2021-03-25 11:48:31 --> Router Class Initialized
DEBUG - 2021-03-25 11:48:31 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:48:31 --> Utf8 Class Initialized
INFO - 2021-03-25 11:48:31 --> URI Class Initialized
INFO - 2021-03-25 11:48:31 --> Output Class Initialized
INFO - 2021-03-25 11:48:31 --> Router Class Initialized
INFO - 2021-03-25 11:48:31 --> Security Class Initialized
DEBUG - 2021-03-25 11:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:48:31 --> Input Class Initialized
INFO - 2021-03-25 11:48:31 --> Output Class Initialized
INFO - 2021-03-25 11:48:31 --> Language Class Initialized
INFO - 2021-03-25 11:48:31 --> Security Class Initialized
ERROR - 2021-03-25 11:48:31 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-25 11:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:48:31 --> Input Class Initialized
INFO - 2021-03-25 11:48:31 --> Hooks Class Initialized
INFO - 2021-03-25 11:48:31 --> Language Class Initialized
ERROR - 2021-03-25 11:48:31 --> 404 Page Not Found: Adminassets/js
DEBUG - 2021-03-25 11:48:31 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:48:31 --> Utf8 Class Initialized
INFO - 2021-03-25 11:48:31 --> URI Class Initialized
INFO - 2021-03-25 11:48:31 --> Router Class Initialized
INFO - 2021-03-25 11:48:31 --> Output Class Initialized
INFO - 2021-03-25 11:48:31 --> Security Class Initialized
DEBUG - 2021-03-25 11:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:48:31 --> Input Class Initialized
INFO - 2021-03-25 11:48:31 --> Language Class Initialized
ERROR - 2021-03-25 11:48:31 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 11:48:31 --> Config Class Initialized
INFO - 2021-03-25 11:48:31 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:48:31 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:48:31 --> Utf8 Class Initialized
INFO - 2021-03-25 11:48:31 --> URI Class Initialized
INFO - 2021-03-25 11:48:31 --> Router Class Initialized
INFO - 2021-03-25 11:48:32 --> Output Class Initialized
INFO - 2021-03-25 11:48:32 --> Security Class Initialized
DEBUG - 2021-03-25 11:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:48:32 --> Input Class Initialized
INFO - 2021-03-25 11:48:32 --> Language Class Initialized
ERROR - 2021-03-25 11:48:32 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 11:48:35 --> Config Class Initialized
INFO - 2021-03-25 11:48:35 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:48:35 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:48:35 --> Utf8 Class Initialized
INFO - 2021-03-25 11:48:35 --> URI Class Initialized
INFO - 2021-03-25 11:48:35 --> Router Class Initialized
INFO - 2021-03-25 11:48:35 --> Output Class Initialized
INFO - 2021-03-25 11:48:35 --> Security Class Initialized
DEBUG - 2021-03-25 11:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:48:35 --> Input Class Initialized
INFO - 2021-03-25 11:48:35 --> Language Class Initialized
INFO - 2021-03-25 11:48:35 --> Loader Class Initialized
INFO - 2021-03-25 11:48:35 --> Helper loaded: url_helper
INFO - 2021-03-25 11:48:35 --> Helper loaded: file_helper
INFO - 2021-03-25 11:48:35 --> Helper loaded: form_helper
INFO - 2021-03-25 11:48:35 --> Helper loaded: text_helper
INFO - 2021-03-25 11:48:35 --> Helper loaded: security_helper
INFO - 2021-03-25 11:48:35 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:48:35 --> Database Driver Class Initialized
INFO - 2021-03-25 11:48:35 --> Email Class Initialized
DEBUG - 2021-03-25 11:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:48:35 --> Form Validation Class Initialized
INFO - 2021-03-25 11:48:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:48:35 --> Pagination Class Initialized
INFO - 2021-03-25 11:48:35 --> Model Class Initialized
INFO - 2021-03-25 11:48:35 --> Controller Class Initialized
INFO - 2021-03-25 11:48:35 --> Model Class Initialized
ERROR - 2021-03-25 11:48:35 --> Severity: error --> Exception: Object of class LoginController could not be converted to string C:\wamp64\www\RDA_Web\adminpoint\application\controllers\LoginController.php 60
INFO - 2021-03-25 11:49:12 --> Config Class Initialized
INFO - 2021-03-25 11:49:12 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:49:12 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:49:12 --> Utf8 Class Initialized
INFO - 2021-03-25 11:49:12 --> URI Class Initialized
INFO - 2021-03-25 11:49:12 --> Router Class Initialized
INFO - 2021-03-25 11:49:12 --> Output Class Initialized
INFO - 2021-03-25 11:49:12 --> Security Class Initialized
DEBUG - 2021-03-25 11:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:49:13 --> Input Class Initialized
INFO - 2021-03-25 11:49:13 --> Language Class Initialized
INFO - 2021-03-25 11:49:13 --> Loader Class Initialized
INFO - 2021-03-25 11:49:13 --> Helper loaded: url_helper
INFO - 2021-03-25 11:49:13 --> Helper loaded: file_helper
INFO - 2021-03-25 11:49:13 --> Helper loaded: form_helper
INFO - 2021-03-25 11:49:13 --> Helper loaded: text_helper
INFO - 2021-03-25 11:49:13 --> Helper loaded: security_helper
INFO - 2021-03-25 11:49:13 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:49:13 --> Database Driver Class Initialized
INFO - 2021-03-25 11:49:13 --> Email Class Initialized
DEBUG - 2021-03-25 11:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:49:13 --> Form Validation Class Initialized
INFO - 2021-03-25 11:49:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:49:13 --> Pagination Class Initialized
INFO - 2021-03-25 11:49:13 --> Model Class Initialized
INFO - 2021-03-25 11:49:13 --> Controller Class Initialized
INFO - 2021-03-25 11:49:13 --> Model Class Initialized
ERROR - 2021-03-25 11:49:13 --> Severity: error --> Exception: Object of class LoginController could not be converted to string C:\wamp64\www\RDA_Web\adminpoint\application\controllers\LoginController.php 60
INFO - 2021-03-25 11:49:25 --> Config Class Initialized
INFO - 2021-03-25 11:49:25 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:49:25 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:49:25 --> Utf8 Class Initialized
INFO - 2021-03-25 11:49:25 --> URI Class Initialized
INFO - 2021-03-25 11:49:25 --> Router Class Initialized
INFO - 2021-03-25 11:49:25 --> Output Class Initialized
INFO - 2021-03-25 11:49:25 --> Security Class Initialized
DEBUG - 2021-03-25 11:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:49:25 --> Input Class Initialized
INFO - 2021-03-25 11:49:25 --> Language Class Initialized
INFO - 2021-03-25 11:49:25 --> Loader Class Initialized
INFO - 2021-03-25 11:49:25 --> Helper loaded: url_helper
INFO - 2021-03-25 11:49:25 --> Helper loaded: file_helper
INFO - 2021-03-25 11:49:25 --> Helper loaded: form_helper
INFO - 2021-03-25 11:49:25 --> Helper loaded: text_helper
INFO - 2021-03-25 11:49:25 --> Helper loaded: security_helper
INFO - 2021-03-25 11:49:25 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:49:25 --> Database Driver Class Initialized
INFO - 2021-03-25 11:49:25 --> Email Class Initialized
DEBUG - 2021-03-25 11:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:49:25 --> Form Validation Class Initialized
INFO - 2021-03-25 11:49:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:49:25 --> Pagination Class Initialized
INFO - 2021-03-25 11:49:25 --> Model Class Initialized
INFO - 2021-03-25 11:49:25 --> Controller Class Initialized
INFO - 2021-03-25 11:49:25 --> Model Class Initialized
INFO - 2021-03-25 11:49:32 --> Config Class Initialized
INFO - 2021-03-25 11:49:32 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:49:32 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:49:32 --> Utf8 Class Initialized
INFO - 2021-03-25 11:49:32 --> URI Class Initialized
INFO - 2021-03-25 11:49:32 --> Router Class Initialized
INFO - 2021-03-25 11:49:32 --> Output Class Initialized
INFO - 2021-03-25 11:49:32 --> Security Class Initialized
DEBUG - 2021-03-25 11:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:49:32 --> Input Class Initialized
INFO - 2021-03-25 11:49:32 --> Language Class Initialized
INFO - 2021-03-25 11:49:32 --> Loader Class Initialized
INFO - 2021-03-25 11:49:32 --> Helper loaded: url_helper
INFO - 2021-03-25 11:49:32 --> Helper loaded: file_helper
INFO - 2021-03-25 11:49:32 --> Helper loaded: form_helper
INFO - 2021-03-25 11:49:32 --> Helper loaded: text_helper
INFO - 2021-03-25 11:49:32 --> Helper loaded: security_helper
INFO - 2021-03-25 11:49:32 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:49:32 --> Database Driver Class Initialized
INFO - 2021-03-25 11:49:32 --> Email Class Initialized
DEBUG - 2021-03-25 11:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:49:32 --> Form Validation Class Initialized
INFO - 2021-03-25 11:49:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:49:32 --> Pagination Class Initialized
INFO - 2021-03-25 11:49:32 --> Model Class Initialized
INFO - 2021-03-25 11:49:32 --> Controller Class Initialized
INFO - 2021-03-25 11:49:32 --> Model Class Initialized
INFO - 2021-03-25 11:49:32 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-25 11:49:32 --> Final output sent to browser
DEBUG - 2021-03-25 11:49:32 --> Total execution time: 0.4802
INFO - 2021-03-25 11:49:33 --> Config Class Initialized
INFO - 2021-03-25 11:49:33 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:49:33 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:49:33 --> Utf8 Class Initialized
INFO - 2021-03-25 11:49:33 --> URI Class Initialized
INFO - 2021-03-25 11:49:33 --> Router Class Initialized
INFO - 2021-03-25 11:49:33 --> Output Class Initialized
INFO - 2021-03-25 11:49:33 --> Security Class Initialized
DEBUG - 2021-03-25 11:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:49:33 --> Input Class Initialized
INFO - 2021-03-25 11:49:33 --> Language Class Initialized
ERROR - 2021-03-25 11:49:33 --> 404 Page Not Found: Adminassets/css
INFO - 2021-03-25 11:50:11 --> Config Class Initialized
INFO - 2021-03-25 11:50:11 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:50:11 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:50:11 --> Utf8 Class Initialized
INFO - 2021-03-25 11:50:11 --> URI Class Initialized
INFO - 2021-03-25 11:50:11 --> Router Class Initialized
INFO - 2021-03-25 11:50:11 --> Output Class Initialized
INFO - 2021-03-25 11:50:11 --> Security Class Initialized
DEBUG - 2021-03-25 11:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:50:11 --> Input Class Initialized
INFO - 2021-03-25 11:50:11 --> Language Class Initialized
ERROR - 2021-03-25 11:50:11 --> 404 Page Not Found: Admin-login/index
INFO - 2021-03-25 11:50:27 --> Config Class Initialized
INFO - 2021-03-25 11:50:27 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:50:27 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:50:27 --> Utf8 Class Initialized
INFO - 2021-03-25 11:50:27 --> URI Class Initialized
INFO - 2021-03-25 11:50:27 --> Router Class Initialized
INFO - 2021-03-25 11:50:27 --> Output Class Initialized
INFO - 2021-03-25 11:50:27 --> Security Class Initialized
DEBUG - 2021-03-25 11:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:50:27 --> Input Class Initialized
INFO - 2021-03-25 11:50:27 --> Language Class Initialized
INFO - 2021-03-25 11:50:27 --> Loader Class Initialized
INFO - 2021-03-25 11:50:27 --> Helper loaded: url_helper
INFO - 2021-03-25 11:50:27 --> Helper loaded: file_helper
INFO - 2021-03-25 11:50:27 --> Helper loaded: form_helper
INFO - 2021-03-25 11:50:27 --> Helper loaded: text_helper
INFO - 2021-03-25 11:50:27 --> Helper loaded: security_helper
INFO - 2021-03-25 11:50:27 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:50:27 --> Database Driver Class Initialized
INFO - 2021-03-25 11:50:27 --> Email Class Initialized
DEBUG - 2021-03-25 11:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:50:27 --> Form Validation Class Initialized
INFO - 2021-03-25 11:50:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:50:27 --> Pagination Class Initialized
INFO - 2021-03-25 11:50:27 --> Model Class Initialized
INFO - 2021-03-25 11:50:27 --> Controller Class Initialized
INFO - 2021-03-25 11:50:27 --> Model Class Initialized
INFO - 2021-03-25 11:50:27 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\login.php
INFO - 2021-03-25 11:50:27 --> Final output sent to browser
DEBUG - 2021-03-25 11:50:27 --> Total execution time: 0.4603
INFO - 2021-03-25 11:50:33 --> Config Class Initialized
INFO - 2021-03-25 11:50:33 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:50:33 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:50:33 --> Utf8 Class Initialized
INFO - 2021-03-25 11:50:33 --> URI Class Initialized
INFO - 2021-03-25 11:50:33 --> Router Class Initialized
INFO - 2021-03-25 11:50:33 --> Output Class Initialized
INFO - 2021-03-25 11:50:33 --> Security Class Initialized
DEBUG - 2021-03-25 11:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:50:33 --> Input Class Initialized
INFO - 2021-03-25 11:50:33 --> Language Class Initialized
INFO - 2021-03-25 11:50:33 --> Loader Class Initialized
INFO - 2021-03-25 11:50:33 --> Helper loaded: url_helper
INFO - 2021-03-25 11:50:33 --> Helper loaded: file_helper
INFO - 2021-03-25 11:50:33 --> Helper loaded: form_helper
INFO - 2021-03-25 11:50:33 --> Helper loaded: text_helper
INFO - 2021-03-25 11:50:33 --> Helper loaded: security_helper
INFO - 2021-03-25 11:50:33 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:50:33 --> Database Driver Class Initialized
INFO - 2021-03-25 11:50:33 --> Email Class Initialized
DEBUG - 2021-03-25 11:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:50:33 --> Form Validation Class Initialized
INFO - 2021-03-25 11:50:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:50:33 --> Pagination Class Initialized
INFO - 2021-03-25 11:50:33 --> Model Class Initialized
INFO - 2021-03-25 11:50:33 --> Controller Class Initialized
INFO - 2021-03-25 11:50:33 --> Model Class Initialized
INFO - 2021-03-25 11:50:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-25 11:50:34 --> Config Class Initialized
INFO - 2021-03-25 11:50:34 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:50:34 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:50:34 --> Utf8 Class Initialized
INFO - 2021-03-25 11:50:34 --> URI Class Initialized
INFO - 2021-03-25 11:50:34 --> Router Class Initialized
INFO - 2021-03-25 11:50:34 --> Output Class Initialized
INFO - 2021-03-25 11:50:34 --> Security Class Initialized
DEBUG - 2021-03-25 11:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:50:34 --> Input Class Initialized
INFO - 2021-03-25 11:50:34 --> Language Class Initialized
INFO - 2021-03-25 11:50:34 --> Loader Class Initialized
INFO - 2021-03-25 11:50:34 --> Helper loaded: url_helper
INFO - 2021-03-25 11:50:34 --> Helper loaded: file_helper
INFO - 2021-03-25 11:50:34 --> Helper loaded: form_helper
INFO - 2021-03-25 11:50:34 --> Helper loaded: text_helper
INFO - 2021-03-25 11:50:34 --> Helper loaded: security_helper
INFO - 2021-03-25 11:50:34 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:50:34 --> Database Driver Class Initialized
INFO - 2021-03-25 11:50:34 --> Email Class Initialized
DEBUG - 2021-03-25 11:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:50:34 --> Form Validation Class Initialized
INFO - 2021-03-25 11:50:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:50:34 --> Pagination Class Initialized
INFO - 2021-03-25 11:50:34 --> Model Class Initialized
INFO - 2021-03-25 11:50:34 --> Controller Class Initialized
INFO - 2021-03-25 11:50:34 --> Model Class Initialized
INFO - 2021-03-25 11:50:34 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 11:50:34 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 11:50:34 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 11:50:34 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 11:50:34 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 11:50:34 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 11:50:34 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 11:50:34 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 11:50:34 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 11:50:34 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 11:50:34 --> Final output sent to browser
DEBUG - 2021-03-25 11:50:34 --> Total execution time: 0.6382
INFO - 2021-03-25 11:50:34 --> Config Class Initialized
INFO - 2021-03-25 11:50:34 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:50:34 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:50:34 --> Utf8 Class Initialized
INFO - 2021-03-25 11:50:34 --> URI Class Initialized
INFO - 2021-03-25 11:50:34 --> Router Class Initialized
INFO - 2021-03-25 11:50:35 --> Output Class Initialized
INFO - 2021-03-25 11:50:35 --> Security Class Initialized
DEBUG - 2021-03-25 11:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:50:35 --> Input Class Initialized
INFO - 2021-03-25 11:50:35 --> Language Class Initialized
ERROR - 2021-03-25 11:50:35 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 11:50:35 --> Config Class Initialized
INFO - 2021-03-25 11:50:35 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:50:35 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:50:35 --> Utf8 Class Initialized
INFO - 2021-03-25 11:50:35 --> URI Class Initialized
INFO - 2021-03-25 11:50:35 --> Router Class Initialized
INFO - 2021-03-25 11:50:35 --> Output Class Initialized
INFO - 2021-03-25 11:50:35 --> Security Class Initialized
DEBUG - 2021-03-25 11:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:50:35 --> Input Class Initialized
INFO - 2021-03-25 11:50:35 --> Language Class Initialized
ERROR - 2021-03-25 11:50:35 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 11:50:35 --> Config Class Initialized
INFO - 2021-03-25 11:50:35 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:50:35 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:50:35 --> Utf8 Class Initialized
INFO - 2021-03-25 11:50:35 --> URI Class Initialized
INFO - 2021-03-25 11:50:35 --> Router Class Initialized
INFO - 2021-03-25 11:50:35 --> Output Class Initialized
INFO - 2021-03-25 11:50:35 --> Security Class Initialized
DEBUG - 2021-03-25 11:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:50:35 --> Input Class Initialized
INFO - 2021-03-25 11:50:35 --> Language Class Initialized
ERROR - 2021-03-25 11:50:35 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 11:50:35 --> Config Class Initialized
INFO - 2021-03-25 11:50:35 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:50:35 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:50:35 --> Utf8 Class Initialized
INFO - 2021-03-25 11:50:35 --> URI Class Initialized
INFO - 2021-03-25 11:50:35 --> Router Class Initialized
INFO - 2021-03-25 11:50:35 --> Output Class Initialized
INFO - 2021-03-25 11:50:36 --> Security Class Initialized
DEBUG - 2021-03-25 11:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:50:36 --> Input Class Initialized
INFO - 2021-03-25 11:50:36 --> Language Class Initialized
ERROR - 2021-03-25 11:50:36 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 11:50:55 --> Config Class Initialized
INFO - 2021-03-25 11:50:55 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:50:55 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:50:55 --> Utf8 Class Initialized
INFO - 2021-03-25 11:50:55 --> URI Class Initialized
INFO - 2021-03-25 11:50:55 --> Router Class Initialized
INFO - 2021-03-25 11:50:55 --> Output Class Initialized
INFO - 2021-03-25 11:50:55 --> Security Class Initialized
DEBUG - 2021-03-25 11:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:50:55 --> Input Class Initialized
INFO - 2021-03-25 11:50:55 --> Language Class Initialized
INFO - 2021-03-25 11:50:55 --> Loader Class Initialized
INFO - 2021-03-25 11:50:55 --> Helper loaded: url_helper
INFO - 2021-03-25 11:50:55 --> Helper loaded: file_helper
INFO - 2021-03-25 11:50:55 --> Helper loaded: form_helper
INFO - 2021-03-25 11:50:55 --> Helper loaded: text_helper
INFO - 2021-03-25 11:50:55 --> Helper loaded: security_helper
INFO - 2021-03-25 11:50:55 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:50:55 --> Database Driver Class Initialized
INFO - 2021-03-25 11:50:55 --> Email Class Initialized
DEBUG - 2021-03-25 11:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:50:55 --> Form Validation Class Initialized
INFO - 2021-03-25 11:50:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:50:55 --> Pagination Class Initialized
INFO - 2021-03-25 11:50:55 --> Model Class Initialized
INFO - 2021-03-25 11:50:55 --> Controller Class Initialized
INFO - 2021-03-25 11:50:55 --> Model Class Initialized
INFO - 2021-03-25 11:50:56 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 11:50:56 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 11:50:56 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 11:50:56 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 11:50:56 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 11:50:56 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 11:50:56 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 11:50:56 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 11:50:56 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\tender.php
INFO - 2021-03-25 11:50:56 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 11:50:56 --> Final output sent to browser
DEBUG - 2021-03-25 11:50:56 --> Total execution time: 0.5933
INFO - 2021-03-25 11:50:56 --> Config Class Initialized
INFO - 2021-03-25 11:50:56 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:50:56 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:50:56 --> Utf8 Class Initialized
INFO - 2021-03-25 11:50:56 --> URI Class Initialized
INFO - 2021-03-25 11:50:56 --> Router Class Initialized
INFO - 2021-03-25 11:50:56 --> Output Class Initialized
INFO - 2021-03-25 11:50:56 --> Security Class Initialized
DEBUG - 2021-03-25 11:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:50:56 --> Input Class Initialized
INFO - 2021-03-25 11:50:56 --> Language Class Initialized
ERROR - 2021-03-25 11:50:56 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 11:50:56 --> Config Class Initialized
INFO - 2021-03-25 11:50:56 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:50:56 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:50:56 --> Utf8 Class Initialized
INFO - 2021-03-25 11:50:56 --> URI Class Initialized
INFO - 2021-03-25 11:50:56 --> Router Class Initialized
INFO - 2021-03-25 11:50:56 --> Output Class Initialized
INFO - 2021-03-25 11:50:56 --> Security Class Initialized
DEBUG - 2021-03-25 11:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:50:56 --> Input Class Initialized
INFO - 2021-03-25 11:50:56 --> Language Class Initialized
ERROR - 2021-03-25 11:50:56 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 11:50:56 --> Config Class Initialized
INFO - 2021-03-25 11:50:56 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:50:56 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:50:56 --> Utf8 Class Initialized
INFO - 2021-03-25 11:50:56 --> URI Class Initialized
INFO - 2021-03-25 11:50:56 --> Router Class Initialized
INFO - 2021-03-25 11:50:56 --> Output Class Initialized
INFO - 2021-03-25 11:50:56 --> Security Class Initialized
DEBUG - 2021-03-25 11:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:50:56 --> Input Class Initialized
INFO - 2021-03-25 11:50:57 --> Language Class Initialized
ERROR - 2021-03-25 11:50:57 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 11:50:57 --> Config Class Initialized
INFO - 2021-03-25 11:50:57 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:50:57 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:50:57 --> Utf8 Class Initialized
INFO - 2021-03-25 11:50:57 --> URI Class Initialized
INFO - 2021-03-25 11:50:57 --> Router Class Initialized
INFO - 2021-03-25 11:50:57 --> Output Class Initialized
INFO - 2021-03-25 11:50:57 --> Security Class Initialized
DEBUG - 2021-03-25 11:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:50:57 --> Input Class Initialized
INFO - 2021-03-25 11:50:57 --> Language Class Initialized
ERROR - 2021-03-25 11:50:57 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 11:51:31 --> Config Class Initialized
INFO - 2021-03-25 11:51:31 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:51:31 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:51:31 --> Utf8 Class Initialized
INFO - 2021-03-25 11:51:31 --> URI Class Initialized
INFO - 2021-03-25 11:51:31 --> Router Class Initialized
INFO - 2021-03-25 11:51:31 --> Output Class Initialized
INFO - 2021-03-25 11:51:31 --> Security Class Initialized
DEBUG - 2021-03-25 11:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:51:31 --> Input Class Initialized
INFO - 2021-03-25 11:51:31 --> Language Class Initialized
ERROR - 2021-03-25 11:51:31 --> 404 Page Not Found: Tender_upload/index
INFO - 2021-03-25 11:51:32 --> Config Class Initialized
INFO - 2021-03-25 11:51:32 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:51:32 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:51:32 --> Utf8 Class Initialized
INFO - 2021-03-25 11:51:32 --> URI Class Initialized
INFO - 2021-03-25 11:51:33 --> Router Class Initialized
INFO - 2021-03-25 11:51:33 --> Output Class Initialized
INFO - 2021-03-25 11:51:33 --> Security Class Initialized
DEBUG - 2021-03-25 11:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:51:33 --> Input Class Initialized
INFO - 2021-03-25 11:51:33 --> Language Class Initialized
INFO - 2021-03-25 11:51:33 --> Loader Class Initialized
INFO - 2021-03-25 11:51:33 --> Helper loaded: url_helper
INFO - 2021-03-25 11:51:33 --> Helper loaded: file_helper
INFO - 2021-03-25 11:51:33 --> Helper loaded: form_helper
INFO - 2021-03-25 11:51:33 --> Helper loaded: text_helper
INFO - 2021-03-25 11:51:33 --> Helper loaded: security_helper
INFO - 2021-03-25 11:51:33 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:51:33 --> Database Driver Class Initialized
INFO - 2021-03-25 11:51:33 --> Email Class Initialized
DEBUG - 2021-03-25 11:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:51:33 --> Form Validation Class Initialized
INFO - 2021-03-25 11:51:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:51:33 --> Pagination Class Initialized
INFO - 2021-03-25 11:51:33 --> Model Class Initialized
INFO - 2021-03-25 11:51:33 --> Controller Class Initialized
INFO - 2021-03-25 11:51:33 --> Model Class Initialized
INFO - 2021-03-25 11:51:33 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 11:51:33 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 11:51:33 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 11:51:33 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 11:51:33 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 11:51:33 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 11:51:33 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 11:51:33 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 11:51:33 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 11:51:33 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 11:51:33 --> Final output sent to browser
DEBUG - 2021-03-25 11:51:33 --> Total execution time: 0.6926
INFO - 2021-03-25 11:51:36 --> Config Class Initialized
INFO - 2021-03-25 11:51:36 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:51:36 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:51:36 --> Utf8 Class Initialized
INFO - 2021-03-25 11:51:36 --> URI Class Initialized
INFO - 2021-03-25 11:51:36 --> Router Class Initialized
INFO - 2021-03-25 11:51:36 --> Output Class Initialized
INFO - 2021-03-25 11:51:36 --> Security Class Initialized
DEBUG - 2021-03-25 11:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:51:36 --> Input Class Initialized
INFO - 2021-03-25 11:51:36 --> Language Class Initialized
INFO - 2021-03-25 11:51:36 --> Loader Class Initialized
INFO - 2021-03-25 11:51:36 --> Helper loaded: url_helper
INFO - 2021-03-25 11:51:36 --> Helper loaded: file_helper
INFO - 2021-03-25 11:51:36 --> Helper loaded: form_helper
INFO - 2021-03-25 11:51:36 --> Helper loaded: text_helper
INFO - 2021-03-25 11:51:36 --> Helper loaded: security_helper
INFO - 2021-03-25 11:51:36 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:51:36 --> Database Driver Class Initialized
INFO - 2021-03-25 11:51:36 --> Email Class Initialized
DEBUG - 2021-03-25 11:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:51:36 --> Form Validation Class Initialized
INFO - 2021-03-25 11:51:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:51:36 --> Pagination Class Initialized
INFO - 2021-03-25 11:51:36 --> Model Class Initialized
INFO - 2021-03-25 11:51:36 --> Controller Class Initialized
INFO - 2021-03-25 11:51:36 --> Model Class Initialized
INFO - 2021-03-25 11:51:36 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 11:51:36 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 11:51:36 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 11:51:36 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 11:51:36 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 11:51:36 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 11:51:36 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 11:51:36 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 11:51:37 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\tender.php
INFO - 2021-03-25 11:51:37 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 11:51:37 --> Final output sent to browser
DEBUG - 2021-03-25 11:51:37 --> Total execution time: 0.6092
INFO - 2021-03-25 11:51:37 --> Config Class Initialized
INFO - 2021-03-25 11:51:37 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:51:37 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:51:37 --> Utf8 Class Initialized
INFO - 2021-03-25 11:51:37 --> URI Class Initialized
INFO - 2021-03-25 11:51:37 --> Router Class Initialized
INFO - 2021-03-25 11:51:37 --> Output Class Initialized
INFO - 2021-03-25 11:51:37 --> Security Class Initialized
DEBUG - 2021-03-25 11:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:51:37 --> Input Class Initialized
INFO - 2021-03-25 11:51:37 --> Language Class Initialized
ERROR - 2021-03-25 11:51:37 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 11:51:37 --> Config Class Initialized
INFO - 2021-03-25 11:51:37 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:51:37 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:51:37 --> Utf8 Class Initialized
INFO - 2021-03-25 11:51:37 --> URI Class Initialized
INFO - 2021-03-25 11:51:37 --> Router Class Initialized
INFO - 2021-03-25 11:51:37 --> Output Class Initialized
INFO - 2021-03-25 11:51:37 --> Security Class Initialized
DEBUG - 2021-03-25 11:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:51:37 --> Input Class Initialized
INFO - 2021-03-25 11:51:37 --> Language Class Initialized
ERROR - 2021-03-25 11:51:37 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 11:51:37 --> Config Class Initialized
INFO - 2021-03-25 11:51:37 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:51:37 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:51:37 --> Utf8 Class Initialized
INFO - 2021-03-25 11:51:37 --> URI Class Initialized
INFO - 2021-03-25 11:51:37 --> Router Class Initialized
INFO - 2021-03-25 11:51:37 --> Output Class Initialized
INFO - 2021-03-25 11:51:37 --> Security Class Initialized
DEBUG - 2021-03-25 11:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:51:37 --> Input Class Initialized
INFO - 2021-03-25 11:51:37 --> Language Class Initialized
ERROR - 2021-03-25 11:51:37 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 11:51:37 --> Config Class Initialized
INFO - 2021-03-25 11:51:38 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:51:38 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:51:38 --> Utf8 Class Initialized
INFO - 2021-03-25 11:51:38 --> URI Class Initialized
INFO - 2021-03-25 11:51:38 --> Router Class Initialized
INFO - 2021-03-25 11:51:38 --> Output Class Initialized
INFO - 2021-03-25 11:51:38 --> Security Class Initialized
DEBUG - 2021-03-25 11:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:51:38 --> Input Class Initialized
INFO - 2021-03-25 11:51:38 --> Language Class Initialized
ERROR - 2021-03-25 11:51:38 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 11:51:42 --> Config Class Initialized
INFO - 2021-03-25 11:51:42 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:51:42 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:51:42 --> Utf8 Class Initialized
INFO - 2021-03-25 11:51:42 --> URI Class Initialized
INFO - 2021-03-25 11:51:42 --> Router Class Initialized
INFO - 2021-03-25 11:51:42 --> Output Class Initialized
INFO - 2021-03-25 11:51:42 --> Security Class Initialized
DEBUG - 2021-03-25 11:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:51:42 --> Input Class Initialized
INFO - 2021-03-25 11:51:42 --> Language Class Initialized
INFO - 2021-03-25 11:51:42 --> Loader Class Initialized
INFO - 2021-03-25 11:51:42 --> Helper loaded: url_helper
INFO - 2021-03-25 11:51:42 --> Helper loaded: file_helper
INFO - 2021-03-25 11:51:42 --> Helper loaded: form_helper
INFO - 2021-03-25 11:51:42 --> Helper loaded: text_helper
INFO - 2021-03-25 11:51:42 --> Helper loaded: security_helper
INFO - 2021-03-25 11:51:42 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 11:51:42 --> Database Driver Class Initialized
INFO - 2021-03-25 11:51:42 --> Email Class Initialized
DEBUG - 2021-03-25 11:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 11:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 11:51:42 --> Form Validation Class Initialized
INFO - 2021-03-25 11:51:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 11:51:42 --> Pagination Class Initialized
INFO - 2021-03-25 11:51:42 --> Model Class Initialized
INFO - 2021-03-25 11:51:42 --> Controller Class Initialized
INFO - 2021-03-25 11:51:42 --> Model Class Initialized
INFO - 2021-03-25 11:51:42 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 11:51:42 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 11:51:42 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 11:51:42 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 11:51:42 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 11:51:42 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 11:51:42 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 11:51:42 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 11:51:42 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\tender.php
INFO - 2021-03-25 11:51:42 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 11:51:42 --> Final output sent to browser
DEBUG - 2021-03-25 11:51:42 --> Total execution time: 0.6008
INFO - 2021-03-25 11:51:43 --> Config Class Initialized
INFO - 2021-03-25 11:51:43 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:51:43 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:51:43 --> Utf8 Class Initialized
INFO - 2021-03-25 11:51:43 --> URI Class Initialized
INFO - 2021-03-25 11:51:43 --> Router Class Initialized
INFO - 2021-03-25 11:51:43 --> Output Class Initialized
INFO - 2021-03-25 11:51:43 --> Security Class Initialized
DEBUG - 2021-03-25 11:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:51:43 --> Input Class Initialized
INFO - 2021-03-25 11:51:43 --> Language Class Initialized
ERROR - 2021-03-25 11:51:43 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 11:51:43 --> Config Class Initialized
INFO - 2021-03-25 11:51:43 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:51:43 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:51:43 --> Utf8 Class Initialized
INFO - 2021-03-25 11:51:43 --> URI Class Initialized
INFO - 2021-03-25 11:51:43 --> Router Class Initialized
INFO - 2021-03-25 11:51:43 --> Output Class Initialized
INFO - 2021-03-25 11:51:43 --> Security Class Initialized
DEBUG - 2021-03-25 11:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:51:43 --> Input Class Initialized
INFO - 2021-03-25 11:51:43 --> Language Class Initialized
ERROR - 2021-03-25 11:51:43 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 11:51:43 --> Config Class Initialized
INFO - 2021-03-25 11:51:43 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:51:43 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:51:43 --> Utf8 Class Initialized
INFO - 2021-03-25 11:51:44 --> URI Class Initialized
INFO - 2021-03-25 11:51:44 --> Router Class Initialized
INFO - 2021-03-25 11:51:44 --> Output Class Initialized
INFO - 2021-03-25 11:51:44 --> Security Class Initialized
DEBUG - 2021-03-25 11:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:51:44 --> Input Class Initialized
INFO - 2021-03-25 11:51:44 --> Language Class Initialized
ERROR - 2021-03-25 11:51:44 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 11:51:44 --> Config Class Initialized
INFO - 2021-03-25 11:51:44 --> Hooks Class Initialized
DEBUG - 2021-03-25 11:51:44 --> UTF-8 Support Enabled
INFO - 2021-03-25 11:51:44 --> Utf8 Class Initialized
INFO - 2021-03-25 11:51:44 --> URI Class Initialized
INFO - 2021-03-25 11:51:44 --> Router Class Initialized
INFO - 2021-03-25 11:51:44 --> Output Class Initialized
INFO - 2021-03-25 11:51:44 --> Security Class Initialized
DEBUG - 2021-03-25 11:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 11:51:44 --> Input Class Initialized
INFO - 2021-03-25 11:51:44 --> Language Class Initialized
ERROR - 2021-03-25 11:51:44 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 12:14:20 --> Config Class Initialized
INFO - 2021-03-25 12:14:20 --> Hooks Class Initialized
DEBUG - 2021-03-25 12:14:20 --> UTF-8 Support Enabled
INFO - 2021-03-25 12:14:21 --> Utf8 Class Initialized
INFO - 2021-03-25 12:14:21 --> URI Class Initialized
INFO - 2021-03-25 12:14:21 --> Router Class Initialized
INFO - 2021-03-25 12:14:21 --> Output Class Initialized
INFO - 2021-03-25 12:14:21 --> Security Class Initialized
DEBUG - 2021-03-25 12:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 12:14:21 --> Input Class Initialized
INFO - 2021-03-25 12:14:21 --> Language Class Initialized
INFO - 2021-03-25 12:14:21 --> Loader Class Initialized
INFO - 2021-03-25 12:14:21 --> Helper loaded: url_helper
INFO - 2021-03-25 12:14:21 --> Helper loaded: file_helper
INFO - 2021-03-25 12:14:21 --> Helper loaded: form_helper
INFO - 2021-03-25 12:14:21 --> Helper loaded: text_helper
INFO - 2021-03-25 12:14:21 --> Helper loaded: security_helper
INFO - 2021-03-25 12:14:21 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 12:14:21 --> Database Driver Class Initialized
INFO - 2021-03-25 12:14:21 --> Email Class Initialized
DEBUG - 2021-03-25 12:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 12:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 12:14:21 --> Form Validation Class Initialized
INFO - 2021-03-25 12:14:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 12:14:21 --> Pagination Class Initialized
ERROR - 2021-03-25 12:14:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Admin_model C:\wamp64\www\RDA_Web\adminpoint\system\core\Loader.php 344
INFO - 2021-03-25 12:14:54 --> Config Class Initialized
INFO - 2021-03-25 12:14:54 --> Hooks Class Initialized
DEBUG - 2021-03-25 12:14:54 --> UTF-8 Support Enabled
INFO - 2021-03-25 12:14:54 --> Utf8 Class Initialized
INFO - 2021-03-25 12:14:54 --> URI Class Initialized
INFO - 2021-03-25 12:14:54 --> Router Class Initialized
INFO - 2021-03-25 12:14:54 --> Output Class Initialized
INFO - 2021-03-25 12:14:54 --> Security Class Initialized
DEBUG - 2021-03-25 12:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 12:14:54 --> Input Class Initialized
INFO - 2021-03-25 12:14:54 --> Language Class Initialized
INFO - 2021-03-25 12:14:54 --> Loader Class Initialized
INFO - 2021-03-25 12:14:54 --> Helper loaded: url_helper
INFO - 2021-03-25 12:14:54 --> Helper loaded: file_helper
INFO - 2021-03-25 12:14:54 --> Helper loaded: form_helper
INFO - 2021-03-25 12:14:54 --> Helper loaded: text_helper
INFO - 2021-03-25 12:14:54 --> Helper loaded: security_helper
INFO - 2021-03-25 12:14:54 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 12:14:54 --> Database Driver Class Initialized
INFO - 2021-03-25 12:14:54 --> Email Class Initialized
DEBUG - 2021-03-25 12:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 12:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 12:14:54 --> Form Validation Class Initialized
INFO - 2021-03-25 12:14:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 12:14:54 --> Pagination Class Initialized
INFO - 2021-03-25 12:14:54 --> Controller Class Initialized
INFO - 2021-03-25 12:14:54 --> Model Class Initialized
INFO - 2021-03-25 12:14:55 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 12:14:55 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 12:14:55 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 12:14:55 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 12:14:55 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 12:14:55 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 12:14:55 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 12:14:55 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 12:14:55 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\tender.php
INFO - 2021-03-25 12:14:55 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 12:14:55 --> Final output sent to browser
DEBUG - 2021-03-25 12:14:55 --> Total execution time: 0.6097
INFO - 2021-03-25 12:14:55 --> Config Class Initialized
INFO - 2021-03-25 12:14:55 --> Hooks Class Initialized
DEBUG - 2021-03-25 12:14:55 --> UTF-8 Support Enabled
INFO - 2021-03-25 12:14:55 --> Utf8 Class Initialized
INFO - 2021-03-25 12:14:55 --> URI Class Initialized
INFO - 2021-03-25 12:14:55 --> Router Class Initialized
INFO - 2021-03-25 12:14:55 --> Output Class Initialized
INFO - 2021-03-25 12:14:55 --> Security Class Initialized
DEBUG - 2021-03-25 12:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 12:14:55 --> Input Class Initialized
INFO - 2021-03-25 12:14:55 --> Language Class Initialized
ERROR - 2021-03-25 12:14:55 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 12:14:55 --> Config Class Initialized
INFO - 2021-03-25 12:14:55 --> Hooks Class Initialized
DEBUG - 2021-03-25 12:14:55 --> UTF-8 Support Enabled
INFO - 2021-03-25 12:14:55 --> Utf8 Class Initialized
INFO - 2021-03-25 12:14:55 --> URI Class Initialized
INFO - 2021-03-25 12:14:55 --> Router Class Initialized
INFO - 2021-03-25 12:14:55 --> Output Class Initialized
INFO - 2021-03-25 12:14:55 --> Security Class Initialized
DEBUG - 2021-03-25 12:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 12:14:55 --> Input Class Initialized
INFO - 2021-03-25 12:14:55 --> Language Class Initialized
ERROR - 2021-03-25 12:14:55 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 12:14:56 --> Config Class Initialized
INFO - 2021-03-25 12:14:56 --> Hooks Class Initialized
DEBUG - 2021-03-25 12:14:56 --> UTF-8 Support Enabled
INFO - 2021-03-25 12:14:56 --> Utf8 Class Initialized
INFO - 2021-03-25 12:14:56 --> URI Class Initialized
INFO - 2021-03-25 12:14:56 --> Router Class Initialized
INFO - 2021-03-25 12:14:56 --> Output Class Initialized
INFO - 2021-03-25 12:14:56 --> Security Class Initialized
DEBUG - 2021-03-25 12:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 12:14:56 --> Input Class Initialized
INFO - 2021-03-25 12:14:56 --> Language Class Initialized
ERROR - 2021-03-25 12:14:56 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 12:14:56 --> Config Class Initialized
INFO - 2021-03-25 12:14:56 --> Hooks Class Initialized
DEBUG - 2021-03-25 12:14:56 --> UTF-8 Support Enabled
INFO - 2021-03-25 12:14:56 --> Config Class Initialized
INFO - 2021-03-25 12:14:56 --> Hooks Class Initialized
DEBUG - 2021-03-25 12:14:56 --> UTF-8 Support Enabled
INFO - 2021-03-25 12:14:56 --> Utf8 Class Initialized
INFO - 2021-03-25 12:14:56 --> URI Class Initialized
INFO - 2021-03-25 12:14:56 --> Utf8 Class Initialized
INFO - 2021-03-25 12:14:56 --> URI Class Initialized
INFO - 2021-03-25 12:14:56 --> Router Class Initialized
INFO - 2021-03-25 12:14:56 --> Output Class Initialized
INFO - 2021-03-25 12:14:56 --> Security Class Initialized
DEBUG - 2021-03-25 12:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 12:14:56 --> Input Class Initialized
INFO - 2021-03-25 12:14:56 --> Language Class Initialized
ERROR - 2021-03-25 12:14:56 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 12:14:56 --> Router Class Initialized
INFO - 2021-03-25 12:14:56 --> Output Class Initialized
INFO - 2021-03-25 12:14:56 --> Security Class Initialized
DEBUG - 2021-03-25 12:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 12:14:56 --> Input Class Initialized
INFO - 2021-03-25 12:14:56 --> Language Class Initialized
ERROR - 2021-03-25 12:14:56 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 12:45:23 --> Config Class Initialized
INFO - 2021-03-25 12:45:23 --> Hooks Class Initialized
DEBUG - 2021-03-25 12:45:23 --> UTF-8 Support Enabled
INFO - 2021-03-25 12:45:23 --> Utf8 Class Initialized
INFO - 2021-03-25 12:45:23 --> URI Class Initialized
INFO - 2021-03-25 12:45:23 --> Router Class Initialized
INFO - 2021-03-25 12:45:23 --> Output Class Initialized
INFO - 2021-03-25 12:45:23 --> Security Class Initialized
DEBUG - 2021-03-25 12:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 12:45:23 --> Input Class Initialized
INFO - 2021-03-25 12:45:23 --> Language Class Initialized
ERROR - 2021-03-25 12:45:23 --> 404 Page Not Found: AdminDashboardController/tender
INFO - 2021-03-25 12:45:26 --> Config Class Initialized
INFO - 2021-03-25 12:45:26 --> Hooks Class Initialized
DEBUG - 2021-03-25 12:45:26 --> UTF-8 Support Enabled
INFO - 2021-03-25 12:45:26 --> Utf8 Class Initialized
INFO - 2021-03-25 12:45:26 --> URI Class Initialized
INFO - 2021-03-25 12:45:26 --> Router Class Initialized
INFO - 2021-03-25 12:45:26 --> Output Class Initialized
INFO - 2021-03-25 12:45:26 --> Security Class Initialized
DEBUG - 2021-03-25 12:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 12:45:26 --> Input Class Initialized
INFO - 2021-03-25 12:45:26 --> Language Class Initialized
INFO - 2021-03-25 12:45:26 --> Loader Class Initialized
INFO - 2021-03-25 12:45:26 --> Helper loaded: url_helper
INFO - 2021-03-25 12:45:26 --> Helper loaded: file_helper
INFO - 2021-03-25 12:45:26 --> Helper loaded: form_helper
INFO - 2021-03-25 12:45:26 --> Helper loaded: text_helper
INFO - 2021-03-25 12:45:26 --> Helper loaded: security_helper
INFO - 2021-03-25 12:45:26 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 12:45:27 --> Database Driver Class Initialized
INFO - 2021-03-25 12:45:27 --> Email Class Initialized
DEBUG - 2021-03-25 12:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 12:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 12:45:27 --> Form Validation Class Initialized
INFO - 2021-03-25 12:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 12:45:27 --> Pagination Class Initialized
INFO - 2021-03-25 12:45:27 --> Controller Class Initialized
INFO - 2021-03-25 12:45:27 --> Model Class Initialized
INFO - 2021-03-25 12:45:27 --> Model Class Initialized
INFO - 2021-03-25 12:45:27 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 12:45:27 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 12:45:27 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 12:45:27 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 12:45:27 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 12:45:27 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 12:45:27 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 12:45:27 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 12:45:27 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 12:45:27 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 12:45:27 --> Final output sent to browser
DEBUG - 2021-03-25 12:45:27 --> Total execution time: 0.6893
INFO - 2021-03-25 12:45:43 --> Config Class Initialized
INFO - 2021-03-25 12:45:43 --> Hooks Class Initialized
DEBUG - 2021-03-25 12:45:43 --> UTF-8 Support Enabled
INFO - 2021-03-25 12:45:43 --> Utf8 Class Initialized
INFO - 2021-03-25 12:45:43 --> URI Class Initialized
INFO - 2021-03-25 12:45:43 --> Router Class Initialized
INFO - 2021-03-25 12:45:43 --> Output Class Initialized
INFO - 2021-03-25 12:45:43 --> Security Class Initialized
DEBUG - 2021-03-25 12:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 12:45:43 --> Input Class Initialized
INFO - 2021-03-25 12:45:43 --> Language Class Initialized
INFO - 2021-03-25 12:45:43 --> Loader Class Initialized
INFO - 2021-03-25 12:45:43 --> Helper loaded: url_helper
INFO - 2021-03-25 12:45:43 --> Helper loaded: file_helper
INFO - 2021-03-25 12:45:43 --> Helper loaded: form_helper
INFO - 2021-03-25 12:45:43 --> Helper loaded: text_helper
INFO - 2021-03-25 12:45:43 --> Helper loaded: security_helper
INFO - 2021-03-25 12:45:43 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 12:45:43 --> Database Driver Class Initialized
INFO - 2021-03-25 12:45:43 --> Email Class Initialized
DEBUG - 2021-03-25 12:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 12:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 12:45:43 --> Form Validation Class Initialized
INFO - 2021-03-25 12:45:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 12:45:43 --> Pagination Class Initialized
INFO - 2021-03-25 12:45:43 --> Controller Class Initialized
INFO - 2021-03-25 12:45:43 --> Model Class Initialized
INFO - 2021-03-25 12:45:43 --> Model Class Initialized
INFO - 2021-03-25 12:45:43 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 12:45:43 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 12:45:43 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 12:45:43 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 12:45:43 --> File loaded: C:\wamp64\www\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 12:45:43 --> Final output sent to browser
DEBUG - 2021-03-25 12:45:43 --> Total execution time: 0.5563
INFO - 2021-03-25 12:45:43 --> Config Class Initialized
INFO - 2021-03-25 12:45:44 --> Hooks Class Initialized
DEBUG - 2021-03-25 12:45:44 --> UTF-8 Support Enabled
INFO - 2021-03-25 12:45:44 --> Utf8 Class Initialized
INFO - 2021-03-25 12:45:44 --> URI Class Initialized
INFO - 2021-03-25 12:45:44 --> Router Class Initialized
INFO - 2021-03-25 12:45:44 --> Output Class Initialized
INFO - 2021-03-25 12:45:44 --> Security Class Initialized
DEBUG - 2021-03-25 12:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 12:45:44 --> Input Class Initialized
INFO - 2021-03-25 12:45:44 --> Language Class Initialized
ERROR - 2021-03-25 12:45:44 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 12:45:44 --> Config Class Initialized
INFO - 2021-03-25 12:45:44 --> Hooks Class Initialized
DEBUG - 2021-03-25 12:45:44 --> UTF-8 Support Enabled
INFO - 2021-03-25 12:45:44 --> Utf8 Class Initialized
INFO - 2021-03-25 12:45:44 --> URI Class Initialized
INFO - 2021-03-25 12:45:44 --> Router Class Initialized
INFO - 2021-03-25 12:45:44 --> Output Class Initialized
INFO - 2021-03-25 12:45:44 --> Security Class Initialized
DEBUG - 2021-03-25 12:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 12:45:44 --> Input Class Initialized
INFO - 2021-03-25 12:45:44 --> Language Class Initialized
ERROR - 2021-03-25 12:45:44 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 16:57:21 --> Config Class Initialized
INFO - 2021-03-25 16:57:21 --> Hooks Class Initialized
DEBUG - 2021-03-25 16:57:21 --> UTF-8 Support Enabled
INFO - 2021-03-25 16:57:21 --> Utf8 Class Initialized
INFO - 2021-03-25 16:57:21 --> URI Class Initialized
INFO - 2021-03-25 16:57:21 --> Router Class Initialized
INFO - 2021-03-25 16:57:21 --> Output Class Initialized
INFO - 2021-03-25 16:57:21 --> Security Class Initialized
DEBUG - 2021-03-25 16:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 16:57:21 --> Input Class Initialized
INFO - 2021-03-25 16:57:21 --> Language Class Initialized
INFO - 2021-03-25 16:57:21 --> Loader Class Initialized
INFO - 2021-03-25 16:57:21 --> Helper loaded: url_helper
INFO - 2021-03-25 16:57:21 --> Helper loaded: file_helper
INFO - 2021-03-25 16:57:21 --> Helper loaded: form_helper
INFO - 2021-03-25 16:57:21 --> Helper loaded: text_helper
INFO - 2021-03-25 16:57:21 --> Helper loaded: security_helper
INFO - 2021-03-25 16:57:21 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 16:57:21 --> Database Driver Class Initialized
INFO - 2021-03-25 16:57:21 --> Email Class Initialized
DEBUG - 2021-03-25 16:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 16:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 16:57:21 --> Form Validation Class Initialized
INFO - 2021-03-25 16:57:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 16:57:21 --> Pagination Class Initialized
INFO - 2021-03-25 16:57:21 --> Controller Class Initialized
INFO - 2021-03-25 16:57:21 --> Model Class Initialized
INFO - 2021-03-25 16:57:21 --> Model Class Initialized
INFO - 2021-03-25 16:57:21 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 16:57:21 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 16:57:21 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 16:57:21 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\tender.php
INFO - 2021-03-25 16:57:21 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 16:57:21 --> Final output sent to browser
DEBUG - 2021-03-25 16:57:21 --> Total execution time: 0.4378
INFO - 2021-03-25 16:57:21 --> Config Class Initialized
INFO - 2021-03-25 16:57:21 --> Hooks Class Initialized
DEBUG - 2021-03-25 16:57:21 --> UTF-8 Support Enabled
INFO - 2021-03-25 16:57:21 --> Utf8 Class Initialized
INFO - 2021-03-25 16:57:21 --> URI Class Initialized
INFO - 2021-03-25 16:57:21 --> Router Class Initialized
INFO - 2021-03-25 16:57:21 --> Output Class Initialized
INFO - 2021-03-25 16:57:21 --> Security Class Initialized
DEBUG - 2021-03-25 16:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 16:57:21 --> Input Class Initialized
INFO - 2021-03-25 16:57:21 --> Language Class Initialized
ERROR - 2021-03-25 16:57:21 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 16:57:21 --> Config Class Initialized
INFO - 2021-03-25 16:57:21 --> Hooks Class Initialized
DEBUG - 2021-03-25 16:57:21 --> UTF-8 Support Enabled
INFO - 2021-03-25 16:57:21 --> Utf8 Class Initialized
INFO - 2021-03-25 16:57:21 --> URI Class Initialized
INFO - 2021-03-25 16:57:21 --> Router Class Initialized
INFO - 2021-03-25 16:57:21 --> Output Class Initialized
INFO - 2021-03-25 16:57:21 --> Security Class Initialized
DEBUG - 2021-03-25 16:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 16:57:21 --> Input Class Initialized
INFO - 2021-03-25 16:57:21 --> Language Class Initialized
ERROR - 2021-03-25 16:57:21 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 16:59:05 --> Config Class Initialized
INFO - 2021-03-25 16:59:05 --> Hooks Class Initialized
DEBUG - 2021-03-25 16:59:05 --> UTF-8 Support Enabled
INFO - 2021-03-25 16:59:05 --> Utf8 Class Initialized
INFO - 2021-03-25 16:59:05 --> URI Class Initialized
INFO - 2021-03-25 16:59:05 --> Router Class Initialized
INFO - 2021-03-25 16:59:05 --> Output Class Initialized
INFO - 2021-03-25 16:59:05 --> Security Class Initialized
DEBUG - 2021-03-25 16:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 16:59:05 --> Input Class Initialized
INFO - 2021-03-25 16:59:05 --> Language Class Initialized
INFO - 2021-03-25 16:59:05 --> Loader Class Initialized
INFO - 2021-03-25 16:59:05 --> Helper loaded: url_helper
INFO - 2021-03-25 16:59:05 --> Helper loaded: file_helper
INFO - 2021-03-25 16:59:05 --> Helper loaded: form_helper
INFO - 2021-03-25 16:59:05 --> Helper loaded: text_helper
INFO - 2021-03-25 16:59:05 --> Helper loaded: security_helper
INFO - 2021-03-25 16:59:05 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 16:59:05 --> Database Driver Class Initialized
INFO - 2021-03-25 16:59:05 --> Email Class Initialized
DEBUG - 2021-03-25 16:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 16:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 16:59:05 --> Form Validation Class Initialized
INFO - 2021-03-25 16:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 16:59:06 --> Pagination Class Initialized
INFO - 2021-03-25 16:59:06 --> Controller Class Initialized
INFO - 2021-03-25 16:59:06 --> Model Class Initialized
INFO - 2021-03-25 16:59:06 --> Model Class Initialized
INFO - 2021-03-25 16:59:06 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 16:59:06 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 16:59:06 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 16:59:06 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\tender.php
INFO - 2021-03-25 16:59:06 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 16:59:06 --> Final output sent to browser
DEBUG - 2021-03-25 16:59:06 --> Total execution time: 0.4163
INFO - 2021-03-25 16:59:06 --> Config Class Initialized
INFO - 2021-03-25 16:59:06 --> Hooks Class Initialized
DEBUG - 2021-03-25 16:59:06 --> UTF-8 Support Enabled
INFO - 2021-03-25 16:59:06 --> Utf8 Class Initialized
INFO - 2021-03-25 16:59:06 --> URI Class Initialized
INFO - 2021-03-25 16:59:06 --> Router Class Initialized
INFO - 2021-03-25 16:59:06 --> Output Class Initialized
INFO - 2021-03-25 16:59:06 --> Security Class Initialized
DEBUG - 2021-03-25 16:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 16:59:06 --> Input Class Initialized
INFO - 2021-03-25 16:59:06 --> Language Class Initialized
ERROR - 2021-03-25 16:59:06 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 16:59:06 --> Config Class Initialized
INFO - 2021-03-25 16:59:06 --> Hooks Class Initialized
DEBUG - 2021-03-25 16:59:06 --> UTF-8 Support Enabled
INFO - 2021-03-25 16:59:06 --> Utf8 Class Initialized
INFO - 2021-03-25 16:59:06 --> URI Class Initialized
INFO - 2021-03-25 16:59:06 --> Router Class Initialized
INFO - 2021-03-25 16:59:06 --> Output Class Initialized
INFO - 2021-03-25 16:59:06 --> Security Class Initialized
DEBUG - 2021-03-25 16:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 16:59:06 --> Input Class Initialized
INFO - 2021-03-25 16:59:06 --> Language Class Initialized
ERROR - 2021-03-25 16:59:06 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 16:59:06 --> Config Class Initialized
INFO - 2021-03-25 16:59:06 --> Hooks Class Initialized
DEBUG - 2021-03-25 16:59:06 --> UTF-8 Support Enabled
INFO - 2021-03-25 16:59:06 --> Utf8 Class Initialized
INFO - 2021-03-25 16:59:06 --> URI Class Initialized
INFO - 2021-03-25 16:59:06 --> Router Class Initialized
INFO - 2021-03-25 16:59:06 --> Output Class Initialized
INFO - 2021-03-25 16:59:06 --> Security Class Initialized
DEBUG - 2021-03-25 16:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 16:59:06 --> Input Class Initialized
INFO - 2021-03-25 16:59:06 --> Language Class Initialized
ERROR - 2021-03-25 16:59:06 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 16:59:12 --> Config Class Initialized
INFO - 2021-03-25 16:59:12 --> Hooks Class Initialized
DEBUG - 2021-03-25 16:59:12 --> UTF-8 Support Enabled
INFO - 2021-03-25 16:59:12 --> Utf8 Class Initialized
INFO - 2021-03-25 16:59:12 --> URI Class Initialized
INFO - 2021-03-25 16:59:12 --> Router Class Initialized
INFO - 2021-03-25 16:59:12 --> Output Class Initialized
INFO - 2021-03-25 16:59:12 --> Security Class Initialized
DEBUG - 2021-03-25 16:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 16:59:12 --> Input Class Initialized
INFO - 2021-03-25 16:59:12 --> Language Class Initialized
INFO - 2021-03-25 16:59:12 --> Loader Class Initialized
INFO - 2021-03-25 16:59:12 --> Helper loaded: url_helper
INFO - 2021-03-25 16:59:12 --> Helper loaded: file_helper
INFO - 2021-03-25 16:59:12 --> Helper loaded: form_helper
INFO - 2021-03-25 16:59:12 --> Helper loaded: text_helper
INFO - 2021-03-25 16:59:12 --> Helper loaded: security_helper
INFO - 2021-03-25 16:59:12 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 16:59:12 --> Database Driver Class Initialized
INFO - 2021-03-25 16:59:12 --> Email Class Initialized
DEBUG - 2021-03-25 16:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 16:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 16:59:12 --> Form Validation Class Initialized
INFO - 2021-03-25 16:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 16:59:12 --> Pagination Class Initialized
INFO - 2021-03-25 16:59:12 --> Controller Class Initialized
INFO - 2021-03-25 16:59:12 --> Model Class Initialized
INFO - 2021-03-25 16:59:12 --> Model Class Initialized
INFO - 2021-03-25 16:59:12 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 16:59:12 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 16:59:12 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 16:59:12 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 16:59:12 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 16:59:12 --> Final output sent to browser
DEBUG - 2021-03-25 16:59:12 --> Total execution time: 0.3969
INFO - 2021-03-25 16:59:12 --> Config Class Initialized
INFO - 2021-03-25 16:59:12 --> Hooks Class Initialized
DEBUG - 2021-03-25 16:59:12 --> UTF-8 Support Enabled
INFO - 2021-03-25 16:59:12 --> Utf8 Class Initialized
INFO - 2021-03-25 16:59:12 --> URI Class Initialized
INFO - 2021-03-25 16:59:12 --> Router Class Initialized
INFO - 2021-03-25 16:59:12 --> Output Class Initialized
INFO - 2021-03-25 16:59:12 --> Security Class Initialized
DEBUG - 2021-03-25 16:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 16:59:12 --> Input Class Initialized
INFO - 2021-03-25 16:59:12 --> Language Class Initialized
ERROR - 2021-03-25 16:59:12 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 16:59:12 --> Config Class Initialized
INFO - 2021-03-25 16:59:12 --> Hooks Class Initialized
DEBUG - 2021-03-25 16:59:12 --> UTF-8 Support Enabled
INFO - 2021-03-25 16:59:12 --> Utf8 Class Initialized
INFO - 2021-03-25 16:59:12 --> URI Class Initialized
INFO - 2021-03-25 16:59:12 --> Router Class Initialized
INFO - 2021-03-25 16:59:12 --> Output Class Initialized
INFO - 2021-03-25 16:59:12 --> Security Class Initialized
DEBUG - 2021-03-25 16:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 16:59:12 --> Input Class Initialized
INFO - 2021-03-25 16:59:12 --> Language Class Initialized
ERROR - 2021-03-25 16:59:12 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 16:59:59 --> Config Class Initialized
INFO - 2021-03-25 16:59:59 --> Hooks Class Initialized
DEBUG - 2021-03-25 16:59:59 --> UTF-8 Support Enabled
INFO - 2021-03-25 16:59:59 --> Utf8 Class Initialized
INFO - 2021-03-25 16:59:59 --> URI Class Initialized
INFO - 2021-03-25 16:59:59 --> Router Class Initialized
INFO - 2021-03-25 16:59:59 --> Output Class Initialized
INFO - 2021-03-25 16:59:59 --> Security Class Initialized
DEBUG - 2021-03-25 16:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 16:59:59 --> Input Class Initialized
INFO - 2021-03-25 16:59:59 --> Language Class Initialized
INFO - 2021-03-25 16:59:59 --> Loader Class Initialized
INFO - 2021-03-25 16:59:59 --> Helper loaded: url_helper
INFO - 2021-03-25 16:59:59 --> Helper loaded: file_helper
INFO - 2021-03-25 16:59:59 --> Helper loaded: form_helper
INFO - 2021-03-25 16:59:59 --> Helper loaded: text_helper
INFO - 2021-03-25 16:59:59 --> Helper loaded: security_helper
INFO - 2021-03-25 16:59:59 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 16:59:59 --> Database Driver Class Initialized
INFO - 2021-03-25 16:59:59 --> Email Class Initialized
DEBUG - 2021-03-25 16:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 16:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 16:59:59 --> Form Validation Class Initialized
INFO - 2021-03-25 16:59:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 16:59:59 --> Pagination Class Initialized
INFO - 2021-03-25 16:59:59 --> Controller Class Initialized
INFO - 2021-03-25 16:59:59 --> Model Class Initialized
INFO - 2021-03-25 16:59:59 --> Model Class Initialized
INFO - 2021-03-25 16:59:59 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 16:59:59 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 16:59:59 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 16:59:59 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-03-25 16:59:59 --> File loaded: C:\xampp\htdocs\git\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 16:59:59 --> Final output sent to browser
DEBUG - 2021-03-25 16:59:59 --> Total execution time: 0.4414
INFO - 2021-03-25 16:59:59 --> Config Class Initialized
INFO - 2021-03-25 16:59:59 --> Hooks Class Initialized
DEBUG - 2021-03-25 16:59:59 --> UTF-8 Support Enabled
INFO - 2021-03-25 16:59:59 --> Utf8 Class Initialized
INFO - 2021-03-25 16:59:59 --> URI Class Initialized
INFO - 2021-03-25 16:59:59 --> Router Class Initialized
INFO - 2021-03-25 16:59:59 --> Output Class Initialized
INFO - 2021-03-25 16:59:59 --> Security Class Initialized
DEBUG - 2021-03-25 16:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 16:59:59 --> Input Class Initialized
INFO - 2021-03-25 16:59:59 --> Language Class Initialized
ERROR - 2021-03-25 16:59:59 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 17:00:00 --> Config Class Initialized
INFO - 2021-03-25 17:00:00 --> Hooks Class Initialized
DEBUG - 2021-03-25 17:00:00 --> UTF-8 Support Enabled
INFO - 2021-03-25 17:00:00 --> Utf8 Class Initialized
INFO - 2021-03-25 17:00:00 --> URI Class Initialized
INFO - 2021-03-25 17:00:00 --> Router Class Initialized
INFO - 2021-03-25 17:00:00 --> Output Class Initialized
INFO - 2021-03-25 17:00:00 --> Security Class Initialized
DEBUG - 2021-03-25 17:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 17:00:00 --> Input Class Initialized
INFO - 2021-03-25 17:00:00 --> Language Class Initialized
ERROR - 2021-03-25 17:00:00 --> 404 Page Not Found: Js/demo
INFO - 2021-03-25 17:00:00 --> Config Class Initialized
INFO - 2021-03-25 17:00:00 --> Hooks Class Initialized
DEBUG - 2021-03-25 17:00:00 --> UTF-8 Support Enabled
INFO - 2021-03-25 17:00:00 --> Utf8 Class Initialized
INFO - 2021-03-25 17:00:00 --> URI Class Initialized
INFO - 2021-03-25 17:00:00 --> Router Class Initialized
INFO - 2021-03-25 17:00:00 --> Output Class Initialized
INFO - 2021-03-25 17:00:00 --> Security Class Initialized
DEBUG - 2021-03-25 17:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 17:00:00 --> Input Class Initialized
INFO - 2021-03-25 17:00:00 --> Language Class Initialized
ERROR - 2021-03-25 17:00:00 --> 404 Page Not Found: Skin-config2html/index
INFO - 2021-03-25 17:37:15 --> Config Class Initialized
INFO - 2021-03-25 17:37:15 --> Hooks Class Initialized
DEBUG - 2021-03-25 17:37:15 --> UTF-8 Support Enabled
INFO - 2021-03-25 17:37:15 --> Utf8 Class Initialized
INFO - 2021-03-25 17:37:15 --> URI Class Initialized
INFO - 2021-03-25 17:37:15 --> Router Class Initialized
INFO - 2021-03-25 17:37:15 --> Output Class Initialized
INFO - 2021-03-25 17:37:15 --> Security Class Initialized
DEBUG - 2021-03-25 17:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 17:37:15 --> Input Class Initialized
INFO - 2021-03-25 17:37:15 --> Language Class Initialized
INFO - 2021-03-25 17:37:15 --> Loader Class Initialized
INFO - 2021-03-25 17:37:15 --> Helper loaded: url_helper
INFO - 2021-03-25 17:37:15 --> Helper loaded: file_helper
INFO - 2021-03-25 17:37:15 --> Helper loaded: form_helper
INFO - 2021-03-25 17:37:15 --> Helper loaded: text_helper
INFO - 2021-03-25 17:37:16 --> Helper loaded: security_helper
INFO - 2021-03-25 17:37:16 --> Helper loaded: ipaddress_helper
INFO - 2021-03-25 17:37:16 --> Database Driver Class Initialized
INFO - 2021-03-25 17:37:16 --> Email Class Initialized
DEBUG - 2021-03-25 17:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 17:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 17:37:16 --> Form Validation Class Initialized
INFO - 2021-03-25 17:37:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-25 17:37:16 --> Pagination Class Initialized
INFO - 2021-03-25 17:37:16 --> Controller Class Initialized
INFO - 2021-03-25 17:37:16 --> Model Class Initialized
INFO - 2021-03-25 17:37:16 --> Model Class Initialized
INFO - 2021-03-25 17:37:16 --> File loaded: C:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-03-25 17:37:16 --> File loaded: C:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-03-25 17:37:16 --> File loaded: C:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-03-25 17:37:16 --> File loaded: C:\xampp\htdocs\RDA_Web\adminpoint\application\views\tender.php
INFO - 2021-03-25 17:37:16 --> File loaded: C:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-03-25 17:37:16 --> Final output sent to browser
DEBUG - 2021-03-25 17:37:16 --> Total execution time: 0.7297
INFO - 2021-03-25 17:37:16 --> Config Class Initialized
INFO - 2021-03-25 17:37:16 --> Hooks Class Initialized
DEBUG - 2021-03-25 17:37:16 --> UTF-8 Support Enabled
INFO - 2021-03-25 17:37:16 --> Utf8 Class Initialized
INFO - 2021-03-25 17:37:16 --> URI Class Initialized
INFO - 2021-03-25 17:37:16 --> Router Class Initialized
INFO - 2021-03-25 17:37:16 --> Output Class Initialized
INFO - 2021-03-25 17:37:16 --> Security Class Initialized
DEBUG - 2021-03-25 17:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 17:37:16 --> Input Class Initialized
INFO - 2021-03-25 17:37:16 --> Language Class Initialized
ERROR - 2021-03-25 17:37:16 --> 404 Page Not Found: Js/demo
