<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-03-09 12:42:42 --> Config Class Initialized
INFO - 2021-03-09 12:42:42 --> Hooks Class Initialized
DEBUG - 2021-03-09 12:42:42 --> UTF-8 Support Enabled
INFO - 2021-03-09 12:42:42 --> Utf8 Class Initialized
INFO - 2021-03-09 12:42:42 --> URI Class Initialized
DEBUG - 2021-03-09 12:42:43 --> No URI present. Default controller set.
INFO - 2021-03-09 12:42:43 --> Router Class Initialized
INFO - 2021-03-09 12:42:43 --> Output Class Initialized
INFO - 2021-03-09 12:42:43 --> Security Class Initialized
DEBUG - 2021-03-09 12:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-09 12:42:43 --> Input Class Initialized
INFO - 2021-03-09 12:42:43 --> Language Class Initialized
INFO - 2021-03-09 12:42:43 --> Loader Class Initialized
INFO - 2021-03-09 12:42:43 --> Helper loaded: url_helper
INFO - 2021-03-09 12:42:43 --> Helper loaded: file_helper
INFO - 2021-03-09 12:42:44 --> Helper loaded: form_helper
INFO - 2021-03-09 12:42:44 --> Helper loaded: text_helper
INFO - 2021-03-09 12:42:44 --> Helper loaded: security_helper
INFO - 2021-03-09 12:42:44 --> Helper loaded: ipaddress_helper
INFO - 2021-03-09 12:42:44 --> Helper loaded: json_output_helper
INFO - 2021-03-09 12:42:44 --> Helper loaded: sms_helper
INFO - 2021-03-09 12:42:44 --> Helper loaded: track_log_helper
INFO - 2021-03-09 12:42:44 --> Helper loaded: api_error_log_helper
INFO - 2021-03-09 12:42:44 --> Helper loaded: curl_call_helper
INFO - 2021-03-09 12:42:44 --> Database Driver Class Initialized
INFO - 2021-03-09 12:42:44 --> Email Class Initialized
DEBUG - 2021-03-09 12:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-09 12:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-09 12:42:45 --> Form Validation Class Initialized
INFO - 2021-03-09 12:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-09 12:42:45 --> Pagination Class Initialized
INFO - 2021-03-09 12:42:45 --> Model Class Initialized
INFO - 2021-03-09 12:42:45 --> Model Class Initialized
INFO - 2021-03-09 12:42:45 --> Model Class Initialized
INFO - 2021-03-09 12:42:45 --> Model Class Initialized
INFO - 2021-03-09 12:42:45 --> Model Class Initialized
INFO - 2021-03-09 12:42:45 --> Controller Class Initialized
INFO - 2021-03-09 12:42:45 --> Model Class Initialized
INFO - 2021-03-09 12:42:45 --> File loaded: C:\xampp\htdocs\cmogit\application\views\user_includes/upperheader.php
INFO - 2021-03-09 12:42:45 --> File loaded: C:\xampp\htdocs\cmogit\application\views\user_includes/header.php
INFO - 2021-03-09 12:42:45 --> File loaded: C:\xampp\htdocs\cmogit\application\views\userhome.php
INFO - 2021-03-09 12:42:46 --> File loaded: C:\xampp\htdocs\cmogit\application\views\user_includes/footer.php
INFO - 2021-03-09 12:42:46 --> Final output sent to browser
DEBUG - 2021-03-09 12:42:46 --> Total execution time: 3.7304
INFO - 2021-03-09 12:42:47 --> Config Class Initialized
INFO - 2021-03-09 12:42:47 --> Hooks Class Initialized
DEBUG - 2021-03-09 12:42:47 --> UTF-8 Support Enabled
INFO - 2021-03-09 12:42:47 --> Utf8 Class Initialized
INFO - 2021-03-09 12:42:47 --> URI Class Initialized
INFO - 2021-03-09 12:42:47 --> Router Class Initialized
INFO - 2021-03-09 12:42:47 --> Output Class Initialized
INFO - 2021-03-09 12:42:47 --> Security Class Initialized
DEBUG - 2021-03-09 12:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-09 12:42:47 --> Input Class Initialized
INFO - 2021-03-09 12:42:47 --> Language Class Initialized
INFO - 2021-03-09 12:42:47 --> Loader Class Initialized
INFO - 2021-03-09 12:42:47 --> Helper loaded: url_helper
INFO - 2021-03-09 12:42:47 --> Helper loaded: file_helper
INFO - 2021-03-09 12:42:47 --> Helper loaded: form_helper
INFO - 2021-03-09 12:42:47 --> Helper loaded: text_helper
INFO - 2021-03-09 12:42:47 --> Helper loaded: security_helper
INFO - 2021-03-09 12:42:47 --> Helper loaded: ipaddress_helper
INFO - 2021-03-09 12:42:47 --> Helper loaded: json_output_helper
INFO - 2021-03-09 12:42:48 --> Helper loaded: sms_helper
INFO - 2021-03-09 12:42:48 --> Helper loaded: track_log_helper
INFO - 2021-03-09 12:42:48 --> Helper loaded: api_error_log_helper
INFO - 2021-03-09 12:42:48 --> Helper loaded: curl_call_helper
INFO - 2021-03-09 12:42:48 --> Database Driver Class Initialized
INFO - 2021-03-09 12:42:48 --> Email Class Initialized
DEBUG - 2021-03-09 12:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-09 12:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-09 12:42:48 --> Form Validation Class Initialized
INFO - 2021-03-09 12:42:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-09 12:42:48 --> Pagination Class Initialized
INFO - 2021-03-09 12:42:48 --> Model Class Initialized
INFO - 2021-03-09 12:42:48 --> Model Class Initialized
INFO - 2021-03-09 12:42:48 --> Model Class Initialized
INFO - 2021-03-09 12:42:48 --> Model Class Initialized
INFO - 2021-03-09 12:42:48 --> Model Class Initialized
INFO - 2021-03-09 12:42:48 --> Controller Class Initialized
INFO - 2021-03-09 12:42:48 --> Model Class Initialized
INFO - 2021-03-09 12:42:48 --> Final output sent to browser
DEBUG - 2021-03-09 12:42:48 --> Total execution time: 0.9371
INFO - 2021-03-09 12:42:57 --> Config Class Initialized
INFO - 2021-03-09 12:42:57 --> Hooks Class Initialized
DEBUG - 2021-03-09 12:42:57 --> UTF-8 Support Enabled
INFO - 2021-03-09 12:42:57 --> Utf8 Class Initialized
INFO - 2021-03-09 12:42:57 --> URI Class Initialized
INFO - 2021-03-09 12:42:57 --> Router Class Initialized
INFO - 2021-03-09 12:42:57 --> Output Class Initialized
INFO - 2021-03-09 12:42:57 --> Security Class Initialized
DEBUG - 2021-03-09 12:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-09 12:42:57 --> Input Class Initialized
INFO - 2021-03-09 12:42:57 --> Language Class Initialized
INFO - 2021-03-09 12:42:57 --> Loader Class Initialized
INFO - 2021-03-09 12:42:57 --> Helper loaded: url_helper
INFO - 2021-03-09 12:42:57 --> Helper loaded: file_helper
INFO - 2021-03-09 12:42:57 --> Helper loaded: form_helper
INFO - 2021-03-09 12:42:57 --> Helper loaded: text_helper
INFO - 2021-03-09 12:42:57 --> Helper loaded: security_helper
INFO - 2021-03-09 12:42:57 --> Helper loaded: ipaddress_helper
INFO - 2021-03-09 12:42:57 --> Helper loaded: json_output_helper
INFO - 2021-03-09 12:42:57 --> Helper loaded: sms_helper
INFO - 2021-03-09 12:42:57 --> Helper loaded: track_log_helper
INFO - 2021-03-09 12:42:57 --> Helper loaded: api_error_log_helper
INFO - 2021-03-09 12:42:58 --> Helper loaded: curl_call_helper
INFO - 2021-03-09 12:42:58 --> Database Driver Class Initialized
INFO - 2021-03-09 12:42:58 --> Email Class Initialized
DEBUG - 2021-03-09 12:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-09 12:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-09 12:42:58 --> Form Validation Class Initialized
INFO - 2021-03-09 12:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-09 12:42:58 --> Pagination Class Initialized
INFO - 2021-03-09 12:42:58 --> Model Class Initialized
INFO - 2021-03-09 12:42:58 --> Model Class Initialized
INFO - 2021-03-09 12:42:58 --> Model Class Initialized
INFO - 2021-03-09 12:42:58 --> Model Class Initialized
INFO - 2021-03-09 12:42:58 --> Model Class Initialized
INFO - 2021-03-09 12:42:58 --> Controller Class Initialized
INFO - 2021-03-09 12:42:58 --> Helper loaded: string_helper
DEBUG - 2021-03-09 12:42:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-09 12:42:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-03-09 12:42:58 --> Model Class Initialized
INFO - 2021-03-09 12:42:58 --> Model Class Initialized
ERROR - 2021-03-09 12:42:58 --> Query error: Unknown column 'pig.gothan_status' in 'field list' - Invalid query: SELECT mdl.district_code code, 
                mdl.district_name_hin name, 
                IFNULL(sd.sanctioned_gothans,0) sanctioned_gothans, 
                COUNT(mgn.gothan_id) total_gothans, 
                pg.start_gothan, 
                pg.inprogress_gothan, 
                pg.complete_gothan, 
                IFNULL(g_map.mapped_gothan,0) mapped_gothans,
                IFNULL(g_n_map.upmapped_gothans,0) upmapped_gothans,
                login.logged_in_gothans, 
                login.not_logged_in_gothans,
                pg.pig_count,
                pg.no_pig_count,
                td.active_in_last_7_days,
                (COUNT(mgn.gothan_id) - td.active_in_last_7_days) not_active_in_last_7_days,
                td.active_in_last_30_days,
                (COUNT(mgn.gothan_id) - td.active_in_last_30_days) not_active_in_last_30_days
                FROM master_district_lgd mdl
                LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                LEFT JOIN (SELECT mdl.district_code, SUM(sct.sanctioned_count) sanctioned_gothans FROM master_district_lgd mdl
                            LEFT JOIN sanctioned_count_tb sct ON sct.fk_master_district_code = mdl.district_code
                            GROUP BY mdl.district_code) sd ON sd.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, mdl.district_name_hin, COUNT(pig.info_id) pig_count,
                                    COUNT(IF(pig.info_id IS NULL, 1, NULL)) no_pig_count,
                                    COUNT(IF(pig.gothan_status=1,1,NULL)) start_gothan, 
                                    COUNT(IF(pig.gothan_status=2,1,NULL)) inprogress_gothan,
                                    COUNT(IF(pig.gothan_status=3,1,NULL)) complete_gothan
                                    FROM master_district_lgd mdl 
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN permanent_info_gothan pig ON mgn.gothan_id = pig.gothan_id
                            GROUP BY mdl.district_code, mdl.district_name_hin) pg ON pg.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, COUNT(egm.fk_master_gothan_employee_id) logged_in_gothans, 
                                    COUNT(IF(egm.fk_master_gothan_employee_id IS NULL,1,NULL)) not_logged_in_gothans
                                    FROM master_district_lgd mdl
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN employee_gothan_map egm ON egm.fk_master_gothan_name_id = mgn.gothan_id AND egm.is_active = 1
                            LEFT JOIN (SELECT mat.fk_mobile_users_id, MAX(mat.local_datetime) FROM mobile_access_token mat
                            GROUP BY mat.fk_mobile_users_id) mat ON mat.fk_mobile_users_id = egm.fk_master_gothan_employee_id 
                            GROUP BY mdl.district_code) login ON login.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, COUNT(mgn.gothan_id) upmapped_gothans FROM master_district_lgd mdl 
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN employee_gothan_map egm ON mgn.gothan_id = egm.fk_master_gothan_name_id AND egm.is_active = 1
                            WHERE egm.fk_master_gothan_employee_id IS NULL
                            GROUP BY mgn.fk_master_district_id) g_n_map ON g_n_map.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, COUNT(mgn.gothan_id) mapped_gothan FROM master_district_lgd mdl 
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN employee_gothan_map egm ON mgn.gothan_id = egm.fk_master_gothan_name_id AND egm.is_active = 1
                            WHERE egm.fk_master_gothan_employee_id IS NOT NULL
                            GROUP BY mdl.district_code) g_map ON g_map.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code,
                        COUNT(CASE WHEN TIMESTAMPDIFF(DAY,td.sqlite_datetime,CURRENT_TIMESTAMP())< 7 THEN 1 ELSE NULL END) active_in_last_7_days, 
                        COUNT(CASE WHEN TIMESTAMPDIFF(DAY,td.sqlite_datetime,CURRENT_TIMESTAMP())< 30 THEN 1 ELSE NULL END) active_in_last_30_days			 
                        FROM master_district_lgd mdl
                        LEFT JOIN (SELECT table_data.fk_master_district_id, table_data.gothan_id, MAX(sqlite_datetime) sqlite_datetime 
                                        FROM (SELECT mgn.fk_master_district_id, mgn.gothan_id, pig.sqlite_datetime FROM master_gothan_name mgn
                                                LEFT JOIN permanent_info_gothan pig ON pig.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE pig.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id, mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, cwg.sqlite_datetime FROM master_gothan_name mgn 
                                                LEFT JOIN construction_works_gothan cwg ON cwg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE cwg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id, mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, pdg.sqlite_datetime FROM master_gothan_name mgn 
                                                LEFT JOIN production_details_gothan pdg ON pdg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE pdg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id,mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, sdg.sqlite_datetime FROM master_gothan_name mgn
                                                LEFT JOIN service_details_gothan sdg ON sdg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE sdg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id,mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, ssg.sqlite_datetime FROM master_gothan_name mgn 
                                                LEFT JOIN success_stories_gothan ssg ON ssg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE ssg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id,mgn.gothan_id) AS table_data
                                        GROUP BY table_data.fk_master_district_id, table_data.gothan_id) td ON td.fk_master_district_id = mdl.district_code
                        GROUP BY mdl.district_code) td ON td.district_code = mdl.district_code
                GROUP BY mdl.district_code, mdl.district_name_hin
ERROR - 2021-03-09 12:42:58 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\cmogit\application\models\Admin_Garuwa_Report_Model.php 962
INFO - 2021-03-09 16:04:10 --> Config Class Initialized
INFO - 2021-03-09 16:04:10 --> Hooks Class Initialized
DEBUG - 2021-03-09 16:04:10 --> UTF-8 Support Enabled
INFO - 2021-03-09 16:04:10 --> Utf8 Class Initialized
INFO - 2021-03-09 16:04:10 --> URI Class Initialized
INFO - 2021-03-09 16:04:10 --> Router Class Initialized
INFO - 2021-03-09 16:04:10 --> Output Class Initialized
INFO - 2021-03-09 16:04:11 --> Security Class Initialized
DEBUG - 2021-03-09 16:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-09 16:04:11 --> Input Class Initialized
INFO - 2021-03-09 16:04:11 --> Language Class Initialized
INFO - 2021-03-09 16:04:11 --> Loader Class Initialized
INFO - 2021-03-09 16:04:11 --> Helper loaded: url_helper
INFO - 2021-03-09 16:04:11 --> Helper loaded: file_helper
INFO - 2021-03-09 16:04:11 --> Helper loaded: form_helper
INFO - 2021-03-09 16:04:11 --> Helper loaded: text_helper
INFO - 2021-03-09 16:04:11 --> Helper loaded: security_helper
INFO - 2021-03-09 16:04:11 --> Helper loaded: ipaddress_helper
INFO - 2021-03-09 16:04:11 --> Helper loaded: json_output_helper
INFO - 2021-03-09 16:04:11 --> Helper loaded: sms_helper
INFO - 2021-03-09 16:04:11 --> Helper loaded: track_log_helper
INFO - 2021-03-09 16:04:11 --> Helper loaded: api_error_log_helper
INFO - 2021-03-09 16:04:11 --> Helper loaded: curl_call_helper
INFO - 2021-03-09 16:04:11 --> Database Driver Class Initialized
INFO - 2021-03-09 16:04:11 --> Email Class Initialized
DEBUG - 2021-03-09 16:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-09 16:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-09 16:04:11 --> Form Validation Class Initialized
INFO - 2021-03-09 16:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-09 16:04:11 --> Pagination Class Initialized
INFO - 2021-03-09 16:04:11 --> Model Class Initialized
INFO - 2021-03-09 16:04:11 --> Model Class Initialized
INFO - 2021-03-09 16:04:11 --> Model Class Initialized
INFO - 2021-03-09 16:04:11 --> Model Class Initialized
INFO - 2021-03-09 16:04:11 --> Model Class Initialized
INFO - 2021-03-09 16:04:11 --> Controller Class Initialized
INFO - 2021-03-09 16:04:11 --> Helper loaded: string_helper
DEBUG - 2021-03-09 16:04:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-09 16:04:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-03-09 16:04:11 --> Model Class Initialized
INFO - 2021-03-09 16:04:12 --> Model Class Initialized
ERROR - 2021-03-09 16:04:12 --> Query error: Table 'cmchhatt_flagship.master_district_lgd' doesn't exist - Invalid query: SELECT mdl.district_code code, 
                mdl.district_name_hin name, 
                IFNULL(sd.sanctioned_gothans,0) sanctioned_gothans, 
                COUNT(mgn.gothan_id) total_gothans, 
                pg.start_gothan, 
                pg.inprogress_gothan, 
                pg.complete_gothan, 
                IFNULL(g_map.mapped_gothan,0) mapped_gothans,
                IFNULL(g_n_map.upmapped_gothans,0) upmapped_gothans,
                login.logged_in_gothans, 
                login.not_logged_in_gothans,
                pg.pig_count,
                pg.no_pig_count,
                td.active_in_last_7_days,
                (COUNT(mgn.gothan_id) - td.active_in_last_7_days) not_active_in_last_7_days,
                td.active_in_last_30_days,
                (COUNT(mgn.gothan_id) - td.active_in_last_30_days) not_active_in_last_30_days
                FROM master_district_lgd mdl
                LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                LEFT JOIN (SELECT mdl.district_code, SUM(sct.sanctioned_count) sanctioned_gothans FROM master_district_lgd mdl
                            LEFT JOIN sanctioned_count_tb sct ON sct.fk_master_district_code = mdl.district_code
                            GROUP BY mdl.district_code) sd ON sd.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, mdl.district_name_hin, COUNT(pig.info_id) pig_count,
                                    COUNT(IF(pig.info_id IS NULL, 1, NULL)) no_pig_count,
                                    COUNT(IF(pig.gothan_status=1,1,NULL)) start_gothan, 
                                    COUNT(IF(pig.gothan_status=2,1,NULL)) inprogress_gothan,
                                    COUNT(IF(pig.gothan_status=3,1,NULL)) complete_gothan
                                    FROM master_district_lgd mdl 
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN permanent_info_gothan pig ON mgn.gothan_id = pig.gothan_id
                            GROUP BY mdl.district_code, mdl.district_name_hin) pg ON pg.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, COUNT(egm.fk_master_gothan_employee_id) logged_in_gothans, 
                                    COUNT(IF(egm.fk_master_gothan_employee_id IS NULL,1,NULL)) not_logged_in_gothans
                                    FROM master_district_lgd mdl
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN employee_gothan_map egm ON egm.fk_master_gothan_name_id = mgn.gothan_id AND egm.is_active = 1
                            LEFT JOIN (SELECT mat.fk_mobile_users_id, MAX(mat.local_datetime) FROM mobile_access_token mat
                            GROUP BY mat.fk_mobile_users_id) mat ON mat.fk_mobile_users_id = egm.fk_master_gothan_employee_id 
                            GROUP BY mdl.district_code) login ON login.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, COUNT(mgn.gothan_id) upmapped_gothans FROM master_district_lgd mdl 
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN employee_gothan_map egm ON mgn.gothan_id = egm.fk_master_gothan_name_id AND egm.is_active = 1
                            WHERE egm.fk_master_gothan_employee_id IS NULL
                            GROUP BY mgn.fk_master_district_id) g_n_map ON g_n_map.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, COUNT(mgn.gothan_id) mapped_gothan FROM master_district_lgd mdl 
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN employee_gothan_map egm ON mgn.gothan_id = egm.fk_master_gothan_name_id AND egm.is_active = 1
                            WHERE egm.fk_master_gothan_employee_id IS NOT NULL
                            GROUP BY mdl.district_code) g_map ON g_map.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code,
                        COUNT(CASE WHEN TIMESTAMPDIFF(DAY,td.sqlite_datetime,CURRENT_TIMESTAMP())< 7 THEN 1 ELSE NULL END) active_in_last_7_days, 
                        COUNT(CASE WHEN TIMESTAMPDIFF(DAY,td.sqlite_datetime,CURRENT_TIMESTAMP())< 30 THEN 1 ELSE NULL END) active_in_last_30_days			 
                        FROM master_district_lgd mdl
                        LEFT JOIN (SELECT table_data.fk_master_district_id, table_data.gothan_id, MAX(sqlite_datetime) sqlite_datetime 
                                        FROM (SELECT mgn.fk_master_district_id, mgn.gothan_id, pig.sqlite_datetime FROM master_gothan_name mgn
                                                LEFT JOIN permanent_info_gothan pig ON pig.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE pig.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id, mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, cwg.sqlite_datetime FROM master_gothan_name mgn 
                                                LEFT JOIN construction_works_gothan cwg ON cwg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE cwg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id, mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, pdg.sqlite_datetime FROM master_gothan_name mgn 
                                                LEFT JOIN production_details_gothan pdg ON pdg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE pdg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id,mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, sdg.sqlite_datetime FROM master_gothan_name mgn
                                                LEFT JOIN service_details_gothan sdg ON sdg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE sdg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id,mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, ssg.sqlite_datetime FROM master_gothan_name mgn 
                                                LEFT JOIN success_stories_gothan ssg ON ssg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE ssg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id,mgn.gothan_id) AS table_data
                                        GROUP BY table_data.fk_master_district_id, table_data.gothan_id) td ON td.fk_master_district_id = mdl.district_code
                        GROUP BY mdl.district_code) td ON td.district_code = mdl.district_code
                GROUP BY mdl.district_code, mdl.district_name_hin
ERROR - 2021-03-09 16:04:12 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\cmogit\application\models\Admin_Garuwa_Report_Model.php 962
INFO - 2021-03-09 16:04:14 --> Config Class Initialized
INFO - 2021-03-09 16:04:14 --> Hooks Class Initialized
DEBUG - 2021-03-09 16:04:14 --> UTF-8 Support Enabled
INFO - 2021-03-09 16:04:14 --> Utf8 Class Initialized
INFO - 2021-03-09 16:04:14 --> URI Class Initialized
INFO - 2021-03-09 16:04:14 --> Router Class Initialized
INFO - 2021-03-09 16:04:14 --> Output Class Initialized
INFO - 2021-03-09 16:04:14 --> Security Class Initialized
DEBUG - 2021-03-09 16:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-09 16:04:14 --> Input Class Initialized
INFO - 2021-03-09 16:04:14 --> Language Class Initialized
INFO - 2021-03-09 16:04:14 --> Loader Class Initialized
INFO - 2021-03-09 16:04:14 --> Helper loaded: url_helper
INFO - 2021-03-09 16:04:14 --> Helper loaded: file_helper
INFO - 2021-03-09 16:04:14 --> Helper loaded: form_helper
INFO - 2021-03-09 16:04:14 --> Helper loaded: text_helper
INFO - 2021-03-09 16:04:14 --> Helper loaded: security_helper
INFO - 2021-03-09 16:04:14 --> Helper loaded: ipaddress_helper
INFO - 2021-03-09 16:04:14 --> Helper loaded: json_output_helper
INFO - 2021-03-09 16:04:14 --> Helper loaded: sms_helper
INFO - 2021-03-09 16:04:14 --> Helper loaded: track_log_helper
INFO - 2021-03-09 16:04:14 --> Helper loaded: api_error_log_helper
INFO - 2021-03-09 16:04:14 --> Helper loaded: curl_call_helper
INFO - 2021-03-09 16:04:14 --> Database Driver Class Initialized
INFO - 2021-03-09 16:04:14 --> Email Class Initialized
DEBUG - 2021-03-09 16:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-09 16:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-09 16:04:15 --> Form Validation Class Initialized
INFO - 2021-03-09 16:04:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-09 16:04:15 --> Pagination Class Initialized
INFO - 2021-03-09 16:04:15 --> Model Class Initialized
INFO - 2021-03-09 16:04:15 --> Model Class Initialized
INFO - 2021-03-09 16:04:15 --> Model Class Initialized
INFO - 2021-03-09 16:04:15 --> Model Class Initialized
INFO - 2021-03-09 16:04:15 --> Model Class Initialized
INFO - 2021-03-09 16:04:15 --> Controller Class Initialized
INFO - 2021-03-09 16:04:15 --> Helper loaded: string_helper
DEBUG - 2021-03-09 16:04:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-09 16:04:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-03-09 16:04:15 --> Model Class Initialized
INFO - 2021-03-09 16:04:15 --> Model Class Initialized
ERROR - 2021-03-09 16:04:15 --> Query error: Table 'cmchhatt_flagship.master_district_lgd' doesn't exist - Invalid query: SELECT mdl.district_code code, 
                mdl.district_name_hin name, 
                IFNULL(sd.sanctioned_gothans,0) sanctioned_gothans, 
                COUNT(mgn.gothan_id) total_gothans, 
                pg.start_gothan, 
                pg.inprogress_gothan, 
                pg.complete_gothan, 
                IFNULL(g_map.mapped_gothan,0) mapped_gothans,
                IFNULL(g_n_map.upmapped_gothans,0) upmapped_gothans,
                login.logged_in_gothans, 
                login.not_logged_in_gothans,
                pg.pig_count,
                pg.no_pig_count,
                td.active_in_last_7_days,
                (COUNT(mgn.gothan_id) - td.active_in_last_7_days) not_active_in_last_7_days,
                td.active_in_last_30_days,
                (COUNT(mgn.gothan_id) - td.active_in_last_30_days) not_active_in_last_30_days
                FROM master_district_lgd mdl
                LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                LEFT JOIN (SELECT mdl.district_code, SUM(sct.sanctioned_count) sanctioned_gothans FROM master_district_lgd mdl
                            LEFT JOIN sanctioned_count_tb sct ON sct.fk_master_district_code = mdl.district_code
                            GROUP BY mdl.district_code) sd ON sd.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, mdl.district_name_hin, COUNT(pig.info_id) pig_count,
                                    COUNT(IF(pig.info_id IS NULL, 1, NULL)) no_pig_count,
                                    COUNT(IF(pig.gothan_status=1,1,NULL)) start_gothan, 
                                    COUNT(IF(pig.gothan_status=2,1,NULL)) inprogress_gothan,
                                    COUNT(IF(pig.gothan_status=3,1,NULL)) complete_gothan
                                    FROM master_district_lgd mdl 
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN permanent_info_gothan pig ON mgn.gothan_id = pig.gothan_id
                            GROUP BY mdl.district_code, mdl.district_name_hin) pg ON pg.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, COUNT(egm.fk_master_gothan_employee_id) logged_in_gothans, 
                                    COUNT(IF(egm.fk_master_gothan_employee_id IS NULL,1,NULL)) not_logged_in_gothans
                                    FROM master_district_lgd mdl
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN employee_gothan_map egm ON egm.fk_master_gothan_name_id = mgn.gothan_id AND egm.is_active = 1
                            LEFT JOIN (SELECT mat.fk_mobile_users_id, MAX(mat.local_datetime) FROM mobile_access_token mat
                            GROUP BY mat.fk_mobile_users_id) mat ON mat.fk_mobile_users_id = egm.fk_master_gothan_employee_id 
                            GROUP BY mdl.district_code) login ON login.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, COUNT(mgn.gothan_id) upmapped_gothans FROM master_district_lgd mdl 
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN employee_gothan_map egm ON mgn.gothan_id = egm.fk_master_gothan_name_id AND egm.is_active = 1
                            WHERE egm.fk_master_gothan_employee_id IS NULL
                            GROUP BY mgn.fk_master_district_id) g_n_map ON g_n_map.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, COUNT(mgn.gothan_id) mapped_gothan FROM master_district_lgd mdl 
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN employee_gothan_map egm ON mgn.gothan_id = egm.fk_master_gothan_name_id AND egm.is_active = 1
                            WHERE egm.fk_master_gothan_employee_id IS NOT NULL
                            GROUP BY mdl.district_code) g_map ON g_map.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code,
                        COUNT(CASE WHEN TIMESTAMPDIFF(DAY,td.sqlite_datetime,CURRENT_TIMESTAMP())< 7 THEN 1 ELSE NULL END) active_in_last_7_days, 
                        COUNT(CASE WHEN TIMESTAMPDIFF(DAY,td.sqlite_datetime,CURRENT_TIMESTAMP())< 30 THEN 1 ELSE NULL END) active_in_last_30_days			 
                        FROM master_district_lgd mdl
                        LEFT JOIN (SELECT table_data.fk_master_district_id, table_data.gothan_id, MAX(sqlite_datetime) sqlite_datetime 
                                        FROM (SELECT mgn.fk_master_district_id, mgn.gothan_id, pig.sqlite_datetime FROM master_gothan_name mgn
                                                LEFT JOIN permanent_info_gothan pig ON pig.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE pig.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id, mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, cwg.sqlite_datetime FROM master_gothan_name mgn 
                                                LEFT JOIN construction_works_gothan cwg ON cwg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE cwg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id, mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, pdg.sqlite_datetime FROM master_gothan_name mgn 
                                                LEFT JOIN production_details_gothan pdg ON pdg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE pdg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id,mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, sdg.sqlite_datetime FROM master_gothan_name mgn
                                                LEFT JOIN service_details_gothan sdg ON sdg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE sdg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id,mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, ssg.sqlite_datetime FROM master_gothan_name mgn 
                                                LEFT JOIN success_stories_gothan ssg ON ssg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE ssg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id,mgn.gothan_id) AS table_data
                                        GROUP BY table_data.fk_master_district_id, table_data.gothan_id) td ON td.fk_master_district_id = mdl.district_code
                        GROUP BY mdl.district_code) td ON td.district_code = mdl.district_code
                GROUP BY mdl.district_code, mdl.district_name_hin
ERROR - 2021-03-09 16:04:15 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\cmogit\application\models\Admin_Garuwa_Report_Model.php 962
INFO - 2021-03-09 16:05:06 --> Config Class Initialized
INFO - 2021-03-09 16:05:06 --> Hooks Class Initialized
DEBUG - 2021-03-09 16:05:06 --> UTF-8 Support Enabled
INFO - 2021-03-09 16:05:06 --> Utf8 Class Initialized
INFO - 2021-03-09 16:05:06 --> URI Class Initialized
INFO - 2021-03-09 16:05:06 --> Router Class Initialized
INFO - 2021-03-09 16:05:06 --> Output Class Initialized
INFO - 2021-03-09 16:05:06 --> Security Class Initialized
DEBUG - 2021-03-09 16:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-09 16:05:06 --> Input Class Initialized
INFO - 2021-03-09 16:05:06 --> Language Class Initialized
INFO - 2021-03-09 16:05:06 --> Loader Class Initialized
INFO - 2021-03-09 16:05:06 --> Helper loaded: url_helper
INFO - 2021-03-09 16:05:06 --> Helper loaded: file_helper
INFO - 2021-03-09 16:05:06 --> Helper loaded: form_helper
INFO - 2021-03-09 16:05:06 --> Helper loaded: text_helper
INFO - 2021-03-09 16:05:06 --> Helper loaded: security_helper
INFO - 2021-03-09 16:05:06 --> Helper loaded: ipaddress_helper
INFO - 2021-03-09 16:05:06 --> Helper loaded: json_output_helper
INFO - 2021-03-09 16:05:06 --> Helper loaded: sms_helper
INFO - 2021-03-09 16:05:06 --> Helper loaded: track_log_helper
INFO - 2021-03-09 16:05:07 --> Helper loaded: api_error_log_helper
INFO - 2021-03-09 16:05:07 --> Helper loaded: curl_call_helper
INFO - 2021-03-09 16:05:07 --> Database Driver Class Initialized
INFO - 2021-03-09 16:05:07 --> Email Class Initialized
DEBUG - 2021-03-09 16:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-09 16:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-09 16:05:07 --> Form Validation Class Initialized
INFO - 2021-03-09 16:05:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-09 16:05:07 --> Pagination Class Initialized
INFO - 2021-03-09 16:05:07 --> Model Class Initialized
INFO - 2021-03-09 16:05:07 --> Model Class Initialized
INFO - 2021-03-09 16:05:07 --> Model Class Initialized
INFO - 2021-03-09 16:05:07 --> Model Class Initialized
INFO - 2021-03-09 16:05:07 --> Model Class Initialized
INFO - 2021-03-09 16:05:07 --> Controller Class Initialized
INFO - 2021-03-09 16:05:07 --> Helper loaded: string_helper
DEBUG - 2021-03-09 16:05:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-09 16:05:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-03-09 16:05:07 --> Model Class Initialized
INFO - 2021-03-09 16:05:07 --> Model Class Initialized
ERROR - 2021-03-09 16:05:07 --> Query error: Table 'cmchhatt_flagship.master_district_lgd' doesn't exist - Invalid query: SELECT mdl.district_code code, 
                mdl.district_name_hin name, 
                IFNULL(sd.sanctioned_gothans,0) sanctioned_gothans, 
                COUNT(mgn.gothan_id) total_gothans, 
                pg.start_gothan, 
                pg.inprogress_gothan, 
                pg.complete_gothan, 
                IFNULL(g_map.mapped_gothan,0) mapped_gothans,
                IFNULL(g_n_map.upmapped_gothans,0) upmapped_gothans,
                login.logged_in_gothans, 
                login.not_logged_in_gothans,
                pg.pig_count,
                pg.no_pig_count,
                td.active_in_last_7_days,
                (COUNT(mgn.gothan_id) - td.active_in_last_7_days) not_active_in_last_7_days,
                td.active_in_last_30_days,
                (COUNT(mgn.gothan_id) - td.active_in_last_30_days) not_active_in_last_30_days
                FROM master_district_lgd mdl
                LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                LEFT JOIN (SELECT mdl.district_code, SUM(sct.sanctioned_count) sanctioned_gothans FROM master_district_lgd mdl
                            LEFT JOIN sanctioned_count_tb sct ON sct.fk_master_district_code = mdl.district_code
                            GROUP BY mdl.district_code) sd ON sd.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, mdl.district_name_hin, COUNT(pig.info_id) pig_count,
                                    COUNT(IF(pig.info_id IS NULL, 1, NULL)) no_pig_count,
                                    COUNT(IF(pig.gothan_status=1,1,NULL)) start_gothan, 
                                    COUNT(IF(pig.gothan_status=2,1,NULL)) inprogress_gothan,
                                    COUNT(IF(pig.gothan_status=3,1,NULL)) complete_gothan
                                    FROM master_district_lgd mdl 
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN permanent_info_gothan pig ON mgn.gothan_id = pig.gothan_id
                            GROUP BY mdl.district_code, mdl.district_name_hin) pg ON pg.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, COUNT(egm.fk_master_gothan_employee_id) logged_in_gothans, 
                                    COUNT(IF(egm.fk_master_gothan_employee_id IS NULL,1,NULL)) not_logged_in_gothans
                                    FROM master_district_lgd mdl
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN employee_gothan_map egm ON egm.fk_master_gothan_name_id = mgn.gothan_id AND egm.is_active = 1
                            LEFT JOIN (SELECT mat.fk_mobile_users_id, MAX(mat.local_datetime) FROM mobile_access_token mat
                            GROUP BY mat.fk_mobile_users_id) mat ON mat.fk_mobile_users_id = egm.fk_master_gothan_employee_id 
                            GROUP BY mdl.district_code) login ON login.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, COUNT(mgn.gothan_id) upmapped_gothans FROM master_district_lgd mdl 
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN employee_gothan_map egm ON mgn.gothan_id = egm.fk_master_gothan_name_id AND egm.is_active = 1
                            WHERE egm.fk_master_gothan_employee_id IS NULL
                            GROUP BY mgn.fk_master_district_id) g_n_map ON g_n_map.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, COUNT(mgn.gothan_id) mapped_gothan FROM master_district_lgd mdl 
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN employee_gothan_map egm ON mgn.gothan_id = egm.fk_master_gothan_name_id AND egm.is_active = 1
                            WHERE egm.fk_master_gothan_employee_id IS NOT NULL
                            GROUP BY mdl.district_code) g_map ON g_map.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code,
                        COUNT(CASE WHEN TIMESTAMPDIFF(DAY,td.sqlite_datetime,CURRENT_TIMESTAMP())< 7 THEN 1 ELSE NULL END) active_in_last_7_days, 
                        COUNT(CASE WHEN TIMESTAMPDIFF(DAY,td.sqlite_datetime,CURRENT_TIMESTAMP())< 30 THEN 1 ELSE NULL END) active_in_last_30_days			 
                        FROM master_district_lgd mdl
                        LEFT JOIN (SELECT table_data.fk_master_district_id, table_data.gothan_id, MAX(sqlite_datetime) sqlite_datetime 
                                        FROM (SELECT mgn.fk_master_district_id, mgn.gothan_id, pig.sqlite_datetime FROM master_gothan_name mgn
                                                LEFT JOIN permanent_info_gothan pig ON pig.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE pig.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id, mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, cwg.sqlite_datetime FROM master_gothan_name mgn 
                                                LEFT JOIN construction_works_gothan cwg ON cwg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE cwg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id, mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, pdg.sqlite_datetime FROM master_gothan_name mgn 
                                                LEFT JOIN production_details_gothan pdg ON pdg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE pdg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id,mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, sdg.sqlite_datetime FROM master_gothan_name mgn
                                                LEFT JOIN service_details_gothan sdg ON sdg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE sdg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id,mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, ssg.sqlite_datetime FROM master_gothan_name mgn 
                                                LEFT JOIN success_stories_gothan ssg ON ssg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE ssg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id,mgn.gothan_id) AS table_data
                                        GROUP BY table_data.fk_master_district_id, table_data.gothan_id) td ON td.fk_master_district_id = mdl.district_code
                        GROUP BY mdl.district_code) td ON td.district_code = mdl.district_code
                GROUP BY mdl.district_code, mdl.district_name_hin
ERROR - 2021-03-09 16:05:07 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\cmogit\application\models\Admin_Garuwa_Report_Model.php 962
INFO - 2021-03-09 16:05:09 --> Config Class Initialized
INFO - 2021-03-09 16:05:09 --> Hooks Class Initialized
DEBUG - 2021-03-09 16:05:09 --> UTF-8 Support Enabled
INFO - 2021-03-09 16:05:09 --> Utf8 Class Initialized
INFO - 2021-03-09 16:05:09 --> URI Class Initialized
INFO - 2021-03-09 16:05:09 --> Router Class Initialized
INFO - 2021-03-09 16:05:09 --> Output Class Initialized
INFO - 2021-03-09 16:05:09 --> Security Class Initialized
DEBUG - 2021-03-09 16:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-09 16:05:09 --> Input Class Initialized
INFO - 2021-03-09 16:05:09 --> Language Class Initialized
INFO - 2021-03-09 16:05:09 --> Loader Class Initialized
INFO - 2021-03-09 16:05:09 --> Helper loaded: url_helper
INFO - 2021-03-09 16:05:09 --> Helper loaded: file_helper
INFO - 2021-03-09 16:05:09 --> Helper loaded: form_helper
INFO - 2021-03-09 16:05:09 --> Helper loaded: text_helper
INFO - 2021-03-09 16:05:09 --> Helper loaded: security_helper
INFO - 2021-03-09 16:05:09 --> Helper loaded: ipaddress_helper
INFO - 2021-03-09 16:05:09 --> Helper loaded: json_output_helper
INFO - 2021-03-09 16:05:09 --> Helper loaded: sms_helper
INFO - 2021-03-09 16:05:09 --> Helper loaded: track_log_helper
INFO - 2021-03-09 16:05:10 --> Helper loaded: api_error_log_helper
INFO - 2021-03-09 16:05:10 --> Helper loaded: curl_call_helper
INFO - 2021-03-09 16:05:10 --> Database Driver Class Initialized
INFO - 2021-03-09 16:05:10 --> Email Class Initialized
DEBUG - 2021-03-09 16:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-09 16:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-09 16:05:10 --> Form Validation Class Initialized
INFO - 2021-03-09 16:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-09 16:05:10 --> Pagination Class Initialized
INFO - 2021-03-09 16:05:10 --> Model Class Initialized
INFO - 2021-03-09 16:05:10 --> Model Class Initialized
INFO - 2021-03-09 16:05:10 --> Model Class Initialized
INFO - 2021-03-09 16:05:10 --> Model Class Initialized
INFO - 2021-03-09 16:05:10 --> Model Class Initialized
INFO - 2021-03-09 16:05:10 --> Controller Class Initialized
INFO - 2021-03-09 16:05:10 --> Helper loaded: string_helper
DEBUG - 2021-03-09 16:05:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-09 16:05:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-03-09 16:05:10 --> Model Class Initialized
INFO - 2021-03-09 16:05:10 --> Model Class Initialized
ERROR - 2021-03-09 16:05:10 --> Query error: Table 'cmchhatt_flagship.master_district_lgd' doesn't exist - Invalid query: SELECT mdl.district_code code, 
                mdl.district_name_hin name, 
                IFNULL(sd.sanctioned_gothans,0) sanctioned_gothans, 
                COUNT(mgn.gothan_id) total_gothans, 
                pg.start_gothan, 
                pg.inprogress_gothan, 
                pg.complete_gothan, 
                IFNULL(g_map.mapped_gothan,0) mapped_gothans,
                IFNULL(g_n_map.upmapped_gothans,0) upmapped_gothans,
                login.logged_in_gothans, 
                login.not_logged_in_gothans,
                pg.pig_count,
                pg.no_pig_count,
                td.active_in_last_7_days,
                (COUNT(mgn.gothan_id) - td.active_in_last_7_days) not_active_in_last_7_days,
                td.active_in_last_30_days,
                (COUNT(mgn.gothan_id) - td.active_in_last_30_days) not_active_in_last_30_days
                FROM master_district_lgd mdl
                LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                LEFT JOIN (SELECT mdl.district_code, SUM(sct.sanctioned_count) sanctioned_gothans FROM master_district_lgd mdl
                            LEFT JOIN sanctioned_count_tb sct ON sct.fk_master_district_code = mdl.district_code
                            GROUP BY mdl.district_code) sd ON sd.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, mdl.district_name_hin, COUNT(pig.info_id) pig_count,
                                    COUNT(IF(pig.info_id IS NULL, 1, NULL)) no_pig_count,
                                    COUNT(IF(pig.gothan_status=1,1,NULL)) start_gothan, 
                                    COUNT(IF(pig.gothan_status=2,1,NULL)) inprogress_gothan,
                                    COUNT(IF(pig.gothan_status=3,1,NULL)) complete_gothan
                                    FROM master_district_lgd mdl 
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN permanent_info_gothan pig ON mgn.gothan_id = pig.gothan_id
                            GROUP BY mdl.district_code, mdl.district_name_hin) pg ON pg.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, COUNT(egm.fk_master_gothan_employee_id) logged_in_gothans, 
                                    COUNT(IF(egm.fk_master_gothan_employee_id IS NULL,1,NULL)) not_logged_in_gothans
                                    FROM master_district_lgd mdl
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN employee_gothan_map egm ON egm.fk_master_gothan_name_id = mgn.gothan_id AND egm.is_active = 1
                            LEFT JOIN (SELECT mat.fk_mobile_users_id, MAX(mat.local_datetime) FROM mobile_access_token mat
                            GROUP BY mat.fk_mobile_users_id) mat ON mat.fk_mobile_users_id = egm.fk_master_gothan_employee_id 
                            GROUP BY mdl.district_code) login ON login.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, COUNT(mgn.gothan_id) upmapped_gothans FROM master_district_lgd mdl 
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN employee_gothan_map egm ON mgn.gothan_id = egm.fk_master_gothan_name_id AND egm.is_active = 1
                            WHERE egm.fk_master_gothan_employee_id IS NULL
                            GROUP BY mgn.fk_master_district_id) g_n_map ON g_n_map.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code, COUNT(mgn.gothan_id) mapped_gothan FROM master_district_lgd mdl 
                            LEFT JOIN master_gothan_name mgn ON mgn.fk_master_district_id = mdl.district_code AND mgn.is_deleted = 0
                            LEFT JOIN employee_gothan_map egm ON mgn.gothan_id = egm.fk_master_gothan_name_id AND egm.is_active = 1
                            WHERE egm.fk_master_gothan_employee_id IS NOT NULL
                            GROUP BY mdl.district_code) g_map ON g_map.district_code = mdl.district_code
                LEFT JOIN (SELECT mdl.district_code,
                        COUNT(CASE WHEN TIMESTAMPDIFF(DAY,td.sqlite_datetime,CURRENT_TIMESTAMP())< 7 THEN 1 ELSE NULL END) active_in_last_7_days, 
                        COUNT(CASE WHEN TIMESTAMPDIFF(DAY,td.sqlite_datetime,CURRENT_TIMESTAMP())< 30 THEN 1 ELSE NULL END) active_in_last_30_days			 
                        FROM master_district_lgd mdl
                        LEFT JOIN (SELECT table_data.fk_master_district_id, table_data.gothan_id, MAX(sqlite_datetime) sqlite_datetime 
                                        FROM (SELECT mgn.fk_master_district_id, mgn.gothan_id, pig.sqlite_datetime FROM master_gothan_name mgn
                                                LEFT JOIN permanent_info_gothan pig ON pig.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE pig.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id, mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, cwg.sqlite_datetime FROM master_gothan_name mgn 
                                                LEFT JOIN construction_works_gothan cwg ON cwg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE cwg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id, mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, pdg.sqlite_datetime FROM master_gothan_name mgn 
                                                LEFT JOIN production_details_gothan pdg ON pdg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE pdg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id,mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, sdg.sqlite_datetime FROM master_gothan_name mgn
                                                LEFT JOIN service_details_gothan sdg ON sdg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE sdg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id,mgn.gothan_id
                                                UNION
                                                SELECT mgn.fk_master_district_id, mgn.gothan_id, ssg.sqlite_datetime FROM master_gothan_name mgn 
                                                LEFT JOIN success_stories_gothan ssg ON ssg.gothan_id = mgn.gothan_id AND mgn.is_deleted = 0
                                                WHERE ssg.sqlite_datetime IS NOT NULL 
                                                GROUP BY mgn.fk_master_district_id,mgn.gothan_id) AS table_data
                                        GROUP BY table_data.fk_master_district_id, table_data.gothan_id) td ON td.fk_master_district_id = mdl.district_code
                        GROUP BY mdl.district_code) td ON td.district_code = mdl.district_code
                GROUP BY mdl.district_code, mdl.district_name_hin
ERROR - 2021-03-09 16:05:10 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\cmogit\application\models\Admin_Garuwa_Report_Model.php 962
INFO - 2021-03-09 16:11:47 --> Config Class Initialized
INFO - 2021-03-09 16:11:47 --> Hooks Class Initialized
DEBUG - 2021-03-09 16:11:47 --> UTF-8 Support Enabled
INFO - 2021-03-09 16:11:47 --> Utf8 Class Initialized
INFO - 2021-03-09 16:11:47 --> URI Class Initialized
INFO - 2021-03-09 16:11:47 --> Router Class Initialized
INFO - 2021-03-09 16:11:47 --> Output Class Initialized
INFO - 2021-03-09 16:11:47 --> Security Class Initialized
DEBUG - 2021-03-09 16:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-09 16:11:48 --> Input Class Initialized
INFO - 2021-03-09 16:11:48 --> Language Class Initialized
INFO - 2021-03-09 16:11:48 --> Loader Class Initialized
INFO - 2021-03-09 16:11:48 --> Helper loaded: url_helper
INFO - 2021-03-09 16:11:48 --> Helper loaded: file_helper
INFO - 2021-03-09 16:11:48 --> Helper loaded: form_helper
INFO - 2021-03-09 16:11:48 --> Helper loaded: text_helper
INFO - 2021-03-09 16:11:48 --> Helper loaded: security_helper
INFO - 2021-03-09 16:11:48 --> Helper loaded: ipaddress_helper
INFO - 2021-03-09 16:11:48 --> Helper loaded: json_output_helper
INFO - 2021-03-09 16:11:48 --> Helper loaded: sms_helper
INFO - 2021-03-09 16:11:48 --> Helper loaded: track_log_helper
INFO - 2021-03-09 16:11:48 --> Helper loaded: api_error_log_helper
INFO - 2021-03-09 16:11:48 --> Helper loaded: curl_call_helper
INFO - 2021-03-09 16:11:48 --> Database Driver Class Initialized
INFO - 2021-03-09 16:11:48 --> Email Class Initialized
DEBUG - 2021-03-09 16:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-09 16:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-09 16:11:48 --> Form Validation Class Initialized
INFO - 2021-03-09 16:11:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-09 16:11:48 --> Pagination Class Initialized
INFO - 2021-03-09 16:11:49 --> Model Class Initialized
INFO - 2021-03-09 16:11:49 --> Model Class Initialized
INFO - 2021-03-09 16:11:49 --> Model Class Initialized
INFO - 2021-03-09 16:11:49 --> Model Class Initialized
INFO - 2021-03-09 16:11:49 --> Model Class Initialized
INFO - 2021-03-09 16:11:49 --> Controller Class Initialized
INFO - 2021-03-09 16:11:49 --> Helper loaded: string_helper
DEBUG - 2021-03-09 16:11:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-09 16:11:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-03-09 16:11:49 --> Model Class Initialized
INFO - 2021-03-09 16:11:49 --> Model Class Initialized
INFO - 2021-03-09 16:11:53 --> File loaded: C:\xampp\htdocs\cmogit\application\views\report/gothan_report.php
INFO - 2021-03-09 16:11:53 --> Final output sent to browser
DEBUG - 2021-03-09 16:11:53 --> Total execution time: 5.5444
INFO - 2021-03-09 16:18:37 --> Config Class Initialized
INFO - 2021-03-09 16:18:37 --> Hooks Class Initialized
DEBUG - 2021-03-09 16:18:37 --> UTF-8 Support Enabled
INFO - 2021-03-09 16:18:37 --> Utf8 Class Initialized
INFO - 2021-03-09 16:18:37 --> URI Class Initialized
INFO - 2021-03-09 16:18:37 --> Router Class Initialized
INFO - 2021-03-09 16:18:37 --> Output Class Initialized
INFO - 2021-03-09 16:18:37 --> Security Class Initialized
DEBUG - 2021-03-09 16:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-09 16:18:37 --> Input Class Initialized
INFO - 2021-03-09 16:18:38 --> Language Class Initialized
INFO - 2021-03-09 16:18:38 --> Loader Class Initialized
INFO - 2021-03-09 16:18:38 --> Helper loaded: url_helper
INFO - 2021-03-09 16:18:38 --> Helper loaded: file_helper
INFO - 2021-03-09 16:18:38 --> Helper loaded: form_helper
INFO - 2021-03-09 16:18:38 --> Helper loaded: text_helper
INFO - 2021-03-09 16:18:38 --> Helper loaded: security_helper
INFO - 2021-03-09 16:18:38 --> Helper loaded: ipaddress_helper
INFO - 2021-03-09 16:18:38 --> Helper loaded: json_output_helper
INFO - 2021-03-09 16:18:38 --> Helper loaded: sms_helper
INFO - 2021-03-09 16:18:38 --> Helper loaded: track_log_helper
INFO - 2021-03-09 16:18:38 --> Helper loaded: api_error_log_helper
INFO - 2021-03-09 16:18:38 --> Helper loaded: curl_call_helper
INFO - 2021-03-09 16:18:38 --> Database Driver Class Initialized
INFO - 2021-03-09 16:18:38 --> Email Class Initialized
DEBUG - 2021-03-09 16:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-09 16:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-09 16:18:38 --> Form Validation Class Initialized
INFO - 2021-03-09 16:18:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-09 16:18:38 --> Pagination Class Initialized
INFO - 2021-03-09 16:18:38 --> Model Class Initialized
INFO - 2021-03-09 16:18:38 --> Model Class Initialized
INFO - 2021-03-09 16:18:38 --> Model Class Initialized
INFO - 2021-03-09 16:18:39 --> Model Class Initialized
INFO - 2021-03-09 16:18:39 --> Model Class Initialized
INFO - 2021-03-09 16:18:39 --> Controller Class Initialized
INFO - 2021-03-09 16:18:39 --> Helper loaded: string_helper
DEBUG - 2021-03-09 16:18:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-09 16:18:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-03-09 16:18:39 --> Model Class Initialized
INFO - 2021-03-09 16:18:39 --> Model Class Initialized
INFO - 2021-03-09 16:18:42 --> File loaded: C:\xampp\htdocs\cmogit\application\views\report/gothan_report.php
INFO - 2021-03-09 16:18:42 --> Final output sent to browser
DEBUG - 2021-03-09 16:18:42 --> Total execution time: 4.8446
INFO - 2021-03-09 16:22:06 --> Config Class Initialized
INFO - 2021-03-09 16:22:06 --> Hooks Class Initialized
DEBUG - 2021-03-09 16:22:06 --> UTF-8 Support Enabled
INFO - 2021-03-09 16:22:06 --> Utf8 Class Initialized
INFO - 2021-03-09 16:22:06 --> URI Class Initialized
INFO - 2021-03-09 16:22:06 --> Router Class Initialized
INFO - 2021-03-09 16:22:06 --> Output Class Initialized
INFO - 2021-03-09 16:22:06 --> Security Class Initialized
DEBUG - 2021-03-09 16:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-09 16:22:06 --> Input Class Initialized
INFO - 2021-03-09 16:22:06 --> Language Class Initialized
INFO - 2021-03-09 16:22:06 --> Loader Class Initialized
INFO - 2021-03-09 16:22:06 --> Helper loaded: url_helper
INFO - 2021-03-09 16:22:06 --> Helper loaded: file_helper
INFO - 2021-03-09 16:22:06 --> Helper loaded: form_helper
INFO - 2021-03-09 16:22:06 --> Helper loaded: text_helper
INFO - 2021-03-09 16:22:06 --> Helper loaded: security_helper
INFO - 2021-03-09 16:22:06 --> Helper loaded: ipaddress_helper
INFO - 2021-03-09 16:22:06 --> Helper loaded: json_output_helper
INFO - 2021-03-09 16:22:06 --> Helper loaded: sms_helper
INFO - 2021-03-09 16:22:06 --> Helper loaded: track_log_helper
INFO - 2021-03-09 16:22:06 --> Helper loaded: api_error_log_helper
INFO - 2021-03-09 16:22:06 --> Helper loaded: curl_call_helper
INFO - 2021-03-09 16:22:06 --> Database Driver Class Initialized
INFO - 2021-03-09 16:22:06 --> Email Class Initialized
DEBUG - 2021-03-09 16:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-09 16:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-09 16:22:06 --> Form Validation Class Initialized
INFO - 2021-03-09 16:22:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-09 16:22:07 --> Pagination Class Initialized
INFO - 2021-03-09 16:22:07 --> Model Class Initialized
INFO - 2021-03-09 16:22:07 --> Model Class Initialized
INFO - 2021-03-09 16:22:07 --> Model Class Initialized
INFO - 2021-03-09 16:22:07 --> Model Class Initialized
INFO - 2021-03-09 16:22:07 --> Model Class Initialized
INFO - 2021-03-09 16:22:07 --> Controller Class Initialized
INFO - 2021-03-09 16:22:07 --> Helper loaded: string_helper
DEBUG - 2021-03-09 16:22:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-09 16:22:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-03-09 16:22:07 --> Model Class Initialized
INFO - 2021-03-09 16:22:07 --> Model Class Initialized
INFO - 2021-03-09 16:22:10 --> File loaded: C:\xampp\htdocs\cmogit\application\views\report/gothan_report.php
INFO - 2021-03-09 16:22:10 --> Final output sent to browser
DEBUG - 2021-03-09 16:22:10 --> Total execution time: 4.5952
INFO - 2021-03-09 16:51:52 --> Config Class Initialized
INFO - 2021-03-09 16:51:52 --> Hooks Class Initialized
DEBUG - 2021-03-09 16:51:52 --> UTF-8 Support Enabled
INFO - 2021-03-09 16:51:52 --> Utf8 Class Initialized
INFO - 2021-03-09 16:51:52 --> URI Class Initialized
INFO - 2021-03-09 16:51:52 --> Router Class Initialized
INFO - 2021-03-09 16:51:52 --> Output Class Initialized
INFO - 2021-03-09 16:51:52 --> Security Class Initialized
DEBUG - 2021-03-09 16:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-09 16:51:52 --> Input Class Initialized
INFO - 2021-03-09 16:51:52 --> Language Class Initialized
INFO - 2021-03-09 16:51:52 --> Loader Class Initialized
INFO - 2021-03-09 16:51:52 --> Helper loaded: url_helper
INFO - 2021-03-09 16:51:52 --> Helper loaded: file_helper
INFO - 2021-03-09 16:51:52 --> Helper loaded: form_helper
INFO - 2021-03-09 16:51:52 --> Helper loaded: text_helper
INFO - 2021-03-09 16:51:52 --> Helper loaded: security_helper
INFO - 2021-03-09 16:51:52 --> Helper loaded: ipaddress_helper
INFO - 2021-03-09 16:51:52 --> Helper loaded: json_output_helper
INFO - 2021-03-09 16:51:52 --> Helper loaded: sms_helper
INFO - 2021-03-09 16:51:52 --> Helper loaded: track_log_helper
INFO - 2021-03-09 16:51:52 --> Helper loaded: api_error_log_helper
INFO - 2021-03-09 16:51:52 --> Helper loaded: curl_call_helper
INFO - 2021-03-09 16:51:52 --> Database Driver Class Initialized
INFO - 2021-03-09 16:51:52 --> Email Class Initialized
DEBUG - 2021-03-09 16:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-09 16:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-09 16:51:52 --> Form Validation Class Initialized
INFO - 2021-03-09 16:51:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-09 16:51:52 --> Pagination Class Initialized
INFO - 2021-03-09 16:51:52 --> Model Class Initialized
INFO - 2021-03-09 16:51:52 --> Model Class Initialized
INFO - 2021-03-09 16:51:52 --> Model Class Initialized
INFO - 2021-03-09 16:51:52 --> Model Class Initialized
INFO - 2021-03-09 16:51:53 --> Model Class Initialized
INFO - 2021-03-09 16:51:53 --> Controller Class Initialized
INFO - 2021-03-09 16:51:53 --> Helper loaded: string_helper
DEBUG - 2021-03-09 16:51:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-09 16:51:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-03-09 16:51:53 --> Model Class Initialized
INFO - 2021-03-09 16:51:53 --> Model Class Initialized
INFO - 2021-03-09 16:51:55 --> File loaded: C:\xampp\htdocs\cmogit\application\views\report/gothan_report.php
INFO - 2021-03-09 16:51:55 --> Final output sent to browser
DEBUG - 2021-03-09 16:51:55 --> Total execution time: 3.6010
INFO - 2021-03-09 17:09:04 --> Config Class Initialized
INFO - 2021-03-09 17:09:04 --> Hooks Class Initialized
DEBUG - 2021-03-09 17:09:04 --> UTF-8 Support Enabled
INFO - 2021-03-09 17:09:04 --> Utf8 Class Initialized
INFO - 2021-03-09 17:09:04 --> URI Class Initialized
INFO - 2021-03-09 17:09:04 --> Router Class Initialized
INFO - 2021-03-09 17:09:04 --> Output Class Initialized
INFO - 2021-03-09 17:09:04 --> Security Class Initialized
DEBUG - 2021-03-09 17:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-09 17:09:04 --> Input Class Initialized
INFO - 2021-03-09 17:09:04 --> Language Class Initialized
INFO - 2021-03-09 17:09:04 --> Loader Class Initialized
INFO - 2021-03-09 17:09:04 --> Helper loaded: url_helper
INFO - 2021-03-09 17:09:04 --> Helper loaded: file_helper
INFO - 2021-03-09 17:09:04 --> Helper loaded: form_helper
INFO - 2021-03-09 17:09:04 --> Helper loaded: text_helper
INFO - 2021-03-09 17:09:04 --> Helper loaded: security_helper
INFO - 2021-03-09 17:09:04 --> Helper loaded: ipaddress_helper
INFO - 2021-03-09 17:09:05 --> Helper loaded: json_output_helper
INFO - 2021-03-09 17:09:05 --> Helper loaded: sms_helper
INFO - 2021-03-09 17:09:05 --> Helper loaded: track_log_helper
INFO - 2021-03-09 17:09:05 --> Helper loaded: api_error_log_helper
INFO - 2021-03-09 17:09:05 --> Helper loaded: curl_call_helper
INFO - 2021-03-09 17:09:05 --> Database Driver Class Initialized
INFO - 2021-03-09 17:09:05 --> Email Class Initialized
DEBUG - 2021-03-09 17:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-09 17:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-09 17:09:05 --> Form Validation Class Initialized
INFO - 2021-03-09 17:09:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-09 17:09:05 --> Pagination Class Initialized
INFO - 2021-03-09 17:09:05 --> Model Class Initialized
INFO - 2021-03-09 17:09:05 --> Model Class Initialized
INFO - 2021-03-09 17:09:05 --> Model Class Initialized
INFO - 2021-03-09 17:09:05 --> Model Class Initialized
INFO - 2021-03-09 17:09:05 --> Model Class Initialized
INFO - 2021-03-09 17:09:05 --> Controller Class Initialized
INFO - 2021-03-09 17:09:05 --> Helper loaded: string_helper
DEBUG - 2021-03-09 17:09:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-09 17:09:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-03-09 17:09:05 --> Model Class Initialized
INFO - 2021-03-09 17:09:05 --> Model Class Initialized
ERROR - 2021-03-09 17:09:05 --> Severity: Notice --> Undefined property: ReportController::$AdminHaatReportModel C:\xampp\htdocs\cmogit\application\controllers\ReportController.php 80
ERROR - 2021-03-09 17:09:05 --> Severity: error --> Exception: Call to a member function overAllHbReport_DistrictWise() on null C:\xampp\htdocs\cmogit\application\controllers\ReportController.php 80
INFO - 2021-03-09 17:10:16 --> Config Class Initialized
INFO - 2021-03-09 17:10:17 --> Hooks Class Initialized
DEBUG - 2021-03-09 17:10:17 --> UTF-8 Support Enabled
INFO - 2021-03-09 17:10:17 --> Utf8 Class Initialized
INFO - 2021-03-09 17:10:17 --> URI Class Initialized
INFO - 2021-03-09 17:10:17 --> Router Class Initialized
INFO - 2021-03-09 17:10:17 --> Output Class Initialized
INFO - 2021-03-09 17:10:17 --> Security Class Initialized
DEBUG - 2021-03-09 17:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-09 17:10:17 --> Input Class Initialized
INFO - 2021-03-09 17:10:17 --> Language Class Initialized
INFO - 2021-03-09 17:10:17 --> Loader Class Initialized
INFO - 2021-03-09 17:10:17 --> Helper loaded: url_helper
INFO - 2021-03-09 17:10:17 --> Helper loaded: file_helper
INFO - 2021-03-09 17:10:17 --> Helper loaded: form_helper
INFO - 2021-03-09 17:10:17 --> Helper loaded: text_helper
INFO - 2021-03-09 17:10:17 --> Helper loaded: security_helper
INFO - 2021-03-09 17:10:17 --> Helper loaded: ipaddress_helper
INFO - 2021-03-09 17:10:17 --> Helper loaded: json_output_helper
INFO - 2021-03-09 17:10:17 --> Helper loaded: sms_helper
INFO - 2021-03-09 17:10:17 --> Helper loaded: track_log_helper
INFO - 2021-03-09 17:10:17 --> Helper loaded: api_error_log_helper
INFO - 2021-03-09 17:10:17 --> Helper loaded: curl_call_helper
INFO - 2021-03-09 17:10:17 --> Database Driver Class Initialized
INFO - 2021-03-09 17:10:17 --> Email Class Initialized
DEBUG - 2021-03-09 17:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-09 17:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-09 17:10:17 --> Form Validation Class Initialized
INFO - 2021-03-09 17:10:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-09 17:10:17 --> Pagination Class Initialized
INFO - 2021-03-09 17:10:17 --> Model Class Initialized
INFO - 2021-03-09 17:10:18 --> Model Class Initialized
INFO - 2021-03-09 17:10:18 --> Model Class Initialized
INFO - 2021-03-09 17:10:18 --> Model Class Initialized
INFO - 2021-03-09 17:10:18 --> Model Class Initialized
INFO - 2021-03-09 17:10:18 --> Controller Class Initialized
INFO - 2021-03-09 17:10:18 --> Helper loaded: string_helper
DEBUG - 2021-03-09 17:10:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-09 17:10:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-03-09 17:10:18 --> Model Class Initialized
INFO - 2021-03-09 17:10:18 --> Model Class Initialized
INFO - 2021-03-09 17:10:18 --> Model Class Initialized
INFO - 2021-03-09 17:10:21 --> File loaded: C:\xampp\htdocs\cmogit\application\views\report/haatbazaar_report.php
INFO - 2021-03-09 17:10:21 --> Final output sent to browser
DEBUG - 2021-03-09 17:10:21 --> Total execution time: 4.2555
INFO - 2021-03-09 17:31:28 --> Config Class Initialized
INFO - 2021-03-09 17:31:28 --> Hooks Class Initialized
DEBUG - 2021-03-09 17:31:28 --> UTF-8 Support Enabled
INFO - 2021-03-09 17:31:28 --> Utf8 Class Initialized
INFO - 2021-03-09 17:31:28 --> URI Class Initialized
INFO - 2021-03-09 17:31:28 --> Router Class Initialized
INFO - 2021-03-09 17:31:28 --> Output Class Initialized
INFO - 2021-03-09 17:31:28 --> Security Class Initialized
DEBUG - 2021-03-09 17:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-09 17:31:28 --> Input Class Initialized
INFO - 2021-03-09 17:31:28 --> Language Class Initialized
INFO - 2021-03-09 17:31:29 --> Loader Class Initialized
INFO - 2021-03-09 17:31:29 --> Helper loaded: url_helper
INFO - 2021-03-09 17:31:29 --> Helper loaded: file_helper
INFO - 2021-03-09 17:31:29 --> Helper loaded: form_helper
INFO - 2021-03-09 17:31:29 --> Helper loaded: text_helper
INFO - 2021-03-09 17:31:29 --> Helper loaded: security_helper
INFO - 2021-03-09 17:31:29 --> Helper loaded: ipaddress_helper
INFO - 2021-03-09 17:31:29 --> Helper loaded: json_output_helper
INFO - 2021-03-09 17:31:29 --> Helper loaded: sms_helper
INFO - 2021-03-09 17:31:29 --> Helper loaded: track_log_helper
INFO - 2021-03-09 17:31:29 --> Helper loaded: api_error_log_helper
INFO - 2021-03-09 17:31:29 --> Helper loaded: curl_call_helper
INFO - 2021-03-09 17:31:29 --> Database Driver Class Initialized
INFO - 2021-03-09 17:31:29 --> Email Class Initialized
DEBUG - 2021-03-09 17:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-09 17:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-09 17:31:29 --> Form Validation Class Initialized
INFO - 2021-03-09 17:31:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-09 17:31:29 --> Pagination Class Initialized
INFO - 2021-03-09 17:31:29 --> Model Class Initialized
INFO - 2021-03-09 17:31:29 --> Model Class Initialized
INFO - 2021-03-09 17:31:29 --> Model Class Initialized
INFO - 2021-03-09 17:31:29 --> Model Class Initialized
INFO - 2021-03-09 17:31:29 --> Model Class Initialized
INFO - 2021-03-09 17:31:29 --> Controller Class Initialized
INFO - 2021-03-09 17:31:29 --> Helper loaded: string_helper
DEBUG - 2021-03-09 17:31:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-09 17:31:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-03-09 17:31:29 --> Model Class Initialized
INFO - 2021-03-09 17:31:29 --> Model Class Initialized
INFO - 2021-03-09 17:31:29 --> Model Class Initialized
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:31 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:32 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:33 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:34 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:35 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:36 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 62
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: sanctioned_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: start_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 74
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: inprogress_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 75
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: complete_gothan C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 76
ERROR - 2021-03-09 17:31:37 --> Severity: Notice --> Undefined index: total_gothans C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 77
INFO - 2021-03-09 17:31:37 --> File loaded: C:\xampp\htdocs\cmogit\application\views\report/haatbazaar_report.php
INFO - 2021-03-09 17:31:37 --> Final output sent to browser
DEBUG - 2021-03-09 17:31:37 --> Total execution time: 9.1310
INFO - 2021-03-09 17:37:31 --> Config Class Initialized
INFO - 2021-03-09 17:37:31 --> Hooks Class Initialized
DEBUG - 2021-03-09 17:37:31 --> UTF-8 Support Enabled
INFO - 2021-03-09 17:37:31 --> Utf8 Class Initialized
INFO - 2021-03-09 17:37:32 --> URI Class Initialized
INFO - 2021-03-09 17:37:32 --> Router Class Initialized
INFO - 2021-03-09 17:37:32 --> Output Class Initialized
INFO - 2021-03-09 17:37:32 --> Security Class Initialized
DEBUG - 2021-03-09 17:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-09 17:37:32 --> Input Class Initialized
INFO - 2021-03-09 17:37:32 --> Language Class Initialized
INFO - 2021-03-09 17:37:32 --> Loader Class Initialized
INFO - 2021-03-09 17:37:32 --> Helper loaded: url_helper
INFO - 2021-03-09 17:37:32 --> Helper loaded: file_helper
INFO - 2021-03-09 17:37:32 --> Helper loaded: form_helper
INFO - 2021-03-09 17:37:32 --> Helper loaded: text_helper
INFO - 2021-03-09 17:37:32 --> Helper loaded: security_helper
INFO - 2021-03-09 17:37:32 --> Helper loaded: ipaddress_helper
INFO - 2021-03-09 17:37:32 --> Helper loaded: json_output_helper
INFO - 2021-03-09 17:37:32 --> Helper loaded: sms_helper
INFO - 2021-03-09 17:37:32 --> Helper loaded: track_log_helper
INFO - 2021-03-09 17:37:32 --> Helper loaded: api_error_log_helper
INFO - 2021-03-09 17:37:32 --> Helper loaded: curl_call_helper
INFO - 2021-03-09 17:37:32 --> Database Driver Class Initialized
INFO - 2021-03-09 17:37:32 --> Email Class Initialized
DEBUG - 2021-03-09 17:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-09 17:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-09 17:37:32 --> Form Validation Class Initialized
INFO - 2021-03-09 17:37:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-03-09 17:37:32 --> Pagination Class Initialized
INFO - 2021-03-09 17:37:32 --> Model Class Initialized
INFO - 2021-03-09 17:37:32 --> Model Class Initialized
INFO - 2021-03-09 17:37:32 --> Model Class Initialized
INFO - 2021-03-09 17:37:33 --> Model Class Initialized
INFO - 2021-03-09 17:37:33 --> Model Class Initialized
INFO - 2021-03-09 17:37:33 --> Controller Class Initialized
INFO - 2021-03-09 17:37:33 --> Helper loaded: string_helper
DEBUG - 2021-03-09 17:37:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2021-03-09 17:37:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-03-09 17:37:33 --> Model Class Initialized
INFO - 2021-03-09 17:37:33 --> Model Class Initialized
INFO - 2021-03-09 17:37:33 --> Model Class Initialized
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:34 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:36 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:37 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:38 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:39 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:39 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:39 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:39 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:39 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:39 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
ERROR - 2021-03-09 17:37:39 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 68
ERROR - 2021-03-09 17:37:39 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 69
ERROR - 2021-03-09 17:37:39 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 70
ERROR - 2021-03-09 17:37:39 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 71
ERROR - 2021-03-09 17:37:39 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 72
ERROR - 2021-03-09 17:37:39 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\cmogit\application\views\report\haatbazaar_report.php 73
INFO - 2021-03-09 17:37:39 --> File loaded: C:\xampp\htdocs\cmogit\application\views\report/haatbazaar_report.php
INFO - 2021-03-09 17:37:39 --> Final output sent to browser
DEBUG - 2021-03-09 17:37:39 --> Total execution time: 7.5702
