<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-04-01 12:04:19 --> Config Class Initialized
INFO - 2021-04-01 12:04:19 --> Hooks Class Initialized
DEBUG - 2021-04-01 12:04:19 --> UTF-8 Support Enabled
INFO - 2021-04-01 12:04:19 --> Utf8 Class Initialized
INFO - 2021-04-01 12:04:19 --> URI Class Initialized
INFO - 2021-04-01 12:04:19 --> Router Class Initialized
INFO - 2021-04-01 12:04:19 --> Output Class Initialized
INFO - 2021-04-01 12:04:20 --> Security Class Initialized
DEBUG - 2021-04-01 12:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 12:04:20 --> Input Class Initialized
INFO - 2021-04-01 12:04:20 --> Language Class Initialized
INFO - 2021-04-01 12:04:20 --> Loader Class Initialized
INFO - 2021-04-01 12:04:20 --> Helper loaded: url_helper
INFO - 2021-04-01 12:04:20 --> Helper loaded: file_helper
INFO - 2021-04-01 12:04:20 --> Helper loaded: form_helper
INFO - 2021-04-01 12:04:20 --> Helper loaded: text_helper
INFO - 2021-04-01 12:04:20 --> Helper loaded: security_helper
INFO - 2021-04-01 12:04:20 --> Helper loaded: ipaddress_helper
INFO - 2021-04-01 12:04:21 --> Database Driver Class Initialized
INFO - 2021-04-01 12:04:21 --> Email Class Initialized
DEBUG - 2021-04-01 12:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-01 12:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-01 12:04:21 --> Form Validation Class Initialized
INFO - 2021-04-01 12:04:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-04-01 12:04:21 --> Pagination Class Initialized
INFO - 2021-04-01 12:04:21 --> Controller Class Initialized
INFO - 2021-04-01 12:04:22 --> Model Class Initialized
INFO - 2021-04-01 12:04:22 --> Model Class Initialized
INFO - 2021-04-01 12:04:22 --> File loaded: C:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/head.php
INFO - 2021-04-01 12:04:22 --> File loaded: C:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/side_bar.php
INFO - 2021-04-01 12:04:22 --> File loaded: C:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/upper_header.php
INFO - 2021-04-01 12:04:22 --> File loaded: C:\xampp\htdocs\RDA_Web\adminpoint\application\views\dashboard.php
INFO - 2021-04-01 12:04:22 --> File loaded: C:\xampp\htdocs\RDA_Web\adminpoint\application\views\admin_includes/footer.php
INFO - 2021-04-01 12:04:22 --> Final output sent to browser
DEBUG - 2021-04-01 12:04:22 --> Total execution time: 3.5102
INFO - 2021-04-01 12:04:23 --> Config Class Initialized
INFO - 2021-04-01 12:04:23 --> Hooks Class Initialized
DEBUG - 2021-04-01 12:04:23 --> UTF-8 Support Enabled
INFO - 2021-04-01 12:04:23 --> Utf8 Class Initialized
INFO - 2021-04-01 12:04:23 --> URI Class Initialized
INFO - 2021-04-01 12:04:23 --> Router Class Initialized
INFO - 2021-04-01 12:04:23 --> Output Class Initialized
INFO - 2021-04-01 12:04:23 --> Security Class Initialized
DEBUG - 2021-04-01 12:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 12:04:23 --> Input Class Initialized
INFO - 2021-04-01 12:04:23 --> Language Class Initialized
ERROR - 2021-04-01 12:04:23 --> 404 Page Not Found: Js/demo
INFO - 2021-04-01 12:04:24 --> Config Class Initialized
INFO - 2021-04-01 12:04:24 --> Hooks Class Initialized
DEBUG - 2021-04-01 12:04:24 --> UTF-8 Support Enabled
INFO - 2021-04-01 12:04:24 --> Utf8 Class Initialized
INFO - 2021-04-01 12:04:24 --> URI Class Initialized
INFO - 2021-04-01 12:04:24 --> Router Class Initialized
INFO - 2021-04-01 12:04:24 --> Output Class Initialized
INFO - 2021-04-01 12:04:24 --> Security Class Initialized
DEBUG - 2021-04-01 12:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 12:04:24 --> Input Class Initialized
INFO - 2021-04-01 12:04:24 --> Language Class Initialized
ERROR - 2021-04-01 12:04:24 --> 404 Page Not Found: Skin-config2html/index
