<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-03-10 13:21:15 --> Config Class Initialized
INFO - 2021-03-10 13:21:15 --> Hooks Class Initialized
DEBUG - 2021-03-10 13:21:16 --> UTF-8 Support Enabled
INFO - 2021-03-10 13:21:16 --> Utf8 Class Initialized
INFO - 2021-03-10 13:21:16 --> URI Class Initialized
INFO - 2021-03-10 13:21:16 --> Router Class Initialized
INFO - 2021-03-10 13:21:16 --> Output Class Initialized
INFO - 2021-03-10 13:21:16 --> Security Class Initialized
DEBUG - 2021-03-10 13:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-10 13:21:16 --> Input Class Initialized
INFO - 2021-03-10 13:21:16 --> Language Class Initialized
ERROR - 2021-03-10 13:21:16 --> 404 Page Not Found: /index
INFO - 2021-03-10 13:31:39 --> Config Class Initialized
INFO - 2021-03-10 13:31:39 --> Hooks Class Initialized
DEBUG - 2021-03-10 13:31:39 --> UTF-8 Support Enabled
INFO - 2021-03-10 13:31:39 --> Utf8 Class Initialized
INFO - 2021-03-10 13:31:39 --> URI Class Initialized
DEBUG - 2021-03-10 13:31:39 --> No URI present. Default controller set.
INFO - 2021-03-10 13:31:39 --> Router Class Initialized
INFO - 2021-03-10 13:31:39 --> Output Class Initialized
INFO - 2021-03-10 13:31:40 --> Security Class Initialized
DEBUG - 2021-03-10 13:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-10 13:31:40 --> Input Class Initialized
INFO - 2021-03-10 13:31:40 --> Language Class Initialized
ERROR - 2021-03-10 13:31:40 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\RDA\adminpoint\application\controllers\AdminLoginController.php 41
ERROR - 2021-03-10 13:31:40 --> Severity: Warning --> include(C:\xampp\htdocs\RDA\adminpoint\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampp\htdocs\RDA\adminpoint\system\core\Exceptions.php 219
ERROR - 2021-03-10 13:31:40 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\RDA\adminpoint\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\RDA\adminpoint\system\core\Exceptions.php 219
